# AI Engineering Playbook — Agent Orchestration Model
> Version: 1.0 — Confirmed and Validated
> Validated against a live run: Discovery invoked → output produced → approved → halted cleanly.

---

## The Core Loop

This is the only mechanic in this playbook. Every step below follows it exactly.

```
1. YOU INVOKE a step by name
   "invoke discovery for: <problem description>"
   "invoke requirements"
   "invoke design"
   etc.

2. I EXECUTE that step only
   I do the real work for that one step — nothing before it, nothing after it.

3. I PRESENT the output and STOP
   I end my turn. I do not ask "shall I proceed?" I do not start the next step.
   I do not summarize what's coming next. I just stop and wait.

4. YOU RESPOND with exactly one of:

   a) FEEDBACK  → I revise the SAME output, present again, return to step 4.
                  Repeat as many times as needed. No limit.

   b) APPROVE   → I stop working on this step. I confirm it's closed.
                  I do NOT move to the next step myself.
                  I wait for you to invoke it by name.

   c) HALT      → I stop entirely. Nothing carries forward automatically.
                  When you return, you re-invoke whatever step you want next,
                  and I resume using whatever was last approved as context.
```

**The one rule that matters most:** I never invoke the next step myself. Approval closes a step — it does not open the next one. You always say the next step's name.

---

## The Steps

```
INVOKE DISCOVERY        → Define and evidence the problem
INVOKE REQUIREMENTS     → Draft BRD + STTM
INVOKE DESIGN           → Architecture, data model, security design
INVOKE PLAN             → Implementation plan — artifacts, sequence, risks
INVOKE BUILD            → Write the actual code / notebooks / DDL
                           (can be invoked per-layer: "invoke build bronze",
                            "invoke build silver", "invoke build gold")
INVOKE TEST             → Write and run tests, report results
INVOKE DEPLOY           → Prepare deployment artifacts and runbook
INVOKE MONITOR          → Set up monitoring, alerting, SLOs
```

You can invoke steps out of order, skip a step you don't need for a given task, or re-invoke an already-approved step later if something changes upstream — the loop is the same regardless.

---

## What Each Step Actually Produces

This is what to expect when you invoke each one — not a template, the actual thing I hand you.

| Step | What I produce |
|---|---|
| **Discovery** | Problem statement, root cause (Five Whys), affected personas, evidence level, opportunity score, recommendation. Every assumption flagged with ⚠️. |
| **Requirements** | A filled BRD (business rules, edge cases, personas, NFRs) and STTM (source-to-target mapping, every column, every transformation rule, every null-handling decision). No "TBD"s — anything unknown is flagged as a question, not guessed. |
| **Design** | Architecture decisions with alternatives considered, data model (grain, SCD type, PII classification), security threat model, NFR targets. |
| **Plan** | Exact artifacts to be created (named, not vague), sequence, risks, acceptance criteria, what's explicitly out of scope. |
| **Build** | The actual working code — DDL, notebooks, pipeline config — following whichever platform standards apply (Databricks / Fabric / Power BI / API / UI). |
| **Test** | Test results — what passed, what failed, coverage, edge cases verified against the BRD. |
| **Deploy** | Deployment runbook, rollback plan, pre-flight checklist. For anything touching production, I prepare — I don't execute. |
| **Monitor** | Dashboard spec, alert definitions, SLOs, runbooks for likely failure modes. |

---

## Worked Reference — What Just Happened

This sequence was run live and is the reference example for how the loop behaves:

```
You:  "invoke discovery for: MSA payment calculation runs on an
       18-year-old Excel model, no audit trail, cost $4.2M in a
       prior underpayment error"

Me:   [Did real research — pulled current MSA facts]
      [Produced full Discovery output: problem statement, root cause,
       personas, evidence level, opportunity score, recommendation]
      [Flagged 3 explicit assumptions needing correction]
      [Stopped]

You:  "Approved"

Me:   "Discovery is closed. I wait for you to invoke Requirements."
      [Did NOT start Requirements]

You:  "Let's halt"

Me:   "Halted. Discovery = Approved. Requirements = not invoked.
       Nothing carries forward automatically."
```

That's the whole mechanic. Every step, every scenario, behaves exactly like this.

---

## How to Use This for a New Scenario

1. Start with: **"invoke discovery for: `<describe the problem>`"**
2. Read what I produce. Give feedback until it's right, or approve it.
3. When ready, say **"invoke requirements"** — I'll use the approved Discovery as context automatically.
4. Repeat through whichever steps the task actually needs.
5. Say **"halt"** any time. Pick back up later by invoking the next step — I don't need the history re-explained if it happened in this same conversation.

---

## What This Playbook Deliberately Does NOT Include

- No templates you fill in yourself — I produce the actual output, not a form
- No checklists you have to manually work through — the review IS you reading real output and reacting
- No automatic progression — approval never triggers the next step on its own
- No reference to a 900KB standards document — that's a different artifact; this file is only the behavioral loop

---

## Using This in VS Code + GitHub Copilot

The invoke → work → stop → feedback → approve → wait loop works exactly as designed in a Claude conversation, because Claude ends its turn naturally and control returns to you. **Copilot's Agent mode does not behave the same way** — it is built to keep running until it decides the task is complete, regardless of what a markdown file instructs it to do. This is a property of the execution harness, not something a prompt can override.

> *"Unlike ask mode, agent mode doesn't stop after a single response. It continues running and refining steps until you reach the goal in your prompt or more input is required."* — Microsoft Learn, GitHub Copilot Agent Mode documentation

Agent mode does have an approval setting ("Allow All" toggle), but it governs *tool-level* permissions — should Copilot edit this file, run this command — not *phase-level* review of whether a Discovery or Requirements output is correct before moving on. Turning "Allow All" off will not recreate the loop this playbook depends on.

### The fix: match the Copilot mode to the phase

| Playbook Phase | Copilot Mode | Why |
|---|---|---|
| Discovery · Requirements · Design · Plan | **Ask mode** | Ask mode stops after every single response by design — this is the direct equivalent of how Claude behaves in this playbook. Invoke a step, read the response, give feedback or approve, invoke the next step yourself. |
| Build · Test | **Agent mode**, with "Allow All" turned **off** | Once Requirements/Design/Plan are approved, autonomous multi-file execution is appropriate — you are past the thinking phases and into implementation. Leaving "Allow All" off gives you per-file and per-command approval as a safety net during the build itself. |
| Deploy · Monitor | **Ask mode** | These steps should produce a runbook and configuration for a human to execute — not run autonomously, regardless of the tool. |

### How to actually run it

1. Set the Copilot mode dropdown to **Ask**.
2. Paste in: `invoke discovery for: <your problem>` (attach or reference this playbook file as context).
3. Read the output. Reply with feedback, or reply "approved."
4. Only when you're ready, type `invoke requirements` — Copilot will not do this on its own in Ask mode.
5. Repeat through Design and Plan the same way.
6. Once Plan is approved, switch the mode dropdown to **Agent**, with "Allow All" off, and invoke Build. Now autonomous execution with per-change approval is the right tool for the job.
7. Switch back to **Ask** mode for Deploy and Monitor — you want runbooks and configs to review, not autonomous production changes.

**The short version:** this playbook's loop is a conversational discipline, not a technical lock. In any tool where the model can be relied on to stop after one response — Claude chat, or Copilot's Ask mode — the loop works as written. In any tool built for continuous autonomous execution — Copilot's Agent mode, and equivalents in other IDEs — you have to select the non-autonomous mode for every phase except Build, where autonomy is actually what you want.
