# Source-to-Target Mapping (STTM)
> Project: MSA Payment Analytics Platform — FIN-2025-011
> BRD Version: 1.0 | STTM Version: 1.1
> Last Updated: 2025-01-21
> Approved: Robert Chen (Legal), Jennifer Park (Tax), Marcus Webb (Data)

---

## Section 1 — Source System Register

| ID | Name | Type | Connection | Secret Key | Owner |
|---|---|---|---|---|---|
| SRC-001 | SAP ERP | SQL Server | `erp-prod.company.internal:1433 / SAP_PROD` | `sap-erp-connstring` in `kv-databricks-prod` | Devon Banks (IT) |
| SRC-002 | TTB Filing Database | SQL Server | `ttb-prod.company.internal:1433 / TTB_FILINGS` | `ttb-db-connstring` in `kv-databricks-prod` | Jennifer Park (Tax) |
| SRC-003 | MSA Auditor SFTP Drop | ADLS Gen2 (Auto Loader) | `abfss://msa-auditor-drop@prodlake.dfs.core.windows.net/` | Managed Identity (no secret needed) | KPMG / David Osei |
| SRC-004 | Legal Reference SharePoint | SharePoint Online | `https://company.sharepoint.com/sites/Legal/MSA/` | `sharepoint-client-secret` in `kv-databricks-prod` | Robert Chen (Legal) |
| SRC-005 | MSA Base Volume (1997) | Databricks control table | `finance_prod.control.msa_base_volumes` | Managed Identity | Marcus Webb |

---

## Section 2 — Source-to-Target Mapping

### 2A — SAP Shipments → Bronze

> Grain: One row per SAP shipment line item as received. Append-only. No transformation.

| # | Src System | Src Table | Src Column | Src Type | Tgt Layer | Tgt Table | Tgt Column | Tgt Type | Nullable | PII | Transformation Rule | Null Handling | Validation Rule | BR Ref | EC Ref |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | SRC-001 | VBAP (Sales Doc Items) | VBELN (Delivery #) | NVARCHAR(10) | Bronze | crm_shipments | delivery_number | STRING | N | None | `TRIM(VBELN)` | Reject: 'delivery_number is null' | NOT NULL | — | — |
| 2 | SRC-001 | VBAP | POSNR (Line Item #) | NVARCHAR(6) | Bronze | crm_shipments | line_item_number | STRING | N | None | `TRIM(POSNR)` | Reject: 'line_item_number is null' | NOT NULL | — | — |
| 3 | SRC-001 | VBAP | MATNR (Material #) | NVARCHAR(18) | Bronze | crm_shipments | material_number | STRING | N | None | `LTRIM(MATNR, '0')` — remove leading zeros per SAP convention | Reject: 'material_number is null' | NOT NULL | — | EC-009 |
| 4 | SRC-001 | VBAP | KWMENG (Confirmed Qty) | DECIMAL(13,3) | Bronze | crm_shipments | quantity_confirmed | DECIMAL(15,3) | N | None | Direct copy | Reject if null | NOT NULL, > 0 | BR-002 | — |
| 5 | SRC-001 | VBAP | MEINS (Unit of Measure) | NVARCHAR(3) | Bronze | crm_shipments | unit_of_measure | STRING | N | None | `UPPER(TRIM(MEINS))` | Reject if null | NOT NULL, IN ('CS','PK','MU','LB','OZ') | BR-002, BR-003 | — |
| 6 | SRC-001 | LIKP (Delivery Header) | WADAT_IST (Act. GI Date) | DATS | Bronze | crm_shipments | goods_issue_date | DATE | N | None | `TO_DATE(WADAT_IST, 'yyyyMMdd')` — SAP stores dates as YYYYMMDD string | Reject if null | NOT NULL, between 2018-01-01 and CURRENT_DATE + 7 | BR-004 | — |
| 7 | SRC-001 | LIKP | KUNNR (Ship-To Party) | NVARCHAR(10) | Bronze | crm_shipments | customer_number | STRING | N | None | `LTRIM(KUNNR, '0')` | Reject if null | NOT NULL | — | EC-005 |
| 8 | SRC-001 | KNA1 (Customer Master) | REGIO (Region / State) | NVARCHAR(3) | Bronze | crm_shipments | destination_state_code | STRING | Y | None | Direct copy. NULL for international customers. | Pass as NULL — Silver validates and excludes non-US | Must be a valid US state code or NULL | BR-004 | EC-005 |
| 9 | SRC-001 | MARA (Material Master) | MTART (Material Type) | NVARCHAR(4) | Bronze | crm_shipments | sap_material_type | STRING | N | None | Direct copy | Reject if null | NOT NULL | BR-004 | EC-009 |
| 10 | SRC-001 | Custom Z-Table | ZTMSA_CAT (MSA Category) | NVARCHAR(10) | Bronze | crm_shipments | msa_product_category | STRING | Y | None | Direct copy from custom MSA classification table. NULL if product not yet classified. | Pass as NULL — Silver excludes unclassified items via EC-009 | IN ('CIGARETTE','RYO') or NULL | BR-004 | EC-009 |
| 11 | SRC-001 | MARA | NTGEW (Net Weight) | DECIMAL(13,3) | Bronze | crm_shipments | product_net_weight | DECIMAL(15,6) | Y | None | Direct copy | Pass as NULL — Silver checks for RYO products per EC-006 | > 0 when not null | BR-003 | EC-006 |
| 12 | SRC-001 | MARA | GEWEI (Weight Unit) | NVARCHAR(3) | Bronze | crm_shipments | weight_unit | STRING | Y | None | `UPPER(TRIM(GEWEI))` | Pass as NULL | IN ('OZ','LB','G','KG') or NULL | BR-003 | EC-006 |
| 13 | SRC-001 | VBFA (Doc Flow) | is_intercompany | BIT (derived) | Bronze | crm_shipments | is_intercompany_transfer | BOOLEAN | N | None | `CASE WHEN VBTYP_N IN ('U','UL') THEN TRUE ELSE FALSE END` — SAP doc type codes for STO/intercompany | Default FALSE if VBTYP_N is null | NOT NULL | BR-004 | — |
| 14 | — | — | — | — | Bronze | crm_shipments | _ingest_timestamp | TIMESTAMP | N | None | `current_timestamp()` | Never null | NOT NULL | — | — |
| 15 | — | — | — | — | Bronze | crm_shipments | _source_system | STRING | N | None | Literal: `'sap_erp'` | Never null | NOT NULL | — | — |
| 16 | — | — | — | — | Bronze | crm_shipments | _pipeline_run_id | STRING | N | None | From widget `p_pipeline_run_id` | Never null | NOT NULL | — | — |
| 17 | — | — | — | — | Bronze | crm_shipments | _calculation_year | INTEGER | N | None | From widget `p_calculation_year` — the MSA year being processed | Never null | NOT NULL, 4-digit year | — | — |

---

### 2B — SAP Shipments → Silver (company_cigarette_shipments)

> Grain: One row per delivery line after filtering to MSA-eligible cigarette and RYO shipments only.
> Write Mode: MERGE on (delivery_number, line_item_number, calculation_year)
> Key transformation: units normalised to cigarette equivalents.

| # | Src Layer | Src Column(s) | Tgt Table | Tgt Column | Tgt Type | Nullable | Transformation Rule | Null Handling | Validation Rule | BR Ref | EC Ref |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 18 | Bronze | delivery_number, line_item_number | company_cigarette_shipments | shipment_line_key | STRING | N | `CONCAT(delivery_number, '-', line_item_number)` — surrogate key | Never null (both parts validated in Bronze) | NOT NULL, UNIQUE within calculation_year | — | — |
| 19 | Bronze | goods_issue_date | company_cigarette_shipments | shipment_date | DATE | N | Direct copy | Never null (validated in Bronze) | NOT NULL, within calculation_year Jan 1 – Dec 31 | BR-004 | — |
| 20 | Bronze | destination_state_code | company_cigarette_shipments | destination_state | STRING | N | Validate: must be in `ref.us_states_msa_eligible` table (50 states + DC + PR, excluding GU/VI/MP per A-003). If NULL or not in list → exclude row, route to exception table | Exclude from Silver if null | NOT NULL in Silver — only eligible destinations written | BR-004 | EC-005 |
| 21 | Bronze | msa_product_category | company_cigarette_shipments | msa_product_category | STRING | N | Direct copy. If NULL → exclude, route to exception table with 'MISSING_PRODUCT_CATEGORY' | Exclude from Silver if null | NOT NULL, IN ('CIGARETTE','RYO') | BR-004 | EC-009 |
| 22 | Bronze | quantity_confirmed, unit_of_measure | company_cigarette_shipments | quantity_in_sticks | DECIMAL(18,0) | N | `CASE WHEN unit_of_measure = 'CS' THEN quantity_confirmed * 10000` (1 case = 500 packs × 20 sticks) `WHEN unit_of_measure = 'PK' THEN quantity_confirmed * 20` (1 pack = 20 sticks) `WHEN unit_of_measure = 'MU' THEN quantity_confirmed * 20` (1 master unit = 1 pack per SAP convention) `ELSE NULL END` — NULL means unknown UOM | Route to exception: 'UNKNOWN_UOM_CANNOT_CONVERT' | NOT NULL, > 0 | BR-002 | — |
| 23 | Bronze | product_net_weight, weight_unit, msa_product_category | company_cigarette_shipments | ryo_weight_oz | DECIMAL(18,6) | Y | Only populated when msa_product_category = 'RYO'. `CASE WHEN weight_unit = 'OZ' THEN product_net_weight * quantity_confirmed WHEN weight_unit = 'LB' THEN product_net_weight * quantity_confirmed * 16 WHEN weight_unit = 'G' THEN product_net_weight * quantity_confirmed / 28.3495 WHEN weight_unit = 'KG' THEN product_net_weight * quantity_confirmed * 35.274 ELSE NULL END`. NULL for non-RYO rows. | For RYO rows: route to exception 'RYO_MISSING_WEIGHT' if result is NULL | >= 0 when not null. NULL only for non-RYO rows. | BR-003 | EC-006 |
| 24 | Silver | quantity_in_sticks, ryo_weight_oz, msa_product_category | company_cigarette_shipments | cigarette_equivalent_units | DECIMAL(18,6) | N | `CASE WHEN msa_product_category = 'CIGARETTE' THEN quantity_in_sticks` (1 stick = 1 unit) `WHEN msa_product_category = 'RYO' THEN ryo_weight_oz / 0.032500` (BR-003: legal constant, 6dp) `ELSE NULL END` | Route to exception if NULL | NOT NULL, > 0 | BR-002, BR-003 | EC-006 |
| 25 | Bronze | is_intercompany_transfer | company_cigarette_shipments | is_intercompany_transfer | BOOLEAN | N | Direct copy. Rows where TRUE are excluded from RMS calculation but retained in Silver for audit completeness. The column `is_included_in_rms` flags the actual inclusion. | Never null | NOT NULL | BR-004 | — |
| 26 | Derived | is_intercompany_transfer, destination_state, msa_product_category | company_cigarette_shipments | is_included_in_rms | BOOLEAN | N | `TRUE` only when: is_intercompany_transfer = FALSE AND destination_state is MSA-eligible AND msa_product_category IN ('CIGARETTE','RYO') AND goods_issue_date within calculation_year. All other rows: FALSE. | Never null | NOT NULL | BR-004 | — |
| 27 | Bronze | _calculation_year | company_cigarette_shipments | calculation_year | INTEGER | N | Direct copy | Never null | NOT NULL, valid 4-digit year | — | — |

---

### 2C — MSA Auditor File → Bronze (auditor_industry_file)

> Grain: One row per line in the auditor's SFTP-delivered file. File format: fixed-width text, annual delivery.
> This file is the legal authoritative source for total OPM industry volume.

| # | Src System | Src Field | Src Format | Tgt Table | Tgt Column | Tgt Type | Nullable | Transformation Rule | Null Handling | Validation Rule | BR Ref | EC Ref |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 28 | SRC-003 | REPORT_YEAR | CHAR(4) | auditor_industry_file | report_year | INTEGER | N | `CAST(REPORT_YEAR AS INTEGER)` | Reject if null | NOT NULL, valid 4-digit year | BR-001 | — |
| 29 | SRC-003 | OPM_NAME | VARCHAR(100) | auditor_industry_file | opm_name | STRING | N | `TRIM(OPM_NAME)` | Reject if null | NOT NULL | BR-001 | — |
| 30 | SRC-003 | PRODUCT_TYPE | CHAR(3) | auditor_industry_file | product_type | STRING | N | `TRIM(PRODUCT_TYPE)` — values: 'CIG' = Cigarettes, 'RYO' = Roll-Your-Own | Reject if null | NOT NULL, IN ('CIG','RYO') | BR-001 | — |
| 31 | SRC-003 | UNITS_BILLIONS | DECIMAL(12,6) | auditor_industry_file | units_billions | DECIMAL(18,9) | N | Direct copy — auditor reports in billions. No rounding. Store as 9 decimal places. | Reject if null | NOT NULL, > 0, match auditor certificate checksum | BR-001 | EC-002 |
| 32 | SRC-003 | CERTIFICATION_DATE | DATE | auditor_industry_file | certification_date | DATE | N | `TO_DATE(CERTIFICATION_DATE, 'YYYY-MM-DD')` | Reject if null | NOT NULL, within expected range | BR-001 | EC-001 |
| 33 | SRC-003 | FILE_VERSION | CHAR(2) | auditor_industry_file | file_version | STRING | N | Direct copy — '01' = initial, '02' = correction, etc. | Reject if null | NOT NULL | BR-010 | EC-007 |
| 34 | — | — | — | auditor_industry_file | _ingest_timestamp | TIMESTAMP | N | `current_timestamp()` | Never null | NOT NULL | — | — |
| 35 | — | — | — | auditor_industry_file | _source_filename | STRING | N | `input_file_name()` — Auto Loader file path | Never null | NOT NULL | — | — |

---

### 2D — MSA Auditor File → Silver (auditor_industry_totals)

> Grain: One row per report_year per product_type. The key table for the RMS denominator.

| # | Src Layer | Src Column(s) | Tgt Table | Tgt Column | Tgt Type | Nullable | Transformation Rule | Null Handling | BR Ref | EC Ref |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 36 | Bronze | report_year | auditor_industry_totals | calculation_year | INTEGER | N | Direct copy | Never null | BR-001 | — |
| 37 | Bronze | units_billions (all OPMs, product_type = 'CIG') | auditor_industry_totals | total_opm_cigarette_units | DECIMAL(18,0) | N | `SUM(units_billions) * 1,000,000,000` — convert billions to individual units. Round to nearest integer. | Halt if result is null or 0 | BR-001 | EC-002 |
| 38 | Bronze | units_billions (all OPMs, product_type = 'RYO') | auditor_industry_totals | total_opm_ryo_units_oz | DECIMAL(18,6) | N | `SUM(units_billions) * 1,000,000,000` — RYO in oz-equivalent per auditor reporting convention | Pass as 0 if no RYO OPMs report | BR-001 | — |
| 39 | Derived | total_opm_ryo_units_oz | auditor_industry_totals | total_opm_ryo_cigarette_equivalent_units | DECIMAL(18,6) | N | `total_opm_ryo_units_oz / 0.032500` — same conversion factor as company RYO per BR-003 | Pass as 0 if no RYO | BR-003 | — |
| 40 | Derived | total_opm_cigarette_units + total_opm_ryo_cigarette_equivalent_units | auditor_industry_totals | total_opm_combined_equivalent_units | DECIMAL(18,6) | N | `total_opm_cigarette_units + total_opm_ryo_cigarette_equivalent_units` | Never null | BR-001 | — |
| 41 | Bronze | file_version, certification_date | auditor_industry_totals | file_version | STRING | N | Direct copy | Never null | BR-010 | EC-007 |
| 42 | Bronze | file_version | auditor_industry_totals | is_latest_version | BOOLEAN | N | `TRUE` for the highest file_version per calculation_year. Earlier versions set to FALSE. | Never null | BR-010 | EC-007 |

---

### 2E — Legal Reference Data → Silver Reference Tables

> These are annual reference updates — not daily pipelines.

| # | Src System | Src File / Table | Src Column | Tgt Table | Tgt Column | Tgt Type | Transformation Rule | Validation | BR Ref |
|---|---|---|---|---|---|---|---|---|---|
| 43 | SRC-004 | NPM_Adjustments_{YEAR}.xlsx | state_code | npm_adjustment_rates | state_code | STRING | `UPPER(TRIM(state_code))` | Must be one of 46 MSA settling states | BR-007 |
| 44 | SRC-004 | NPM_Adjustments_{YEAR}.xlsx | adjustment_rate_pct | npm_adjustment_rates | npm_adjustment_rate_pct | DECIMAL(8,6) | `CAST(adjustment_rate_pct / 100 AS DECIMAL(8,6))` — input is percentage (e.g. 12.5), store as decimal (0.125000) | 0.000000 to 1.000000 | BR-007 |
| 45 | SRC-004 | NPM_Adjustments_{YEAR}.xlsx | is_disputed | npm_adjustment_rates | is_npm_disputed | BOOLEAN | Direct copy | NOT NULL | BR-007 | EC-004 |
| 46 | SRC-004 | NPM_Adjustments_{YEAR}.xlsx | effective_year | npm_adjustment_rates | effective_year | INTEGER | Direct copy | Must match calculation_year | BR-007 |
| 47 | SRC-004 | MSA_State_Allocations.xlsx (STATIC — loaded once, never updated) | state_code | msa_state_allocations | state_code | STRING | `UPPER(TRIM(state_code))` | Must be one of 46 MSA settling states | BR-008 |
| 48 | SRC-004 | MSA_State_Allocations.xlsx | allocation_pct | msa_state_allocations | allocation_pct | DECIMAL(14,10) | `CAST(allocation_pct AS DECIMAL(14,10))` — store at 10dp: these are legal constants, no rounding | SUM of all 46 = 100.0000000000 (validate at load) | BR-008 |
| 49 | SRC-004 | Annual_Payment_Schedule.xlsx | calculation_year | msa_payment_schedule | calculation_year | INTEGER | Direct copy | Valid year | BR-009 |
| 50 | SRC-004 | Annual_Payment_Schedule.xlsx | aggregate_base_payment_usd | msa_payment_schedule | aggregate_base_payment_usd | DECIMAL(18,2) | Direct copy — provided by MSA Settlement Office | NOT NULL, > 0 | BR-009 |

---

### 2F — Gold — RMS and Payment Calculation

> Grain: One row per calculation_year per version_id.
> These tables are the output of the MSA payment computation.

| # | Src Layer | Source | Tgt Table | Tgt Column | Tgt Type | Nullable | Calculation Rule | BR Ref |
|---|---|---|---|---|---|---|---|---|
| 51 | Silver | company_cigarette_shipments | msa_rms_calculation | company_cigarette_equivalent_units | DECIMAL(18,6) | N | `SUM(cigarette_equivalent_units) WHERE is_included_in_rms = TRUE` | BR-001, BR-004 |
| 52 | Silver | auditor_industry_totals | msa_rms_calculation | total_opm_combined_equivalent_units | DECIMAL(18,6) | N | `total_opm_combined_equivalent_units WHERE is_latest_version = TRUE AND calculation_year = {year}` | BR-001 |
| 53 | Derived | rows 51, 52 | msa_rms_calculation | relative_market_share_pct | DECIMAL(14,10) | N | `(company_cigarette_equivalent_units / total_opm_combined_equivalent_units) * 100`. Store at 10dp — legal precision requirement. Never round intermediate. | BR-001 |
| 54 | Silver | auditor_industry_totals | msa_va_calculation | current_year_total_opm_units | DECIMAL(18,6) | N | `total_opm_combined_equivalent_units WHERE is_latest_version = TRUE AND calculation_year = {year}` | BR-006 |
| 55 | Control | msa_base_volumes | msa_va_calculation | base_year_1997_units | DECIMAL(18,6) | N | `units WHERE year = 1997` — NEVER recalculate, read directly from control table | BR-006 |
| 56 | Derived | rows 54, 55 | msa_va_calculation | volume_adjustment_factor | DECIMAL(14,10) | N | `MIN(1.0, POWER(current_year_total_opm_units / base_year_1997_units, 0.980000))`. Exponent = 0.980000 (6dp legal constant). Store factor at 10dp. | BR-006 |
| 57 | Silver + Gold | aggregate_base_payment × rms_pct × va_factor | msa_state_payments | gross_national_payment_usd | DECIMAL(18,4) | N | `aggregate_base_payment_usd × (relative_market_share_pct / 100) × volume_adjustment_factor` | BR-001, BR-006 |
| 58 | Derived | gross_national × state_allocation_pct | msa_state_payments | gross_state_payment_usd | DECIMAL(18,4) | N | `gross_national_payment_usd × (allocation_pct / 100)` per state | BR-008 |
| 59 | Silver + Derived | gross_state × (1 − npm_rate) | msa_state_payments | npm_adjusted_payment_usd | DECIMAL(18,4) | Y | `CASE WHEN is_npm_disputed THEN NULL ELSE gross_state_payment_usd × (1 − npm_adjustment_rate_pct) END`. NULL when disputed. | BR-007, EC-004 |
| 60 | Derived | npm_adjusted_payment_usd | msa_state_payments | payment_status | STRING | N | `CASE WHEN is_npm_disputed THEN 'NPM_DISPUTED — PAYMENT HELD' WHEN npm_adjusted_payment_usd IS NOT NULL THEN 'READY FOR PAYMENT' ELSE 'CALCULATION_INCOMPLETE' END` | BR-007 |

---

## Section 3 — Medallion Layer Summary

### Bronze Tables

| Table | Source | Grain | Write Mode | Partition |
|---|---|---|---|---|
| `crm_shipments` | SAP ERP (daily) | One row per SAP delivery line item | Append | `goods_issue_date` |
| `ttb_filing_records` | TTB DB (monthly) | One row per TTB filing line (product × state × month) | Append | `filing_month` |
| `auditor_industry_file` | MSA Auditor SFTP (annual) | One row per auditor file line | Append | `report_year` |

### Silver Tables

| Table | Source Bronze | Grain | Write Mode |
|---|---|---|---|
| `company_cigarette_shipments` | `crm_shipments` | One row per eligible shipment line (CIGARETTE or RYO, MSA-eligible state, not intercompany) | MERGE on (delivery_number, line_item_number, calculation_year) |
| `ttb_filing_summary` | `ttb_filing_records` | One row per product_category × state × calculation_year | MERGE on composite key |
| `auditor_industry_totals` | `auditor_industry_file` | One row per calculation_year per file_version | MERGE on (calculation_year, file_version) |
| `npm_adjustment_rates` | Legal SharePoint | One row per state per effective_year | MERGE on (state_code, effective_year) |

### Gold Tables

| Table | Grain | Purpose |
|---|---|---|
| `msa_rms_calculation` | One row per calculation_year per version_id | RMS and VA Factor intermediate steps |
| `msa_state_payments` | One row per state per calculation_year per version_id | Final payment per state with NPM adjustment |
| `msa_reconciliation` | One row per calculation_year | ERP vs TTB reconciliation |
| `msa_payment_schedule` | One row per calculation_year | Due dates, submission status, lock status |
| `msa_exceptions` | One row per exception event | All validation exceptions, routing, resolution status |

---

## Section 4 — Known Data Quality Issues

| # | Source | Issue | Handling |
|---|---|---|---|
| DQ-001 | SRC-001 SAP | ~2% of delivery records have REGIO (state) = blank for US domestic customers (data entry gap in customer master) | Route to exception table EC-005. Tax team resolves manually before calculation is finalised. |
| DQ-002 | SRC-001 SAP | Legacy product codes (pre-2015) do not have MSA category populated in ZTMSA_CAT | Tax team has a manual mapping table for ~150 legacy SKUs. This is loaded as a lookup override before Silver transformation. |
| DQ-003 | SRC-003 Auditor | Auditor file has historically arrived between Jan 28 and Mar 15. Exact date unpredictable. | Pipeline monitors ADLS landing zone daily. Auto Loader triggers the calculation pipeline on file arrival. |
| DQ-004 | SRC-001 SAP | ~0.3% of shipment records in SAP are marked as intercompany but the intercompany flag is set in VBTYP_N incorrectly (known SAP config issue). | Tax team has a manual exclusion list of specific delivery numbers to exclude. Loaded as a lookup in Silver before `is_included_in_rms` is set. |

---

## Section 5 — Transformation Rules Glossary

| Rule Name | Logic | Applied To |
|---|---|---|
| `STICKS_FROM_PACKS` | `quantity_confirmed * 20` where unit_of_measure = 'PK' | Bronze → Silver, cigarette unit conversion |
| `STICKS_FROM_CASES` | `quantity_confirmed * 10000` where unit_of_measure = 'CS' (500 packs × 20 sticks) | Bronze → Silver, cigarette unit conversion |
| `RYO_TO_CIGARETTE_EQUIVALENT` | `ryo_weight_oz / 0.032500` — MSA legal constant, 6 decimal places, never rounded | Silver cigarette_equivalent_units for RYO |
| `VA_FACTOR_FORMULA` | `MIN(1.0, POWER(current_year_units / 1997_base_units, 0.980000))` | Gold msa_va_calculation |
| `SAP_DATE_TO_DATE` | `TO_DATE(sap_dats_field, 'yyyyMMdd')` | All SAP DATS type fields |
| `SAP_LEADING_ZEROS` | `LTRIM(field, '0')` | SAP material number and customer number fields |

---

## Section 6 — STTM Sign-Off

| Role | Name | Date | Notes |
|---|---|---|---|
| Legal Sponsor | Robert Chen | 2025-01-20 | Confirmed BR-001, BR-003, BR-006, BR-008 legal constants. Confirmed A-003 (Puerto Rico / DC included). |
| Tax Analyst | Jennifer Park | 2025-01-21 | Confirmed SAP field mappings and TTB reconciliation logic. Confirmed DQ-001 to DQ-004. |
| Data Engineering | Marcus Webb | 2025-01-21 | Reviewed all transformation rules. Confirmed SRC-005 base volume constant = 667,754,000,000. |
