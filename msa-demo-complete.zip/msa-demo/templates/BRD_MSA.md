# Business Requirements Document (BRD)
> Project: Master Settlement Agreement (MSA) Payment Analytics Platform
> Version: 1.0 | Status: Approved
> Last Updated: 2025-01-20
> BRD Owner: Patricia Lawson — VP Finance & Tax Compliance

---

## 1. Project Overview

| Field | Value |
|---|---|
| Project Name | MSA Payment Analytics Platform |
| Project Code | FIN-2025-011 |
| Business Owner | Patricia Lawson — VP Finance & Tax Compliance |
| Data Owner | Marcus Webb — Director, Data Engineering |
| Legal Sponsor | Robert Chen — SVP & General Counsel |
| Requested By | Patricia Lawson |
| Target Go-Live | 2025-06-30 (before FY2025 annual calculation cycle begins) |
| Priority | Critical — Legal & Financial Obligation |

### 1.1 Business Objective

The company is obligated under the 1998 Master Settlement Agreement to make annual payments to 46 Settling States in perpetuity, calculated on the basis of Relative Market Share of cigarette shipments. The current payment calculation is performed in a Microsoft Excel model built in 2007 and maintained by two individuals in the Finance Tax team. The model has no version control, no audit trail, no automated data validation, and has produced three calculation errors in the last five years — one of which resulted in a $4.2M underpayment and a corrective filing with the Independent Auditor.

This project will replace the Excel model with an automated, auditable, end-to-end MSA payment calculation platform built on Databricks and surfaced in Power BI. The platform must produce payment figures that are reproducible, fully traceable to source data, and defensible in an arbitration proceeding. Every intermediate calculation step must be stored — not just the final payment number.

### 1.2 Success Criteria

- Annual MSA payment calculation completed within 5 business days of receiving the MSA Auditor's certified industry volume file (currently takes 6 weeks)
- Zero manual data entry in the payment calculation — all inputs sourced from validated data pipelines
- Full audit trail: any payment figure can be traced back to the source shipment record that contributed to it
- Prior year restatements can be replayed automatically without rebuilding the Excel model
- Independent Auditor can access a read-only view of the calculation methodology and intermediate steps for verification
- Zero underpayment or overpayment errors attributable to data processing — all variances traceable to source data issues

---

## 2. Stakeholders and Personas

| Persona | Role | What They Need |
|---|---|---|
| Patricia Lawson | VP Finance & Tax Compliance | Final payment figures per state, variance to prior year, executive summary for Board |
| Robert Chen | SVP & General Counsel | Legal defensibility of calculation — full audit trail, ability to produce calculation records for arbitration |
| Jennifer Park | Senior Tax Analyst | Day-to-day calculation monitoring, exception handling, corrective filing preparation |
| David Osei | External Independent Auditor (KPMG) | Read-only access to verify calculation methodology and intermediate steps |
| Marcus Webb | Director, Data Engineering | Technical ownership of the platform |
| State Attorneys General (46 states) | Regulatory recipients | Accurate on-time payment and supporting documentation |

---

## 3. Source Systems

| # | System Name | Type | Owner | Access Method | Refresh |
|---|---|---|---|---|---|
| SRC-001 | SAP ERP (Shipments) | SQL Server via SAP connector | IT — Devon Banks | JDBC, Databricks secret scope: `sap-erp-connstring` | Daily — reflects prior day shipments by 06:00 UTC |
| SRC-002 | TTB Federal Filing System | Internal SQL database (Tax team maintains) | Jennifer Park | JDBC, secret scope: `ttb-db-connstring` | Monthly — updated when federal excise tax filings are submitted |
| SRC-003 | MSA Auditor Annual Data File | Secure file delivery (SFTP → ADLS) | KPMG (David Osei) | Auto Loader from ADLS container: `msa-auditor-drop` | Annual — arrives approximately 6–8 weeks after December 31 year-end |
| SRC-004 | Legal Reference Data | SharePoint — maintained by Robert Chen's team | Legal (Robert Chen) | SharePoint API, secret scope: `sharepoint-client-secret` | Annual — updated in January each year; mid-year updates only for NPM dispute resolutions |
| SRC-005 | Historical Volume Database (1997 Base) | Static SQL table — loaded once | Marcus Webb | JDBC, maintained in `finance_prod.control.msa_base_volumes` | Static — never changes (legal constant from 1997 calendar year) |

### 3.1 Data Volume

| Source | Row Count | Notes |
|---|---|---|
| SAP Shipments (annual) | ~850,000 shipment records | Each record = one product line on one shipping document to one customer |
| TTB Filing Records (annual) | ~12,000 records | Aggregated monthly by product category × state |
| MSA Auditor File (annual) | ~250 rows | Total OPM industry volumes by product category |
| NPM Adjustment Rates | 46 rows | One per settling state, updated annually |
| MSA State Allocation Table | 46 rows | Legal constants — fixed since 1998 |

---

## 4. Business Rules

| Rule ID | Business Rule | Source Field(s) | Target Field | Owner |
|---|---|---|---|---|
| BR-001 | **Relative Market Share (RMS)**: RMS = Company Cigarette Equivalent Units Shipped to US ÷ Total OPM Cigarette Equivalent Units Shipped to US × 100. The denominator is sourced EXCLUSIVELY from the MSA Auditor's certified annual data file (SRC-003). The company's own ERP data is NEVER used as the denominator. If the Auditor file has not yet been received for the calculation year, the calculation CANNOT proceed — no proxy or estimate is permitted. | `silver.company_shipments.cigarette_equivalent_units`, `silver.auditor_industry_totals.total_opm_units` | `gold.msa_rms_calculation.relative_market_share_pct` | Robert Chen |
| BR-002 | **Cigarette Equivalent Units — Cigarettes**: Standard cigarettes count as 1 unit each. A standard pack = 20 units. A carton = 200 units. The count is based on individual cigarette sticks shipped, not packs or cartons. Sourced from SAP at the individual stick level by multiplying pack count × 20. | `sap.shipments.packs_shipped` | `silver.company_shipments.cigarette_units` | Jennifer Park |
| BR-003 | **Cigarette Equivalent Units — Roll-Your-Own (RYO)**: Per MSA Section II(nn), 0.0325 ounces of roll-your-own tobacco = 1 cigarette equivalent. This conversion factor is a legal constant and must be stored as DECIMAL(10,6) = 0.032500 with no rounding. RYO ounces are sourced from SAP product weight field. | `sap.shipments.product_net_weight_oz` where `product_category = 'RYO'` | `silver.company_shipments.ryo_cigarette_equivalent_units` | Robert Chen |
| BR-004 | **Units Included in RMS Calculation**: Only include shipments where: (a) destination state is one of the 50 US states, DC, or Puerto Rico; (b) product category is 'CIGARETTE' or 'RYO'; (c) `is_intercompany_transfer = FALSE`; (d) shipment date falls within the January 1 – December 31 calendar year being calculated. Shipments to Guam, USVI, and other territories are EXCLUDED from the MSA RMS calculation even though they may appear in TTB filings. | `sap.shipments.*` | `silver.company_shipments.is_included_in_rms` | Jennifer Park |
| BR-005 | **ERP to TTB Reconciliation**: Before using shipment data in the RMS calculation, company cigarette units from SAP (SRC-001) must be reconciled against TTB federal filing data (SRC-002). The variance must be < 0.5% at the national level. If variance is ≥ 0.5%, the calculation is HALTED and a reconciliation exception is raised for Jennifer Park's manual review. The TTB filing is the legally submitted figure; SAP is operational. If they differ, the cause must be identified before proceeding. | `silver.company_shipments.cigarette_units` vs `silver.ttb_filings.cigarette_units_reported` | `gold.msa_reconciliation.erp_vs_ttb_variance_pct` | Jennifer Park |
| BR-006 | **Volume Adjustment (VA) Factor**: The VA factor reduces the aggregate OPM payment obligation when total industry volume falls below the 1997 calendar year base volume. Formula per MSA Section IX(d)(1): `VA_Factor = MIN(1.0, (Current Year Total OPM Units / 1997 Base Year Total OPM Units) ^ 0.98)`. The exponent 0.98 is a legal constant and must be stored and applied as DECIMAL(8,6) = 0.980000. The 1997 Base Year Total OPM Units is a legal constant stored in SRC-005 and must NEVER be updated or recalculated. | `silver.auditor_industry_totals.total_opm_units` (current year), `control.msa_base_volumes.base_year_1997_units` | `gold.msa_va_calculation.volume_adjustment_factor` | Robert Chen |
| BR-007 | **NPM Adjustment**: Each settling state may receive a reduced payment from the manufacturer if the state did not "diligently enforce" its Qualifying Statute during the year (which requires Non-Participating Manufacturers to make escrow payments). The NPM adjustment rate per state is determined by the legal team and received annually from counsel. The rate is expressed as a percentage reduction (0.00% to 100.00%) applied to that state's gross allocated payment. A state with a disputed NPM adjustment must have its payment held and flagged as 'NPM_DISPUTED — PAYMENT HELD'. | `legal.npm_adjustment_rates.adjustment_rate_pct` per `state_code` | `gold.msa_state_payments.npm_adjusted_payment_usd` | Robert Chen |
| BR-008 | **State Allocation Percentages**: After calculating the national payment obligation, it is allocated to each of the 46 Settling States according to fixed percentage allocations defined in Exhibit A of the MSA. These percentages are legal constants that have not changed since 1998 and must not be calculated, estimated, or derived. They must be stored in a reference table and treated as read-only. The 4 states that settled separately (Mississippi, Florida, Texas, Minnesota) are NOT Settling States and do NOT receive payments under this calculation. | `ref.msa_state_allocations.allocation_pct` | `gold.msa_state_payments.state_allocation_pct` | Robert Chen |
| BR-009 | **Payment Due Date**: The annual MSA payment is due on April 15 of the year following the calculation year (e.g., the FY2025 payment is due April 15, 2026). If April 15 falls on a weekend or federal holiday, the payment is due the next business day. Late payments accrue interest at the rate specified in Section IX(c) of the MSA. The platform must track: calculation completion date, payment submission date, and whether payment was made before or after the due date. | `gold.msa_payment_schedule.due_date` | `gold.msa_payment_schedule.payment_status` | Patricia Lawson |
| BR-010 | **Prior Year True-Up**: When the MSA Auditor issues a corrected or restated industry volume figure for a prior year, the company must recalculate its payment for that year and submit a corrective payment or receive a credit. The platform must support recalculation for any prior year (minimum: 7 years back) using the corrected auditor data while preserving the original calculation as a separate version. True-up amounts must be presented separately from current year obligations. | `silver.auditor_industry_totals.*` (versioned) | `gold.msa_true_up.corrective_payment_usd` | Patricia Lawson |
| BR-011 | **Calculation Freeze**: Once the annual MSA payment has been submitted to the Settling States, the calculation for that year is frozen. No changes to source data (ERP, TTB) for the submitted year are permitted to alter the submitted figures. A separate 'restatement' calculation can be run but is clearly labelled as a restatement and does not overwrite the submitted calculation. | `gold.msa_calculation_versions.is_submitted` | `gold.msa_calculation_versions.lock_status` | Robert Chen |

---

## 5. KPIs and Metrics Required

| Metric | Definition | Calculation | Consumer |
|---|---|---|---|
| Relative Market Share % | Company's share of total OPM cigarette shipments | Company Units ÷ Total OPM Units × 100 | Executive dashboard, Legal |
| RMS vs Prior Year (pp) | Change in market share percentage points | Current RMS% − Prior Year RMS% | Patricia Lawson |
| Gross National Payment ($) | Pre-adjustment national payment obligation | Base Annual Amount × RMS% × VA Factor | Finance |
| NPM Adjustment Total ($) | Total payment reduction from NPM adjustments | SUM(state NPM adjustment amounts) | Legal |
| Net National Payment ($) | Final payment obligation after all adjustments | Gross − NPM Adjustments − Other Adjustments | Patricia Lawson, Board |
| Payment by State ($) | Individual state payment amounts | Net Payment × State Allocation % × (1 − NPM Rate) | Finance, Legal |
| ERP vs TTB Variance % | Reconciliation between internal and TTB-filed units | ABS(ERP Units − TTB Units) ÷ TTB Units × 100 | Jennifer Park |
| Days to Calculation Complete | Operational KPI — from auditor file receipt to final figures | DATE(calculation complete) − DATE(auditor file received) | Marcus Webb |

---

## 6. Edge Cases and Exception Handling

| # | Scenario | Expected Behaviour | Rule Ref |
|---|---|---|---|
| EC-001 | MSA Auditor file has NOT arrived by February 15 (6 weeks after year-end) | Send automated reminder email to David Osei (KPMG) and Patricia Lawson. Pipeline remains in 'AWAITING_AUDITOR_FILE' status. Do NOT use prior year totals as proxy. Do NOT estimate. | BR-001 |
| EC-002 | MSA Auditor file arrives but total OPM units differ from the Preliminary Estimate (received in January) by more than 2% | Flag as 'AUDITOR_VOLUME_VARIANCE — REVIEW REQUIRED'. Notify Robert Chen and Jennifer Park. Do not auto-proceed — wait for manual confirmation from Jennifer Park before running the RMS calculation. | BR-001 |
| EC-003 | ERP vs TTB reconciliation variance is ≥ 0.5% at national level | HALT calculation. Create a reconciliation exception record. Email Jennifer Park with: ERP total, TTB total, variance amount, variance %, and list of the top 10 product-state combinations contributing most to the variance. Do not proceed until Jennifer Park manually approves continuation or uploads a corrected file. | BR-005 |
| EC-004 | An NPM adjustment rate for a state is marked as 'DISPUTED' by the Legal team | Set that state's payment status to 'NPM_DISPUTED — PAYMENT HELD'. Calculate and display the state's payment at both 0% adjustment and at the disputed rate, labelled clearly. Include in executive report as a contingent liability. Exclude from the wire transfer instruction until dispute resolved. | BR-007 |
| EC-005 | A shipment record in SAP has `destination_state` = NULL | Exclude from all MSA calculations. Route to exception table with `error_category = 'MISSING_DESTINATION_STATE'`. Notify Jennifer Park — these shipments must be resolved (state identified) before the year is closed. If unresolved at calculation time, document as known exclusion in the audit package. | BR-004 |
| EC-006 | A product in SAP is categorised as 'RYO' but the `product_net_weight_oz` field is NULL | Exclude from RMS calculation. Route to exception table with `error_category = 'RYO_MISSING_WEIGHT'`. These shipments CANNOT be converted to cigarette equivalents without the weight — they are not excluded from MSA scope, they are unresolvable until the product master is corrected. Notify Jennifer Park daily until resolved. | BR-003 |
| EC-007 | The auditor issues a corrected file for a prior year (e.g., FY2023 restated in March 2025) | Create a new version of the FY2023 calculation using the corrected file. Preserve the original submitted calculation as version 1. Present the true-up amount as a separate line item. Do NOT overwrite the submitted figures. Tag the new version as 'RESTATEMENT — PENDING REVIEW'. | BR-010 |
| EC-008 | April 15 payment due date falls on a Saturday | Payment due date shifts to Monday April 17. This must be calculated dynamically using a US federal holiday calendar, not hardcoded. If April 17 is also a federal holiday (e.g., Tax Day conflicts), continue shifting forward one business day at a time until a business day is reached. | BR-009 |
| EC-009 | A new product is launched and does not have a `product_category` mapping in the SAP product master | Do NOT assume product category. Exclude from all calculations. Route to exception table with `error_category = 'MISSING_PRODUCT_CATEGORY'`. Alert Jennifer Park with product details. This is critical — a misclassified product could either inflate or deflate the RMS calculation. | BR-004 |
| EC-010 | The calculation has been submitted and a minor ERP data correction arrives (< 0.1% impact) | The submitted calculation is FROZEN and cannot be altered (BR-011). The correction is logged as a 'POST-SUBMISSION DATA CORRECTION' record. Legal team decides whether to file a voluntary amendment — the platform presents the amendment amount but does NOT automatically trigger one. | BR-011 |

---

## 7. Non-Functional Requirements

| Requirement | Value |
|---|---|
| Calculation turnaround | Final payment figures within 5 business days of Auditor file receipt |
| Audit trail | Every source record contributing to the final payment must be traceable end-to-end. Minimum 7 years of historical calculation versions retained. |
| Security classification | Highly Confidential — MSA payment amounts, market share data, and competitor industry volumes are commercially sensitive and legally privileged |
| Access control | Finance Tax team: full access. Legal: read-only on final figures + audit trail. Independent Auditor (KPMG): read-only on calculation steps and methodology. No business unit access to competitor volume data. |
| Reproducibility | Running the calculation twice with identical inputs must produce identical outputs to 6 decimal places |
| Environments | Dev, UAT, Prod — separate Databricks workspaces. Prod calculation figures are legally significant. |
| PII | No PII involved — all data is at shipment/product/state level |
| Arbitration readiness | Platform must be able to produce a formatted calculation package (PDF or Excel export) suitable for submission to arbitration panel within 2 business days of request |

---

## 8. Assumptions and Open Questions

| # | Item | Raised By | Status |
|---|---|---|---|
| A-001 | The 1997 base year total OPM volume (used in VA Factor calculation) is sourced from the MSA Auditor's historical records and has been agreed with Legal as a fixed constant: 667,754,000,000 cigarette equivalent units. | Robert Chen | Confirmed 2025-01-15 |
| A-002 | The aggregate base annual payment amount for the current calculation year is provided by the MSA Settlement Office and is a given input to the platform — the platform does NOT calculate the aggregate from scratch, only allocates it. | Patricia Lawson | Confirmed 2025-01-16 |
| A-003 | Shipments to Puerto Rico and DC are INCLUDED in the MSA RMS calculation per the MSA definition of "United States." Shipments to Guam, USVI, and Northern Mariana Islands are EXCLUDED. | Robert Chen | Confirmed 2025-01-15 |
| A-004 | The four states that settled separately (Mississippi, Florida, Texas, Minnesota) are excluded from the MSA allocation. Their payments are handled through separate legal agreements and are out of scope for this platform. | Robert Chen | Confirmed 2025-01-15 |
| Q-001 | Should the platform also calculate payments for the four separate state settlements (MS, FL, TX, MN)? They use similar but not identical formulas. | Patricia Lawson | OPEN — decision needed by 2025-02-01 |
| Q-002 | The platform will produce wire transfer instructions. Should it also submit those instructions directly to the bank, or produce a file for manual upload by the Treasury team? | Patricia Lawson | OPEN — Treasury team to confirm |

---

## 9. Approvals

| Role | Name | Date | Status |
|---|---|---|---|
| Business Owner | Patricia Lawson | 2025-01-18 | ✓ Approved |
| Legal Sponsor | Robert Chen | 2025-01-18 | ✓ Approved |
| Data Owner | Marcus Webb | 2025-01-19 | ✓ Approved |
