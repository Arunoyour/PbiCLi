# Generated Output — Work Items (Jira-Style Tasks)
> Generated from: USER_STORIES_MSA.md
> Project: MSA Payment Analytics Platform — FIN-2025-011
> Generated: 2025-01-22

---

## Work Item Sequence — US-001 (SAP Bronze Ingestion)

```
┌─────────────────────────────────────────────────────────────────┐
│ WORK ITEM ID:   WI-001                                          │
│ USER STORY:     US-001 — Ingest SAP Shipments to Bronze         │
│ TITLE:          Create Bronze DDL for finance_prod.bronze.       │
│                 crm_shipments                                    │
│ TYPE:           DDL                                             │
│ PLATFORM:       Databricks                                      │
│ ESTIMATED:      S (2 hours)                                     │
└─────────────────────────────────────────────────────────────────┘

DESCRIPTION
────────────────
Create the Delta table DDL for the Bronze landing table for SAP
shipment records. This table is append-only and stores the raw
SAP data exactly as extracted. Schema is based on STTM rows 1–17.

EXACT DELIVERABLE
──────────────────
  Artifact:   setup_bronze_crm_shipments.sql
  Location:   /sql/bronze/setup_bronze_crm_shipments.sql
  Playbook:   databricks-standards/unity-catalog.md

TECHNICAL SPECIFICATION
────────────────────────
  Catalog:    {p_catalog} widget — confirm from workspace.config.md
  Schema:     bronze
  Table:      crm_shipments
  Full path:  {catalog}.bronze.crm_shipments
  Grain:      One row per SAP delivery line per pipeline run (append)

  Columns (from STTM rows 1–17):
    delivery_number         STRING      NOT NULL   -- STTM row 1
    line_item_number        STRING      NOT NULL   -- STTM row 2
    material_number         STRING      NOT NULL   -- STTM row 3: leading zeros removed
    quantity_confirmed      DECIMAL(15,3) NOT NULL -- STTM row 4
    unit_of_measure         STRING      NOT NULL   -- STTM row 5: UPPER(TRIM())
    goods_issue_date        DATE        NOT NULL   -- STTM row 6: SAP DATS converted
    customer_number         STRING      NOT NULL   -- STTM row 7
    destination_state_code  STRING      NULL       -- STTM row 8: nullable (EC-005)
    sap_material_type       STRING      NOT NULL   -- STTM row 9
    msa_product_category    STRING      NULL       -- STTM row 10: nullable (EC-009)
    product_net_weight      DECIMAL(15,6) NULL     -- STTM row 11: nullable (EC-006)
    weight_unit             STRING      NULL       -- STTM row 12: nullable
    is_intercompany_transfer BOOLEAN    NOT NULL   -- STTM row 13: derived
    _ingest_timestamp       TIMESTAMP   NOT NULL   -- STTM row 14: system
    _source_system          STRING      NOT NULL   -- STTM row 15: = 'sap_erp'
    _pipeline_run_id        STRING      NOT NULL   -- STTM row 16: from widget
    _calculation_year       INTEGER     NOT NULL   -- STTM row 17: from widget

  TBLPROPERTIES:
    layer           = 'bronze'
    domain          = 'finance_tax'
    source_system   = 'sap_erp'
    owner           = 'finance-data-team'
    pii             = 'false'
    description     = 'Raw SAP ERP shipment lines for MSA calculation.
                       Append-only. No transformation applied at Bronze.'
  Partition:    goods_issue_date
  OPTIMIZE:     Not applied to Bronze

STTM ROWS IMPLEMENTED:   1–17

COMPLETION CRITERIA
─────────────────────────────────────────────────────────────────
  - [ ] DDL runs without error in {catalog_dev}.bronze
  - [ ] All 17 columns exist with correct types
  - [ ] Table is partitioned by goods_issue_date
  - [ ] TBLPROPERTIES verified via DESCRIBE EXTENDED
  - [ ] Reviewed by Marcus Webb


┌─────────────────────────────────────────────────────────────────┐
│ WORK ITEM ID:   WI-002                                          │
│ USER STORY:     US-001 — Ingest SAP Shipments to Bronze         │
│ TITLE:          Build Bronze Ingestion Notebook for SAP          │
│                 Shipments (nb_bronze_msa_sap_shipments)          │
│ TYPE:           Notebook                                        │
│ PLATFORM:       Databricks                                      │
│ ESTIMATED:      L (8 hours)                                     │
└─────────────────────────────────────────────────────────────────┘

DESCRIPTION
────────────────
Build the PySpark notebook that extracts SAP shipment data via
JDBC, applies Bronze-level field transformations (date format
conversion, leading zero removal, intercompany flag derivation),
and appends to the Bronze table. Follows the 8-cell notebook
standard from databricks-standards/notebooks.md.

EXACT DELIVERABLE
──────────────────
  Artifact:   nb_bronze_msa_sap_shipments.py
  Location:   /src/bronze/nb_bronze_msa_sap_shipments.py
  Playbook:   databricks-standards/notebooks.md (8-cell)
              databricks-standards/delta.md (Bronze write pattern)

TECHNICAL SPECIFICATION
────────────────────────
  Source:       SRC-001 SAP ERP via JDBC
                Connection: dbutils.secrets.get('kv-databricks-prod',
                            'sap-erp-connstring')
  Target:       {catalog}.bronze.crm_shipments
  Write mode:   Append only — Bronze cardinal rule

  Widget params (Cell 3):
    p_catalog           (REQUIRED — no default)
    p_calculation_year  (REQUIRED — 4-digit integer)
    p_run_mode          ('incremental' default)
    p_start_date        (empty = use watermark from pipeline_watermarks)
    p_end_date          (empty = current UTC)
    p_pipeline_run_id   (empty = generate UUID)

  SAP extraction query (Cell 6 — Extract):
    SELECT VBAP.VBELN, VBAP.POSNR, LTRIM(VBAP.MATNR,'0') AS MATNR,
           VBAP.KWMENG, VBAP.MEINS,
           TO_DATE(LIKP.WADAT_IST,'yyyyMMdd') AS goods_issue_date,
           LTRIM(LIKP.KUNNR,'0') AS KUNNR,
           KNA1.REGIO,
           MARA.MTART, MARA.NTGEW, MARA.GEWEI,
           ZTMSA.ZTMSA_CAT,
           CASE WHEN VBFA.VBTYP_N IN ('U','UL') THEN TRUE ELSE FALSE END
             AS is_intercompany_transfer
    FROM   VBAP
    JOIN   LIKP ON VBAP.VBELN = LIKP.VBELN
    JOIN   MARA ON VBAP.MATNR = MARA.MATNR
    LEFT JOIN KNA1 ON LIKP.KUNNR = KNA1.KUNNR
    LEFT JOIN ZTMSA_CAT ZTMSA ON VBAP.MATNR = ZTMSA.MATNR
    LEFT JOIN VBFA ON VBAP.VBELN = VBFA.VBELV
    WHERE  LIKP.WADAT_IST >= '{start_date}'
    AND    LIKP.WADAT_IST <  '{end_date}'

  Transformations (Cell 6 — Transform):
    - Add metadata: _ingest_timestamp, _source_system='sap_erp',
                    _pipeline_run_id, _calculation_year
    - Validate NOT NULL on: delivery_number, line_item_number,
                             material_number, quantity_confirmed,
                             unit_of_measure, goods_issue_date,
                             customer_number, sap_material_type,
                             is_intercompany_transfer
    - Route NULL violations to {catalog}.control.msa_exceptions

  Write (Cell 6 — Load):
    df.write.format("delta").mode("append")
      .partitionBy("goods_issue_date")
      .option("mergeSchema","true")
      .saveAsTable(f"{catalog}.bronze.crm_shipments")

  Cell 7 — Optimization: NO OPTIMIZE on Bronze (policy)
  Cell 8 — Log success/failure to {catalog}.control.pipeline_run_log
           Update watermark ONLY on success

STTM ROWS IMPLEMENTED:   1–17
ACs SATISFIED:           AC-01 through AC-05, AC-EC-01, AC-EC-03

COMPLETION CRITERIA
─────────────────────────────────────────────────────────────────
  - [ ] Notebook runs end-to-end in DEV with 1,000 test SAP records
  - [ ] Date conversion verified: '20250115' → DATE '2025-01-15'
  - [ ] Leading zero removal verified on 3 test material numbers
  - [ ] Intercompany flag: U/UL → TRUE, J → FALSE (3 test cases each)
  - [ ] NULL delivery_number → exception table (confirmed in DEV)
  - [ ] Re-run test: second run for same date window adds 0 rows to Bronze
  - [ ] Pipeline run log populated: status, rows_extracted, rows_loaded


┌─────────────────────────────────────────────────────────────────┐
│ WORK ITEM ID:   WI-003                                          │
│ USER STORY:     US-001 — Ingest SAP Shipments to Bronze         │
│ TITLE:          Create Databricks Workflow Job for Bronze        │
│                 SAP Ingestion (job_msa_bronze_sap)               │
│ TYPE:           Config (DABs YAML)                              │
│ PLATFORM:       Databricks                                      │
│ ESTIMATED:      S (2 hours)                                     │
└─────────────────────────────────────────────────────────────────┘

EXACT DELIVERABLE
──────────────────
  Artifact:   job_msa_bronze_sap.yml
  Location:   /jobs/job_msa_bronze_sap.yml
  Playbook:   databricks-standards/workflows.md

TECHNICAL SPECIFICATION
────────────────────────
  Job name:             job_msa_bronze_sap
  Schedule:             Daily at 07:00 UTC (after SAP batch closes)
  max_concurrent_runs:  1
  Spark version:        Confirm from workspace.config.md
  Cluster:              job_cluster (NOT all-purpose cluster)
  data_security_mode:   SINGLE_USER (Unity Catalog requirement)

  Job parameters:
    p_catalog:          {from DABs target config — dev/prod}
    p_calculation_year: {current year — derived at runtime}
    p_run_mode:         'incremental'
    p_pipeline_run_id:  {{job.run_id}}

  Tasks:
    task_bronze_sap:     nb_bronze_msa_sap_shipments
    task_notify_failure: nb_shared_utils_notify_failure
                         (depends_on: task_bronze_sap, outcome: FAILED)

  Notifications:
    on_failure: data-team-alerts@company.com,
                jennifer.park@company.com (Tax team must know)
    Teams webhook: from workspace.config.md

COMPLETION CRITERIA
─────────────────────────────────────────────────────────────────
  - [ ] Job runs successfully in DEV triggered manually
  - [ ] Failure notification received within 2 minutes of
        simulated notebook failure
  - [ ] max_concurrent_runs=1 verified (second trigger during run
        is queued, not started in parallel)
```

---

## Work Item Sequence — US-004 (RMS Calculation)

```
┌─────────────────────────────────────────────────────────────────┐
│ WORK ITEM ID:   WI-012                                          │
│ USER STORY:     US-004 — Calculate RMS and VA Factor            │
│ TITLE:          Build Gold RMS Calculation Notebook              │
│                 (nb_gold_msa_rms_calculation)                    │
│ TYPE:           Notebook                                        │
│ PLATFORM:       Databricks                                      │
│ ESTIMATED:      XL (16 hours)                                   │
└─────────────────────────────────────────────────────────────────┘

DESCRIPTION
────────────────
This is the highest-risk notebook in the platform — it implements
the legal formula that determines the company's MSA payment
obligation. Every constant (0.032500, 0.980000, 667,754,000,000)
must be stored as a named, documented Decimal literal. No magic
numbers. Every intermediate step stored in Gold for audit.

EXACT DELIVERABLE
──────────────────
  Artifact:   nb_gold_msa_rms_calculation.py
  Location:   /src/gold/nb_gold_msa_rms_calculation.py
  Playbook:   databricks-standards/notebooks.md (8-cell)
              databricks-standards/delta.md (Gold write pattern)

TECHNICAL SPECIFICATION
────────────────────────
  Source tables:
    {catalog}.silver.company_cigarette_shipments  (STTM row 51)
    {catalog}.silver.auditor_industry_totals      (STTM row 52)
    {catalog}.control.msa_base_volumes            (STTM row 55)
    {catalog}.control.msa_payment_schedule        (for pre-conditions)
    {catalog}.control.msa_reconciliation          (reconciliation gate)

  Target tables:
    {catalog}.gold.msa_rms_calculation
    {catalog}.gold.msa_va_calculation

  Widget params (Cell 3):
    p_catalog           (REQUIRED)
    p_calculation_year  (REQUIRED)
    p_version_id        (UUID — new calculation version)
    p_pipeline_run_id   (from Workflow job.run_id)

  Cell 4 — Pre-Condition Checks (MUST ALL PASS before Cell 6):

    CHECK 1: Auditor file received and approved
    ─────────────────────────────────────────────
    auditor_status = spark.sql(f"""
        SELECT calculation_status
        FROM {catalog}.control.msa_payment_schedule
        WHERE calculation_year = {p_calculation_year}
    """).collect()[0][0]

    if auditor_status != 'AUDITOR_FILE_APPROVED':
        raise RuntimeError(f"CALCULATION_BLOCKED: Auditor file status is "
                           f"'{auditor_status}' — must be AUDITOR_FILE_APPROVED")

    CHECK 2: ERP-TTB reconciliation cleared
    ────────────────────────────────────────
    recon_status = spark.sql(f"""
        SELECT reconciliation_status
        FROM {catalog}.gold.msa_reconciliation
        WHERE calculation_year = {p_calculation_year}
    """).collect()[0][0]

    if recon_status != 'CLEARED':
        raise RuntimeError(f"CALCULATION_BLOCKED: ERP-TTB reconciliation "
                           f"status is '{recon_status}' — must be CLEARED")

    CHECK 3: No prior submitted calculation for this year
    ──────────────────────────────────────────────────────
    (Allows calculation to run only if no frozen version exists,
     or if explicitly running a restatement version)

  Cell 5 — Legal Constants (named, documented, NEVER variables):
    RYO_CONVERSION_FACTOR = Decimal('0.032500')  # MSA Section II(nn)
    VA_EXPONENT           = Decimal('0.980000')  # MSA Section IX(d)(1)
    BASE_YEAR_1997_UNITS  = Decimal('667754000000')  # BRD A-001, confirmed Legal

  Cell 6 — RMS Calculation (Spark SQL for auditability):

    -- Step 1: Company cigarette equivalent units (STTM row 51)
    company_units = spark.sql(f"""
        SELECT
            SUM(cigarette_equivalent_units) AS company_cigarette_equivalent_units,
            COUNT(*) AS eligible_shipment_line_count
        FROM {catalog}.silver.company_cigarette_shipments
        WHERE is_included_in_rms = TRUE
        AND   calculation_year   = {p_calculation_year}
    """)

    -- Step 2: Total OPM units from auditor (STTM row 52)
    -- MUST use is_latest_version = TRUE ONLY
    opm_units = spark.sql(f"""
        SELECT total_opm_combined_equivalent_units,
               file_version,
               certification_date
        FROM {catalog}.silver.auditor_industry_totals
        WHERE calculation_year   = {p_calculation_year}
        AND   is_latest_version  = TRUE
    """)

    -- Step 3: RMS formula (STTM row 53)
    -- All intermediate values stored — nothing discarded
    rms_pct = (company_units / opm_units) * 100
    -- Store at 10 decimal places: DECIMAL(14,10)

    -- Step 4: VA Factor (STTM rows 54–56)
    -- base_year_1997_units read from control table (read-only)
    base_1997 = spark.sql(f"""
        SELECT units FROM {catalog}.control.msa_base_volumes
        WHERE year = 1997
    """).collect()[0][0]

    raw_ratio  = opm_units / base_1997
    va_factor  = min(Decimal('1.0'), raw_ratio ** VA_EXPONENT)
    -- Store at 10 decimal places: DECIMAL(14,10)

  Cell 7 — Write to Gold (partition overwrite by calculation_year):
    Store in gold.msa_rms_calculation:
      calculation_year, version_id, company_cigarette_equivalent_units,
      total_opm_combined_equivalent_units, relative_market_share_pct (10dp),
      eligible_shipment_line_count, auditor_file_version,
      current_year_total_opm_units, base_year_1997_units,
      volume_adjustment_factor (10dp),
      _gold_loaded_at, _gold_run_id

STTM ROWS IMPLEMENTED:   51–56
ACs SATISFIED:           US-004 AC-01 through AC-06, AC-EC-01

COMPLETION CRITERIA
─────────────────────────────────────────────────────────────────
  - [ ] FY2023 RMS matches submitted figure to 10 decimal places
        (Jennifer Park confirms using prior Excel calculation)
  - [ ] FY2023 VA Factor matches to 10 decimal places
  - [ ] Legal constant 0.980000 verified in code as Decimal literal
        (search the notebook for any float representation of 0.98)
  - [ ] Pre-condition CHECK 1: blocked when status != APPROVED
  - [ ] Pre-condition CHECK 2: blocked when reconciliation != CLEARED
  - [ ] VA cap tested: synthetic test where current > 1997 base →
        va_factor = 1.0000000000 exactly
  - [ ] Both Gold tables populated with correct intermediate values
  - [ ] Robert Chen reviews calculation logic — legal sign-off required


┌─────────────────────────────────────────────────────────────────┐
│ WORK ITEM ID:   WI-013                                          │
│ USER STORY:     US-005 — Per-State Payments + NPM               │
│ TITLE:          Build Gold State Payment Notebook                │
│                 (nb_gold_msa_state_payments)                     │
│ TYPE:           Notebook                                        │
│ PLATFORM:       Databricks                                      │
│ ESTIMATED:      L (8 hours)                                     │
└─────────────────────────────────────────────────────────────────┘

DESCRIPTION
────────────────
Computes the final per-state MSA payment amounts by multiplying
the gross national payment by each state's legal allocation
percentage, applying NPM adjustments, flagging disputed states
with NULL payments, and computing the payment due date with
weekend/holiday logic.

TECHNICAL SPECIFICATION
────────────────────────
  Source tables:
    {catalog}.gold.msa_rms_calculation        (RMS + VA Factor)
    {catalog}.control.msa_payment_schedule    (aggregate base payment)
    {catalog}.ref.msa_state_allocations       (legal constants — read-only)
    {catalog}.silver.npm_adjustment_rates     (annual legal file)
    {catalog}.ref.us_federal_holidays         (for due date calculation)

  Cell 5 — Key validation before calculation:
    -- Confirm all 46 settling states have allocation records
    -- Confirm SUM(allocation_pct) = 100.0000000000 exactly
    -- If either check fails → raise RuntimeError, do not proceed

  Cell 6 — State Payment Calculation (Spark SQL):

    -- Step 1: Gross national payment (STTM row 57)
    gross_national =
      aggregate_base_payment_usd        -- from payment_schedule
      × (relative_market_share_pct/100) -- from msa_rms_calculation
      × volume_adjustment_factor        -- from msa_rms_calculation

    -- Step 2: State allocation (STTM row 58)
    -- CRITICAL: allocation_pct read from ref table (legal constant)
    --           stored at 10dp — never computed or rounded
    gross_state = gross_national × (allocation_pct / 100)
    -- per state, produces 46 rows

    -- Step 3: NPM adjustment (STTM row 59)
    npm_adjusted = CASE
      WHEN is_npm_disputed = TRUE THEN NULL  -- payment held (EC-004)
      ELSE gross_state × (1 - npm_adjustment_rate_pct)
    END

    -- Step 4: Payment status (STTM row 60)
    payment_status = CASE
      WHEN is_npm_disputed = TRUE THEN 'NPM_DISPUTED — PAYMENT HELD'
      WHEN npm_adjusted IS NOT NULL THEN 'READY FOR PAYMENT'
      ELSE 'CALCULATION_INCOMPLETE'
    END

    -- Step 5: Due date (BR-009)
    -- Base due date = April 15 of following year
    -- Shift forward for weekends and US federal holidays
    base_due_date = DATE(calculation_year + 1, 4, 15)
    -- Loop: while base_due_date is weekend OR in us_federal_holidays
    --         base_due_date = base_due_date + 1 day
    -- Maximum iterations: 7 (no chain of >7 consecutive non-business days)

  Post-calculation reconciliation (Cell 6 — validate before write):
    -- SUM of all 46 states must equal gross_national
    -- If SUM differs by > $0.01 → raise error, alert Patricia Lawson

STTM ROWS IMPLEMENTED:   57–60
ACs SATISFIED:           US-005 AC-01 through AC-05, AC-EC-01 through AC-EC-03

COMPLETION CRITERIA
─────────────────────────────────────────────────────────────────
  - [ ] FY2023: all 46 state payments match submitted amounts to $0.01
  - [ ] NPM adjustment: 5 states tested with known prior rates
  - [ ] Disputed state: NY set to is_npm_disputed=TRUE in DEV,
        confirmed payment_status='NPM_DISPUTED', amount=NULL
  - [ ] SUM reconciliation: confirmed SUM = gross_national for FY2023
  - [ ] Due date: verified for calculation_years 2024 (April 15 Monday),
        2025 (April 15 Tuesday), 2026 (April 15 Wednesday),
        and a synthetic test for a Saturday April 15
  - [ ] Robert Chen reviews disputed state handling before UAT


┌─────────────────────────────────────────────────────────────────┐
│ WORK ITEM ID:   WI-014                                          │
│ USER STORY:     US-004, US-005                                  │
│ TITLE:          Create Calculation Freeze Lock on Gold Tables    │
│ TYPE:           Security / Config                               │
│ PLATFORM:       Databricks (Unity Catalog)                      │
│ ESTIMATED:      S (2 hours)                                     │
└─────────────────────────────────────────────────────────────────┘

DESCRIPTION
────────────────
Implement the BR-011 calculation freeze. Once is_submitted = TRUE
for a calculation_year, no pipeline run may update the Gold
calculation tables for that year. This is enforced at two levels:
(1) notebook pre-condition check and (2) Unity Catalog row-level
filter via a security function.

TECHNICAL SPECIFICATION
────────────────────────
  Implementation:
    1. Pre-condition in Gold notebooks (Cell 4):
       Check gold.msa_payment_schedule.lock_status for calculation_year
       If lock_status = 'FROZEN' → raise RuntimeError('CALCULATION_FROZEN')

    2. Unity Catalog row filter on gold.msa_rms_calculation and
       gold.msa_state_payments:
       Prevent MODIFY (INSERT/UPDATE/DELETE) on rows where
       version_id corresponds to a frozen calculation_year.
       Pipeline service principal DENY MODIFY on frozen rows.

    3. msa_calculation_versions table tracks:
       calculation_year, version_id, is_submitted (BOOLEAN),
       submitted_at (TIMESTAMP), submitted_by (STRING),
       lock_status ('ACTIVE'/'FROZEN')

  Setting is_submitted = TRUE is a privileged operation:
    - Only role 'msa_calculation_admin' can set is_submitted = TRUE
    - Assignment to this role requires two-person approval (Legal + Finance)
    - The action is logged in audit.entity_changes (trigger on the table)

COMPLETION CRITERIA
─────────────────────────────────────────────────────────────────
  - [ ] FY2023 set to is_submitted=TRUE in DEV
  - [ ] Confirmed: re-running Gold calculation for FY2023 raises
        CALCULATION_FROZEN error and writes nothing to Gold
  - [ ] EC-010 confirmed: Silver correction for FY2023 lands in
        msa_exceptions, does NOT alter Gold calculation
  - [ ] Audit trigger confirmed: changing is_submitted generates
        audit.entity_changes record with old/new values
  - [ ] Robert Chen confirms the two-person approval process
        for submitting a calculation is documented in runbook


┌─────────────────────────────────────────────────────────────────┐
│ WORK ITEM ID:   WI-015                                          │
│ USER STORY:     US-001 through US-005                           │
│ TITLE:          FY2023 Parallel Run — Validate Against           │
│                 Submitted Excel Calculation                      │
│ TYPE:           Test                                            │
│ PLATFORM:       Databricks                                      │
│ ESTIMATED:      XL (16 hours)                                   │
└─────────────────────────────────────────────────────────────────┘

DESCRIPTION
────────────────
Run the complete platform end-to-end using FY2023 actual data
and compare every output against the FY2023 Excel calculation
that was actually submitted to the states. This is the ultimate
acceptance test — if the platform produces identical results to
the submitted calculation, it is proven legally defensible.

ACCEPTANCE CRITERIA
────────────────────
  All of the following must be verified by Jennifer Park AND
  Robert Chen before this WI is marked complete:

  - [ ] Company cigarette equivalent units (FY2023) matches
        Excel model to 0 units (exact match)
  - [ ] RMS % matches to 10 decimal places
  - [ ] VA Factor matches to 10 decimal places
  - [ ] Gross national payment matches to $0.01
  - [ ] All 46 state gross payments match to $0.01 each
  - [ ] All 46 state NPM-adjusted payments match to $0.01 each
  - [ ] Total of all 46 states matches gross national to $0.01
  - [ ] Any variances are documented with root cause analysis
        (acceptable causes: rounding improvement, known Excel bug)
  - [ ] Jennifer Park signs parallel run acceptance document
  - [ ] Robert Chen confirms legal sufficiency of audit trail
```
