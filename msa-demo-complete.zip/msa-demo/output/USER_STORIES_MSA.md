# Generated Output — User Stories
> Generated from: BRD_MSA.md v1.0 + STTM_MSA.md v1.1 + FEATURES_MSA.md
> Project: MSA Payment Analytics Platform — FIN-2025-011
> Generated: 2025-01-22

---

```
───────────────────────────────────────────────────────────────────
USER STORY ID:    US-001
FEATURE:          F-001 — SAP Shipment Ingestion — Bronze to Silver
TITLE:            Ingest SAP ERP Cigarette and RYO Shipments to Bronze
TYPE:             Ingestion
PLATFORM:         Databricks
LAYER:            Bronze
PRIORITY:         Critical
STATUS:           Draft
───────────────────────────────────────────────────────────────────

AS A      Tax Compliance Analyst (Jennifer Park)
I WANT    all daily SAP shipment records to be automatically
          ingested into the Bronze lakehouse
SO THAT   I have a complete, append-only record of every shipment
          that serves as the audit-ready source of truth for the
          MSA calculation

BACKGROUND
────────────────
The MSA payment calculation requires accurate, complete records of
every cigarette and RYO shipment to US destinations. Currently
these are exported manually from SAP into Excel. This story
replaces that manual export with an automated daily pipeline that
lands raw SAP data — with zero transformation — into Bronze.

STTM REFERENCE (STTM rows 1–17)
────────────────────────────────
Row  | Source                        | Target Column              | Rule
-----|-------------------------------|----------------------------|------------------------------
1    | VBAP.VBELN                    | delivery_number            | TRIM()
2    | VBAP.POSNR                    | line_item_number           | TRIM()
3    | VBAP.MATNR                    | material_number            | LTRIM leading zeros
4    | VBAP.KWMENG                   | quantity_confirmed         | Direct, DECIMAL(15,3)
5    | VBAP.MEINS                    | unit_of_measure            | UPPER(TRIM())
6    | LIKP.WADAT_IST                | goods_issue_date           | TO_DATE('yyyyMMdd')
7    | LIKP.KUNNR                    | customer_number            | LTRIM leading zeros
8    | KNA1.REGIO                    | destination_state_code     | Direct copy, nullable
9    | MARA.MTART                    | sap_material_type          | Direct copy
10   | ZTMSA_CAT.ZTMSA_CAT          | msa_product_category       | Direct copy, nullable
11   | MARA.NTGEW                    | product_net_weight         | Direct copy, nullable
12   | MARA.GEWEI                    | weight_unit                | UPPER(TRIM()), nullable
13   | VBFA.VBTYP_N (derived)        | is_intercompany_transfer   | CASE on doc type codes
14-17| System generated              | _ingest_timestamp etc.     | Metadata columns

BUSINESS RULES APPLIED
────────────────────────
  - BR-002: quantity_confirmed × unit conversion factor gives sticks (applied in Silver, not here)
  - BR-004: MSA eligibility filtering is applied in Silver — Bronze accepts ALL SAP shipment lines

ACCEPTANCE CRITERIA
────────────────────

  AC-01: Successful Daily Incremental Load
  GIVEN  SAP ERP contains shipment records with goods_issue_date in the prior day
  WHEN   the Bronze ingestion pipeline runs at 07:00 UTC
  THEN   all new and updated delivery lines (identified by updated_at watermark) are
         appended to finance_prod.bronze.crm_shipments
  AND    each appended row contains all 17 columns per the STTM (rows 1–17)
  AND    _ingest_timestamp reflects the actual run time (not the goods_issue_date)
  AND    _pipeline_run_id matches the Databricks Workflow run ID
  AND    the pipeline run log records status='success' with rows_extracted count

  AC-02: SAP Date Format Conversion (STTM row 6)
  GIVEN  LIKP.WADAT_IST contains a date in SAP DATS format (e.g. '20250115')
  WHEN   the Bronze ingestion runs
  THEN   goods_issue_date in Bronze = DATE '2025-01-15'
  AND    goods_issue_date is stored as DATE type (not STRING)

  AC-03: Leading Zero Removal (STTM rows 3, 7)
  GIVEN  VBAP.MATNR = '000000000040012345' (18-char with leading zeros)
  WHEN   the Bronze ingestion runs
  THEN   material_number in Bronze = '40012345' (leading zeros removed)
  AND    LIKP.KUNNR = '0000012345' results in customer_number = '12345'

  AC-04: Intercompany Flag Derivation (STTM row 13)
  GIVEN  a delivery record has VBTYP_N = 'U' (STO — Stock Transport Order)
  WHEN   the Bronze ingestion runs
  THEN   is_intercompany_transfer = TRUE for that record
  GIVEN  a delivery record has VBTYP_N = 'J' (standard outbound delivery)
  WHEN   the Bronze ingestion runs
  THEN   is_intercompany_transfer = FALSE for that record

  AC-05: NULL msa_product_category Accepted in Bronze (EC-009 pre-condition)
  GIVEN  a shipment record has no entry in ZTMSA_CAT (new product, not yet classified)
  WHEN   the Bronze ingestion runs
  THEN   the record IS written to Bronze with msa_product_category = NULL
  AND    the record is NOT rejected in Bronze (rejection happens in Silver)
  AND    _pipeline_run_id and _ingest_timestamp are still populated

EDGE CASE ACCEPTANCE CRITERIA
───────────────────────────────

  AC-EC-01: NULL delivery_number (STTM row 1)
  GIVEN  a SAP record has VBELN = NULL
  WHEN   the Bronze ingestion processes it
  THEN   the record is routed to finance_prod.control.msa_exceptions
  AND    the exception row contains: pipeline_name='nb_bronze_msa_sap_shipments',
         error_category='VALIDATION_ERROR',
         error_message='delivery_number is null — cannot identify record',
         raw_record=the full source row as JSONB
  AND    the pipeline continues processing remaining records
  AND    rows_rejected in pipeline_run_log increments by 1

  AC-EC-02: Unknown Unit of Measure (STTM row 5)
  GIVEN  MEINS contains a value not in ('CS','PK','MU','LB','OZ') — e.g. 'EA'
  WHEN   the Bronze ingestion runs
  THEN   the record IS written to Bronze (Bronze accepts all)
  AND    unit_of_measure = 'EA' is stored
  AND    the record will fail Silver conversion (handled in US-002)

  AC-EC-03: Idempotency — Re-run for Same Date Window
  GIVEN  the Bronze pipeline is re-run for the same goods_issue_date range
  WHEN   the pipeline runs a second time
  THEN   no duplicate records are created in Bronze
  AND    the row count in Bronze for that date range remains identical
  AND    the pipeline run log shows rows_extracted > 0 but rows_loaded = 0
         (all rows already present — merge detects no new records)

NON-FUNCTIONAL REQUIREMENTS
─────────────────────────────
  - Volume: Up to 5,000 delivery line items per daily run
  - Runtime: Must complete within 30 minutes
  - Retry: SAP connection failure → retry 3× with 5-min backoff
  - Watermark: Updated ONLY after confirmed successful append
  - Secret: SAP connection string read from `kv-databricks-prod`
             via dbutils.secrets — never from widget or hardcode

TECHNICAL NOTES
────────────────
  Notebook name:    nb_bronze_msa_sap_shipments
  Source:           SRC-001 (SAP ERP) via JDBC
  Target:           finance_prod.bronze.crm_shipments
  Write mode:       Append only (Bronze cardinal rule)
  Watermark col:    SAP updated_at (from VBAK/LIKP change timestamp)
  Partition:        goods_issue_date
  Catalog:          From widget p_catalog — NEVER hardcoded
  Playbook ref:     databricks-standards/notebooks.md (8-cell standard)
                    databricks-standards/delta.md (Bronze write pattern)

DEFINITION OF DONE
────────────────────
  - [ ] AC-01 through AC-05 pass with real SAP data in DEV
  - [ ] EC-01, EC-02, EC-03 pass with synthetic test records
  - [ ] Pipeline run log verified: all fields populated
  - [ ] Watermark tested: advance only on success, not on failure
  - [ ] Code reviewed by Marcus Webb
  - [ ] Jennifer Park confirms Bronze row count matches SAP report
───────────────────────────────────────────────────────────────────


───────────────────────────────────────────────────────────────────
USER STORY ID:    US-002
FEATURE:          F-001 — SAP Shipment Ingestion — Bronze to Silver
TITLE:            Transform and Normalise Shipments to Cigarette
                  Equivalent Units in Silver
TYPE:             Transformation
PLATFORM:         Databricks
LAYER:            Silver
PRIORITY:         Critical
STATUS:           Draft
───────────────────────────────────────────────────────────────────

AS A      Tax Compliance Analyst (Jennifer Park)
I WANT    all MSA-eligible shipments to be filtered, converted to
          cigarette equivalent units, and merged into Silver
SO THAT   the RMS calculation has a clean, standardised unit count
          with full traceability back to the source SAP delivery

STTM REFERENCE (STTM rows 18–27)
────────────────────────────────
Row  | Transformation                                      | Key Rule
-----|-----------------------------------------------------|---------------------
18   | CONCAT(delivery_number,'-',line_item_number)         | Surrogate key
19   | goods_issue_date direct copy                         | BR-004 date filter
20   | Validate destination_state in MSA-eligible list      | BR-004, EC-005
21   | Validate msa_product_category IN ('CIGARETTE','RYO') | BR-004, EC-009
22   | Unit conversion to sticks (CS/PK/MU)                 | BR-002
23   | RYO weight in oz (with unit conversion to oz)         | BR-003
24   | cigarette_equivalent_units (sticks or oz/0.032500)    | BR-002, BR-003
25   | is_intercompany_transfer direct copy                  | BR-004
26   | Derived: is_included_in_rms (all 4 conditions)        | BR-004
27   | calculation_year from widget                          | —

ACCEPTANCE CRITERIA
────────────────────

  AC-01: Cigarette Stick Count — Packs (STTM row 22, BR-002)
  GIVEN  a Bronze record with msa_product_category='CIGARETTE',
         unit_of_measure='PK', quantity_confirmed=500.000
  WHEN   the Silver transformation runs
  THEN   quantity_in_sticks = 10,000 (500 packs × 20 sticks)
  AND    cigarette_equivalent_units = 10,000.000000

  AC-02: Cigarette Stick Count — Cases (STTM row 22, BR-002)
  GIVEN  a Bronze record with msa_product_category='CIGARETTE',
         unit_of_measure='CS', quantity_confirmed=10.000
  WHEN   the Silver transformation runs
  THEN   quantity_in_sticks = 100,000 (10 cases × 500 packs × 20 sticks)
  AND    cigarette_equivalent_units = 100,000.000000

  AC-03: RYO Conversion — Oz to Cigarette Equivalent (STTM rows 23–24, BR-003)
  GIVEN  a Bronze record with msa_product_category='RYO',
         product_net_weight=1.500 (oz per unit), weight_unit='OZ',
         quantity_confirmed=1000.000
  WHEN   the Silver transformation runs
  THEN   ryo_weight_oz = 1,500.000000 (1.500 × 1000)
  AND    cigarette_equivalent_units = 46,153.846154
         (1500 / 0.032500 = 46,153.846154... stored at 6dp)
  AND    the divisor used is EXACTLY 0.032500 — NOT 0.0325 or any
         rounded form (legal constant per BR-003)

  AC-04: RYO Conversion — Pounds to Oz (STTM row 23)
  GIVEN  a Bronze record with msa_product_category='RYO',
         product_net_weight=2.000, weight_unit='LB',
         quantity_confirmed=100.000
  WHEN   the Silver transformation runs
  THEN   ryo_weight_oz = 3,200.000000 (2.0 lb × 16 × 100 units)
  AND    cigarette_equivalent_units = 98,461.538462

  AC-05: is_included_in_rms = TRUE — All Four Conditions Met (STTM row 26, BR-004)
  GIVEN  a shipment with: is_intercompany_transfer=FALSE,
         destination_state='IL' (MSA-eligible),
         msa_product_category='CIGARETTE',
         goods_issue_date='2025-06-15' (within calculation_year 2025)
  WHEN   the Silver transformation runs
  THEN   is_included_in_rms = TRUE

  AC-06: is_included_in_rms = FALSE — Intercompany Excluded (BR-004)
  GIVEN  a shipment with is_intercompany_transfer=TRUE (all other conditions met)
  WHEN   the Silver transformation runs
  THEN   is_included_in_rms = FALSE
  AND    the record IS written to Silver (for audit purposes)
  AND    cigarette_equivalent_units IS populated correctly
  AND    the record does NOT appear in the RMS calculation inputs

  AC-07: Merge — No Duplicates on Re-run (BR-005 idempotency)
  GIVEN  Silver already contains 10,000 rows for calculation_year 2025
  WHEN   the Silver pipeline runs again for the same date window
  THEN   no duplicate shipment_line_key values exist in Silver
  AND    updated records (same key, new data) are correctly updated

EDGE CASE ACCEPTANCE CRITERIA
───────────────────────────────

  AC-EC-01: NULL destination_state — Exclude with Exception (EC-005)
  GIVEN  a Bronze record has destination_state_code = NULL
  WHEN   the Silver transformation processes it
  THEN   the record is NOT written to Silver
  AND    the record IS written to finance_prod.control.msa_exceptions with:
         error_category = 'MISSING_DESTINATION_STATE',
         error_message = 'destination_state_code is null — cannot determine
                          MSA eligibility. Resolve in SAP customer master.',
         delivery_number and line_item_number populated for easy lookup
  AND    Jennifer Park receives a daily digest email listing all EC-005
         exceptions unresolved for > 3 business days

  AC-EC-02: RYO with NULL Net Weight — Exclude with Exception (EC-006)
  GIVEN  a Bronze record has msa_product_category='RYO' AND
         product_net_weight = NULL
  WHEN   the Silver transformation processes it
  THEN   the record is NOT written to Silver
  AND    routed to msa_exceptions with error_category='RYO_MISSING_WEIGHT',
         error_message='RYO product has no net weight in SAP product master —
                        cannot convert to cigarette equivalents'
  AND    Jennifer Park notified daily until resolved

  AC-EC-03: Unknown UOM — Exclude with Exception
  GIVEN  a Bronze record has unit_of_measure='EA' (not in CS/PK/MU)
  WHEN   the Silver transformation attempts conversion
  THEN   quantity_in_sticks = NULL (conversion impossible)
  AND    record routed to msa_exceptions with:
         error_category='UNKNOWN_UOM_CANNOT_CONVERT',
         error_message='Unit of measure EA has no cigarette equivalent
                        conversion rule. Update STTM or correct in SAP.'

  AC-EC-04: Non-MSA Destination State — Silently Excluded (BR-004)
  GIVEN  a Bronze record has destination_state_code = 'GU' (Guam)
  WHEN   the Silver transformation runs
  THEN   is_included_in_rms = FALSE
  AND    the record IS written to Silver with is_included_in_rms=FALSE
  AND    no exception record is created (Guam exclusion is expected, not an error)

TECHNICAL NOTES
────────────────
  Notebook name:    nb_silver_msa_company_shipments
  Source:           finance_prod.bronze.crm_shipments
  Target:           finance_prod.silver.company_cigarette_shipments
  Write mode:       MERGE on (delivery_number, line_item_number, calculation_year)
  PII:              None
  RYO legal const:  0.032500 stored as Decimal literal — not a variable
  Ref table:        finance_prod.ref.us_states_msa_eligible (loaded from
                    Legal reference — 50 states + DC + PR)
  Catalog:          From widget p_catalog

DEFINITION OF DONE
────────────────────
  - [ ] AC-01 through AC-07 pass with real and synthetic data
  - [ ] EC-01 through EC-04 confirmed in DEV with synthetic records
  - [ ] RYO conversion verified: 0.032500 divisor checked in Spark
        with DECIMAL(18,6) precision — no floating point drift
  - [ ] Total cigarette_equivalent_units for a prior year matches
        the value Jennifer Park previously calculated in Excel
  - [ ] Exception emails tested: received by Jennifer Park in UAT
───────────────────────────────────────────────────────────────────


───────────────────────────────────────────────────────────────────
USER STORY ID:    US-003
FEATURE:          F-003 — MSA Auditor File Ingestion
TITLE:            Detect, Validate, and Ingest Annual MSA Auditor File
TYPE:             Ingestion
PLATFORM:         Databricks
LAYER:            Bronze + Silver
PRIORITY:         Critical
STATUS:           Draft
───────────────────────────────────────────────────────────────────

AS A      Tax Compliance Analyst (Jennifer Park)
I WANT    the MSA Auditor file to be automatically detected when
          it arrives in the secure ADLS drop zone and ingested
          without manual intervention
SO THAT   the RMS calculation can begin within hours of file
          arrival rather than days of manual processing

STTM REFERENCE (STTM rows 28–42)
────────────────────────────────
Row  | Source              | Target                               | Key Rule
-----|---------------------|--------------------------------------|------------------
28   | REPORT_YEAR         | report_year                          | CAST to INTEGER
29   | OPM_NAME            | opm_name                             | TRIM()
30   | PRODUCT_TYPE        | product_type (CIG/RYO)               | Validate IN list
31   | UNITS_BILLIONS      | units_billions                       | DECIMAL(18,9) — 9dp
32   | CERTIFICATION_DATE  | certification_date                   | TO_DATE
33   | FILE_VERSION        | file_version                         | Direct copy
35   | Auto Loader         | _source_filename                     | input_file_name()
37   | Derived: SUM CIG    | total_opm_cigarette_units            | × 1,000,000,000
38   | Derived: SUM RYO    | total_opm_ryo_units_oz               | × 1,000,000,000
39   | Derived: RYO → CEU  | total_opm_ryo_cigarette_equiv_units  | ÷ 0.032500
40   | Derived: CIG + RYO  | total_opm_combined_equivalent_units  | Sum of 37+39
42   | Derived             | is_latest_version                    | Max version = TRUE

ACCEPTANCE CRITERIA
────────────────────

  AC-01: Auto Loader Detects File on Arrival
  GIVEN  KPMG uploads the auditor file to the ADLS landing zone
  WHEN   Auto Loader's scheduled check runs (every 6 hours)
  THEN   the file is detected within 6 hours of upload
  AND    the ingestion pipeline is triggered automatically
  AND    Patricia Lawson receives an email: 'MSA Auditor file received —
         ingestion started. Expected completion: {estimated_time}.'

  AC-02: Units Stored at Full Precision (STTM row 31, BR-001)
  GIVEN  the auditor file contains UNITS_BILLIONS = '312.156789123'
  WHEN   the Bronze ingestion runs
  THEN   units_billions in Bronze = 312.156789123 (stored at 9dp minimum)
  AND    no rounding occurs at any point in Bronze ingestion
  AND    when converted to individual units in Silver:
         total_opm_cigarette_units = 312,156,789,123 (rounded to nearest integer
         only at the final unit count — not during intermediate steps)

  AC-03: Version Management — First File (STTM row 42, EC-007)
  GIVEN  the auditor delivers file_version = '01' for report_year 2025
  WHEN   the Silver aggregation runs
  THEN   is_latest_version = TRUE for the file_version='01' row
  AND    the total_opm_combined_equivalent_units for 2025 is populated

  AC-04: Version Management — Restated File (EC-007)
  GIVEN  the auditor later delivers file_version = '02' (corrected data)
         for report_year 2025 with different unit totals
  WHEN   the Silver aggregation runs for the restated file
  THEN   is_latest_version = TRUE for file_version='02'
  AND    is_latest_version = FALSE for file_version='01' (the prior version)
  AND    BOTH versions are retained in Silver (the original is NOT deleted)
  AND    the Gold RMS calculation uses only the row where is_latest_version=TRUE
  AND    Patricia Lawson receives an alert: 'Auditor restated file received for
         {year}. Prior version preserved. New RMS calculation initiated.'

  AC-05: Combined OPM Total (STTM rows 37–40)
  GIVEN  auditor file contains: CIG total = 300B units, RYO total = 1.5B oz
  WHEN   Silver aggregation runs
  THEN   total_opm_cigarette_units = 300,000,000,000
  AND    total_opm_ryo_units_oz = 1,500,000,000
  AND    total_opm_ryo_cigarette_equivalent_units = 46,153,846,153.846154
         (1,500,000,000 / 0.032500)
  AND    total_opm_combined_equivalent_units = 346,153,846,153.846154

EDGE CASE ACCEPTANCE CRITERIA
───────────────────────────────

  AC-EC-01: File Not Arrived by February 15 (EC-001)
  GIVEN  no auditor file has been received by 08:00 UTC on February 15
         of the year following the calculation year
  WHEN   the daily monitoring check runs
  THEN   an automated email is sent to David Osei (KPMG auditor),
         Patricia Lawson, and Robert Chen containing:
         'MSA Auditor file for FY{year} has not been received as of
          February 15. Annual payment deadline is April 15. Please
          advise on expected delivery date.'
  AND    the pipeline remains in status 'AWAITING_AUDITOR_FILE'
  AND    the monitoring check continues daily until file arrives
  AND    NO calculation proceeds using prior year totals as a proxy

  AC-EC-02: Auditor Totals Differ from Preliminary Estimate > 2% (EC-002)
  GIVEN  a preliminary industry estimate was loaded (from a January
         pre-file courtesy data share from KPMG) showing ~320B units
  AND    the official auditor file shows 328B units (2.5% higher)
  WHEN   the Silver validation runs
  THEN   the pipeline sets status='AUDITOR_VOLUME_VARIANCE'
  AND    an alert is sent to Robert Chen and Jennifer Park:
         'Certified auditor file total (328B units) differs from
          preliminary estimate (320B units) by 2.50%. Manual review
          required before calculation proceeds.'
  AND    the RMS calculation (US-004) does NOT run until Jennifer Park
         manually sets approved=TRUE in the pipeline control table

DEFINITION OF DONE
────────────────────
  - [ ] AC-01 through AC-05 pass using last year's auditor file (FY2023)
        as a test input
  - [ ] EC-01 date override tested in UAT (set system date to Feb 15)
  - [ ] EC-02 tested with synthetic preliminary estimate in control table
  - [ ] Precision verified: 0.032500 conversion tested to 6dp in Spark
  - [ ] Restatement round-trip tested: two file versions for same year
        both retained, is_latest_version switches correctly
───────────────────────────────────────────────────────────────────


───────────────────────────────────────────────────────────────────
USER STORY ID:    US-004
FEATURE:          F-004 — MSA Payment Calculation Engine
TITLE:            Calculate Relative Market Share and Volume
                  Adjustment Factor
TYPE:             Aggregation
PLATFORM:         Databricks
LAYER:            Gold
PRIORITY:         Critical
STATUS:           Draft
───────────────────────────────────────────────────────────────────

AS A      VP Finance & Tax Compliance (Patricia Lawson)
I WANT    the RMS and Volume Adjustment Factor to be computed
          automatically from validated Silver data
SO THAT   I can review the calculation within 5 business days of
          the auditor file arriving — not 6 weeks

STTM REFERENCE (STTM rows 51–56)
────────────────────────────────
Row 51: SUM(cigarette_equivalent_units) WHERE is_included_in_rms=TRUE → company units
Row 52: total_opm_combined_equivalent_units WHERE is_latest_version=TRUE → OPM total
Row 53: (51 / 52) × 100 → relative_market_share_pct at 10dp
Row 54: Current year total OPM units from auditor
Row 55: 1997 base year units from control table (legal constant)
Row 56: MIN(1.0, POWER(54/55, 0.980000)) → volume_adjustment_factor at 10dp

ACCEPTANCE CRITERIA
────────────────────

  AC-01: RMS Calculation — Core Formula (STTM row 53, BR-001)
  GIVEN  company_cigarette_equivalent_units = 124,567,890,000.000000
  AND    total_opm_combined_equivalent_units = 621,430,500,000.000000
  WHEN   the Gold RMS calculation runs
  THEN   relative_market_share_pct = 20.0444823467 (10 decimal places)
  AND    the intermediate values (numerator and denominator) are BOTH
         stored in gold.msa_rms_calculation — not discarded
  AND    relative_market_share_pct is NOT rounded to fewer decimal places
         at any intermediate step — only the final displayed value in
         Power BI may round for presentation

  AC-02: RMS Only Uses is_latest_version Auditor Data (BR-001)
  GIVEN  two versions of the auditor file exist for the same year
         (file_version '01' and '02' with different totals)
  WHEN   the RMS calculation runs
  THEN   only the file where is_latest_version=TRUE is used as the denominator
  AND    using file_version='01' data in the denominator while '02' exists
         is explicitly BLOCKED by a pre-calculation validation check

  AC-03: VA Factor — Normal Year (BR-006)
  GIVEN  current_year_total_opm_units = 580,000,000,000
  AND    base_year_1997_units = 667,754,000,000 (legal constant, SRC-005)
  WHEN   the VA Factor is computed
  THEN   raw_ratio = 580,000,000,000 / 667,754,000,000 = 0.868567...
  AND    volume_adjustment_factor = POWER(0.868567, 0.980000) = 0.8706... (10dp)
  AND    MIN(1.0, 0.8706...) = 0.8706... (less than 1.0, so MIN has no effect)
  AND    the exponent used is EXACTLY 0.980000 stored in a named constant —
         NOT computed, NOT user-editable

  AC-04: VA Factor — Volume Above 1997 Base (BR-006 edge case)
  GIVEN  current_year_total_opm_units EXCEEDS base_year_1997_units
         (hypothetical: 700,000,000,000 > 667,754,000,000)
  WHEN   the VA Factor is computed
  THEN   raw_ratio > 1.0
  AND    POWER(raw_ratio, 0.980000) > 1.0
  AND    MIN(1.0, POWER(raw_ratio, 0.980000)) = 1.0000000000
  AND    volume_adjustment_factor = 1.0000000000 (capped at 1.0)

  AC-05: Calculation Blocked Until Pre-Conditions Met
  GIVEN  the ERP-to-TTB reconciliation has status = 'EXCEPTION'
         (variance ≥ 0.5%, unresolved)
  WHEN   the RMS calculation notebook attempts to run
  THEN   the notebook halts at the pre-condition check (Cell 4)
  AND    raises: 'CALCULATION_BLOCKED: ERP-TTB reconciliation has not
                  been cleared. Resolve exception before proceeding.'
  AND    no Gold records are written for this calculation_year version

  AC-06: 1997 Base Volume Is a Read-Only Constant (BR-006)
  GIVEN  a user attempts to UPDATE finance_prod.control.msa_base_volumes
  WHEN   the update is attempted
  THEN   the operation is REJECTED by Unity Catalog DENY permission on
         MODIFY for this table for all roles except 'data_engineering_admin'
  AND    the 1997 base volume used in every VA calculation is always
         667,754,000,000 — the legally confirmed constant (BRD A-001)

EDGE CASE ACCEPTANCE CRITERIA
───────────────────────────────

  AC-EC-01: Auditor File Not Yet Received (EC-001)
  GIVEN  the msa_payment_schedule.calculation_status = 'AWAITING_AUDITOR_FILE'
  WHEN   the RMS calculation notebook is triggered (manually or by schedule)
  THEN   the notebook exits immediately after the pre-condition check
  AND    logs: 'CALCULATION_BLOCKED: Auditor file for {year} not yet received'
  AND    no Gold calculation records are written
  AND    Patricia Lawson is notified

DEFINITION OF DONE
────────────────────
  - [ ] AC-01 verified: RMS for FY2023 matches submitted figure to 10dp
  - [ ] AC-02 verified: version gating tested with two synthetic file versions
  - [ ] AC-03 verified: VA Factor for FY2023 matches prior calculation
  - [ ] AC-04 verified: synthetic test with volume > 1997 base confirms cap
  - [ ] AC-05 verified: reconciliation exception blocks Gold write
  - [ ] AC-06 verified: DENY permission on control table tested in UAT
  - [ ] Robert Chen and Patricia Lawson sign off on FY2023 parallel run
───────────────────────────────────────────────────────────────────


───────────────────────────────────────────────────────────────────
USER STORY ID:    US-005
FEATURE:          F-004 — MSA Payment Calculation Engine
TITLE:            Calculate Per-State MSA Payments with NPM
                  Adjustments and Produce Final Payment Schedule
TYPE:             Aggregation
PLATFORM:         Databricks
LAYER:            Gold
PRIORITY:         Critical
STATUS:           Draft
───────────────────────────────────────────────────────────────────

AS A      VP Finance & Tax Compliance (Patricia Lawson) and
          SVP General Counsel (Robert Chen)
I WANT    the per-state MSA payment amounts to be automatically
          calculated, with NPM adjustments applied correctly and
          disputed states clearly flagged
SO THAT   I can approve 46 individual state payments and identify
          any that are held pending legal resolution

STTM REFERENCE (STTM rows 57–60)
────────────────────────────────
Row 57: gross_national = aggregate_base × (rms/100) × va_factor
Row 58: gross_state = gross_national × (allocation_pct/100) per state
Row 59: npm_adjusted = gross_state × (1 − npm_rate) OR NULL if disputed
Row 60: payment_status = derived from dispute flag

ACCEPTANCE CRITERIA
────────────────────

  AC-01: State Allocation Uses Legal Constants Only (BR-008)
  GIVEN  a state has allocation_pct = 12.0962581034 (stored at 10dp)
  AND    gross_national_payment = $4,250,000,000.0000
  WHEN   the state allocation is computed
  THEN   gross_state_payment for that state =
         $4,250,000,000.0000 × 0.120962581034 = $513,090,969.3945
  AND    the allocation_pct value was READ from the msa_state_allocations
         reference table — NOT recalculated or overridden
  AND    SUM of all 46 gross_state_payments = gross_national_payment
         (reconciliation check run after each calculation)

  AC-02: NPM Adjustment Applied — Non-Disputed State (BR-007)
  GIVEN  state = 'IL' with npm_adjustment_rate_pct = 0.125000 (12.5%)
  AND    gross_state_payment_IL = $150,000,000.0000
  WHEN   the NPM adjustment is applied
  THEN   npm_adjusted_payment_usd = $150,000,000.0000 × (1 − 0.125000)
         = $131,250,000.0000
  AND    payment_status = 'READY FOR PAYMENT'

  AC-03: NPM Adjustment — Zero Rate State (BR-007)
  GIVEN  state = 'CA' with npm_adjustment_rate_pct = 0.000000 (no adjustment)
  AND    gross_state_payment_CA = $500,000,000.0000
  WHEN   NPM adjustment applied
  THEN   npm_adjusted_payment_usd = $500,000,000.0000 × 1.000000
         = $500,000,000.0000 (unchanged)
  AND    payment_status = 'READY FOR PAYMENT'

  AC-04: Payment Due Date — Standard Year (BR-009)
  GIVEN  calculation_year = 2025
  WHEN   the payment schedule is computed
  THEN   payment_due_date = DATE '2026-04-15' (April 15 of following year)
  AND    this date is NOT hardcoded — it is computed as:
         DATE(calculation_year + 1, 4, 15) adjusted for weekends/holidays

  AC-05: SUM of All 46 States = National Total
  GIVEN  all 46 state payments have been computed
  WHEN   a reconciliation check runs
  THEN   SUM(npm_adjusted_payment_usd) WHERE payment_status != 'NPM_DISPUTED'
         + SUM(gross_state_payment_usd) WHERE payment_status = 'NPM_DISPUTED'
         = gross_national_payment_usd
  AND    if this check fails, the calculation is flagged 'RECONCILIATION_ERROR'
         and Patricia Lawson is notified before any outputs are released

EDGE CASE ACCEPTANCE CRITERIA
───────────────────────────────

  AC-EC-01: Disputed NPM State (EC-004)
  GIVEN  state = 'NY' has is_npm_disputed = TRUE
  WHEN   state payment is computed
  THEN   npm_adjusted_payment_usd = NULL for New York
  AND    payment_status = 'NPM_DISPUTED — PAYMENT HELD'
  AND    the Power BI report shows New York's payment amount as 'HELD — PENDING'
         with gross_state_payment displayed as the contingent liability amount
  AND    the wire transfer instruction file does NOT include New York
  AND    a separate contingent liability line item shows the disputed amount

  AC-EC-02: April 15 Falls on Saturday (EC-008)
  GIVEN  calculation_year = 2026 (April 15, 2027 is a Tuesday — normal)
  AND    calculation_year = 2027 (April 15, 2028 is a Saturday)
  WHEN   the payment due date is computed
  THEN   for 2027 calculation: payment_due_date = DATE '2028-04-17' (Monday)
  AND    the US federal holiday calendar is consulted for April 17, 2028 —
         if also a holiday, shift to April 18, 2028
  AND    the logic uses a stored US_FEDERAL_HOLIDAYS reference table,
         NOT a hardcoded list of dates

  AC-EC-03: Post-Submission Data Correction (EC-010, BR-011)
  GIVEN  the FY2025 payment has been submitted (is_submitted = TRUE)
  AND    a minor ERP data correction arrives (0.08% variance)
  WHEN   the correction is loaded to Silver
  THEN   the Gold calculation for FY2025 with is_submitted = TRUE is NOT updated
  AND    the correction is logged in msa_exceptions with:
         error_category = 'POST_SUBMISSION_CORRECTION',
         error_message = 'Data correction received after submission.
                          Impact: ${calculated_difference}. Legal team to
                          determine if voluntary amendment is required.'
  AND    Patricia Lawson and Robert Chen are notified with the impact amount
  AND    a separate restatement version can be initiated by Legal if needed
         (this does NOT happen automatically)

DEFINITION OF DONE
────────────────────
  - [ ] AC-01: FY2023 state payment for all 46 states matches
        submitted amounts to 4 decimal places
  - [ ] AC-02, AC-03: NPM adjustment logic verified for 5 states
        with known prior-year adjustment rates
  - [ ] AC-04, EC-02: Due date logic tested for years 2024–2030
        where April 15 falls on various days
  - [ ] EC-01: NY disputed test confirms NULL payment and HELD status
  - [ ] EC-03: Post-submission freeze confirmed — Silver update does
        not alter submitted Gold calculation
  - [ ] Wire transfer file generation excludes disputed states
  - [ ] Robert Chen confirms legal accuracy of disputed state handling
───────────────────────────────────────────────────────────────────
```
