# Generated Output — Features (Epics)
> Generated from: BRD_MSA.md v1.0 + STTM_MSA.md v1.1
> Project: MSA Payment Analytics Platform — FIN-2025-011
> Generated: 2025-01-22 | Status: Draft — Pending Engineering Review

---

```
═══════════════════════════════════════════════════════════════════
FEATURE ID:       F-001
FEATURE NAME:     SAP Shipment Ingestion — Bronze to Silver
PLATFORM:         Databricks
DOMAIN:           Finance / Tax Compliance
PRIORITY:         Critical
STATUS:           Draft
═══════════════════════════════════════════════════════════════════

BUSINESS CONTEXT
────────────────
The MSA payment calculation begins with the company's own
cigarette and RYO shipment data from SAP ERP. Before any payment
can be computed, shipment records must be ingested daily, validated
for MSA eligibility, and converted to a standardised cigarette
equivalent unit count. Without clean, complete shipment data in
Silver, the RMS calculation cannot be initiated.

BUSINESS VALUE
────────────────
Replaces the manual export of SAP shipment data into the Excel
model, eliminating the risk of copy-paste errors and providing a
daily-updated, fully traceable Bronze layer that any investigation
or arbitration can inspect end-to-end.

SCOPE
────────────────
IN SCOPE:
  - Daily incremental ingestion from SAP ERP (VBAP, LIKP, MARA,
    KNA1, custom ZTMSA_CAT Z-table) to Bronze
  - Filtering, unit conversion and normalisation to Silver
  - ERP vs TTB reconciliation (FR-003 triggers this)
  - Exception routing for all excluded records

OUT OF SCOPE:
  - TTB filing ingestion (covered in F-002)
  - MSA payment calculation (covered in F-004)
  - Four separate-state settlements (MS, FL, TX, MN) — out of
    scope per BRD Q-001 pending Legal decision

SOURCE SYSTEMS:   SRC-001 SAP ERP

TARGET LAYERS
────────────────
  - [x] Bronze  — finance_prod.bronze.crm_shipments
  - [x] Silver  — finance_prod.silver.company_cigarette_shipments
  - [ ] Gold    — (not in scope for this feature)

BUSINESS RULES COVERED
────────────────────────
  - BR-002: Cigarettes — quantity in sticks
  - BR-003: RYO — convert oz to cigarette equivalents using 0.032500
  - BR-004: Eligibility filters (US states, MSA categories,
            non-intercompany, within calculation year)

EDGE CASES COVERED
────────────────────
  - EC-005: NULL destination_state — exclude, exception table
  - EC-006: RYO with NULL weight — exclude, exception table
  - EC-009: NULL/unclassified msa_product_category — exclude,
            exception table, alert Jennifer Park

DEFINITION OF DONE
────────────────────────────────────────────────────────────────────
  - [ ] All User Stories within this Feature accepted by Jennifer Park
  - [ ] Bronze row count reconciles to SAP extraction count ±0 rows
  - [ ] Silver cigarette_equivalent_units spot-checked for
        5 random shipment lines against manual calculation
  - [ ] All three exception categories (EC-005, EC-006, EC-009)
        tested with synthetic data — confirmed routed correctly
  - [ ] Notebook follows databricks-standards/notebooks.md 8-cell
  - [ ] Pipeline deployed to UAT, run signed off by Jennifer Park
═══════════════════════════════════════════════════════════════════


═══════════════════════════════════════════════════════════════════
FEATURE ID:       F-002
FEATURE NAME:     TTB Filing Ingestion & ERP Reconciliation
PLATFORM:         Databricks
DOMAIN:           Finance / Tax Compliance
PRIORITY:         Critical
STATUS:           Draft
═══════════════════════════════════════════════════════════════════

BUSINESS CONTEXT
────────────────
The TTB (Alcohol and Tobacco Tax and Trade Bureau) federal excise
tax filing is the legally submitted version of the company's
shipment volumes. Before using SAP shipment data in the MSA
calculation, it must be reconciled against the TTB filing to
within 0.5% at the national level. A variance ≥ 0.5% halts the
calculation — it indicates either a data processing error or a
TTB filing discrepancy that must be resolved before submission.

BUSINESS VALUE
────────────────
Provides automated reconciliation that previously took Jennifer
Park 2 days of manual work. More importantly, it creates a formal
record that the ERP and TTB figures were reconciled — a document
that is required for the audit package.

SCOPE
────────────────
IN SCOPE:
  - Monthly ingestion of TTB filing database to Bronze/Silver
  - Annual aggregation to calculation_year grain for reconciliation
  - Automated reconciliation report in Gold
  - Halt logic: if variance ≥ 0.5%, block downstream calculation

OUT OF SCOPE:
  - Correction of TTB filings (that is a Tax team process)
  - Amendment filings to TTB

BUSINESS RULES COVERED
────────────────────────
  - BR-005: ERP vs TTB reconciliation < 0.5% required

EDGE CASES COVERED
────────────────────
  - EC-003: Variance ≥ 0.5% — halt pipeline, exception alert

DEFINITION OF DONE
────────────────────────────────────────────────────────────────────
  - [ ] TTB ingestion tested with real TTB data for prior year
  - [ ] Reconciliation report verified against manually computed
        variance for FY2023 (known reference)
  - [ ] Halt logic tested: confirmed downstream F-004 does not
        run when reconciliation is in 'EXCEPTION' state
  - [ ] Alert confirmed received by Jennifer Park within 5 minutes
        of exception detection
═══════════════════════════════════════════════════════════════════


═══════════════════════════════════════════════════════════════════
FEATURE ID:       F-003
FEATURE NAME:     MSA Auditor File Ingestion
PLATFORM:         Databricks
DOMAIN:           Finance / Tax Compliance
PRIORITY:         Critical
STATUS:           Draft
═══════════════════════════════════════════════════════════════════

BUSINESS CONTEXT
────────────────
The MSA Auditor's certified annual data file (delivered by KPMG
via SFTP) is the sole authoritative source for total OPM industry
cigarette volumes — the denominator in the RMS formula. No
calculation can begin until this file arrives and is validated.
The file arrives unpredictably between late January and mid-March
each year and must be monitored continuously.

BUSINESS VALUE
────────────────
Eliminates the manual process of downloading, reformatting, and
keying the auditor file into the Excel model — historically the
step most likely to introduce copy errors in the denominator,
which directly impacts the payment amount.

SCOPE
────────────────
IN SCOPE:
  - Auto Loader monitoring of ADLS landing zone for file arrival
  - File validation: checksum, format, completeness
  - Bronze ingestion of raw auditor file
  - Silver aggregation to total OPM volume by calculation year
  - Version management for restated files

OUT OF SCOPE:
  - Requesting the file from KPMG (manual process)
  - Validating the auditor's underlying methodology

BUSINESS RULES COVERED
────────────────────────
  - BR-001: Auditor file is the ONLY permitted denominator source

EDGE CASES COVERED
────────────────────
  - EC-001: File not arrived by Feb 15 — automated reminder alert
  - EC-002: Auditor totals differ from preliminary estimate > 2%
  - EC-007: Restated file (file_version > '01') — version management

DEFINITION OF DONE
────────────────────────────────────────────────────────────────────
  - [ ] Auto Loader triggered correctly on file arrival in ADLS
  - [ ] EC-001 reminder tested: confirmed email sent at Feb 15
        when no file present (tested in UAT with date override)
  - [ ] EC-002 variance check tested with synthetic file where
        totals differ by 2.1% — confirmed alert generated and
        pipeline halted awaiting manual approval
  - [ ] EC-007 tested: second file version correctly sets
        is_latest_version = TRUE on new, FALSE on prior version
═══════════════════════════════════════════════════════════════════


═══════════════════════════════════════════════════════════════════
FEATURE ID:       F-004
FEATURE NAME:     MSA Payment Calculation Engine
PLATFORM:         Databricks
DOMAIN:           Finance / Tax Compliance — Legal
PRIORITY:         Critical
STATUS:           Draft
═══════════════════════════════════════════════════════════════════

BUSINESS CONTEXT
────────────────
This feature is the core of the platform: taking the validated
company shipment data (F-001), the TTB reconciliation (F-002),
and the auditor industry totals (F-003) and computing the annual
MSA payment obligation — RMS, Volume Adjustment Factor, gross
national payment, NPM adjustments per state, and final state-
level payment amounts. Every intermediate step is stored and
traceable. The calculation is versioned so prior years can be
restated and the submitted calculation is frozen once submitted.

BUSINESS VALUE
────────────────
Replaces the 18-year-old Excel model. Reduces calculation time
from 6 weeks to 5 business days. Eliminates the $4.2M class of
error by replacing manual formula entry with validated pipeline
logic. Creates the audit trail that legal proceedings require.

SCOPE
────────────────
IN SCOPE:
  - RMS calculation (BR-001)
  - Volume Adjustment Factor (BR-006)
  - Gross national payment calculation
  - State-level allocation (BR-008)
  - NPM adjustment per state (BR-007)
  - Calculation versioning and freeze (BR-011)
  - Prior year true-up / restatement (BR-010)

OUT OF SCOPE:
  - Bank wire transfer execution (pending Treasury decision Q-002)
  - Four separate-state settlements (Q-001)

BUSINESS RULES COVERED
────────────────────────
  - BR-001: RMS formula
  - BR-006: Volume Adjustment Factor (exponent = 0.980000)
  - BR-007: NPM adjustments per state
  - BR-008: State allocation percentages (legal constants)
  - BR-009: Payment due date calculation
  - BR-010: Prior year true-up
  - BR-011: Calculation freeze after submission

EDGE CASES COVERED
────────────────────
  - EC-004: Disputed NPM states — payment held, NULL displayed
  - EC-008: April 15 on weekend/holiday — next business day
  - EC-010: Post-submission data correction — logged but not
            applied to submitted calculation

DEFINITION OF DONE
────────────────────────────────────────────────────────────────────
  - [ ] RMS calculation verified for FY2023 against known result
        (the submitted figure) to 10 decimal places
  - [ ] VA Factor verified: POWER() and MIN() logic confirmed
        against manual calculation for 3 test years
  - [ ] Each of 46 state payments verified: SUM of all 46 states
        = gross national payment (to 4dp)
  - [ ] NPM disputed state confirmed: payment_status = 'NPM_DISPUTED'
        and npm_adjusted_payment_usd = NULL
  - [ ] EC-008 tested: confirmed April 15 logic for 3 years where
        April 15 falls on Saturday (2023), Sunday (2018), Monday (2024)
  - [ ] BR-011 freeze confirmed: after is_submitted = TRUE, any
        new Silver data does not alter the Gold calculation
  - [ ] Restatement tested with a synthetic prior-year correction —
        confirmed original version preserved, new version created
  - [ ] Signed off by Robert Chen and Patricia Lawson with FY2023
        parallel-run comparison
═══════════════════════════════════════════════════════════════════


═══════════════════════════════════════════════════════════════════
FEATURE ID:       F-005
FEATURE NAME:     MSA Executive Dashboard (Power BI)
PLATFORM:         Power BI (Direct Lake from Databricks Gold)
DOMAIN:           Finance / Legal Reporting
PRIORITY:         High
STATUS:           Draft
═══════════════════════════════════════════════════════════════════

BUSINESS CONTEXT
────────────────
Patricia Lawson, Robert Chen, and the Board need a clear,
executive-level view of the MSA calculation results: total
payment obligation, state-by-state breakdown, prior year
comparison, disputed states flagged visually, and calculation
status. The report must also be exportable as a PDF for the
Board pack and the audit submission.

SCOPE
────────────────
IN SCOPE:
  - National payment summary (current year vs prior year)
  - State payment table with NPM status flags
  - Calculation status page (pipeline status, exceptions count)
  - Prior year comparison and restatement history
  - PDF export-ready layout for Board pack
  - RLS: Finance Tax + Legal see all. Data Engineering sees
    calculation metadata only. No external access except
    Auditor read-only via row-filtered view.

OUT OF SCOPE:
  - Competitor market share breakdown (legally sensitive — not
    displayed even to internal users)
  - Wire transfer initiation (pending Q-002)

DEFINITION OF DONE
────────────────────────────────────────────────────────────────────
  - [ ] All measures validated against Gold table values
  - [ ] RLS tested for all 4 role types
  - [ ] PDF export tested: formatting intact, no truncated numbers
  - [ ] Approved by Patricia Lawson and Robert Chen
═══════════════════════════════════════════════════════════════════
```
