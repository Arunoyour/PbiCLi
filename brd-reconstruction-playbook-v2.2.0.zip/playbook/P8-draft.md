# Phase 8 — Write the BRD documents (shared rules)

**Follow:** `P0-phase-rules.md` · **Closes with:** APPROVED, per document

| Step | Command | File | Needs |
|---|---|---|---|
| 8A Functional BRD | `/brd-p8a-functional` | `P8A-functional.md` | P7 approved |
| 8B Technical BRD | `/brd-p8b-technical` | `P8B-technical.md` | P7 approved |
| 8C Summary BRD | `/brd-p8c-summary` | `P8C-summary.md` | 8A **and** 8B approved (whichever are registered) |

8A and 8B in either order. `/brd-p8-draft` asks which document to write and then follows that file. Only the documents registered in `PROJECT.md` → *BRD documents* are written.

## Templates
- Use each document's template exactly: section order, headings, numbering, tables, required fields. Normally these are the **detailed defaults** (`templates/default-functional-template.md`, `default-technical-template.md`, `default-summary-template.md`); a client template replaces a default if one was registered.
- Map content with `brd/template-map.md`.
- **Very detailed** (`content-depth.md`): every section is filled completely from the approved phases, the memory cards and the digests; everything found goes in with its evidence; repetition between sections is expected; lists are never shortened; long documents are written in batches, section by section, until complete.
- A section with no content: fill from the memory where possible (labelled); otherwise "To be completed" with the question, and it appears in the risks / open questions.
- Template instruction text ("describe here…") is removed once the section is filled.

## Presentation (all documents)
Write as a **senior Microsoft Word editor** as well as an analyst (`document-style.md`): lead every section with the point, plain confident business English, the right element for each kind of content (key-message, insight and risk panels, headline figures, flow and layer diagrams, captioned figures and tables, exact SQL panels), and an **editor's pass** over the whole document before presenting it. Presentation never changes a fact, a label or an id.

## Content rules (all documents)
- Built from the approved BRD definition, phases P1–P7 (with P5E and P6 answers) and, for detail, the memory cards, digests and logged queries of the in-scope objects (for the Summary, only from the approved Functional and Technical documents). **No unsupported facts:** detail taken from the memory keeps its label and evidence.
- **Current state only.** Scope carries the future-state line from phase 2.
- Every statement keeps its label and source; Confirmed items show who confirmed them. Pills in the HTML: `[[Confirmed]]`, `[[From evidence]]`, `[[Inferred]]`, `[[Conflicting]]`.
- **Same facts, same words.** A rule, figure, process step or object appearing in more than one document uses the same id (BR-, PUR-, OBJ-, R-) and the same statement; documents differ in depth and audience, never in facts.
- The cover shows the BRD name and the approved summary, the fence in one line (core count, interfaces), and the sign-off name.

## Files and versions
- `brd/functional/BRD-F_v<n>.md|.html` · `brd/technical/BRD-T_v<n>.md|.html` · `brd/summary/BRD-S_v<n>.md|.html`; one `CHANGELOG.md` per folder. First draft v1; each redraft v2, v3 … Never overwrite.
- Front matter: `kind: brd`, `document_type`, `brd_name`, `brd_version`, `memory_version`, `playbook_version: 2.2.0`, `approved_by` (sign-off name or "Pending"), the table **"Memory version per phase"**, and for the Summary `based_on: Functional vX, Technical vY`.
- Memory notice on the cover if any phase was approved on an older memory version.

## Keeping the documents in step
- A new version of one document after another was approved → `STATUS.md` marks the others **may need revisiting**, shown on their next page. Nothing changes by itself.
- Functional or Technical moving past the versions the Summary was based on → Summary **out of date** in `STATUS.md`; `/brd-p8c-summary` makes its next version.
- A correction in one document that affects shared facts is listed on the page as "Also affects: Technical 8.2, Summary 5" for the user to apply in that document's next round.

## Build (every document)
1. Write the `.md` (in batches for long documents; checklist in `brd-work/_progress-brd.md`).
2. Copy `templates/viewer.html` to the same name `.html` with the identical Markdown between the marker comments, front matter `kind: brd`.
3. The HTML is the review page. Feedback creates the next version.

## Before presenting
Optionally run `/brd-check` for this document. Self-check: the editor's pass is done (`document-style.md` §4); every template section present or marked; everything the template map assigned is present; only fence content; no future-state description; labels on every statement; ids and statements identical to the other documents; stamps correct.

## Word output (the final deliverable)
The final BRD is delivered as a **Word document in the client's template**. When a document is approved, tell the user the exact command (the agent has no terminal):
```
python tools/word-conversion/md_to_docx.py brd-work/brd/technical/BRD-T_v<n>.md --template "sources/template/word/<Technical template>.docx" --out "brd-work/brd/technical/BRD-T_v<n>.docx"
```
It keeps the template's cover, styles, headers, footers and page setup, fills the cover fields, and writes the BRD body in the template's heading, table and list styles (`tools/word-conversion/README.md`). Diagrams (```flow, ```layers) become diagram tables in Word. Without a client template, the script uses a clean default layout. PDF: print the HTML page, or save the Word file as PDF.
