# Large files

The agent can only hold a limited amount of text in one conversation and has no terminal, so it cannot read a huge file in one go or split it itself.

## 1. Limits
- **Large:** over **200 KB** or over **3,000 lines**. It must be split before it is read. (A larger file does not fit in one conversation; reading it slice by slice in one chat fills the conversation until Copilot stalls.)
- **Not large:** read in full in consecutive ranges, from line 1 to the last line, updating the reading ledger after each range (`reading-protocol.md`).

## 2. Finding and splitting large files
- **The split tool does the splitting, run by a person:** `python tools/split-large-files/split_export.py <file>` (`tools/split-large-files/README.md`). It splits logically, with no part over **150 KB and 2,500 lines**, and writes a short index and an object list next to the parts.
- **Optional, for many files at once:** `python tools/prepare-sources/prepare_sources.py` measures every source file, splits the large ones with the same tool and writes the inventory `brd-work/index/inventory.md`. If the inventory exists, the agent uses it for sizes and statuses.
- **The agent never tries to split a file.** When it meets a large file (from the inventory, the file size shown in the folder listing, or the line count the read tool reports on the first read), it stops reading that file, lists it as **waiting to be split** in `_progress.md` and on the review page, asks the user to run the split tool on it, and carries on with the other files. Running the same command again after the split continues with the parts.
- Word, PDF, Excel and image files: ask for a Markdown or CSV version (§5).

## 3. How split files are used
- The original is registered as **one evidence item**; locations are given as part and object or section (`EV-012, part 007, object sales.usp_calc_rebate`). Its parts are read in full; the original is not read again.
- Which part holds which object: search the split's object list (`<stem>.objects.csv`) or its short index; never read a long list whole when a search answers the question.
- Parts marked "continued" hold one unit (a procedure, a section, a job) spread over several parts: read them in order, in the same run where possible.

## 4. Splitting is logical
Never by size alone; a unit is never cut (details in `tools/split-large-files/README.md`):
- code and metadata exports: one object per unit, grouped by schema, then business group
- documents: one section per unit, parts never mix chapters
- job and pipeline definitions: one job or pipeline per unit

## 5. Files that cannot be split or read
Word, PDF, Excel, images: ask for a Markdown or CSV version (`tools/word-conversion/README.md`) and list the file as waiting.
