# Phase 3 — Process analysis — `/brd-p3-process`

**Follow:** `P0-phase-rules.md`, `content-depth.md` · **Closes with:** APPROVED · **Output:** `brd/P3-process.md`

## Purpose
Describe the business process step by step as the system actually runs it today, split into phases, and tie every step to the technology behind it, with the detail the documents need.

## Produce
1. **Process overview:** the end-to-end process as a ```flow block, split into phases (Phase 1 — …, Phase 2 — …).
2. **The seven points for every process and phase** (`content-depth.md` §2): operation start (trigger, schedule or interval, time zone, what must finish first), input source details (system, database, table, file or API, format, frequency, volume), current calculations, formulas (as implemented, with a worked example), tables involved (read / write), flow (first table → procedure → next table …), out stream (targets, reports, files, systems, consumers). Each with evidence.
3. **Step table:** for each step: what happens in business terms, who or what triggers it, the job / pipeline / procedure that performs it (OBJ ids), inputs and outputs, timing, and its label.
4. **Variants and exceptions:** month-end, corrections, reruns, late data, manual interventions found in documents, code or run history.
5. **Manual steps:** anything people do outside the system (from documents); mark clearly.
6. **Hand-offs:** where the process passes to or from another area, with the integration used.
7. **Missing points:** any of the seven points not found goes through the deep dig (`deep-dig.md`); still unknown → `### Q-…` with what was searched.
8. **Questions** where documents and code disagree on order or behaviour (`### Q-…`, `### CLM-…`).

## Review page
The process picture by phase, the seven-point table per process, the step table, variants, manual steps, hand-offs, questions.
