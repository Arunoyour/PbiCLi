---
kind: brd
title: <BRD name> — Technical BRD
subtitle: How the current system runs the business process, from the ground up
project: <Project name>
brd_name: <BRD name>
document_type: Technical
brd_version: v<n>
memory_version: <vX.Y>
memory_notice: <only if a newer memory exists>
status: Draft for review
date: <YYYY-MM-DD>
platform: <platforms>
playbook_version: 2.2.0
prepared_by: <operator> with the BRD Reconstruction agent
approved_by: Pending
feedback_file: brd-technical-review-v<n>.json
feedback_folder: brd-work/feedback/
---

<!-- Default Technical BRD template (playbook 2.2). Follow playbook/content-depth.md: everything found goes in, with evidence;
repetition between sections is expected; never shorten lists; exact names, values, schedules and SQL. Labels and sources on every
statement. Current state only. Business rules use the same ids and wording as the Functional BRD. Never write personal data or
business rows; name sensitive columns, never their values. Presentation: playbook/document-style.md (lead with the point, one
[!KEY] per main section, numbered "Figure n:" captions after diagrams and "Table n:" captions before important tables, an
editor's pass before presenting). Remove these comments as sections are filled. -->

## 0. Document control
| Version | Date | What changed | Memory version | Approved by |
|---|---|---|---|---|

Memory version per phase · Functional BRD version this document matches · Confirmed-by summary (person → number of statements)

## 1. Business scope
> [!KEY] <the one thing the reader must take away from this document, in one or two sentences>

```figures
<value> | <headline figure, e.g. stores opened per month>
<value> | <headline figure, e.g. procedures in scope>
<value> | <headline figure, e.g. integration points>
```

### 1.1 Purpose and business outcome
What the process exists to do, for whom, and why it matters (volumes, deadlines, money, compliance), each with its source.
### 1.2 Business areas, teams and users
| Team / user group | What they do in this process | What they receive or use | Source |
|---|---|---|---|
### 1.3 In scope
Every process, sub-process, report and data set covered, one line each, in business words, with the technical objects behind it.
### 1.4 Supporting and shared data
| Data | Owner area | What this process uses from it | Objects |
|---|---|---|---|
### 1.5 Hand-overs with other areas
| Direction | Other area / system | What is passed | When |
|---|---|---|---|
### 1.6 Out of scope
| Item | Why excluded | Source |
|---|---|---|
### 1.7 Current-state statement
"This document describes the system as it runs today." Future-state line from phase 2.

## 2. End-to-end process summary
### 2.1 Business context
The process in plain words from start to finish (one or two paragraphs), with the business events that drive it.
### 2.2 Key process characteristics
| Characteristic | Value | Evidence |
|---|---|---|
| Operation start (trigger, schedule, interval, time zone) | | |
| Input sources | | |
| Frequency and run window | | |
| Volumes (rows / files per run, growth) | | |
| Main calculations | | |
| Main tables written | | |
| Out streams and consumers | | |
| Systems and platforms involved | | |
| Manual steps | | |
| Typical duration, failure and rerun behaviour | | |
### 2.3 Process at a glance
```flow
Phase 1 — <name> | <what happens, main objects>
Phase 2 — <name> | <…>
Phase 3 — <name> | <…>
```
Figure 1: <the process in n phases>

## 3. Process flow by phase
One sub-section per phase, in run order. Each phase covers the seven points of `content-depth.md` §2 and every object it touches.

### 3.n Phase n — <name>
**Operation start:** trigger, schedule or interval, what must finish first.

**Input sources:** system · database / catalog · schema · table / file / API · format · frequency · volume.

**Pipelines and jobs in this phase**
| Pipeline / job | Platform | Trigger / interval | Activities in order (what each does) | Procedures / notebooks called (with parameters) | Upstream dependency | Downstream dependency |
|---|---|---|---|---|---|---|

**Stored procedures called in this phase (in call order)**
| Order | Procedure | Called by | Parameters (name, type, value passed) | Key functionality | Tables read | Tables written (operation) |
|---|---|---|---|---|---|---|

For each procedure, a block:
```
OBJ-0042 · Sales.sales.usp_calc_rebate · called by ADF pipeline PL_Rebate_Daily, activity "Calc rebate" (daily 02:00 UTC)
Purpose: …
Steps: 1 … 2 … 3 … (exact conditions and values)
Data transformation: sales.invoice.units, rate_card.rate → rebate_calc.rebate_amount (formula below)
Key query (EV-001 part 07, lines 112–140) — what it does: …
  SELECT …
```

**Data flow in this phase** (first table touched, then each procedure and table in order)
```flow
1 · <source table / file> | read by <pipeline activity>
2 · <procedure> | reads …, writes …
3 · <target table> | n rows per run
```

**Calculations and formulas**
| Calculation | Formula as implemented | Variables | Rounding / nulls / defaults | Worked example | Where (object, step) |
|---|---|---|---|---|---|

**Tables affected and how the data changes**
| Table | Operation | Columns changed | Transformation | Rows per run | Evidence |
|---|---|---|---|---|---|

**Out stream of this phase:** targets, files, reports, APIs, the next phase or system.

**Evidence for this phase:** EV, OBJ, LQ ids.

### 3.x Complete list of procedures called in this process
| # | Procedure | Database.schema | Phase | Called by (job / pipeline / procedure / API / application) | Purpose |
|---|---|---|---|---|---|

### 3.y End-to-end data flow
```flow
<first source> | …
<procedure> | …
<table> | …
<out stream> | …
```
Numbered list of every hop: source → object → target, with the operation and the evidence.

## 4. System data flow and data architecture
### 4.1 Landscape
```layers
Source systems | <…>
Integration (ADF, jobs, APIs) | <…>
SQL Server databases | <…>
Databricks catalogs | <…>
Consumers | <…>
```
### 4.2 Databases and catalogs
| Database / catalog | Server / workspace | Purpose in this process | Schema(s) | Schema type (staging, core, reporting, reference, audit …) | Table types held | Row counts (main tables, as of) | Key columns | Environment (note) |
|---|---|---|---|---|---|---|---|---|
### 4.3 Stored procedures
| Procedure | Database | Schema | Purpose | Parameters | Tables read | Tables written | Row counts of tables written | Key columns used | Called by (system, job, pipeline, API) | Used for / where | What happens inside |
|---|---|---|---|---|---|---|---|---|---|---|---|
### 4.4 ADF and Databricks pipelines and jobs
| Pipeline / job | Platform | Purpose | Trigger / schedule | Activities | Procedures / notebooks called | Source → target | Upstream dependencies | Downstream dependencies | Last run / duration / failures |
|---|---|---|---|---|---|---|---|---|---|
### 4.5 Applications and APIs that call the database
| Application / API | Calls (procedure, view, table) | Parameters | Direction | Frequency | Evidence |
|---|---|---|---|---|---|
### 4.6 Lineage
**Table level**
| Source | Via (pipeline / job / procedure / view) | Target | Operation | Evidence |
|---|---|---|---|---|

**Column level (main outputs)**
| Target column | Source column(s) | Transformation / formula | Evidence |
|---|---|---|---|

## 5. Integration points
| Integration | Type (DB link, linked server, ADF copy, API, file, web application, foreign catalog) | Direction | Protocol / method (direct DB connection, REST, SFTP, file share, JDBC/ODBC) | Counterpart system | Data exchanged (objects, key columns) | Frequency | Volume | Error handling | Owner | Evidence |
|---|---|---|---|---|---|---|---|---|---|---|

Where a field is not in the documents, take it from the code, the pipeline definitions or the data (`deep-dig.md`); if still unknown, say what was searched.

## 6. Technical constraints and controls
| Constraint / control | What it protects | Implementation (check, unique index, FK, trigger, validation step, pipeline condition, reconciliation, manual check) | Enforcement point (object, step) | Steps when it fails | Evidence |
|---|---|---|---|---|---|

Also: run-time limits, locking and concurrency, ordering constraints between jobs, retention rules, security constraints (as observed).

## 7. Detailed process analysis
### 7.1 Process inventory
| Process | Description | Purpose | Input | Output | Trigger | Objects | Evidence |
|---|---|---|---|---|---|---|---|
### 7.2 Technical analysis per process (one sub-section each)
Layer by layer (source → integration → staging → core → reporting / consumers): what happens, objects, conditions, timings, volumes, error handling, reruns, manual steps.
### 7.3 Business rules as implemented
| BR | Rule (same wording as Functional) | Object · step | Exact condition in code | Data check (LQ) | Differences (code vs documents vs data) |
|---|---|---|---|---|---|
### 7.4 Discovery findings
Everything else a reader should know: hard-coded values, commented-out logic, dead branches, duplicate copies, inactive objects, undocumented behaviour, data anomalies, surprises in run history. Each with evidence.

## 8. Key data objects and queries
### 8.1 Tables (one sub-section per in-scope table)
```
8.1.n  Sales.sales.invoice · OBJ-0007 · base table · Active · ≈ 4.2M rows (2019-01 → 2026-10, checked 2026-10-26)
Purpose: …
Written by: usp_load_invoice (INSERT, daily) · Read by: usp_calc_rebate, vw_rebate_statement, report "Monthly rebate"
```
| Column | Data type | Null | Key (PK / UK / FK → table) | What it stores | Code values and meanings | Consumed by (procedures, views) |
|---|---|---|---|---|---|---|

Keys and links · rules in the design (checks, defaults, computed columns) · history or soft-delete handling.
### 8.2 Views and functions
| Object | Purpose | Base tables | Filters and conditions | Consumers |
|---|---|---|---|---|
### 8.3 Code lists
| Column | Value | Meaning | Share of rows (LQ) | Source of meaning |
|---|---|---|---|---|
### 8.4 Key queries
One block per query (`content-depth.md` §6): id · used by · location in code · what it does · SQL.

## 9. Evidence collection
### 9.1 Process flow summary with evidence
| Step | What happens | Objects | Evidence (EV / OBJ / LQ / name) |
|---|---|---|---|
### 9.2 Evidence by section
| Section | Statement | Label | Evidence | How it was found (document, code, metadata, data query, person) |
|---|---|---|---|---|
### 9.3 Source files used
| EV | File (and part) | What it gave us | Sections |
|---|---|---|---|
### 9.4 Code evidence
| Object | Where the code came from (export file, part, lines; or live definition) | What it proves |
|---|---|---|
### 9.5 Data evidence (queries run)
| LQ | Purpose | SQL | Result | As of | Supports |
|---|---|---|---|---|---|
### 9.6 Answers from people
| Q | Answer | Given by | Date | Sections |
|---|---|---|---|---|
### 9.7 Open-question deep-dig trail
| Q / GAP | Where we looked (memory files, code, data) | What we found | Outcome |
|---|---|---|---|

## 10. Non-functional observations
Volumes and growth · run times · retention · availability · performance hotspots · error handling, logging and audit · security and access as observed (sensitive columns named, never their values).

## 11. Technical gaps, risks, assumptions and open questions
Same structure as Functional §12, technical items.

## Appendix A. Object inventory
| OBJ | Full name | Type | Ring | Activity | Card |
|---|---|---|---|---|---|
## Appendix B. Traceability matrix
| BR | Process step | Object | Column(s) | Functional section |
|---|---|---|---|---|
