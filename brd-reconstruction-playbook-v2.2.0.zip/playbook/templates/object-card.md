# Object card format (memory files 10-catalog/<db>.<schema>.md)

Every field below is filled when the evidence has it; a field the evidence does not have says "not found (searched: …)". The detail standard is `playbook/content-depth.md`.

```
### OBJ-0042 · Sales.sales.usp_calc_rebate · Stored procedure · Active
Database: Sales · Schema: sales · Server: SQLPROD01 (prod)
Source: EV-001 (part 07, lines 112–260), EV-003 (dependencies), EV-006 (usage), EV-011 (ADF pipeline PL_Rebate_Daily)
Purpose: computes the monthly rebate per customer (PUR-007, Inferred)
Parameters: @period_end DATE (no default) — last day of the period · @dry_run BIT = 0 — 1 skips the final write
Called by: ADF pipeline PL_Rebate_Daily, activity "Calc rebate" (SqlServerStoredProcedure), daily 02:00 UTC, @period_end = pipeline().parameters.periodEnd (EV-011)
           SQL Agent job "Month-end rebate" step 2 (EV-008) · application/API: none found (searched code, documents)
Reads: sales.invoice (status, units, invoice_date, customer_id), sales.rate_card (tier, rate), ref.calendar
Writes: INSERT sales.rebate_calc · UPDATE sales.invoice SET rebate_flag = 1
Calls: sales.usp_log_run · functions: dbo.fn_fiscal_period
What it does (From evidence):
  1. Selects invoices with status = 'PAID' and invoice_date in the period
  2. Applies tier thresholds from rate_card (units >= 5000 → tier 2)
  3. Subtracts credit notes where doc_type = 'CN'
  4. Writes one row per customer per period; sets rebate_flag = 1 on the invoices
Data transformation: SUM(invoice.units) → rebate_calc.units; rate_card.rate × SUM(invoice.net_amount) → rebate_calc.rebate_amount
Formulas: rebate_amount = ROUND(SUM(net_amount) * rate, 2) (lines 180–184)
Key query (lines 140–176) — selects paid invoices of the period with the customer's tier:
  SELECT i.customer_id, SUM(i.units) AS units, SUM(i.net_amount) AS net, r.rate
  FROM sales.invoice i JOIN sales.rate_card r ON ...
  WHERE i.status = 'PAID' AND i.invoice_date BETWEEN @start AND @period_end
  GROUP BY i.customer_id, r.rate
Business rules: BR-21 (tier threshold), BR-22 (credit notes)
Hard-coded values: 'PAID', 'CN', 5000 → 35-reference-data.md
Error handling: TRY/CATCH writes to dbo.error_log; no retry
Edge handling: nulls in rate → default 0; no handling of missing calendar rows
Dynamic SQL / outside references: none
Upstream: PL_Load_Invoices must finish first (dependsOn in EV-011) · Downstream: vw_rebate_statement, report "Monthly rebate"
Activity: Active — 92 executions since 2026-09-30, last 2026-10-17 (EV-006)
Data checks: LQ-0031 (3% of customers reach tier 2, 2026-10-26)
Open questions: Q-012
State: Current state
```

**Tables and views** add: table type (base, view, staging, history, lookup, fact, dimension, log), purpose, row count and date range (with the date checked), primary key, unique keys, foreign keys, every column (name, type, nullable, key, what it stores, **code values with meanings**), rules in the design (checks, defaults, computed columns, triggers), history or soft-delete handling, and a **Where used** block:

```
Where used:
| Object | Reads / writes | Conditions it applies to this table |
|---|---|---|
| OBJ-0042 usp_calc_rebate | reads, updates rebate_flag | status = 'PAID'; invoice_date in period |
| OBJ-0215 vw_rebate_statement | reads | rebate_flag = 1 |
```

**Jobs and pipelines:** platform, purpose, trigger and schedule or interval (with time zone), parameters, every activity or step in order (name, type, what it does, procedure or notebook called with parameters, source and target), upstream and downstream dependencies, linked services (server and database), failure handling and retries, last run, typical duration, failures.

**Integration points** (cards in `20-lineage.md` → Integrations): type, direction, protocol or method, counterpart system, data exchanged, frequency, volume, error handling, owner, evidence.
