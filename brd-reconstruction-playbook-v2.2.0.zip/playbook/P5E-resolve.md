# Phase 5E — Resolve open questions from the evidence — `/brd-p5e-resolve`

**Follow:** `P0-phase-rules.md`, `deep-dig.md`, `query-protocol.md` · **Closes with:** APPROVED · **Needs:** P5D approved · **Output:** `brd/P5E-resolve.md`, entries in `brd-work/query-log.md`

## Purpose
Answer as many open questions and gaps as possible from the memory files, the source digests, the live code and the data in SQL Server and Databricks, so phase 6 asks people only what the evidence cannot answer.

## Work
1. **Collect every open item:** the gap register from P5D, open questions from P1–P5C, open questions in the memory (`70-open-questions.md`) that touch this BRD's fence, and every field `content-depth.md` requires that is still empty (operation start, input sources, calculations, formulas, tables involved, flow, out streams, procedure parameters, pipeline schedules and dependencies, integration direction, protocol and frequency, column meanings, code values, row counts).
2. **Run the deep dig** (`deep-dig.md` §1) on each item, HIGH first, in batches; save the trail (`### DIG-nnn`) after each item. Respect the run budget: when it is reached, save and stop with "open a NEW chat and run /brd-p5e-resolve".
3. **Collect new leads** found on the way (extra objects, calculations, integrations, schedules, code meanings) under "New leads for the BRD".
4. **Hand over to people:** items still open, each with what was found, a suggested answer and who could probably answer. These are the input of phase 6.

## Review page
Counts (answered / partly / still open, by severity), the answered items with their evidence (`### DIG-…`, so each can be agreed or corrected), the items going to people (`### Q-…`), new leads, queries run. Then `review-loop.md`.

## On APPROVED
Answers agreed on the page count as From evidence (or Confirmed where the user confirmed them); later phases use them. Next command: `/brd-p6-clarify`.
