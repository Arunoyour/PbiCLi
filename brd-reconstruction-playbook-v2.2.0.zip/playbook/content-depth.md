# Content depth: write the BRD rich, from the ground up

A BRD that only names things is not enough. A reader who does not know the system must be able to see exactly how the process starts, what comes in, what is calculated and how, which tables and procedures are touched in which order, and what goes out, with the proof for each point. This file sets the minimum detail for every phase from 3 onwards and for every document.

## 1. The rule
- **Everything found goes in.** Every lead the memory, the digests, the code or the data checks give us is written into the BRD, with its evidence. Nothing is left in the memory "because it is too detailed".
- **Repetition is fine.** The same table, procedure or query may appear in the process flow, in the data architecture, in the process analysis and again in the evidence section. Each place gives the detail that section needs; never write "see above" instead of the facts.
- **No shortening.** No "etc.", "and others", "various tables", "some procedures". Name every one. Long lists are written in batches until complete.
- **Exact, not approximate.** Real object names (database.schema.object), real column names, real values (`status = 'PAID'`, `units >= 5000`, `DATEADD(day,-7,GETDATE())`), real schedules (`daily 02:00 UTC`, `every 15 minutes`), real row counts with their date.
- **Every statement has its label and evidence** (`labels-and-versions.md`). If something could not be found, say so and say where it was looked for (`deep-dig.md`).

## 2. For every process (or process step), always cover these seven points
| # | Point | What to write |
|---|---|---|
| 1 | **Operation start** | What starts it: schedule (cron / interval / time and time zone), event, file arrival, API call, user action, upstream job finishing; who or what triggers it |
| 2 | **Input source details** | Every input: system, server, database or catalog, schema, table / file / API, format, frequency, volume, how it arrives (pipeline, linked server, file drop, API) |
| 3 | **Current calculations** | Every calculation done today, in business words and in technical words, with where it happens (object and step) |
| 4 | **Formula** | The exact formula as implemented (copy the expression from the code), variables explained, rounding, defaults, null handling, a worked example with realistic numbers |
| 5 | **Tables involved** | Every table and view read or written, with read / write / update / delete / merge, and the key columns used |
| 6 | **Flow** | The order: first table touched → procedure → next table → … as a ```flow block and a numbered list |
| 7 | **Out stream** | Every output: target table, file, report, API, downstream system or job; format, frequency, who consumes it |

## 3. For every pipeline or job (ADF, Databricks job, SQL Agent job, notebook)
Name · platform · purpose · trigger and schedule or interval · parameters · every activity or task **in order** (activity name, type, what it does, what it calls: procedure, notebook, copy, lookup, web or API call) · procedures called and with which parameters · source and target of each copy · upstream dependencies (what must finish first) · downstream dependencies (what waits for it) · failure handling, retries, alerts · run history (last run, typical duration, failures) · evidence.

## 4. For every stored procedure, function or view
Name · database · schema · type · purpose · **parameters** (name, type, default, what it controls) · who calls it (job, pipeline activity, other procedure, application or API) · tables **read** and tables **written**, with the operation (INSERT / UPDATE / DELETE / MERGE / TRUNCATE) · **step-by-step logic** with the exact conditions and values · how the data is transformed (column in → column out) · calculations and formulas · error handling and logging · dynamic SQL or outside references · business rules implemented (BR ids) · activity (Active / Inactive / Unknown, with evidence) · **the key query attached** (the SQL statement copied from the code, with a plain-English line saying what it does).

## 5. For every table
Database · schema · table type (base table, view, staging, history, lookup / reference, fact, dimension, log, temp landing) · purpose · row count and date range (with the date checked) · key columns (primary key, unique keys, foreign keys) · **every column** with data type, nullable, key, what it stores in plain words, and **code values with meanings** (for example `is_active: 1 = active, 0 = inactive`) · who writes it and who reads it (procedures, pipelines, views, reports) · history or soft-delete handling.

## 6. For every query shown as proof
```
Query Q-T-07 · used by usp_calc_rebate step 2 (EV-001 part 07, lines 112–140)
What it does: selects paid invoices of the period, joins the rate card, and keeps customers with 5,000 units or more
SQL:
  SELECT ... FROM sales.invoice i JOIN sales.rate_card r ON ... WHERE i.status = 'PAID' AND ...
```
Copy the SQL exactly as it appears in the code or the export (trim only comments that add nothing). Never invent or "tidy" SQL. A data-check query (LQ) is shown the same way, with its result and date.

## 7. For every integration point
Integration name · type (database link, linked server, ADF copy, API / web service, file transfer, web application, message, Databricks foreign catalog) · direction (inbound / outbound / both) · protocol or method (direct database connection, REST API, SFTP, file share, JDBC/ODBC, linked server) · counterpart system · data exchanged (objects and key columns) · frequency · volume · owner · error handling · evidence. If the documents do not say, find it in the code, the pipeline definitions and the data (`deep-dig.md`) before marking it unknown.

## 8. For every constraint or control
Constraint · what it protects · how it is implemented (check constraint, unique index, foreign key, trigger, validation step in a procedure, pipeline condition, reconciliation, manual check) · **enforcement point** (object and step) · what happens when it fails · evidence.

## 9. Evidence for everything
Every section ends with, or points to, its evidence: source file and lines (EV), memory card (OBJ), data check (LQ with SQL and result), Genie or DevOps item, or the name of the person who confirmed it. The Technical BRD repeats all of it in its evidence section, grouped so a reviewer can check each statement.

## 10. Self-check before presenting (every phase from 3, every document)
- Every in-scope process has all seven points (§2), or the missing point says what was searched.
- Every in-scope pipeline, procedure, table, integration and constraint has the fields above.
- Every procedure and pipeline has its key query attached with a plain-English explanation.
- No "etc." and no unnamed groups of objects.
- Every statement has a label and evidence.
