# Phase 8B — Technical BRD — `/brd-p8b-technical`

**Follow:** `P8-draft.md`, `document-style.md`, `P0-phase-rules.md` and `content-depth.md` · **Closes with:** APPROVED · **Output:** `brd/technical/BRD-T_v<n>.md|.html`, `brd/technical/CHANGELOG.md`, then Word (`tools/word-conversion/`)

## Audience and depth
Technical readers who must maintain, change or rebuild the system. They must be able to follow the process from the first trigger to the last output, object by object, query by query, with the proof for every point. **Maximum detail is the goal:** everything the memory, the digests, the code and the data checks hold for the in-scope objects goes in, and repetition between sections is expected.

## Template (default: `templates/default-technical-template.md`)
| Section | Filled from |
|---|---|
| 0 Document control | as Functional, plus the Functional version it matches |
| 1 Business scope (very detailed) | BRD definition, P1, P2: purpose, teams, in scope with objects, supporting data, hand-overs, out of scope |
| 2 End-to-end process summary | P1, P3: business context; key process characteristics table (operation start, inputs, frequency, volumes, calculations, tables, out streams, systems, manual steps, duration and reruns); process at a glance by phase |
| 3 Process flow by phase | P3, P4, P5A, P5B, P5E: per phase the seven points (`content-depth.md` §2); every pipeline with its activities, interval and dependencies; every procedure in call order with parameters, functionality, tables read and written, transformation and **its key query attached and explained**; data flow (first table, procedure, next table …) as a ```flow block and numbered hops; calculations with formulas and worked examples; tables affected; out stream; evidence. Then the full list of procedures called and the end-to-end data flow |
| 4 System data flow and data architecture | P5A, memory cards and lineage, P5B: databases and catalogs (purpose, schema type, table types, row counts, key columns); every procedure (database, schema, purpose, parameters, tables read and written, row counts, key columns, called by including applications and APIs, used for, what happens); every ADF / Databricks pipeline (purpose, procedures called, source → target, upstream and downstream, run history); applications and APIs; table- and column-level lineage |
| 5 Integration points | P2, P5A, P5E: type, direction, protocol or method, counterpart, data exchanged, frequency, volume, error handling, owner; gaps filled from code, pipeline definitions and data |
| 6 Technical constraints and controls | P4, P5A: constraint, what it protects, implementation, enforcement point, steps on failure |
| 7 Detailed process analysis | P3, P5A, P5D, P5E: process inventory (description, purpose, input, output, trigger, objects); technical analysis layer by layer; business rules as implemented; discovery findings |
| 8 Key data objects and queries | P5A, memory cards, P5B: every in-scope table with every column (type, null, key, what it stores, code values with meanings, consumers); views and functions; code lists; key queries |
| 9 Evidence collection | everything above, regrouped: process flow summary with evidence, evidence by section, source files, code evidence, data queries with SQL and results, answers from people, deep-dig trail |
| 10 Non-functional observations | P5A, P5B |
| 11 Gaps, risks, assumptions, open questions | P5D, P5E, P7 |
| A Object inventory · B Traceability matrix | |

## How to write it
1. **Batch by phase and by object.** Write section 3 one phase at a time, sections 4 and 8 a few objects at a time (checklist in `brd-work/_progress-brd.md`), until every in-scope object is covered. Never shorten.
2. **Go back to the evidence.** For each object, open its memory card and the digest of its code (`notes/EV-…`) and take the exact steps, conditions, parameters and SQL from there. If the card lacks a field `content-depth.md` requires, look in the digests, then the live definition (read-only), then mark it with what was searched.
3. **Attach queries.** Every procedure, view and pipeline step that runs SQL shows its key query, copied exactly, with a one-line explanation.
4. **Code values in plain words.** Every flag and status column gets its meanings (`1 = active, 0 = inactive`), from code, reference data, data checks (P5B) or people (P6).
5. **Evidence section last**, built from everything written above, so every statement can be traced.

## Client template
When a client Technical template is registered, keep its headings and order (`11-template-map.md`). Every block this file requires still appears: under the closest client heading, or, where the template has no home for it, in an extra section "Additional technical detail" agreed at the template map. Never drop required detail because the template is shorter.

## Self-check before presenting
`content-depth.md` §10, plus: every in-scope object from the fence appears in sections 3, 4 and 8; every procedure has parameters, callers, tables read and written and a key query; every pipeline has trigger, activities and dependencies; every integration has direction, method and frequency (or what was searched); every column in an in-scope table is listed.
