# Connections: Databricks and SQL Server — `/brd-connect`

The memory build, the deep dig (`deep-dig.md`) and the data evidence phase depend on two live, read-only connections. `/brd-setup` sets them up; **`/brd-connect`** re-tests them at any time (after a token expires, a profile changes, or before a long run) and records the result in `PROJECT.md` → *Data connections*. It changes nothing else.

## 1. Databricks (Databricks SQL MCP server `dbsql`)
**Once, by the user:**
1. Copy `.vscode/mcp.dbsql.example.json` into `.vscode/mcp.json` (merge with any servers already there) and put in the workspace host. The token stays `${input:dbx_token}`: never in the file, never in chat.
2. Command Palette → **MCP: List Servers** → `dbsql` → **Start**. VS Code asks for the token in its own password box.
3. In Copilot Chat, open the tool picker for the **BRD Reconstruction** agent and tick the `dbsql` tools.
4. The token belongs to a **read-only** identity: `USE CATALOG`, `USE SCHEMA`, `SELECT`, `BROWSE` on the registered catalogs. For the deep dig, ask the admin also for `SELECT` on `system.access` (lineage) and `system.lakeflow` (jobs) if your workspace has system tables.

**Test (the agent, step by step, stopping at the first failure):**
| Step | Check | If it fails, say |
|---|---|---|
| D1 | `.vscode/mcp.json` has `dbsql` with the right host | "The connection file is missing or has another host; I've written it from the example. Start the server." |
| D2 | the `dbsql` tools are available to this agent | "The dbsql server is not running, or its tools are not ticked for this agent (tool picker)." |
| D3 | `SELECT current_user()` answers | the error in plain words: token expired · no access to the SQL warehouse · MCP servers not allowed by your organisation · wrong host |
| D4 | read-only rights: `SHOW GRANTS ON CATALOG <catalog>` (or `information_schema.catalog_privileges`) shows nothing that writes | "This identity can write. Status Blocked until a read-only token is used." |
| D5 | `SHOW SCHEMAS IN <catalog>` lists the registered schemas | "The catalog is not visible to this identity." |
| D6 (optional) | `SELECT 1 FROM system.access.table_lineage LIMIT 1` and `SELECT 1 FROM system.lakeflow.jobs LIMIT 1` | "System tables are not available; the deep dig uses DESCRIBE HISTORY and the job exports instead." |

## 2. SQL Server (MSSQL extension)
**Once, by the user:**
1. Install the **SQL Server (mssql)** extension (VS Code offers it from `.vscode/extensions.json`) and reload.
2. In the SQL Server view, add a **connection profile** per database (server, database, authentication). Passwords stay in the extension; never in chat or files.
3. Tick the `mssql_*` tools for the **BRD Reconstruction** agent (tool picker).
4. The login is **read-only**: `db_datareader` and `VIEW DEFINITION` on each registered database. For the deep dig, optionally `VIEW DATABASE STATE` (usage statistics) and, to read SQL Agent jobs and schedules, `SQLAgentReaderRole` in `msdb` (then register `msdb` as a database at setup).

**Test (step by step):**
| Step | Check | If it fails, say |
|---|---|---|
| S1 | the `mssql_*` tools are available | "Install the SQL Server (mssql) extension, reload, and tick its tools for this agent." |
| S2 | `mssql_connect` with the profile succeeds | the error in plain words: login failed · server not reachable from this machine (VPN, firewall) · certificate not trusted (tick *Trust server certificate* in the profile if your policy allows) |
| S3 | `mssql_get_connection_details` shows the registered server **and** database | "The profile points to another server or database. Fix the profile." |
| S4 | `SELECT permission_name FROM fn_my_permissions(NULL, 'DATABASE')` shows nothing that writes (INSERT, UPDATE, DELETE, ALTER, CREATE, EXECUTE, CONTROL) | "This login can write. Status Blocked until a read-only login is used." |
| S5 | `SELECT COUNT(*) FROM sys.sql_modules` > 0 | "VIEW DEFINITION is missing: queries work, but code must come from the export." |
| S6 (optional) | `SELECT TOP (1) name FROM msdb.dbo.sysjobs` (only if `msdb` is registered) | "No access to SQL Agent jobs; schedules come from documents or exports." |

## 3. After the tests
- Record each connection in `PROJECT.md` → *Data connections*: mode (Live / Relay / Genie), the last step that passed, status (OK / Blocked / Relay), date. Log every test query (`query-log.md`).
- A connection that cannot be made runs in **Relay** mode (`query-protocol.md` §7): the agent writes the queries, a person runs them and saves the results.
- Report in chat: one line per connection, ✓ or ✗ per step, and what to do next.

## 4. Common problems
| Symptom | Usual cause | What to do |
|---|---|---|
| Agent says "no Databricks tools" | server not started or tools not ticked | MCP: List Servers → dbsql → Start; tick the tools; new chat |
| `401` / `403` from dbsql | token expired or no warehouse access | MCP: List Servers → dbsql → Restart (asks for the token again); ask the admin for `CAN USE` on the warehouse |
| dbsql answers but sees no catalogs | identity lacks `USE CATALOG` / `BROWSE` | ask the admin; re-run `/brd-connect` |
| "MCP servers are disabled by your organisation" | Copilot policy | ask the GitHub admin to allow MCP servers; meanwhile use Relay |
| MSSQL tools missing | extension not installed, old version, or tools not ticked | install or update the extension, reload, tick the tools |
| MSSQL connects to the wrong database | profile default database | edit the profile's database; `mssql_get_connection_details` must match |
| Queries time out | big scans | follow `query-protocol.md` §3 (metadata first, sample, aggregate) |
