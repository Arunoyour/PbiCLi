# Phase 5A — Technical analysis — `/brd-p5a-technical`

**Follow:** `P0-phase-rules.md`, `content-depth.md`, `deep-dig.md` · **Closes with:** APPROVED · **Output:** `brd/P5A-technical.md`

## Purpose
Collect, for every in-scope object, the ground-level detail the Technical BRD needs (`content-depth.md` §3–§8), from the memory cards, the source digests, the live code and the data. This phase is the main source of sections 3–8 of the Technical BRD, so nothing found is left out.

## Produce, in batches (one database or one phase of the process at a time)
1. **Object inventory for this BRD:** every in-scope table, view, procedure, function, trigger, job, pipeline, notebook, application or API, with database, schema, type and activity (Active / Inactive / Unknown, with evidence).
2. **Processing order by phase:** the process split into phases (load, validate, calculate, publish …); for each phase, what starts it (schedule, interval, trigger, upstream job), the pipelines and jobs, the procedures in call order, and the data flow: first table touched → procedure → next table … (```flow plus numbered hops).
3. **Pipelines and jobs (ADF, Databricks, SQL Agent):** for each, `content-depth.md` §3: trigger and interval, parameters, every activity in order with what it does, procedures and notebooks called with their parameters, copy sources and targets, upstream and downstream dependencies, failure handling, run history. Read the pipeline JSON in full; check schedules and history read-only (`deep-dig.md` §3–§5).
4. **Procedures, functions and views:** for each, `content-depth.md` §4: database, schema, purpose, parameters (name, type, default, meaning), callers (job, pipeline activity, procedure, application, API), tables read and written with the operation, step-by-step logic with exact conditions and values, data transformation column by column, calculations and formulas (copied from the code), error handling, dynamic SQL, business rules implemented, and **the key query copied exactly with a plain-English explanation** (`content-depth.md` §6).
5. **Tables:** for each, `content-depth.md` §5: table type, purpose, row count and date range (with date), primary, unique and foreign keys, every column with type, nullability, what it stores and its code values with meanings, writers and readers, history or soft-delete handling.
6. **Databases and catalogs:** purpose in this process, schemas and their type (staging, core, reporting, reference, audit), table types held, main row counts, key columns.
7. **Integration points:** `content-depth.md` §7: type, direction, protocol or method, counterpart, data exchanged, frequency, volume, error handling. Look in linked servers, synonyms, `OPENQUERY` / `OPENROWSET` in code, ADF linked services and datasets, foreign catalogs, file paths, API activities, documents.
8. **Constraints and controls:** `content-depth.md` §8: check constraints, unique indexes, foreign keys, triggers, validation steps, pipeline conditions, reconciliations; implementation and enforcement point.
9. **Lineage for this BRD:** table and column level, source to consumer, with evidence for each link.
10. **Technical facts behind rules:** confirm or challenge each BR from phase 4 against the code; mismatches become `### CLM-…`.
11. **Discovery findings:** hard-coded values, commented-out logic, duplicate copies (`environments-and-duplicates.md`), inactive objects, dynamic SQL, objects referenced but not found.
12. **Fill the gaps as you go:** any required field that the memory lacks goes through the deep dig (`deep-dig.md`) right away; if still unknown, record what was searched.

## Review page
Inventory; processing order by phase with flow pictures; pipeline, procedure and table detail (the review page may show the detail in compact tables, but `brd/P5A-technical.md` keeps everything); integrations; constraints; lineage; rule-vs-code checks; discovery findings; fields still unknown with what was searched.
