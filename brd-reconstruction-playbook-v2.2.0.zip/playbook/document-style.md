# Document style: write like a senior Word editor

When the agent writes a BRD document (phases 8A, 8B, 8C), it works as two people at once: the **analyst** who owns the facts (`content-depth.md`, labels, evidence) and a **senior Microsoft Word editor** who owns how the document reads and looks. The editor never changes a fact, a label or an id; it changes how the facts are presented, so a business reader is impressed and a technical reader finds everything.

The Markdown the agent writes is turned into Word by `tools/word-conversion/md_to_docx.py`, which gives every element below its finished look (colour theme, cover, contents, tables, diagrams, callouts). So the editor's job in Markdown is to **use the right element for each kind of content**.

## 1. The editor's voice
- **Lead with the point.** Every section opens with one or two sentences that say what the reader needs to know, then the detail. No warm-up sentences.
- **Plain, confident business English.** Active voice ("The nightly job opens the store"), short sentences, concrete nouns, no filler ("it should be noted that", "in order to", "various"). Technical terms are explained once, in passing.
- **Numbers do the work.** Prefer "9 stores are waiting to open (28 Oct)" to "several stores are waiting". Every number keeps its source.
- **Consistent words.** One name per thing across the whole document (the glossary decides); same ids and statements as the other documents.
- **Headings tell the story.** Section headings follow the template; sub-headings are short and specific ("Phase 3 — Go live", not "Details").
- **Never decorate a fact.** No adjectives that the evidence does not support ("robust", "seamless"). Impressive comes from clarity and completeness, never from claims.

## 2. Elements and when to use them
| Content | Element in Markdown | How it looks in Word |
|---|---|---|
| The one thing a section must get across | `> [!KEY] …` | Navy "Key message" panel with a thick accent bar |
| A finding that changes how the reader sees the process | `> [!INSIGHT] …` | Saffron "Insight" panel |
| A worked calculation or example | `> [!EXAMPLE] …` | Teal "Worked example" panel |
| A risk, a warning, a decision needed | `> [!RISK]`, `> [!WARNING]`, `> [!DECISION]` | Red panel |
| A confirmed or provisional statement worth showing | `> [!CONFIRMED]`, `> [!PROVISIONAL]` | Green / amber panel |
| A short summary at the end of a long section | `> [!SUMMARY] …` | Navy "In summary" panel |
| A quote from a person or document | `> "…" — Name, date` (no tag) | Large italic pull quote with an accent rule |
| 3–5 headline numbers | ```figures block: `value | label` per line | Big-number tiles |
| A process or a sequence of phases | ```flow block: `Phase n — Name | what happens` per line | Numbered step cards with arrows (left to right up to 5 steps, top to bottom above that) |
| Layers of a system, from source to consumer | ```layers block: `Layer | what is in it` per line | Banded architecture diagram, darkest at the top |
| Relationships too complex for a flow (data model, call graph) | ```mermaid block | A sharp picture in the theme colours when the Mermaid CLI is installed (`--mermaid`) |
| Facts with the same fields | a table | Navy header row that repeats on every page, light banding, wide tables on landscape pages |
| SQL and code | ```sql block, copied exactly | Shaded monospace panel with an accent bar |
| Labels | `[[Confirmed]]`, `[[From evidence]]`, `[[Inferred]]`, `[[Conflicting]]` | Small coloured label chips |

## 3. Rules for a polished document
1. **Open strong.** The first page of content (Overview, or Business scope in the Technical BRD) has a `[!KEY]` panel and a ```figures row with the three to five numbers that matter most.
2. **One key message per main section**, at the top. Use `[!INSIGHT]` sparingly: at most one per section, only for real findings.
3. **Every diagram and every important table has a caption** on its own line: `Figure 2: Layers involved in the go-live phase` after a diagram, `Table 3: Stored procedures called in the go-live phase` before a table. Number them in order through the document. Refer to them in the text ("see Figure 2").
4. **Show, then tell.** Each process phase starts with its ```flow, followed by the explanation; each architecture section starts with its ```layers.
5. **Tables are for comparison, not for prose.** Short cell text; long explanations go in the paragraph after the table. Keep the columns the template asks for; never leave a column empty without "—" or "not found (searched: …)".
6. **Lists are short and parallel.** Same grammatical form in every item; no more than two levels.
7. **Code is evidence.** Introduce each query with one plain sentence ("selects the stores whose checklist is complete"), then the exact SQL.
8. **White space is part of the design.** One idea per paragraph; paragraphs of three to five lines; no walls of text.
9. **Finish each long section** (over two pages) with `[!SUMMARY]` in two or three lines.
10. **No visual noise:** no emoji, no ASCII art, no bold whole paragraphs, no ALL CAPS sentences, no exclamation marks.

## 4. The editor's pass (before presenting any document)
After the content is complete, read the whole document once as the editor and fix:
- the opening of every section (does it lead with the point?)
- every number (source, date, unit)
- every caption and its number, and every reference to it
- every table (right element? headers clear? cells short?)
- consistency of names, ids, tenses and spelling (British or American, as the client uses)
- the right callout for each message, none overused
- nothing implies more certainty than its label

Record "Editor's pass done" with the date on the review page.

## 5. Look and feel in Word
`md_to_docx.py` applies one colour theme to every element. With a client template it uses the **template's own theme colours** (so the document matches the client's branding) and keeps its styles, cover, headers and footers; without one, it uses the built-in **sapphire** theme (deep navy, teal, saffron) with a full-colour cover band, a contents page, a running header and "Page x of y". Other built-in themes: `emerald`, `graphite`, `royal`, `crimson` (`--theme`). See `tools/word-conversion/README.md`.
