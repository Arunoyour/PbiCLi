# Phase 4 — Business rules and controls — `/brd-p4-rules`

**Follow:** `P0-phase-rules.md`, `content-depth.md` · **Closes with:** APPROVED · **Output:** `brd/P4-rules.md`

## Purpose
List every business rule, calculation and control the area applies, exactly as implemented, so the client can confirm which rules are intended.

## Produce
1. **Rules (`BR-nn`), in batches:** rule in plain English; where it is implemented (OBJ id, procedure step, code location with lines); the exact condition copied from the code; where it is stated (documents, team BRD); label and state tag. Rules found only in code are From evidence for *what* and Inferred for *whether it is intended*.
2. **Calculations and formulas:** for every calculation, the formula as implemented (copied from the code), each variable and the column it comes from, rounding, defaults, null handling, a worked example with realistic numbers, and where it runs (object, step, phase).
3. **Code values:** every flag and status the rules depend on, with meanings (`1 = active, 0 = inactive`), from code, reference data, data checks or people.
4. **Controls and constraints:** validations, reconciliations, checks, approvals, alerts, database constraints (check, unique, foreign key, triggers); what each protects, how it is implemented, its enforcement point (object, step) and what happens on failure (`content-depth.md` §8).
5. **Rules without controls, and controls without a clear rule.**
6. **Conflicts:** rules stated differently in different sources (`### CLM-…`).
7. **Questions:** which rules are intended, thresholds that look arbitrary, behaviour on edge cases (`### Q-…`), after the deep dig (`deep-dig.md`).

## Review page
Rule table with labels, sources and exact conditions; calculation table with formulas and examples; code values; controls table; conflicts and questions.
