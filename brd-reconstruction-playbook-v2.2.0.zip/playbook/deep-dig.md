# Deep dig: answer open questions from the evidence before asking people

Every open question, gap and unknown field goes through this protocol **before** it is put to a person. People are asked only what the memory, the source files, the code and the data cannot answer, and they see what was found.

Used by: memory build stage 6, phase 5E (`P5E-resolve.md`), phase 6 (for new questions), the document phases (for missing required detail, `content-depth.md`) and Ask Me. All queries follow `query-protocol.md` (read-only, logged, no query over 15 minutes).

## 1. The steps, for each open item
1. **Restate it.** What exactly would answer it, and what kind of answer (a meaning, a value, a schedule, an object, a direction, a count).
2. **Make the search terms.** Object names (with and without schema), column names, code values, business terms and their synonyms, job and pipeline names, file names.
3. **Sweep the memory files.** Search every Markdown file of the memory for each term: `05-index.md`, `10-catalog/*`, `15-data-facts.md`, `20-lineage.md`, `30-business-map.md`, `35-reference-data.md`, `40-claims.md`, `60-future-state.md`, `70-open-questions.md`, `80-summaries.md` and **every digest** in `notes/`. Read each hit's card or section **in full** (`reading-protocol.md`). Note every lead: an object, a column, a value, a sentence in a document.
4. **Follow the connections.** From each lead, follow reads, writes, calls, called-by, job steps, pipeline activities, views and reports, up to three hops, and note the chain (`usp_load_invoice → sales.invoice → usp_calc_rebate → rebate_calc → vw_rebate_statement`). Search the digests of the source files those objects came from.
5. **Check the live code** (read-only, §3 and §4): definitions, parameters, dependencies, job steps, schedules, constraints, triggers, synonyms, linked servers.
6. **Check the data** (read-only): code value distributions, counts, date ranges, freshness, history of writes, lineage system tables, job run history.
7. **Conclude and record** in the step's output (`### DIG-nnn`):
   - **Answered:** the answer, labelled From evidence, with the chain of evidence (EV, OBJ, LQ ids).
   - **Partly answered:** what is known, what is still missing.
   - **Not answerable from the evidence:** why (no code, no data, intent only a person can give).
   Partly and not answered items go to people (phase 6) with the findings as context and the agent's suggested answer.
8. **Collect new leads.** Anything found on the way that enriches the BRD (an extra procedure, a calculation, an integration, a code value meaning, a schedule) is listed under "New leads for the BRD", so the document phases use it.

## 2. Limits
- Up to **8 queries per item** without asking; up to `PROJECT.md` → *Deep-dig query budget per run* (default 60) per run. Ask before going further.
- The run budget for reading still applies (`reading-protocol.md` §4); save the trail after each item.
- Only registered databases and catalogs (`query-protocol.md` §1). `msdb` (SQL Agent jobs) is used only if it was registered at setup.
- Never execute a procedure to see what it does: read its code.

## 3. SQL Server cookbook (read-only)
Replace `sales`, `usp_calc_rebate`, `invoice`, `rebate_flag` with the real names.

```sql
-- Definition of a procedure, view, function or trigger
SELECT OBJECT_DEFINITION(OBJECT_ID('sales.usp_calc_rebate')) AS definition;

-- Parameters of a procedure or function
SELECT p.parameter_id, p.name, TYPE_NAME(p.user_type_id) AS data_type, p.max_length, p.is_output, p.has_default_value
FROM sys.parameters p WHERE p.object_id = OBJECT_ID('sales.usp_calc_rebate') ORDER BY p.parameter_id;

-- What an object reads and writes (objects it references)
SELECT referenced_schema_name, referenced_entity_name, referenced_minor_name, is_selected, is_updated, is_insert_all
FROM sys.dm_sql_referenced_entities('sales.usp_calc_rebate', 'OBJECT');

-- Who references a table (procedures, views, functions, triggers)
SELECT OBJECT_SCHEMA_NAME(d.referencing_id) AS ref_schema, OBJECT_NAME(d.referencing_id) AS ref_object, o.type_desc
FROM sys.sql_expression_dependencies d JOIN sys.objects o ON o.object_id = d.referencing_id
WHERE d.referenced_entity_name = 'invoice' AND (d.referenced_schema_name = 'sales' OR d.referenced_schema_name IS NULL);

-- Code that mentions a column, value or table (also finds dynamic SQL and writers)
SELECT OBJECT_SCHEMA_NAME(m.object_id) AS sch, OBJECT_NAME(m.object_id) AS obj, o.type_desc
FROM sys.sql_modules m JOIN sys.objects o ON o.object_id = m.object_id
WHERE m.definition LIKE '%rebate_flag%';

-- Columns, types, nullability
SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, IS_NULLABLE, COLUMN_DEFAULT
FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'sales' AND TABLE_NAME = 'invoice' ORDER BY ORDINAL_POSITION;

-- Primary and unique keys
SELECT i.name AS index_name, i.is_primary_key, i.is_unique, c.name AS column_name, ic.key_ordinal
FROM sys.indexes i JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
WHERE i.object_id = OBJECT_ID('sales.invoice') AND (i.is_primary_key = 1 OR i.is_unique = 1) ORDER BY i.name, ic.key_ordinal;

-- Foreign keys
SELECT fk.name, OBJECT_NAME(fk.parent_object_id) AS from_table, cp.name AS from_column,
       OBJECT_NAME(fk.referenced_object_id) AS to_table, cr.name AS to_column
FROM sys.foreign_keys fk JOIN sys.foreign_key_columns fkc ON fkc.constraint_object_id = fk.object_id
JOIN sys.columns cp ON cp.object_id = fkc.parent_object_id AND cp.column_id = fkc.parent_column_id
JOIN sys.columns cr ON cr.object_id = fkc.referenced_object_id AND cr.column_id = fkc.referenced_column_id
WHERE fk.parent_object_id = OBJECT_ID('sales.invoice') OR fk.referenced_object_id = OBJECT_ID('sales.invoice');

-- Check constraints, defaults and triggers
SELECT name, definition FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID('sales.invoice');
SELECT name, definition FROM sys.default_constraints WHERE parent_object_id = OBJECT_ID('sales.invoice');
SELECT t.name, t.is_disabled, OBJECT_DEFINITION(t.object_id) AS definition FROM sys.triggers t WHERE t.parent_id = OBJECT_ID('sales.invoice');

-- Row count without scanning
SELECT SUM(p.rows) AS row_count FROM sys.partitions p WHERE p.object_id = OBJECT_ID('sales.invoice') AND p.index_id IN (0, 1);

-- Code values and their frequency (meaning comes from code, reference data or people)
SELECT TOP (50) rebate_flag, COUNT(*) AS n FROM sales.invoice WITH (NOLOCK) GROUP BY rebate_flag ORDER BY n DESC;

-- Last changes and use (DMVs may need VIEW SERVER STATE; if refused, note it)
SELECT name, create_date, modify_date FROM sys.objects WHERE object_id = OBJECT_ID('sales.usp_calc_rebate');
SELECT last_execution_time, execution_count FROM sys.dm_exec_procedure_stats WHERE object_id = OBJECT_ID('sales.usp_calc_rebate');
SELECT MAX(last_user_update) AS last_write FROM sys.dm_db_index_usage_stats WHERE database_id = DB_ID() AND object_id = OBJECT_ID('sales.invoice');

-- Linked servers and synonyms (integration points)
SELECT name, product, provider, data_source FROM sys.servers WHERE is_linked = 1;
SELECT name, base_object_name FROM sys.synonyms;

-- SQL Agent: jobs that run a procedure, their schedules and history (only if msdb is registered)
SELECT j.name AS job, s.step_id, s.step_name, s.subsystem, s.command
FROM msdb.dbo.sysjobs j JOIN msdb.dbo.sysjobsteps s ON s.job_id = j.job_id WHERE s.command LIKE '%usp_calc_rebate%';
SELECT j.name AS job, sc.name AS schedule, sc.freq_type, sc.freq_interval, sc.freq_subday_type, sc.freq_subday_interval, sc.active_start_time
FROM msdb.dbo.sysjobs j JOIN msdb.dbo.sysjobschedules js ON js.job_id = j.job_id JOIN msdb.dbo.sysschedules sc ON sc.schedule_id = js.schedule_id;
SELECT TOP (20) j.name, h.run_date, h.run_time, h.run_duration, h.run_status
FROM msdb.dbo.sysjobs j JOIN msdb.dbo.sysjobhistory h ON h.job_id = j.job_id WHERE h.step_id = 0 ORDER BY h.run_date DESC, h.run_time DESC;
```
Schedules: `freq_type` 4 = daily, 8 = weekly, 16 = monthly; `freq_subday_type` 4 = minutes, 8 = hours (interval in `freq_subday_interval`); `active_start_time` is HHMMSS.

## 4. Databricks cookbook (read-only)
```sql
-- Table definition, properties, columns
SHOW CREATE TABLE main.sales.invoice;
DESCRIBE TABLE EXTENDED main.sales.invoice;
SELECT column_name, data_type, is_nullable, comment FROM main.information_schema.columns
WHERE table_schema = 'sales' AND table_name = 'invoice' ORDER BY ordinal_position;

-- Keys (informational constraints in Unity Catalog)
SELECT tc.constraint_name, tc.constraint_type, kcu.column_name
FROM main.information_schema.table_constraints tc JOIN main.information_schema.key_column_usage kcu
  ON kcu.constraint_name = tc.constraint_name AND kcu.table_schema = tc.table_schema
WHERE tc.table_schema = 'sales' AND tc.table_name = 'invoice';

-- Size, files, last writes and who or what wrote them (job, notebook, pipeline)
DESCRIBE DETAIL main.sales.invoice;
DESCRIBE HISTORY main.sales.invoice LIMIT 20;

-- View and function definitions
SELECT table_name, view_definition FROM main.information_schema.views WHERE table_schema = 'sales';
SELECT routine_name, routine_definition FROM main.information_schema.routines WHERE routine_schema = 'sales';

-- Lineage (system tables, if your workspace exposes them)
SELECT source_table_full_name, target_table_full_name, entity_type, entity_id, MAX(event_time) AS last_seen
FROM system.access.table_lineage
WHERE target_table_full_name = 'main.sales.invoice' OR source_table_full_name = 'main.sales.invoice'
GROUP BY ALL ORDER BY last_seen DESC LIMIT 50;

-- Jobs and their runs (system tables, if available)
SELECT job_id, name FROM system.lakeflow.jobs WHERE name ILIKE '%rebate%' LIMIT 50;
SELECT job_id, period_start_time, period_end_time, result_state FROM system.lakeflow.job_run_timeline
WHERE job_id = '<job_id>' ORDER BY period_start_time DESC LIMIT 20;

-- Code values and their frequency
SELECT rebate_flag, COUNT(*) AS n FROM main.sales.invoice GROUP BY rebate_flag ORDER BY n DESC LIMIT 50;
```
System tables differ between workspaces. If one is not visible, say so and use the exports and pipeline definitions instead.

## 5. Pipelines, jobs and applications
- **ADF pipelines:** read the pipeline JSON in `sources/pipelines/` in full: activities in order, `SqlServerStoredProcedure` activities (procedure name and parameters), Copy activities (source and sink datasets), Lookup and Web activities (API calls), `dependsOn` (order and conditions), triggers (schedule recurrence, tumbling window, event), parameters and linked services (which server and database). If a pipeline is mentioned but its JSON is missing, ask the user for the ARM template or the ADF Git export.
- **Databricks jobs:** the job JSON export (tasks, notebooks, parameters, schedule) or the system tables above.
- **Applications and APIs:** look for callers in the code search (§3), in documents, in connection strings mentioned in documents, and in `system.query.history` or SQL Server DMVs if available. Record the calling system, never personal names or e-mail addresses.

## 6. Record of the dig
Each item gets a block in the step's output:
```
### DIG-014 · GAP-031 · What does order_status 'H' mean?
Searched memory: 05-index, 10-catalog/sales.orders, 35-reference-data, notes/EV-004, EV-019 → lead: usp_hold_orders sets 'H' (EV-019 lines 88–96)
Followed: usp_hold_orders → called by job "Credit hold check" (EV-022)
Live code: OBJECT_DEFINITION(sales.usp_hold_orders) (LQ-0201): sets 'H' when credit_limit exceeded
Data: 1.2% of orders are 'H' (LQ-0202, 2026-10-28)
Outcome: Answered — 'H' = on credit hold [[From evidence]] (EV-019, LQ-0201, LQ-0202)
```
