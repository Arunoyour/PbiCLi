#!/usr/bin/env python3
"""
docx_to_md.py - turn a client's Word BRD template (or any .docx) into Markdown the agent can read.

Standard library only. Keeps headings (by style or outline level), paragraphs, bullet / numbered items, tables and the text
of content controls. Pictures are noted as [picture].

    python tools/word-conversion/docx_to_md.py "sources/template/word/Technical BRD Template.docx" --out sources/template/technical.md
    python tools/word-conversion/docx_to_md.py sources/template/word        (every .docx/.dotx in the folder → sources/template/<name>.md)
"""
import argparse
import os
import re
import sys
import zipfile
import xml.etree.ElementTree as ET

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def style_names(z):
    names = {}
    try:
        root = ET.fromstring(z.read("word/styles.xml"))
    except KeyError:
        return names
    for s in root.iter(W + "style"):
        sid = s.get(W + "styleId")
        n = s.find(W + "name")
        lvl = None
        ppr = s.find(W + "pPr")
        if ppr is not None and ppr.find(W + "outlineLvl") is not None:
            lvl = int(ppr.find(W + "outlineLvl").get(W + "val")) + 1
        name = n.get(W + "val") if n is not None else sid
        m = re.match(r"(?i)heading\s*(\d)", name or "")
        if m:
            lvl = int(m.group(1))
        names[sid] = (name, lvl)
    return names


def text_of(el):
    out = []
    for node in el.iter():
        if node.tag == W + "t":
            out.append(node.text or "")
        elif node.tag == W + "tab":
            out.append(" ")
        elif node.tag in (W + "br", W + "cr"):
            out.append(" ")
        elif node.tag.endswith("}drawing") or node.tag.endswith("}pict"):
            out.append("[picture]")
    return "".join(out).strip()


def para_md(p, styles):
    ppr = p.find(W + "pPr")
    level, bullet = None, False
    if ppr is not None:
        ps = ppr.find(W + "pStyle")
        if ps is not None:
            name, lvl = styles.get(ps.get(W + "val"), (ps.get(W + "val"), None))
            level = lvl
            if name and re.search(r"(?i)list", name) and not level:
                bullet = True
        ol = ppr.find(W + "outlineLvl")
        if ol is not None and level is None:
            level = int(ol.get(W + "val")) + 1
        if ppr.find(W + "numPr") is not None and not level:
            bullet = True
    t = text_of(p)
    if not t:
        return ""
    if level and 1 <= level <= 6:
        return "#" * level + " " + t
    if bullet:
        return "- " + t
    return t


def table_md(tbl, styles):
    rows = []
    for tr in tbl.findall(W + "tr"):
        cells = []
        for tc in tr.findall(W + "tc"):
            parts = [text_of(p) for p in tc.iter(W + "p")]
            cells.append(" <br> ".join(p for p in parts if p).replace("|", "\\|"))
        rows.append(cells)
    if not rows:
        return ""
    n = max(len(r) for r in rows)
    rows = [r + [""] * (n - len(r)) for r in rows]
    out = ["| " + " | ".join(rows[0]) + " |", "|" + "---|" * n]
    out += ["| " + " | ".join(r) + " |" for r in rows[1:]]
    return "\n".join(out)


def walk(container, styles, out):
    for el in container:
        if el.tag == W + "p":
            s = para_md(el, styles)
            if s:
                out.append(s)
        elif el.tag == W + "tbl":
            out.append(table_md(el, styles))
        elif el.tag == W + "sdt":
            c = el.find(W + "sdtContent")
            if c is not None:
                walk(c, styles, out)


def convert(path, out_path):
    with zipfile.ZipFile(path) as z:
        styles = style_names(z)
        root = ET.fromstring(z.read("word/document.xml"))
    body = root.find(W + "body")
    out = []
    walk(body, styles, out)
    md = "\n\n".join(out) + "\n"
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(f"<!-- Converted from {os.path.basename(path)} by docx_to_md.py. Headings, tables and lists kept; check before use. -->\n\n")
        f.write(md)
    heads = sum(1 for l in out if l.startswith("#"))
    tables = sum(1 for l in out if l.startswith("|"))
    print(f"{path} → {out_path}: {heads} headings, {tables} tables, {len(out)} blocks")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source", help=".docx/.dotx file, or a folder of them")
    ap.add_argument("--out", help="output .md (file mode) or folder (folder mode); default sources/template/")
    a = ap.parse_args()
    if os.path.isdir(a.source):
        out_dir = a.out or os.path.join("sources", "template")
        os.makedirs(out_dir, exist_ok=True)
        files = [f for f in sorted(os.listdir(a.source)) if f.lower().endswith((".docx", ".dotx")) and not f.startswith("~$")]
        if not files:
            sys.exit("No .docx or .dotx files found in " + a.source)
        for f in files:
            stem = re.sub(r"[^\w-]+", "-", os.path.splitext(f)[0]).strip("-").lower()
            convert(os.path.join(a.source, f), os.path.join(out_dir, stem + ".md"))
    else:
        out = a.out or os.path.join("sources", "template", re.sub(r"[^\w-]+", "-", os.path.splitext(os.path.basename(a.source))[0]).strip("-").lower() + ".md")
        os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
        convert(a.source, out)


if __name__ == "__main__":
    main()
