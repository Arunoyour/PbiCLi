#!/usr/bin/env python3
"""
md_to_docx.py - write an approved BRD (Markdown) into the client's Word template.

Standard library only (Python 3.8+). No pandoc, no pip installs.

    python tools/word-conversion/md_to_docx.py BRD-T_v3.md --template "sources/template/word/Technical BRD Template.docx" --out BRD-T_v3.docx
    python tools/word-conversion/md_to_docx.py BRD-T_v3.md --out BRD-T_v3.docx          (no template: clean default layout)

What it keeps from the template: styles, fonts, headers, footers, page setup, numbering, and the cover.
Where the BRD goes:
  1. if the template has a paragraph containing {{BRD_BODY}}, the BRD replaces that paragraph (everything else is kept);
  2. otherwise everything before the template's first heading is kept (cover, document control) and the rest of the
     template body (its example sections and instruction text) is replaced by the BRD;
  3. --body all replaces the whole template body (only styles, headers, footers and page setup are kept).
Cover fields: {{title}}, {{brd_name}}, {{brd_version}}, {{date}} ... (any front-matter key) in the kept part are filled in.

Markdown handled: front matter, headings, paragraphs, **bold**, *italic*, `code`, [[Label]] pills, links, bullet and numbered
lists (nested), tables, code blocks (SQL etc.), > quotes and > [!NOTE] callouts, ```flow / ```layers / ```figures blocks
(drawn as diagram tables), ```mermaid (rendered to a picture if the Mermaid CLI "mmdc" is installed and --mermaid is given,
otherwise shown as source), HTML comments (dropped).
"""
import argparse
import os
import re
import shutil
import struct
import subprocess
import sys
import tempfile
import zipfile
from xml.sax.saxutils import escape

W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
DOC_CT = "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"
TPL_CT = "application/vnd.openxmlformats-officedocument.wordprocessingml.template.main+xml"
NUM_CT = "application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"
NUM_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering"
IMG_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image"

PILL_COLOURS = {"confirmed": "1E7350", "from evidence": "2F6DB5", "inferred": "9A5F0C", "conflicting": "B83A2A"}
BULLET_ABS, DECIMAL_ABS = 9101, 9102

# Colour themes. "primary" carries headings, table headers and the cover band; "accent" the rules, numbers and arrows;
# "highlight" the key figures and insight boxes. Tints are mixed automatically.
THEMES = {
    "sapphire": {"primary": "14213D", "accent": "0F7C80", "highlight": "D99A00"},   # deep navy, teal, saffron (default)
    "emerald":  {"primary": "0B3D2E", "accent": "1A8754", "highlight": "C9A227"},   # forest, emerald, gold
    "graphite": {"primary": "22272E", "accent": "4F6D7A", "highlight": "E07A1F"},   # charcoal, slate blue, copper
    "royal":    {"primary": "2A1B5C", "accent": "5B4BB7", "highlight": "E0A100"},   # indigo, violet, amber
    "crimson":  {"primary": "4A0E1C", "accent": "A23B48", "highlight": "C98B2B"},   # wine, crimson, bronze
}
FONTS = {"body": "Segoe UI", "head": "Segoe UI Semibold", "code": "Consolas"}


def mix(hex_colour, pct_white):
    """Mix a colour with white: pct_white 0.0 = colour, 1.0 = white."""
    r, g, b = (int(hex_colour[i:i + 2], 16) for i in (0, 2, 4))
    f = lambda c: int(c + (255 - c) * pct_white)
    return f"{f(r):02X}{f(g):02X}{f(b):02X}"


def make_theme(base):
    th = dict(base)
    th.update(
        primary_tint=mix(th["primary"], 0.90), accent_tint=mix(th["accent"], 0.88), highlight_tint=mix(th["highlight"], 0.85),
        zebra=mix(th["primary"], 0.955), line=mix(th["primary"], 0.72), muted="5A6478", ink="1E2433",
        risk="B3261E", risk_tint="FCEBEA", ok="1E7350", ok_tint="E6F4EC", code_bg="F6F8FA",
    )
    return th


def theme_from_template(files):
    """Read the template's Office theme colours so our tables, boxes and diagrams match the client's branding."""
    for name in files:
        if name.startswith("word/theme/") and name.endswith(".xml"):
            xml = files[name].decode("utf-8", "ignore")

            def col(tag):
                m = re.search(r"<a:" + tag + r">.*?(?:srgbClr val|lastClr)=\"([0-9A-Fa-f]{6})\"", xml, flags=re.S)
                return m.group(1).upper() if m else None
            dk2, a1, a2 = col("dk2"), col("accent1"), col("accent2")

            def dark(c):
                return c and sum(int(c[i:i + 2], 16) for i in (0, 2, 4)) < 330
            primary = dk2 if dark(dk2) else (a1 if dark(a1) else None)
            if primary and a1:
                return {"primary": primary, "accent": a1 if a1 != primary else (a2 or a1), "highlight": a2 or a1}
    return None


def x(s):
    return escape(s, {'"': "&quot;"})


# ----------------------------------------------------------------------------- Markdown parsing
def split_front_matter(text):
    meta = {}
    if text.startswith("---"):
        end = text.find("\n---", 3)
        if end != -1:
            for line in text[3:end].splitlines():
                m = re.match(r"\s*([A-Za-z_][\w-]*)\s*:\s*(.*)$", line)
                if m:
                    meta[m.group(1)] = m.group(2).strip().strip('"')
            text = text[end + 4:]
            text = text.split("\n", 1)[1] if "\n" in text else ""
    return meta, text


def parse_blocks(text):
    text = re.sub(r"<!--.*?-->", "", text, flags=re.S)
    lines = text.splitlines()
    blocks, i, para = [], 0, []

    def flush():
        if para:
            blocks.append(("p", " ".join(s.strip() for s in para)))
            para.clear()

    while i < len(lines):
        line = lines[i]
        s = line.strip()
        fence = re.match(r"^\s*(```|~~~)\s*([\w-]*)", line)
        if fence:
            flush()
            mark, lang = fence.group(1), fence.group(2).lower()
            body = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith(mark):
                body.append(lines[i])
                i += 1
            i += 1
            blocks.append(("code", lang, body))
            continue
        if not s:
            flush(); i += 1; continue
        h = re.match(r"^(#{1,6})\s+(.*?)\s*#*\s*$", s)
        if h:
            flush(); blocks.append(("h", len(h.group(1)), h.group(2))); i += 1; continue
        if re.match(r"^(\*\s*\*\s*\*|-\s*-\s*-|_\s*_\s*_)[\s*_-]*$", s):
            flush(); i += 1; continue
        if s.startswith("|"):
            flush()
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                rows.append(lines[i].strip()); i += 1
            blocks.append(("table", rows))
            continue
        if s.startswith(">"):
            flush()
            q = []
            while i < len(lines) and lines[i].strip().startswith(">"):
                q.append(re.sub(r"^\s*>\s?", "", lines[i])); i += 1
            blocks.append(("quote", q))
            continue
        lm = re.match(r"^(\s*)([-*+]|\d+[.)])\s+(.*)$", line)
        if lm:
            flush()
            items = []
            while i < len(lines):
                m2 = re.match(r"^(\s*)([-*+]|\d+[.)])\s+(.*)$", lines[i])
                if m2:
                    indent = len(m2.group(1).replace("\t", "    "))
                    items.append([indent, not m2.group(2)[0].isdigit(), m2.group(3)])
                    i += 1
                elif lines[i].strip() and items and (lines[i].startswith("  ") or lines[i].startswith("\t")) \
                        and not lines[i].strip().startswith("|"):
                    items[-1][2] += " " + lines[i].strip(); i += 1
                else:
                    break
            blocks.append(("list", items))
            continue
        para.append(line)
        i += 1
    flush()
    return blocks


def split_row(row):
    row = row.strip()
    if row.startswith("|"):
        row = row[1:]
    if row.endswith("|") and not row.endswith("\\|"):
        row = row[:-1]
    cells, cur, esc = [], "", False
    for ch in row:
        if esc:
            cur += ch; esc = False
        elif ch == "\\":
            esc = True
        elif ch == "|":
            cells.append(cur.strip()); cur = ""
        else:
            cur += ch
    cells.append(cur.strip())
    return cells


# ----------------------------------------------------------------------------- the writer
class Writer:
    def __init__(self, styles, page_width_twips=9360, sect=None, pg=(11906, 16838), margins=(1200, 1200), landscape=True, wide_cols=9,
                 theme=None):
        self.st = styles
        self.th = theme or make_theme(THEMES["sapphire"])
        self.figure_no = 0
        self.sect = sect or f'<w:sectPr><w:pgSz w:w="{pg[0]}" w:h="{pg[1]}"/><w:pgMar w:top="1300" w:right="{margins[1]}" w:bottom="1300" w:left="{margins[0]}" w:header="600" w:footer="600" w:gutter="0"/></w:sectPr>'
        self.pg_w, self.pg_h = pg
        self.land_width = pg[1] - margins[0] - margins[1]
        self.landscape = landscape
        self.wide_cols = wide_cols
        self.table_size = 18
        self.in_land = False
        self.pending_heads = 0
        self.breaks = 0
        self.parts = []
        self.num_instances = []          # (numId, abstractId)
        self.next_num = 9201
        self.images = []                 # (rId, filename, bytes)
        self.next_img = 1
        self.width = page_width_twips

    def add(self, xml, wide=False, head=False):
        """Append body XML. Wide tables (and the headings just before them) go into landscape sections."""
        if head:
            self.parts.append(xml)
            self.pending_heads += 1
            return
        if wide and not self.in_land:
            self.parts.insert(len(self.parts) - self.pending_heads, self.section_break(landscape=False))
            self.in_land = True
        elif not wide and self.in_land:
            self.parts.insert(len(self.parts) - self.pending_heads, self.section_break(landscape=True))
            self.in_land = False
        self.parts.append(xml)
        self.pending_heads = 0

    def finish(self):
        if self.in_land:
            self.parts.insert(len(self.parts) - self.pending_heads, self.section_break(landscape=True))
            self.in_land = False

    # inline ------------------------------------------------------------------
    def runs(self, text, base=None, size=None, colour=None, font=None):
        base = dict(base or {})
        out = []
        text = text.replace("<br>", "\n").replace("<br/>", "\n").replace("<br />", "\n")
        token = re.compile(r"(\[\[[^\]]+\]\]|\*\*[^*]+\*\*|(?<!\w)__[^_]+__(?!\w)|`[^`]+`|(?<![\w*])\*[^*\s][^*]*\*(?![\w*])|(?<!\w)_[^_\s][^_]*_(?!\w)|\[[^\]]+\]\([^)]+\))")
        for piece in token.split(text):
            if not piece:
                continue
            fmt = dict(base)
            t = piece
            if piece.startswith("[[") and piece.endswith("]]"):
                t = piece[2:-2]
                c = PILL_COLOURS.get(t.lower(), self.th["muted"])
                fmt.update(bold=True, colour=c, shade=mix(c, 0.88), size=fmt.get("size") or 16)
                t = "\u2009" + t + "\u2009"
            elif (piece.startswith("**") and piece.endswith("**")) or (piece.startswith("__") and piece.endswith("__")):
                t = piece[2:-2]; fmt["bold"] = True
            elif piece.startswith("`") and piece.endswith("`"):
                t = piece[1:-1]; fmt["code"] = True
            elif re.match(r"^\[[^\]]+\]\([^)]+\)$", piece):
                m = re.match(r"^\[([^\]]+)\]\(([^)]+)\)$", piece)
                t = m.group(1) + ("" if m.group(2).startswith("#") else " (" + m.group(2) + ")")
                fmt["colour"] = fmt.get("colour") or self.th["accent"]
            elif len(piece) > 2 and ((piece[0] == "*" and piece[-1] == "*") or (piece[0] == "_" and piece[-1] == "_")):
                t = piece[1:-1]; fmt["italic"] = True
            for k, line in enumerate(t.split("\n")):
                if k:
                    out.append("<w:r><w:br/></w:r>")
                out.append(self.run(line, fmt, size, colour, font))
        return "".join(out)

    def run(self, t, fmt, size=None, colour=None, font=None):
        rpr = []
        if fmt.get("code") or font:
            f = font or FONTS["code"]
            rpr.append(f'<w:rFonts w:ascii="{f}" w:hAnsi="{f}" w:cs="{f}"/>')
        if fmt.get("bold"):
            rpr.append("<w:b/>")
        if fmt.get("italic"):
            rpr.append("<w:i/>")
        if fmt.get("caps"):
            rpr.append("<w:caps/>")
        c = fmt.get("colour") or colour
        if c:
            rpr.append(f'<w:color w:val="{c}"/>')
        if fmt.get("spacing"):
            rpr.append(f'<w:spacing w:val="{fmt["spacing"]}"/>')
        sz = fmt.get("size") or size
        if sz:
            rpr.append(f'<w:sz w:val="{sz}"/><w:szCs w:val="{sz}"/>')
        if fmt.get("shade"):
            rpr.append(f'<w:shd w:val="clear" w:color="auto" w:fill="{fmt["shade"]}"/>')
        rp = f"<w:rPr>{''.join(rpr)}</w:rPr>" if rpr else ""
        return f'<w:r>{rp}<w:t xml:space="preserve">{x(t)}</w:t></w:r>'

    def para(self, inner, style=None, extra_ppr="", keep_next=False):
        ppr = ""
        if style:
            ppr += f'<w:pStyle w:val="{style}"/>'
        if keep_next:
            ppr += "<w:keepNext/>"
        ppr += extra_ppr
        return f"<w:p>{'<w:pPr>' + ppr + '</w:pPr>' if ppr else ''}{inner}</w:p>"

    def heading(self, level, text):
        sid = self.st.heading(level)
        self.add(self.para(self.runs(text), sid, keep_next=True), head=True)

    def paragraph(self, text):
        cap = re.match(r"^(\*\*|_|\*)?(Figure|Table|Diagram|Exhibit)\s+\d+[.:]", text)
        if cap:                                            # "Figure 3: ..." / "Table 2: ..." captions
            clean = re.sub(r"^[*_]+|[*_]+$", "", text)
            label, _, rest = clean.partition(":") if ":" in clean[:20] else clean.partition(".")
            inner = self.run(label.strip() + ":  ", {"bold": True, "colour": self.th["accent"]}, size=17) + self.runs(rest.strip(), {"italic": True}, size=17, colour=self.th["muted"])
            self.add(self.para(inner, self.st.get("caption") or self.st.get("normal"), '<w:spacing w:before="60" w:after="120"/>', keep_next=label.startswith("Table")))
            return
        self.add(self.para(self.runs(text), self.st.get("normal")))

    def new_num(self, abstract):
        nid = self.next_num
        self.next_num += 1
        self.num_instances.append((nid, abstract))
        return nid

    def lst(self, items):
        base = min(it[0] for it in items)
        levels = []
        ids = {}
        for indent, bullet, text in items:
            lvl = 0
            while levels and indent < levels[-1]:
                levels.pop()
            if not levels or indent > levels[-1]:
                levels.append(indent)
            lvl = min(len(levels) - 1, 8)
            key = (lvl, bullet)
            if key not in ids:
                ids[key] = self.new_num(BULLET_ABS if bullet else DECIMAL_ABS)
            # a shallower item restarts deeper numbering
            for k in list(ids):
                if k[0] > lvl:
                    del ids[k]
            ppr = f'<w:numPr><w:ilvl w:val="{lvl}"/><w:numId w:val="{ids[key]}"/></w:numPr><w:spacing w:after="40"/>'
            self.add(self.para(self.runs(text), self.st.get("list") or self.st.get("normal"), ppr))
        _ = base

    def code(self, lines, caption=None):
        if caption:
            self.add(self.para(self.runs(caption, {"italic": True}, size=17, colour=self.th["muted"]), self.st.get("normal"), keep_next=True))
        th = self.th
        lines = lines or [""]
        body = []
        for k, line in enumerate(lines):
            body.append(self.para(self.run(line.replace("\t", "    ") or " ", {"code": True}, size=16, colour="24292F"),
                                  self.st.get("normal"), '<w:spacing w:before="0" w:after="0" w:line="252" w:lineRule="auto"/>'))
        lang_bar = ""
        cell = (f'<w:tc><w:tcPr><w:tcW w:w="{self.width}" w:type="dxa"/>'
                f'<w:tcBorders><w:top w:val="nil"/><w:left w:val="single" w:sz="24" w:color="{th["accent"]}"/><w:bottom w:val="nil"/><w:right w:val="nil"/></w:tcBorders>'
                f'<w:shd w:val="clear" w:color="auto" w:fill="{th["code_bg"]}"/><w:tcMar><w:top w:w="100" w:type="dxa"/><w:left w:w="180" w:type="dxa"/><w:bottom w:w="100" w:type="dxa"/></w:tcMar></w:tcPr>'
                f'{lang_bar}{"".join(body)}</w:tc>')
        self.add(self.raw_table([[cell]], [self.width]))
        self.add(self.spacer())

    def spacer(self, after=80):
        return self.para("", self.st.get("normal"), f'<w:spacing w:before="0" w:after="{after}" w:line="120" w:lineRule="exact"/>')

    def raw_table(self, rows_of_cells, widths, centre=False, row_props=""):
        grid = "".join(f'<w:gridCol w:w="{w}"/>' for w in widths)
        jc = '<w:jc w:val="center"/>' if centre else ""
        out = [f'<w:tbl><w:tblPr><w:tblW w:w="{sum(widths)}" w:type="dxa"/>{jc}'
               '<w:tblBorders><w:top w:val="nil"/><w:left w:val="nil"/><w:bottom w:val="nil"/><w:right w:val="nil"/><w:insideH w:val="nil"/><w:insideV w:val="nil"/></w:tblBorders>'
               '<w:tblLayout w:type="fixed"/><w:tblCellMar><w:left w:w="0" w:type="dxa"/><w:right w:w="0" w:type="dxa"/></w:tblCellMar>'
               '<w:tblLook w:val="0000" w:firstRow="0" w:lastRow="0" w:firstColumn="0" w:lastColumn="0" w:noHBand="1" w:noVBand="1"/></w:tblPr>'
               f'<w:tblGrid>{grid}</w:tblGrid>']
        for cells in rows_of_cells:
            out.append(f'<w:tr><w:trPr><w:cantSplit/>{row_props}</w:trPr>{"".join(cells)}</w:tr>')
        out.append("</w:tbl>")
        return "".join(out)

    def box(self, content, width, fill=None, top=None, left=None, all_sides=None, pad=(90, 120, 90, 120), valign="center"):
        bd = []
        for side in ("top", "left", "bottom", "right"):
            spec = None
            if all_sides:
                spec = all_sides
            if side == "top" and top:
                spec = top
            if side == "left" and left:
                spec = left
            bd.append(f'<w:{side} w:val="single" w:sz="{spec[0]}" w:color="{spec[1]}"/>' if spec else f'<w:{side} w:val="nil"/>')
        shd = f'<w:shd w:val="clear" w:color="auto" w:fill="{fill}"/>' if fill else ""
        mar = (f'<w:tcMar><w:top w:w="{pad[0]}" w:type="dxa"/><w:left w:w="{pad[1]}" w:type="dxa"/>'
               f'<w:bottom w:w="{pad[2]}" w:type="dxa"/><w:right w:w="{pad[3]}" w:type="dxa"/></w:tcMar>')
        return (f'<w:tc><w:tcPr><w:tcW w:w="{width}" w:type="dxa"/><w:tcBorders>{"".join(bd)}</w:tcBorders>{shd}{mar}'
                f'<w:vAlign w:val="{valign}"/></w:tcPr>{content or "<w:p/>"}</w:tc>')

    def cell(self, content_xml, width, fill=None, borders=True, valign=None):
        tcpr = f'<w:tcW w:w="{width}" w:type="dxa"/>'
        if not borders:
            tcpr += '<w:tcBorders><w:top w:val="nil"/><w:left w:val="nil"/><w:bottom w:val="nil"/><w:right w:val="nil"/></w:tcBorders>'
        if fill:
            tcpr += f'<w:shd w:val="clear" w:color="auto" w:fill="{fill}"/>'
        if valign:
            tcpr += f'<w:vAlign w:val="{valign}"/>'
        return f"<w:tc><w:tcPr>{tcpr}</w:tcPr>{content_xml or '<w:p/>'}</w:tc>"

    def table_xml(self, rows, header=True, widths=None, fills=None, borders=True, align=None):
        th = self.th
        ncol = max(len(r) for r in rows)
        widths = widths or [self.width // ncol] * ncol
        grid = "".join(f'<w:gridCol w:w="{w}"/>' for w in widths)
        line = th["line"]
        bd = (f'<w:tblBorders><w:top w:val="single" w:sz="8" w:color="{th["primary"]}"/><w:left w:val="nil"/>'
              f'<w:bottom w:val="single" w:sz="8" w:color="{th["primary"]}"/><w:right w:val="nil"/>'
              f'<w:insideH w:val="single" w:sz="4" w:color="{line}"/><w:insideV w:val="single" w:sz="4" w:color="{mix(th["primary"], 0.85)}"/></w:tblBorders>') if borders else \
             '<w:tblBorders><w:top w:val="nil"/><w:left w:val="nil"/><w:bottom w:val="nil"/><w:right w:val="nil"/><w:insideH w:val="nil"/><w:insideV w:val="nil"/></w:tblBorders>'
        out = [f'<w:tbl><w:tblPr><w:tblW w:w="{sum(widths)}" w:type="dxa"/>{bd}'
               f'<w:tblLayout w:type="fixed"/><w:tblCellMar><w:top w:w="45" w:type="dxa"/><w:left w:w="100" w:type="dxa"/><w:bottom w:w="45" w:type="dxa"/><w:right w:w="100" w:type="dxa"/></w:tblCellMar>'
               f'<w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" w:firstColumn="0" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/></w:tblPr>'
               f"<w:tblGrid>{grid}</w:tblGrid>"]
        for ri, row in enumerate(rows):
            row = row + [""] * (ncol - len(row))
            is_head = header and ri == 0
            trpr = "<w:trPr><w:cantSplit/><w:tblHeader/></w:trPr>" if is_head else "<w:trPr><w:cantSplit/></w:trPr>"
            cells = []
            for ci, c in enumerate(row):
                if is_head:
                    fill = th["primary"]
                elif fills:
                    fill = fills[ri][ci]
                elif borders and header and ri % 2 == 0:
                    fill = th["zebra"]
                else:
                    fill = None
                if isinstance(c, tuple):         # pre-built xml
                    content = c[0]
                else:
                    jc = f'<w:jc w:val="{align}"/>' if align else ""
                    fmt = {"bold": True, "colour": "FFFFFF"} if is_head else {}
                    content = self.para(self.runs(c, fmt, size=self.table_size - (1 if is_head else 0)), self.st.get("normal"),
                                        f'<w:spacing w:before="0" w:after="0" w:line="252" w:lineRule="auto"/>{jc}')
                cells.append(self.cell(content, widths[ci], fill, borders, "center" if is_head else None))
            out.append(f"<w:tr>{trpr}{''.join(cells)}</w:tr>")
        out.append("</w:tbl>")
        return "".join(out)

    def table(self, raw_rows):
        rows = [split_row(r) for r in raw_rows]
        body = [r for r in rows if not all(re.match(r"^:?-{2,}:?$", c.replace(" ", "")) for c in r if c)]
        header = len(rows) > 1 and all(re.match(r"^:?-{1,}:?$", c.replace(" ", "")) for c in rows[1] if c)
        if not body:
            return
        ncol = max(len(r) for r in body)
        wide = self.landscape and ncol >= self.wide_cols
        width = self.land_width if wide else self.width
        size = 16 if ncol >= 9 else 18
        char = 112 if size == 16 else 125         # twips per character (bold header text, wide fonts), roughly
        # let long identifiers (schema.table_name) wrap at dots and underscores
        body = [[re.sub(r"(?<=\w)([_.])(?=\w)", "\\1\u200b", c) for c in r] for r in body]
        longest = [0] * ncol
        lens = [0] * ncol
        for r in body:
            for i, c in enumerate(r):
                plain = re.sub(r"[*`\[\]]", "", c)
                lens[i] = max(lens[i], min(len(plain), 45))
                longest[i] = max(longest[i], max((len(wd) for wd in re.split(r"[\s/\u200b]+", plain)), default=0))
        mins = [min(max(lw, 4) * char + 220, width // 2) for lw in longest]
        weights = [max(l, lw, 4) for l, lw in zip(lens, longest)]
        widths = [int(width * wgt / sum(weights)) for wgt in weights]
        # lift columns below their minimum, taking the space from the widest columns
        for _ in range(ncol * 2):
            short = [i for i in range(ncol) if widths[i] < mins[i]]
            if not short:
                break
            need = sum(mins[i] - widths[i] for i in short)
            donors = [i for i in range(ncol) if widths[i] > mins[i]]
            spare = sum(widths[i] - mins[i] for i in donors)
            if spare <= 0:
                break
            take = min(need, spare)
            for i in short:
                widths[i] += int((mins[i] - widths[i]) * take / need)
            for i in donors:
                widths[i] -= int((widths[i] - mins[i]) * take / spare)
        self.table_size = size
        self.add(self.table_xml(body, header=header, widths=widths), wide=wide)
        self.table_size = 18
        self.add(self.para("", self.st.get("normal"), '<w:spacing w:after="60"/>'), wide=wide)

    def section_break(self, landscape):
        """End the current section. landscape=False closes a portrait section (a landscape one follows); True closes the landscape one."""
        s = self.sect
        # every section keeps the template's header and footer; only the first keeps a different first page (cover)
        if self.breaks:
            s = s.replace("<w:titlePg/>", "")
        self.breaks += 1
        if landscape:
            s = re.sub(r'<w:pgSz[^>]*/>', f'<w:pgSz w:w="{self.pg_h}" w:h="{self.pg_w}" w:orient="landscape"/>', s)
        s = re.sub(r"<w:type [^>]*/>", "", s)
        # w:type goes after the header/footer references and before pgSz
        s = re.sub(r"(<w:pgSz)", r'<w:type w:val="nextPage"/>\1', s, count=1)
        return f"<w:p><w:pPr>{s}</w:pPr></w:p>"

    def flow(self, lines):
        """Process flow: numbered step cards with arrows. Up to 5 steps run left to right, more run top to bottom."""
        th = self.th
        steps = [l.strip() for l in lines if l.strip()]
        if not steps:
            return
        parsed = []
        for k, l in enumerate(steps):
            title, _, desc = l.partition("|")
            title = title.strip()
            m = re.match(r"^((?:Phase|Step|Stage)\s*\d+|\d+)\s*[·.:—–-]+\s*(.*)$", title, flags=re.I)
            label, name = (m.group(1), m.group(2)) if m else (f"Step {k + 1}", title)
            if label.isdigit():
                label = f"Step {label}"
            parsed.append((label.upper(), name, desc.strip()))

        def card(label, name, desc, width):
            c = self.para(self.run(label, {"bold": True, "colour": th["accent"], "spacing": 20}, size=15), self.st.get("normal"),
                          '<w:spacing w:before="0" w:after="20"/><w:jc w:val="center"/>')
            c += self.para(self.runs(name, {"bold": True, "colour": th["primary"]}, size=19), self.st.get("normal"),
                           '<w:spacing w:before="0" w:after="20"/><w:jc w:val="center"/>')
            if desc:
                c += self.para(self.runs(desc, size=16, colour=th["ink"]), self.st.get("normal"),
                               '<w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/><w:jc w:val="center"/>')
            return self.box(c, width, fill=th["primary_tint"], top=(24, th["accent"]), pad=(100, 100, 110, 100))

        def arrow(char, width):
            p = self.para(self.run(char, {"bold": True, "colour": th["accent"]}, size=26), self.st.get("normal"),
                          '<w:spacing w:before="0" w:after="0"/><w:jc w:val="center"/>')
            return self.box(p, width, valign="center", pad=(0, 0, 0, 0))

        n = len(parsed)
        if n <= 5:
            aw = 360
            cw = int((self.width - aw * (n - 1)) / n)
            cells = []
            for k, (label, name, desc) in enumerate(parsed):
                cells.append(card(label, name, desc, cw))
                if k < n - 1:
                    cells.append(arrow("\u25B6", aw))
            widths = []
            for k in range(n):
                widths.append(cw)
                if k < n - 1:
                    widths.append(aw)
            self.add(self.raw_table([cells], widths, centre=True))
        else:
            cw = int(self.width * 0.78)
            rows = []
            for k, (label, name, desc) in enumerate(parsed):
                rows.append([card(label, name, desc, cw)])
                if k < n - 1:
                    rows.append([arrow("\u25BC", cw)])
            self.add(self.raw_table(rows, [cw], centre=True))
        self.add(self.spacer(120))

    def layers(self, lines):
        """Layered architecture: each layer a band, darkest on top."""
        th = self.th
        items = [l.strip().partition("|") for l in lines if l.strip()]
        if not items:
            return
        w1 = int(self.width * 0.30)
        rows = []
        n = len(items)
        for k, (a, _, b) in enumerate(items):
            shade = mix(th["primary"], min(0.08 + k * (0.55 / max(n - 1, 1)), 0.7))
            left = self.para(self.runs(a.strip(), {"bold": True, "colour": "FFFFFF"}, size=18), self.st.get("normal"), '<w:spacing w:before="0" w:after="0"/>')
            right = self.para(self.runs(b.strip(), size=17), self.st.get("normal"), '<w:spacing w:before="0" w:after="0"/>')
            rows.append([self.box(left, w1, fill=shade, pad=(110, 160, 110, 120)),
                         self.box(right, self.width - w1, fill=th["primary_tint"], pad=(110, 160, 110, 120))])
        xml = self.raw_table(rows, [w1, self.width - w1])
        # white gap between bands
        xml = xml.replace("<w:tblCellMar>", '<w:tblCellSpacing w:w="30" w:type="dxa"/><w:tblCellMar>', 1) if False else xml
        self.add(xml)
        self.add(self.spacer(120))

    def figures(self, lines):
        """Key figures: big-number tiles."""
        th = self.th
        items = [l.strip().partition("|") for l in lines if l.strip()]
        if not items:
            return
        n = len(items)
        gap = 140
        w = int((self.width - gap * (n - 1)) / n)
        cells, widths = [], []
        for k, (a, _, b) in enumerate(items):
            c = self.para(self.runs(a.strip(), {"bold": True, "colour": th["primary"]}, size=40), self.st.get("normal"),
                          '<w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/>')
            c += self.para(self.runs(b.strip(), size=16, colour=th["muted"]), self.st.get("normal"), '<w:spacing w:before="20" w:after="0"/>')
            cells.append(self.box(c, w, fill=th["highlight_tint"], top=(24, th["highlight"]), pad=(120, 160, 120, 140), valign="top"))
            widths.append(w)
            if k < n - 1:
                cells.append(self.box("", gap, pad=(0, 0, 0, 0)))
                widths.append(gap)
        self.add(self.raw_table([cells], widths))
        self.add(self.spacer(140))

    def quote(self, lines):
        """Callout boxes: > [!KEY] key message, [!INSIGHT], [!EXAMPLE], [!NOTE], [!RISK], [!DECISION], [!CONFIRMED], [!PROVISIONAL]; plain > quote."""
        th = self.th
        kind = None
        if lines and re.match(r"^\[!(\w+)\]", lines[0].strip()):
            kind = re.match(r"^\[!(\w+)\]", lines[0].strip()).group(1).upper()
            lines = [re.sub(r"^\[!\w+\]\s*", "", lines[0].strip())] + lines[1:]
        paras = [p.strip() for p in "\n".join(lines).split("\n\n") if p.strip()] or [""]
        styles = {
            "KEY": ("Key message", th["primary"], th["primary_tint"]),
            "SUMMARY": ("In summary", th["primary"], th["primary_tint"]),
            "INSIGHT": ("Insight", th["highlight"], th["highlight_tint"]),
            "EXAMPLE": ("Worked example", th["accent"], th["accent_tint"]),
            "NOTE": ("Note", th["accent"], th["accent_tint"]),
            "TIP": ("Tip", th["accent"], th["accent_tint"]),
            "RISK": ("Risk", th["risk"], th["risk_tint"]),
            "WARNING": ("Warning", th["risk"], th["risk_tint"]),
            "IMPORTANT": ("Important", th["risk"], th["risk_tint"]),
            "DECISION": ("Decision needed", th["risk"], th["risk_tint"]),
            "CONFIRMED": ("Confirmed", th["ok"], th["ok_tint"]),
            "PROVISIONAL": ("Provisional", th["highlight"], th["highlight_tint"]),
        }
        if kind is None:                                   # a plain quotation: large italic, accent rule
            body = "".join(self.para(self.runs(p, {"italic": True}, size=21, colour=th["primary"]), self.st.get("normal"),
                                     '<w:spacing w:before="40" w:after="40"/>') for p in paras)
            cell = self.box(body, self.width, left=(24, th["highlight"]), pad=(80, 240, 80, 200))
        else:
            label, colour, fill = styles.get(kind, (kind.title(), th["accent"], th["accent_tint"]))
            body = self.para(self.run(label, {"bold": True, "caps": True, "colour": colour, "spacing": 16}, size=16), self.st.get("normal"),
                             '<w:spacing w:before="0" w:after="40"/>')
            body += "".join(self.para(self.runs(p), self.st.get("normal"), '<w:spacing w:before="0" w:after="40"/>') for p in paras)
            cell = self.box(body, self.width, fill=fill, left=(36, colour), pad=(120, 220, 100, 200))
        self.add(self.raw_table([[cell]], [self.width]))
        self.add(self.spacer(120))

    def image(self, png_bytes, caption=None):
        w, h = struct.unpack(">II", png_bytes[16:24])
        max_emu = int(self.width / 1440 * 914400)
        cx = min(max_emu, int(w * 9525))
        cy = int(h * cx / w)
        rid = f"rIdBrdImg{self.next_img}"
        name = f"brd_image{self.next_img}.png"
        n = self.next_img
        self.next_img += 1
        self.images.append((rid, name, png_bytes))
        drawing = (f'<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0" '
                   f'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing">'
                   f'<wp:extent cx="{cx}" cy="{cy}"/><wp:docPr id="{900 + n}" name="Diagram {n}"/>'
                   f'<a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
                   f'<a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
                   f'<pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">'
                   f'<pic:nvPicPr><pic:cNvPr id="{900 + n}" name="{name}"/><pic:cNvPicPr/></pic:nvPicPr>'
                   f'<pic:blipFill><a:blip r:embed="{rid}" xmlns:r="{R_NS}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
                   f'<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>'
                   f'</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>')
        self.add(self.para(drawing, self.st.get("normal"), '<w:jc w:val="center"/>'))
        if caption:
            self.add(self.para(self.runs(caption, {"italic": True}, size=17, colour=self.th["muted"]), self.st.get("caption") or self.st.get("normal"),
                               '<w:spacing w:before="40" w:after="160"/><w:jc w:val="center"/>'))


def render(blocks, writer, mermaid=False):
    levels = [b[1] for b in blocks if b[0] == "h"]
    top = min(levels) if levels else 1
    diag = 0
    for b in blocks:
        kind = b[0]
        if kind == "h":
            writer.heading(min(b[1] - top + 1, 6), b[2])
        elif kind == "p":
            writer.paragraph(b[1])
        elif kind == "list":
            writer.lst(b[1])
        elif kind == "table":
            writer.table(b[1])
        elif kind == "quote":
            writer.quote(b[1])
        elif kind == "code":
            lang, body = b[1], b[2]
            if lang == "flow":
                writer.flow(body)
            elif lang == "layers":
                writer.layers(body)
            elif lang == "figures":
                writer.figures(body)
            elif lang == "mermaid":
                diag += 1
                png = mermaid_png("\n".join(body), writer.th) if mermaid else None
                if png:
                    writer.image(png, f"Figure {diag}")
                else:
                    writer.code(body, f"Diagram {diag} (Mermaid source; render with --mermaid when the Mermaid CLI is installed)")
            else:
                writer.code(body, None)


def mermaid_png(src, theme=None):
    exe = shutil.which("mmdc")
    if not exe:
        return None
    tmp = tempfile.mkdtemp()
    try:
        inp, out, cfg = os.path.join(tmp, "d.mmd"), os.path.join(tmp, "d.png"), os.path.join(tmp, "c.json")
        open(inp, "w", encoding="utf-8").write(src)
        th = theme or make_theme(THEMES["sapphire"])
        import json
        json.dump({"theme": "base", "themeVariables": {
            "primaryColor": "#" + th["primary_tint"], "primaryBorderColor": "#" + th["primary"], "primaryTextColor": "#" + th["primary"],
            "lineColor": "#" + th["accent"], "secondaryColor": "#" + th["accent_tint"], "tertiaryColor": "#" + th["highlight_tint"],
            "fontFamily": "Segoe UI, Calibri, Arial", "fontSize": "15px"}}, open(cfg, "w"))
        subprocess.run([exe, "-i", inp, "-o", out, "-b", "white", "-s", "3", "-c", cfg], check=True, capture_output=True, timeout=180)
        return open(out, "rb").read()
    except Exception as e:
        print(f"  note: Mermaid diagram not rendered ({e}); shown as source", file=sys.stderr)
        return None
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ----------------------------------------------------------------------------- template handling
class Styles:
    def __init__(self, styles_xml):
        self.xml = styles_xml
        self.by_name = {}
        for m in re.finditer(r'<w:style\b([^>]*)>(.*?)</w:style>', styles_xml, flags=re.S):
            attrs, body = m.group(1), m.group(2)
            sid = re.search(r'w:styleId="([^"]+)"', attrs)
            name = re.search(r'<w:name w:val="([^"]+)"', body)
            typ = re.search(r'w:type="([^"]+)"', attrs)
            if sid and name:
                self.by_name[(typ.group(1) if typ else "paragraph", name.group(1).lower())] = sid.group(1)
        self.added = []
        self.map = {
            "normal": self.find("paragraph", ["normal"]),
            "list": self.find("paragraph", ["list paragraph"]),
            "caption": self.find("paragraph", ["caption"]),
            "table": self.find("table", ["table grid", "brd table"]),
        }
        self.heads = {}
        for lvl in range(1, 7):
            sid = self.find("paragraph", [f"heading {lvl}"])
            if not sid:
                sid = f"BRDHeading{lvl}"
                size = {1: 32, 2: 26, 3: 23, 4: 21, 5: 20, 6: 20}[lvl]
                self.added.append(
                    f'<w:style w:type="paragraph" w:styleId="{sid}"><w:name w:val="BRD Heading {lvl}"/><w:basedOn w:val="{self.map["normal"] or "Normal"}"/>'
                    f'<w:next w:val="{self.map["normal"] or "Normal"}"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before="{240 if lvl < 3 else 160}" w:after="80"/>'
                    f'<w:outlineLvl w:val="{lvl - 1}"/></w:pPr><w:rPr><w:b/><w:color w:val="0F2C4C"/><w:sz w:val="{size}"/><w:szCs w:val="{size}"/></w:rPr></w:style>')
            self.heads[lvl] = sid

    def find(self, typ, names):
        for n in names:
            if (typ, n) in self.by_name:
                return self.by_name[(typ, n)]
        return None

    def get(self, key):
        return self.map.get(key)

    def heading(self, lvl):
        return self.heads[max(1, min(lvl, 6))]

    def patched(self):
        if not self.added:
            return self.xml
        return self.xml.replace("</w:styles>", "".join(self.added) + "</w:styles>")


def numbering_xml(existing, instances, accent="0F7C80"):
    def abstract(aid, bullet):
        lv = []
        for i in range(9):
            ind = 360 * (i + 1)
            if bullet:
                char = ["•", "◦", "▪"][i % 3]
                lv.append(f'<w:lvl w:ilvl="{i}"><w:start w:val="1"/><w:numFmt w:val="bullet"/><w:lvlText w:val="{char}"/><w:lvlJc w:val="left"/>'
                          f'<w:pPr><w:ind w:left="{ind}" w:hanging="260"/></w:pPr><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri"/><w:color w:val="{accent}"/></w:rPr></w:lvl>')
            else:
                fmt = ["decimal", "lowerLetter", "lowerRoman"][i % 3]
                lv.append(f'<w:lvl w:ilvl="{i}"><w:start w:val="1"/><w:numFmt w:val="{fmt}"/><w:lvlText w:val="%{i + 1}."/><w:lvlJc w:val="left"/>'
                          f'<w:pPr><w:ind w:left="{ind}" w:hanging="300"/></w:pPr><w:rPr><w:b/><w:color w:val="{accent}"/></w:rPr></w:lvl>')
        return f'<w:abstractNum w:abstractNumId="{aid}"><w:multiLevelType w:val="hybridMultilevel"/>{"".join(lv)}</w:abstractNum>'
    abstracts = abstract(BULLET_ABS, True) + abstract(DECIMAL_ABS, False)
    nums = "".join(f'<w:num w:numId="{nid}"><w:abstractNumId w:val="{aid}"/>'
                   f'<w:lvlOverride w:ilvl="0"><w:startOverride w:val="1"/></w:lvlOverride></w:num>' for nid, aid in instances)
    if existing:
        # abstractNum elements must come before num elements
        m = re.search(r"<w:num\b", existing)
        if m:
            existing = existing[:m.start()] + abstracts + existing[m.start():]
        else:
            existing = existing.replace("</w:numbering>", abstracts + "</w:numbering>")
        return existing.replace("</w:numbering>", nums + "</w:numbering>")
    return (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:numbering xmlns:w="{W_NS}">{abstracts}{nums}</w:numbering>')


def default_styles(th):
    p, a, f = th["primary"], th["accent"], FONTS
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="{W_NS}"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="{f['body']}" w:hAnsi="{f['body']}" w:cs="{f['body']}" w:eastAsia="{f['body']}"/>
<w:color w:val="{th['ink']}"/><w:sz w:val="19"/><w:szCs w:val="19"/><w:lang w:val="en-GB"/></w:rPr></w:rPrDefault>
<w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="276" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>
<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>
<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:before="0" w:after="120"/></w:pPr>
<w:rPr><w:rFonts w:ascii="{f['head']}" w:hAnsi="{f['head']}"/><w:color w:val="FFFFFF"/><w:sz w:val="56"/><w:szCs w:val="56"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/>
<w:pPr><w:keepNext/><w:keepLines/><w:pageBreakBefore/><w:pBdr><w:bottom w:val="single" w:sz="12" w:space="6" w:color="{a}"/></w:pBdr><w:spacing w:before="0" w:after="240"/><w:outlineLvl w:val="0"/></w:pPr>
<w:rPr><w:rFonts w:ascii="{f['head']}" w:hAnsi="{f['head']}"/><w:color w:val="{p}"/><w:sz w:val="40"/><w:szCs w:val="40"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/>
<w:pPr><w:keepNext/><w:keepLines/><w:spacing w:before="320" w:after="120"/><w:outlineLvl w:val="1"/></w:pPr>
<w:rPr><w:rFonts w:ascii="{f['head']}" w:hAnsi="{f['head']}"/><w:color w:val="{a}"/><w:sz w:val="28"/><w:szCs w:val="28"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Heading3"><w:name w:val="heading 3"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/>
<w:pPr><w:keepNext/><w:keepLines/><w:spacing w:before="240" w:after="80"/><w:outlineLvl w:val="2"/></w:pPr>
<w:rPr><w:rFonts w:ascii="{f['head']}" w:hAnsi="{f['head']}"/><w:color w:val="{p}"/><w:sz w:val="23"/><w:szCs w:val="23"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Heading4"><w:name w:val="heading 4"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/>
<w:pPr><w:keepNext/><w:spacing w:before="200" w:after="60"/><w:outlineLvl w:val="3"/></w:pPr>
<w:rPr><w:rFonts w:ascii="{f['head']}" w:hAnsi="{f['head']}"/><w:caps/><w:color w:val="{a}"/><w:spacing w:val="10"/><w:sz w:val="18"/><w:szCs w:val="18"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Caption"><w:name w:val="caption"/><w:basedOn w:val="Normal"/><w:rPr><w:i/><w:color w:val="{th['muted']}"/><w:sz w:val="17"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="TOC1"><w:name w:val="toc 1"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:pPr><w:tabs><w:tab w:val="right" w:leader="dot" w:pos="9350"/></w:tabs><w:spacing w:before="120" w:after="40"/></w:pPr><w:rPr><w:b/><w:color w:val="{p}"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="TOC2"><w:name w:val="toc 2"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:pPr><w:tabs><w:tab w:val="right" w:leader="dot" w:pos="9350"/></w:tabs><w:spacing w:before="0" w:after="20"/><w:ind w:left="300"/></w:pPr><w:rPr><w:color w:val="{th['ink']}"/></w:rPr></w:style>
<w:style w:type="table" w:styleId="TableGrid"><w:name w:val="Table Grid"/><w:tblPr><w:tblBorders><w:top w:val="single" w:sz="4" w:color="{th['line']}"/><w:left w:val="single" w:sz="4" w:color="{th['line']}"/><w:bottom w:val="single" w:sz="4" w:color="{th['line']}"/><w:right w:val="single" w:sz="4" w:color="{th['line']}"/><w:insideH w:val="single" w:sz="4" w:color="{th['line']}"/><w:insideV w:val="single" w:sz="4" w:color="{th['line']}"/></w:tblBorders></w:tblPr></w:style>
</w:styles>"""


DEFAULT_STYLES = None   # built per theme by default_styles()


def default_package(th, meta):
    sect = ('<w:sectPr><w:headerReference w:type="default" r:id="rIdHeader1"/><w:footerReference w:type="default" r:id="rIdFooter1"/>'
            '<w:footerReference w:type="first" r:id="rIdFooter2"/>'
            '<w:pgSz w:w="11906" w:h="16838"/>'
            '<w:pgMar w:top="1300" w:right="1200" w:bottom="1200" w:left="1200" w:header="560" w:footer="560" w:gutter="0"/><w:titlePg/></w:sectPr>')
    doc_name = x(meta.get("brd_name") or meta.get("title") or "Business Requirements Document")
    doc_type = x((meta.get("document_type") or "") + (" BRD" if meta.get("document_type") else ""))
    ver = x(meta.get("brd_version") or "")
    small = f'<w:rPr><w:color w:val="{th["muted"]}"/><w:sz w:val="15"/></w:rPr>'
    header = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:hdr xmlns:w="{W_NS}"><w:p><w:pPr>'
              f'<w:pBdr><w:bottom w:val="single" w:sz="4" w:space="4" w:color="{th["line"]}"/></w:pBdr>'
              f'<w:tabs><w:tab w:val="right" w:pos="9500"/></w:tabs><w:spacing w:after="0"/></w:pPr>'
              f'<w:r><w:rPr><w:b/><w:color w:val="{th["primary"]}"/><w:sz w:val="15"/></w:rPr><w:t xml:space="preserve">{doc_name}</w:t></w:r>'
              f'<w:r>{small}<w:t xml:space="preserve">  ·  {doc_type}</w:t></w:r><w:r>{small}<w:tab/></w:r>'
              f'<w:r><w:rPr><w:b/><w:color w:val="{th["accent"]}"/><w:sz w:val="15"/></w:rPr><w:t xml:space="preserve">{ver}</w:t></w:r></w:p></w:hdr>')

    def footer_xml(page_no=True):
        runs = (f'<w:r>{small}<w:t xml:space="preserve">Confidential · prepared with the BRD Reconstruction playbook</w:t></w:r>')
        if page_no:
            fld = lambda instr: (f'<w:r>{small}<w:fldChar w:fldCharType="begin"/></w:r><w:r>{small}<w:instrText xml:space="preserve"> {instr} </w:instrText></w:r>'
                                 f'<w:r>{small}<w:fldChar w:fldCharType="separate"/></w:r><w:r>{small}<w:t>1</w:t></w:r><w:r>{small}<w:fldChar w:fldCharType="end"/></w:r>')
            runs += f'<w:r>{small}<w:tab/></w:r><w:r>{small}<w:t xml:space="preserve">Page </w:t></w:r>{fld("PAGE")}<w:r>{small}<w:t xml:space="preserve"> of </w:t></w:r>{fld("NUMPAGES")}'
        return (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:ftr xmlns:w="{W_NS}"><w:p><w:pPr>'
                f'<w:pBdr><w:top w:val="single" w:sz="4" w:space="4" w:color="{th["line"]}"/></w:pBdr><w:tabs><w:tab w:val="right" w:pos="9500"/></w:tabs></w:pPr>{runs}</w:p></w:ftr>')
    settings = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:settings xmlns:w="{W_NS}"><w:defaultTabStop w:val="720"/>'
                '<w:updateFields w:val="true"/><w:compat><w:compatSetting w:name="compatibilityMode" w:uri="http://schemas.microsoft.com/office/word" w:val="15"/></w:compat></w:settings>')
    return {
        "[Content_Types].xml": ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                                '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                                '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                                '<Default Extension="xml" ContentType="application/xml"/>'
                                f'<Override PartName="/word/document.xml" ContentType="{DOC_CT}"/>'
                                '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
                                '<Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/>'
                                '<Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/>'
                                '<Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/>'
                                '<Override PartName="/word/footer2.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/>'
                                '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
                                '</Types>'),
        "_rels/.rels": ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
                        '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
                        '</Relationships>'),
        "word/_rels/document.xml.rels": ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                                         '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                                         '<Relationship Id="rIdStyles1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
                                         '<Relationship Id="rIdSettings1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/>'
                                         '<Relationship Id="rIdHeader1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target="header1.xml"/>'
                                         '<Relationship Id="rIdFooter1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/>'
                                         '<Relationship Id="rIdFooter2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer2.xml"/>'
                                         '</Relationships>'),
        "word/document.xml": (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="{W_NS}" xmlns:r="{R_NS}">'
                              f'<w:body>{{COVER}}{sect}</w:body></w:document>'),
        "word/styles.xml": default_styles(th),
        "word/settings.xml": settings,
        "word/header1.xml": header,
        "word/footer1.xml": footer_xml(True),
        "word/footer2.xml": footer_xml(False),
        "docProps/core.xml": ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties '
                              'xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
                              'xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title></dc:title></cp:coreProperties>'),
    }


def default_cover(meta, w, toc=True):
    """Cover: a full-width colour band with the title, a details panel, then a table of contents."""
    th = w.th
    doc_type = meta.get("document_type")
    kicker = (doc_type + " business requirements document") if doc_type else "Business requirements document"
    title = meta.get("brd_name") or meta.get("title") or "Business Requirements Document"
    band = w.para(w.run(kicker, {"bold": True, "caps": True, "colour": th["highlight"], "spacing": 30}, size=18), w.st.get("normal"),
                  '<w:spacing w:before="0" w:after="160"/>')
    band += w.para(w.runs(title, {"bold": True, "colour": "FFFFFF"}, size=60), w.st.get("normal"),
                   '<w:spacing w:before="0" w:after="120" w:line="216" w:lineRule="auto"/>')
    if meta.get("subtitle"):
        band += w.para(w.runs(meta["subtitle"], size=24, colour=mix(th["primary"], 0.75)), w.st.get("normal"), '<w:spacing w:before="0" w:after="0"/>')
    lines = [w.para("", w.st.get("normal"), '<w:spacing w:before="1400" w:after="0"/>'),
             w.raw_table([[w.box(band, w.width, fill=th["primary"], pad=(700, 520, 700, 520), valign="top")]], [w.width]),
             w.raw_table([[w.box("", w.width, fill=th["accent"], pad=(0, 0, 0, 0))]], [w.width], row_props='<w:trHeight w:val="90" w:hRule="exact"/>')]
    rows = [(k, meta[key]) for k, key in [("Project", "project"), ("Document", "document_type"), ("Version", "brd_version"),
                                         ("Status", "status"), ("Date", "date"), ("Memory version", "memory_version"),
                                         ("Prepared by", "prepared_by"), ("Approved by", "approved_by")] if meta.get(key)]
    if rows:
        lines.append(w.para("", w.st.get("normal"), '<w:spacing w:before="520" w:after="0"/>'))
        cells = []
        half = (len(rows) + 1) // 2
        cols = [rows[:half], rows[half:]]
        cw = (w.width - 300) // 2
        for col in cols:
            c = ""
            for k, v in col:
                c += w.para(w.run(k, {"bold": True, "caps": True, "colour": th["accent"], "spacing": 12}, size=14), w.st.get("normal"), '<w:spacing w:before="60" w:after="0"/>')
                c += w.para(w.runs(v, {"colour": th["primary"]}, size=21), w.st.get("normal"), '<w:spacing w:before="0" w:after="80"/>')
            cells.append(w.box(c, cw, left=(12, th["line"]), pad=(0, 200, 0, 100), valign="top"))
        lines.append(w.raw_table([[cells[0], w.box("", 300, pad=(0, 0, 0, 0)), cells[1]]], [cw, 300, cw]))
    if toc:
        lines.append(toc_block(w))
    return "".join(lines)


def toc_block(w):
    th = w.th
    out = w.para('<w:r><w:br w:type="page"/></w:r>', w.st.get("normal"))
    out += w.para(w.run("Contents", {"bold": True, "colour": th["primary"]}, size=36), w.st.get("normal"),
                  f'<w:pBdr><w:bottom w:val="single" w:sz="12" w:space="6" w:color="{th["accent"]}"/></w:pBdr><w:spacing w:before="0" w:after="240"/>')
    fld = ('<w:r><w:fldChar w:fldCharType="begin" w:dirty="true"/></w:r><w:r><w:instrText xml:space="preserve"> TOC \\o "1-2" \\h \\z \\u </w:instrText></w:r>'
           '<w:r><w:fldChar w:fldCharType="separate"/></w:r>'
           f'<w:r><w:rPr><w:i/><w:color w:val="{th["muted"]}"/></w:rPr><w:t>Right-click here and choose Update Field to build the table of contents.</w:t></w:r>'
           '<w:r><w:fldChar w:fldCharType="end"/></w:r>')
    return out + w.para(fld, w.st.get("normal"))


def fill_fields(xml, meta):
    """Replace {{key}} fields in paragraphs of the kept template part, also when Word split them across runs."""
    def fix_para(m):
        p = m.group(0)
        texts = re.findall(r"<w:t(?:\s[^>]*)?>([^<]*)</w:t>", p)
        joined = "".join(texts)
        if "{{" not in joined:
            return p
        new = re.sub(r"\{\{\s*([\w-]+)\s*\}\}", lambda k: x(meta.get(k.group(1), meta.get(k.group(1).lower(), k.group(0)))), joined)
        first = [True]

        def put(t):
            if first[0]:
                first[0] = False
                return f'<w:t xml:space="preserve">{new}</w:t>'
            return "<w:t></w:t>"
        return re.sub(r"<w:t(?:\s[^>]*)?>[^<]*</w:t>", lambda t: put(t), p)
    return re.sub(r"<w:p\b.*?</w:p>", fix_para, xml, flags=re.S)


def top_level_elements(body):
    """Split body XML into top-level elements (w:p, w:tbl, w:sdt, w:sectPr ...)."""
    out, i, n = [], 0, len(body)
    while i < n:
        m = re.compile(r"<(w:[A-Za-z]+)\b").search(body, i)
        if not m:
            break
        tag = m.group(1)
        start = m.start()
        # self-closing?
        gt = body.find(">", start)
        if body[gt - 1] == "/":
            out.append((tag, body[start:gt + 1])); i = gt + 1; continue
        depth, j = 0, start
        pat = re.compile(r"<(/?)" + re.escape(tag) + r"\b[^>]*?(/?)>")
        while True:
            mm = pat.search(body, j)
            if not mm:
                j = n; break
            if mm.group(1) == "/":
                depth -= 1
            elif mm.group(2) != "/":
                depth += 1
            j = mm.end()
            if depth == 0:
                break
        out.append((tag, body[start:j])); i = j
    return out


def is_heading_para(el, styles):
    sid = re.search(r'<w:pStyle w:val="([^"]+)"', el)
    head_ids = set(v for (t, n), v in styles.by_name.items() if t == "paragraph" and re.match(r"heading \d", n))
    if sid and (sid.group(1) in head_ids or re.match(r"(?i)heading\d", sid.group(1))):
        return True
    return bool(re.search(r"<w:outlineLvl w:val=\"[0-8]\"", el))


def build(md_path, template, out, body_mode, mermaid, landscape=True, wide_cols=9, theme_name="auto", toc=None):
    text = open(md_path, encoding="utf-8-sig").read()
    meta, text = split_front_matter(text)
    blocks = parse_blocks(text)

    files = None
    if template:
        zin = zipfile.ZipFile(template)
        files = {n: zin.read(n) for n in zin.namelist()}
        zin.close()
    base = None
    if theme_name in ("auto", "template") and files:
        base = theme_from_template(files)
    if not base:
        base = THEMES.get(theme_name if theme_name in THEMES else "sapphire")
    th = make_theme(base)
    if files is None:
        files = {k: v.encode("utf-8") for k, v in default_package(th, meta).items()}

    doc = files["word/document.xml"].decode("utf-8")
    styles_xml = files.get("word/styles.xml", default_styles(th).encode()).decode("utf-8")
    styles = Styles(styles_xml)

    # page width from the last sectPr
    pw = re.findall(r'<w:pgSz[^>]*w:w="(\d+)"', doc)
    ml = re.findall(r'<w:pgMar[^>]*w:left="(\d+)"', doc)
    mr = re.findall(r'<w:pgMar[^>]*w:right="(\d+)"', doc)
    width = 9360
    if pw and ml and mr:
        width = int(pw[-1]) - int(ml[-1]) - int(mr[-1])
    sects = re.findall(r"<w:sectPr\b.*?</w:sectPr>", doc, flags=re.S)
    pg = (int(pw[-1]), int((re.findall(r'<w:pgSz[^>]*w:h="(\d+)"', doc) or ["16838"])[-1])) if pw else (11906, 16838)
    if pg[0] > pg[1]:
        pg = (pg[1], pg[0])
    margins = (int(ml[-1]), int(mr[-1])) if ml and mr else (1200, 1200)
    writer = Writer(styles, width, sects[-1] if sects else None, pg, margins, landscape, wide_cols, th)
    render(blocks, writer, mermaid)
    writer.finish()
    body_xml = "".join(writer.parts)

    bm = re.search(r"(<w:body>)(.*)(</w:body>)", doc, flags=re.S)
    inner = bm.group(2)
    if "{COVER}" in inner:                                     # default package
        new_inner = inner.replace("{COVER}", default_cover(meta, writer, toc is not False) + body_xml)
    else:
        els = top_level_elements(inner)
        sect = [e for t, e in els if t == "w:sectPr"]
        content = [(t, e) for t, e in els if t != "w:sectPr"]
        marker = next((k for k, (t, e) in enumerate(content) if "{{BRD_BODY}}" in re.sub(r"<[^>]+>", "", e)), None)
        if body_mode == "all":
            keep_before, keep_after = [], []
        elif marker is not None:
            keep_before, keep_after = content[:marker], content[marker + 1:]
        else:
            first_head = next((k for k, (t, e) in enumerate(content) if t == "w:p" and is_heading_para(e, styles)), len(content))
            keep_before, keep_after = content[:first_head], []
        if toc:
            body_xml = toc_block(writer) + body_xml
        before = fill_fields("".join(e for _, e in keep_before), meta)
        after = fill_fields("".join(e for _, e in keep_after), meta)
        if not keep_before and body_mode != "all":
            before = default_cover(meta, writer, bool(toc))
        new_inner = before + body_xml + after + "".join(sect)
    doc = doc[:bm.start(2)] + new_inner + doc[bm.end(2):]
    if 'xmlns:r=' not in doc[:2000]:
        doc = doc.replace("<w:document ", f'<w:document xmlns:r="{R_NS}" ', 1)
    files["word/document.xml"] = doc.encode("utf-8")
    files["word/styles.xml"] = styles.patched().encode("utf-8")

    # numbering part
    rels = files["word/_rels/document.xml.rels"].decode("utf-8")
    ct = files["[Content_Types].xml"].decode("utf-8")
    existing_num = files.get("word/numbering.xml")
    files["word/numbering.xml"] = numbering_xml(existing_num.decode("utf-8") if existing_num else None,
                                                writer.num_instances, writer.th["accent"]).encode("utf-8")
    if NUM_REL not in rels:
        rels = rels.replace("</Relationships>", f'<Relationship Id="rIdBrdNumbering" Type="{NUM_REL}" Target="numbering.xml"/></Relationships>')
    if "/word/numbering.xml" not in ct:
        ct = ct.replace("</Types>", f'<Override PartName="/word/numbering.xml" ContentType="{NUM_CT}"/></Types>')
    # images
    for rid, name, data in writer.images:
        files["word/media/" + name] = data
        rels = rels.replace("</Relationships>", f'<Relationship Id="{rid}" Type="{IMG_REL}" Target="media/{name}"/></Relationships>')
    if writer.images and 'Extension="png"' not in ct:
        ct = ct.replace("<Default ", '<Default Extension="png" ContentType="image/png"/><Default ', 1)
    ct = ct.replace(TPL_CT, DOC_CT)                       # .dotx template → .docx document
    files["word/_rels/document.xml.rels"] = rels.encode("utf-8")
    files["[Content_Types].xml"] = ct.encode("utf-8")

    # document title
    core = files.get("docProps/core.xml")
    if core and meta.get("title"):
        c = core.decode("utf-8")
        if "<dc:title" in c:
            c = re.sub(r"<dc:title\s*/>|<dc:title>.*?</dc:title>", f"<dc:title>{x(meta['title'])}</dc:title>", c, flags=re.S)
        files["docProps/core.xml"] = c.encode("utf-8")

    tmp = out + ".tmp"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        order = ["[Content_Types].xml"] + [n for n in files if n != "[Content_Types].xml"]
        for n in order:
            z.writestr(n, files[n])
    os.replace(tmp, out)
    counts = {}
    for b in blocks:
        counts[b[0]] = counts.get(b[0], 0) + 1
    print(f"Wrote {out}: {counts.get('h', 0)} headings, {counts.get('table', 0)} tables, {counts.get('code', 0)} code/diagram blocks, "
          f"{counts.get('list', 0)} lists, {len(writer.images)} pictures" + (f" (template: {os.path.basename(template)})" if template else " (default layout)"))


def main():
    ap = argparse.ArgumentParser(description="Write a BRD Markdown file into a Word template.")
    ap.add_argument("markdown")
    ap.add_argument("--template", help="client template (.docx or .dotx); default: clean built-in layout")
    ap.add_argument("--out", help="output .docx (default: next to the Markdown file)")
    ap.add_argument("--body", choices=["auto", "all"], default="auto",
                    help="auto: keep the cover before the template's first heading (or use {{BRD_BODY}}); all: replace the whole body")
    ap.add_argument("--no-landscape", action="store_true", help="keep wide tables on portrait pages")
    ap.add_argument("--wide-columns", type=int, default=9, help="tables with this many columns or more go on landscape pages (default 9)")
    ap.add_argument("--theme", default="auto", choices=["auto", "template"] + list(THEMES),
                    help="colour theme: auto = the template's own colours if it has a theme, else sapphire; or one of " + ", ".join(THEMES))
    ap.add_argument("--toc", action="store_true", help="add a table of contents after the cover (always on in the built-in layout)")
    ap.add_argument("--mermaid", action="store_true", help="render ```mermaid blocks to pictures with the Mermaid CLI (mmdc)")
    a = ap.parse_args()
    out = a.out or os.path.splitext(a.markdown)[0] + ".docx"
    if a.template and not os.path.exists(a.template):
        sys.exit(f"Template not found: {a.template}")
    build(a.markdown, a.template, out, a.body, a.mermaid, not a.no_landscape, a.wide_columns, a.theme, True if a.toc else None)


if __name__ == "__main__":
    main()
