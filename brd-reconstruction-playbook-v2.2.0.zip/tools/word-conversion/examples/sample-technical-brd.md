---
kind: brd
title: Store opening — Technical BRD
subtitle: How the current system prepares and opens a new store, from the first trigger to the last report
project: Retail Operations Modernisation
brd_name: Store opening
document_type: Technical
brd_version: v3
memory_version: v1.3
status: Draft for review
date: 2026-10-28
prepared_by: Abhijith
approved_by: Pending
---

## 1. Business scope

> [!KEY] A new store goes live only when every opening task is complete and its tills are configured. The nightly go-live job then switches it to OPEN, and finance sees it in the next morning's sales cube.

```figures
14 | standard opening tasks per store
9 | stores in OPENING today (LQ-0412)
02:00 UTC | nightly go-live run
3 | systems involved
```

### 1.1 Purpose and business outcome
Retail Operations prepares each new store for its opening day [[From evidence]] (EV-001 §2). The process protects revenue on day one: a store opened without configured tills cannot trade [[Confirmed]] by Priya, 2026-10-21.

### 1.2 Business areas, teams and users
| Team / user group | What they do in this process | What they receive or use | Source |
|---|---|---|---|
| Retail Operations | Create the store, track the opening checklist | Opening status report | EV-001 |
| Store Setup | Configure tills and terminals | Till configuration screen | EV-004 |
| Finance | Reconcile first-day sales | Sales cube (Databricks) | EV-009 |

## 2. End-to-end process summary

```flow
Phase 1 — Prepare | Store created, 14 tasks generated (usp_store_open_setup)
Phase 2 — Configure | Tills registered in pos_config
Phase 3 — Go live | Nightly job sets status OPEN (usp_store_golive)
Phase 4 — Report | Databricks dim_store refreshed for finance
```
Figure 1: The store opening process in four phases

> [!INSIGHT] Two thirds of late openings in 2026 trace back to one task, "till configuration", which has no reminder or escalation.

### 2.1 Key process characteristics
| Characteristic | Value | Evidence |
|---|---|---|
| Operation start | Store record created in the planning app; tasks generated on insert | EV-001, OBJ-0101 |
| Frequency | Go-live job daily 02:00 UTC | EV-008 (msdb schedule) |
| Main tables written | store_master, store_opening_checklist, pos_config | OBJ-0101–0103 |

## 3. Process flow by phase
### 3.1 Phase 3 — Go live
```layers
Source systems | Store planning app (REST API, nightly export)
Integration | ADF pipeline PL_Store_Daily
SQL Server | Sales.dbo: store_master, store_opening_checklist, pos_config
Databricks | prod_sales.store_gold.dim_store
Consumers | Finance sales cube, opening status report
```
Figure 2: Layers involved in the go-live phase

Key query (EV-019 lines 88–112) — selects the stores whose checklist is complete and whose tills are configured:
```sql
SELECT s.store_id
FROM dbo.store_master s
WHERE s.store_status = 'OPENING'
  AND s.open_date <= CAST(GETDATE() AS date)
  AND NOT EXISTS (SELECT 1 FROM dbo.store_opening_checklist c WHERE c.store_id = s.store_id AND c.done_flag = 0)
  AND EXISTS (SELECT 1 FROM dbo.pos_config p WHERE p.store_id = s.store_id AND p.terminal_count > 0);
```

Table 3: Stored procedures called in the go-live phase
| Order | Procedure | Called by | Parameters | Key functionality | Tables read | Tables written |
|---|---|---|---|---|---|---|
| 1 | dbo.usp_store_golive | SQL Agent job "Store go-live daily", step 1 | @run_date DATE = GETDATE() | Opens every ready store | store_master, store_opening_checklist, pos_config | store_master (UPDATE store_status) |
| 2 | dbo.usp_log_run | usp_store_golive | @proc, @rows | Writes the run log | — | dbo.run_log (INSERT) |

> [!RISK] The job has no retry; a failed run leaves stores in OPENING until the next night.

- Every ready store moves from `OPENING` to `OPEN` in one transaction
  - stores with open tasks stay in OPENING and appear on the morning report
- Finance sees the change after the Databricks refresh at 05:00 UTC
