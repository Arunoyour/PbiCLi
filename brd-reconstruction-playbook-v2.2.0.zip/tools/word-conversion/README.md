# Word in, Word out (run by a person; the agent has no terminal)

Two small Python scripts, **standard library only** (Python 3.8 or later; no pandoc, no pip installs).

## 1. Client templates: Word → Markdown (before `/brd-setup`)
1. Put the client's Word templates in `sources/template/word/` (`.docx` or `.dotx`), for example `Technical BRD Template.docx`.
2. Convert them so the agent can read them:
   ```
   python tools/word-conversion/docx_to_md.py sources/template/word
   ```
   This writes one `.md` per template into `sources/template/` (headings, tables, lists and content-control text kept).
3. Open each `.md` and check the headings came through (`#`, `##`, `###`). At `/brd-setup` the agent registers each template with its type (Functional, Technical, Summary) and both paths: the `.md` it reads and the `.docx` used for output.

## 2. Approved BRD: Markdown → Word in the client's template
When a document is approved, the agent gives you the exact command, for example:
```
python tools/word-conversion/md_to_docx.py brd-work/brd/technical/BRD-T_v3.md --template "sources/template/word/Technical BRD Template.docx" --out brd-work/brd/technical/BRD-T_v3.docx
```
What happens:
- **Kept from the template:** styles, fonts, headers, footers, page setup, numbering, and the cover.
- **Where the BRD goes:** if the template has a paragraph `{{BRD_BODY}}`, the BRD replaces it and everything around it is kept (best for templates with a fixed front section and a fixed sign-off page). Otherwise everything before the template's first heading is kept (cover, document control) and the template's example sections are replaced by the BRD. `--body all` keeps only styles, headers, footers and page setup.
- **Cover fields:** `{{title}}`, `{{project}}`, `{{brd_name}}`, `{{brd_version}}`, `{{date}}`, `{{status}}`, `{{prepared_by}}`, `{{approved_by}}`, `{{memory_version}}` (any key of the BRD's front matter) are filled in. Add them to the template's cover once.
- **Headings** use the template's Heading 1–6 styles; **tables** use its "Table Grid" style with a shaded header row that repeats on every page; **wide tables** (9 columns or more) go on landscape pages (`--no-landscape` to switch off, `--wide-columns 11` to change the limit).
- **Diagrams:** ```flow blocks become boxes with arrows, ```layers and ```figures become tables, `> [!RISK]`-style callouts become shaded boxes, `[[Confirmed]]`-style labels become coloured bold text. ```mermaid diagrams become pictures with `--mermaid` if the Mermaid CLI (`mmdc`) is installed; otherwise their source is shown.
- **Code and queries** keep their exact text in a monospaced, shaded block.

**Look and feel** (`playbook/document-style.md`):
- **Colour theme:** with a client template, the script reads the template's own theme colours so tables, panels and diagrams match the client's branding (`--theme auto`, the default). Without a template, or with `--theme <name>`, it uses a built-in theme: `sapphire` (deep navy, teal, saffron; default), `emerald`, `graphite`, `royal`, `crimson`.
- **Built-in layout** (no template): full-colour cover band with the document type, title and subtitle, a details panel, a contents page (Word fills it on opening; click **Yes** when it asks to update fields), a running header with the BRD name and version, and "Page x of y". Headings in Segoe UI with an accent rule under each main section.
- **Panels:** `> [!KEY]`, `[!INSIGHT]`, `[!EXAMPLE]`, `[!SUMMARY]`, `[!RISK]`, `[!DECISION]`, `[!CONFIRMED]`, `[!PROVISIONAL]`, `[!NOTE]` become coloured panels with a label; a plain `>` quote becomes a pull quote.
- **Headline figures:** a ```figures block becomes big-number tiles.
- **Diagrams:** ```flow becomes numbered step cards with arrows (left to right up to five steps), ```layers a banded architecture diagram, ```mermaid a sharp picture in the theme colours with `--mermaid`.
- **Tables:** dark header row that repeats on every page, light banding, long names wrap at dots and underscores, wide tables on landscape pages.
- **Captions:** a line starting `Figure 2:` or `Table 3:` becomes a styled caption.
- `--toc` adds a contents page after a client template's cover too.

See `examples/` for a sample BRD in Markdown and the Word file it produces.

After converting: open the file in Word, right-click the table of contents (if the template has one) → **Update field**, and check the cover.

## PDF
Open the `.docx` in Word and save as PDF, or open the `.html` version in a browser and use **Print → Save as PDF**.
