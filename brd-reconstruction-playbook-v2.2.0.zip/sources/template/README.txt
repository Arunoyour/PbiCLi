Client BRD templates.
  word/            the client's Word templates (.docx or .dotx), as received. Used for the final Word documents.
  <name>.md        the same templates as Markdown, for the agent to read. Make them with:
                   python tools/word-conversion/docx_to_md.py sources/template/word
Without client templates, the detailed default templates in playbook/templates/ are used and the Word output uses a clean default layout.
Tip: put {{title}}, {{brd_version}}, {{date}}, {{approved_by}} on the template's cover, and optionally a paragraph {{BRD_BODY}} where the BRD should go.
See tools/word-conversion/README.md.
