Put the client's Word BRD templates (.docx / .dotx) here.
