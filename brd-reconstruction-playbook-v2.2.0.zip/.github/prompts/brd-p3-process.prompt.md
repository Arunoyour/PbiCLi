---
name: brd-p3-process
description: Phase 3 - Process analysis
agent: BRD Reconstruction
---
Run **BRD phase 3, process analysis** and nothing else.

Follow [content-depth.md](../../playbook/content-depth.md), [deep-dig.md](../../playbook/deep-dig.md), [P0-phase-rules.md](../../playbook/P0-phase-rules.md), [P3-process.md](../../playbook/P3-process.md), [query-protocol.md](../../playbook/query-protocol.md), together with [review-loop.md](../../playbook/review-loop.md), [labels-and-versions.md](../../playbook/labels-and-versions.md) and [people-and-confirmations.md](../../playbook/people-and-confirmations.md).

First read `brd-work/PROJECT.md`, `brd-work/STATUS.md` and the manifest of the memory in use, check the workspace type and the step's gate; if it is not met, tell me what is missing and stop.

Work inside the fence. Sources first, then read-only data checks, then questions.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do not start any other step.
