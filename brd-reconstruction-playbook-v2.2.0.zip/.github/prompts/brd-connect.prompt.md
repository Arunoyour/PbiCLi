---
name: brd-connect
description: Re-test the Databricks (dbsql) and SQL Server (MSSQL extension) connections step by step, read-only, and record the result
agent: BRD Reconstruction
---
Run **Connection test** and nothing else.

Follow [connections.md](../../playbook/connections.md) and [query-protocol.md](../../playbook/query-protocol.md).

Read `brd-work/PROJECT.md` first. For every registered database and catalog, run the test steps in order and stop at the first failure for that connection, saying exactly which step failed and what to do. Use only read-only statements. Never ask me for tokens or passwords. Update only `PROJECT.md` → *Data connections* and `brd-work/query-log.md`, report one line per connection in chat, then stop.
