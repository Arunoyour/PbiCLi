---
name: brd-p8c-summary
description: Phase 8C - Summary BRD, built only from the approved Functional and Technical BRDs
agent: BRD Reconstruction
---
Run **BRD phase 8C, Summary BRD** and nothing else.

Follow [document-style.md](../../playbook/document-style.md), [content-depth.md](../../playbook/content-depth.md), [deep-dig.md](../../playbook/deep-dig.md), [P0-phase-rules.md](../../playbook/P0-phase-rules.md), [P8-draft.md](../../playbook/P8-draft.md), [P8C-summary.md](../../playbook/P8C-summary.md), together with [review-loop.md](../../playbook/review-loop.md), [labels-and-versions.md](../../playbook/labels-and-versions.md) and [people-and-confirmations.md](../../playbook/people-and-confirmations.md).

First read `brd-work/PROJECT.md`, `brd-work/STATUS.md` and the manifest of the memory in use, check the workspace type and the step's gate; if it is not met, tell me what is missing and stop.

Write `brd-work/brd/summary/BRD-S_v<n>.md` and `.html` with identical text, every template section filled completely (in batches for long documents), stamped with document type and version, memory and playbook versions. Never overwrite an earlier version.

Write as a senior Word editor (lead with the point, key-message panels, headline figures, flow and layer diagrams, numbered captions, exact SQL panels) and do the editor's pass before presenting. Write every section at full depth (everything found, with evidence, repetition allowed, no "etc."). After APPROVED, give me the `python tools/word-conversion/md_to_docx.py` command for the Word document in the registered template.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do not start any other step.
