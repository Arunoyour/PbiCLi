---
name: brd-p5e-resolve
description: Phase 5E - answer open questions and gaps from the memory files, source digests, live code and data (SQL Server, Databricks) before asking people
agent: BRD Reconstruction
---
Run **Phase 5E — Resolve open questions from the evidence** and nothing else.

Follow [P5E-resolve.md](../../playbook/P5E-resolve.md), [deep-dig.md](../../playbook/deep-dig.md), [query-protocol.md](../../playbook/query-protocol.md), [content-depth.md](../../playbook/content-depth.md) and [P0-phase-rules.md](../../playbook/P0-phase-rules.md), together with [review-loop.md](../../playbook/review-loop.md), [labels-and-versions.md](../../playbook/labels-and-versions.md) and [people-and-confirmations.md](../../playbook/people-and-confirmations.md).

First read `brd-work/PROJECT.md`, `brd-work/STATUS.md` and the manifest of the memory in use, check the step's gate; if it is not met, tell me what is missing and stop.

For every open item: search all memory Markdown files and digests, follow the connections, check the live code and the data read-only, and record the trail. Ask me only about what the evidence cannot answer. Respect the run budget and the query limits; save after each item.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do not start any other step.
