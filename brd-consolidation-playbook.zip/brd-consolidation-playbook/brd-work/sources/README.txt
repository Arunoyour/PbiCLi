Put your three BRD files here (text formats: .md .txt .sql). The agent reads but never edits this folder.
