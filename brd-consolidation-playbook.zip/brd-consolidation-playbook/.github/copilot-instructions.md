# BRD Consolidation — standing rules for Copilot

These rules apply whenever a `/brd-*` prompt or the **BRD Consolidation** agent is used in this workspace.

## 1. One stage per invoke
Run only the stage the user invoked. Present the result, then stop. Never start another stage, even after approval. The user starts every stage by name.

## 2. Always load state first
Chat context is lost between sessions. Before doing anything, read:
1. `brd-work/MEMORY.md` — what we have understood and decided so far
2. `brd-work/STATUS.md` — which stage is in which state

If either file is missing, create it from `brd-playbook/templates/`.

## 3. Ask, do not guess
If information is missing, ambiguous or contradictory, ask the user. Do not fill gaps with assumptions and do not invent requirements.
- Ask in rounds of **at most 5 questions**, most important first.
- Use the `askQuestions` tool when available. If it is not available or does not wait for the user, ask in chat as a numbered list and wait for the reply.
- After every answered round, **update `brd-work/MEMORY.md` and `brd-work/31-decisions-log.md` immediately**, before asking anything else.
- Never treat silence or a vague reply as an answer. Re-ask.

## 4. Approval is explicit
You may mark a stage `APPROVED` in `STATUS.md` only when the user's latest message contains the word **APPROVED** for that stage. Never mark any stage approved yourself.

## 5. Scope of changes
Write only inside `brd-work/`. Never edit `brd-work/sources/` (the original BRD files). Never run terminal commands. Stages 1–4 never write code, schemas or SQL.

## 6. Provenance
Every statement you record cites its source (`SRC-A`, `SRC-B`, `SRC-C` + section or procedure name) or a decision ID (`DEC-nnn`). If it has neither, it does not go in.

## 7. End of every stage
Finish with the review prompt:

```
STAGE <n> — <name>: ready for your review.
Output: <files>
Summary: <3-5 lines>
Open items needing you: <count>

Reply: FEEDBACK: <change>  |  APPROVED  |  HALT
To continue after approval, run the next stage's command yourself.
```
