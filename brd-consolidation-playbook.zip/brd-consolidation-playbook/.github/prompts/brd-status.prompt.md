---
name: brd-status
description: Show where we are - stage states, open questions, what to run next. Changes nothing.
agent: BRD Consolidation
tools: ['search/codebase', 'search', 'read']
---
Read `brd-work/STATUS.md` and `brd-work/MEMORY.md` and tell me, briefly:

1. The state of each stage
2. How many gaps are open, deferred and resolved
3. The questions still waiting on me
4. The next command I should run

Change nothing. Do not run any stage.
