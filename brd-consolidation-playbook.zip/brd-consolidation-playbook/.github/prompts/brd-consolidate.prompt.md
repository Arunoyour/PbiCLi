---
name: brd-consolidate
description: Stage 4 - build the single readable HTML for human review
agent: BRD Consolidation
---
Run **Stage 4 — Consolidate to HTML** and nothing else.

Follow the stage instructions in [04-consolidate.md](../../brd-playbook/04-consolidate.md).

First read `brd-work/MEMORY.md` and `brd-work/STATUS.md`. Stage 3 must be APPROVED; if it is not, tell me and stop. Build only from the approved inventory, gap register and decisions log. If you find something that needs a decision, ask me instead of choosing. When finished, tell me the file name, how to open it, and give the review prompt. Then stop.
