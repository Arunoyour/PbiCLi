---
name: brd-blueprint
description: Stage 5 - technical blueprint from the approved HTML (runs only after Stage 4 is approved)
agent: BRD Consolidation
---
Run **Stage 5 — Technical Blueprint** and nothing else.

Follow the stage instructions in [05-blueprint.md](../../brd-playbook/05-blueprint.md).

First read `brd-work/MEMORY.md` and `brd-work/STATUS.md`. Stage 4 must be APPROVED and `brd-work/40-consolidated-brd.html` must be the approved version; if not, tell me and stop. Ask me about platform and constraints before designing. If a requirement is unclear, log a new gap and ask; do not guess. Design documents only, no code. When finished, present with the review prompt and stop.
