---
name: brd-gaps
description: Stage 2 - find conflicts, missing items and hidden rules across the three BRDs
agent: BRD Consolidation
---
Run **Stage 2 — Gap Analysis** and nothing else.

Follow the stage instructions in [02-gap-analysis.md](../../brd-playbook/02-gap-analysis.md).

First read `brd-work/MEMORY.md` and `brd-work/STATUS.md`. Stage 1 must be APPROVED; if it is not, tell me and stop. Do not ask the clarifying questions yet; log gaps only. When finished, present the result with the review prompt and stop.
