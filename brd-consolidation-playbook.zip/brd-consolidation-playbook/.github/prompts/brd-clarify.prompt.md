---
name: brd-clarify
description: Stage 3 - ask me clarifying questions in rounds, record my answers, update memory
agent: BRD Consolidation
tools: ['search/codebase', 'search', 'read', 'edit', 'vscode/askQuestions']
---
Run **Stage 3 — Clarify** and nothing else.

Follow the stage instructions in [03-clarify.md](../../brd-playbook/03-clarify.md).

First read `brd-work/MEMORY.md` and `brd-work/STATUS.md`. Stage 2 must be APPROVED; if it is not, tell me and stop.

This stage is a conversation. Ask me in rounds of at most 5 questions, wait for my answers, record them, update memory, then continue until no HIGH or MEDIUM gap is open (or I tell you to defer). Then present the summary with the review prompt and stop.
