---
name: brd-ingest
description: Stage 1 - read the three BRD files and build one tagged inventory
agent: BRD Consolidation
argument-hint: filenames of the 3 BRDs (if not already in brd-work/sources/)
---
Run **Stage 1 — Ingest** and nothing else.

Follow the stage instructions in [01-ingest.md](../../brd-playbook/01-ingest.md).
Source files are in `brd-work/sources/`. If I have named files below, use those: ${input:files:optional - file names, or leave blank to use everything in brd-work/sources}

Start by reading `brd-work/MEMORY.md` and `brd-work/STATUS.md`. If a file is unreadable or unclear, ask me before continuing. When finished, present the result with the review prompt and stop.
