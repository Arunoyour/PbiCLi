# BRD Consolidation — setup for VS Code + GitHub Copilot

## 1. Install (2 minutes)
1. Copy these into the root of your workspace, keeping the structure:
   - `.github/` (instructions, agent, prompts)
   - `brd-playbook/`
   - `brd-work/`
2. Put your three BRD files in `brd-work/sources/`. Use text formats (`.md`, `.txt`, `.sql`). Convert Word/PDF to text first.
3. In VS Code open Copilot Chat. In the agent dropdown you should see **BRD Consolidation**. Typing `/brd` should list the commands.
4. Check the tools: open the agent's tool picker and confirm it has read, search, edit and ask-questions, and **no terminal**.

## 2. Run
| Step | You type | You do next |
|------|----------|-------------|
| 1 | `/brd-ingest` | Review. Answer any questions. Reply `APPROVED` |
| 2 | `/brd-gaps` | Review the gap register. Reply `APPROVED` |
| 3 | `/brd-clarify` | Answer the question rounds. Reply `APPROVED` at the end |
| 4 | `/brd-consolidate` | Open `brd-work/40-consolidated-brd.html` in a browser. Reply `APPROVED` or give feedback |
| 5 | `/brd-blueprint` | Review the blueprint |

Lost your place? `/brd-status`. New chat? Same: memory lives in `brd-work/MEMORY.md`.

## 3. Things to know
- **The pause is mostly instruction-based.** The agent has no terminal and each command loads only its own stage, but Copilot can still run on if it ignores instructions. If it starts the next stage, say HALT and check that `STATUS.md` was not changed. Only your APPROVED may change a stage to approved.
- **`askQuestions` has had bugs** (for example auto-answering instead of waiting, and not working inside subagents). The rules fall back to plain numbered questions in chat if it does not wait. If it auto-answers, tell the agent to ask in chat instead.
- **Custom agents are `.agent.md` in `.github/agents/`.** The older `.chatmode.md` format is no longer supported by VS Code.
- Tool names can vary by VS Code version. If the picker shows different names, adjust the `tools:` line in the agent file.
- Do not edit `brd-work/sources/`. The agent is told not to, but keep a backup anyway.
