# Stage 4 — Consolidate to HTML

**Invoke:** `/brd-consolidate` (requires Stage 3 APPROVED)
**Output:** `brd-work/40-consolidated-brd.html` (single self-contained file)
**Mode:** write the HTML only. Then STOP.

## Readability first
The HTML is for a human who has not read the three source files and may not be technical. Design it to be understood in one sitting:
- Plain English. Define a term the first time it appears; link it to the glossary.
- A one-screen **summary at the top**: what this is, what changes, key numbers, how many items are decided vs. still open.
- A **sticky table of contents** and a progress indicator.
- Business sections first; technical detail in collapsible blocks (`<details>`) labelled "Technical detail".
- Tables for rules, fields and decisions. Short paragraphs. No walls of text.
- Clear visual marking for: Decided, Deferred / open (with owner), and "found in code, confirmed by DEC-nnn".
- Print-friendly, light and dark mode, readable on a laptop and a phone.

## Approval
The human reads the HTML, then replies in chat. Approval is the chat reply **APPROVED**; per-section buttons and the exported decisions file are a convenience for reviewers, not the gate. If a reviewer marks sections Rejected or adds comments, they paste or save the export into `brd-work/review-feedback.json` (or paste it in chat). The agent then revises only those sections, raises the version number, adds to the change log in the HTML, and asks again.

## Purpose
Merge the three BRDs plus all decisions into one document a human can read, challenge and sign off section by section. This HTML is the single source of truth for Stage 5.

## Content rules
1. Build **only** from: the inventory, the decisions log, and the gap register. No new facts.
2. Every requirement and rule shows its **provenance**: source files, and the decision ID if a decision shaped it.
3. Where a gap is `DEFERRED` or `STILL-OPEN`, show it in place, visibly marked, not hidden in an appendix.
4. Business rules found only in stored procedures are shown as normal rules, flagged "from code, confirmed by DEC-xxx".
5. Keep wording plain. Business sections read for business people; technical detail goes in clearly separated technical sections.

## Page structure
1. Cover: title, version, date, sources used, reviewer fields
2. Executive summary (one screen)
3. Open items summary (deferred and still-open, with owners)
4. Scope and objectives
5. Business requirements
6. Business rules and calculations
7. Data (entities, fields, sources, targets)
8. Processes and workflows
9. Interfaces and integrations
10. Non-functional requirements
11. Stored procedure rule map (procedure, rules implemented, requirement it supports)
12. Glossary (agreed terms)
13. Decisions log
14. Traceability table (requirement, source files, decision IDs)
15. Sign-off panel

## Review features (per section)
- Buttons: **Approve**, **Reject**, **Comment**, with the reviewer name and a timestamp
- Overall progress bar (sections approved / total)
- Filter: show only unapproved, rejected, or open-item sections
- **Export decisions** as a JSON/Markdown file containing every approval, rejection and comment, so the agent can read the reviewers' result back
- Works offline, no external libraries or network calls, works in light and dark mode, readable on a laptop and printable

## Process
1. Draft the HTML.
2. Self-check before presenting: every inventory item appears, every RESOLVED gap shows its decision, every open item is visible, no unresolved placeholder text, the export button works.
3. Present: section list, counts, open items, and the file. **STOP** with the standard review prompt.

## Revisions
If reviewers reject or comment, the human pastes or uploads the exported decisions file. The agent revises only the affected sections, increments the document version, and keeps a change log inside the HTML.

## Approval
Stage 4 is APPROVED only when the human states it after all sections show Approved in the exported decisions file, or the human explicitly accepts any exceptions by name.

## Do NOT
- Add requirements, "improvements" or suggestions.
- Remove a section because it has open items.
- Start the blueprint.
