# Gap entry template

Types: CON conflict · MIS missing · HID hidden rule in code · ORP orphan requirement · ORT orphan technical · AMB ambiguity · TRM term mismatch · ASM unstated assumption · STL stale
Severity: HIGH (changes results, money or compliance; blocks design) · MEDIUM (affects design choices) · LOW (wording)
Status: OPEN · RESOLVED (needs DEC id) · DEFERRED (needs reason + owner) · STILL-OPEN

```
### GAP-000 · TYPE · SEVERITY
Topic:
What each source says:
  - SRC-A <location>:
  - SRC-B <location>:
  - SRC-C <location>:
Why it matters:
Candidate readings:
Status: OPEN
Resolved by: (DEC-id)
```

# Question entry template

```
### Q-000 · closes GAP-xxx, GAP-yyy · severity
Context (with source refs):
Question:
Options:
  A)
  B)
  C)
Agent's proposed default (a proposal, not a fact):
Likely owner:
Answer:        (human fills)
Decided by / date:
```

# Decision log row

| DEC-ID | Gap IDs | Decision | Decided by | Date | Basis (human answer / accepted default / deferred) | Supersedes |
|--------|---------|----------|-----------|------|------------------------------------------------------|-----------|
