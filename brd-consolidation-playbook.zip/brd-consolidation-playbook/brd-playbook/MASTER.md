# BRD Consolidation Playbook — MASTER

Turns three BRD files of different depth into one human-approved HTML, then into a technical blueprint.
Runs in VS Code with GitHub Copilot as a **conversation**: the agent works one stage at a time, asks you when it needs information, remembers what you tell it, and never advances on its own.

---

## 1. Inputs

| Code | File type | Typical content |
|------|-----------|-----------------|
| `SRC-A` | Business + light technical BRD | Objectives, scope, rules, some technical notes |
| `SRC-B` | Summary BRD | Short version, headline requirements |
| `SRC-C` | Technical BRD | Stored procedures, tables, technical detail |

Put the three files in `brd-work/sources/` (as `.md`, `.txt`, `.sql` or other text formats; convert Word/PDF to text first).

---

## 2. The loop

```
YOU run a /brd-* command
   → AGENT reads MEMORY.md + STATUS.md
   → AGENT works the stage (asks you questions when it needs information)
   → AGENT records your answers in MEMORY.md and the decisions log
   → AGENT presents the result and STOPS
        ├─ FEEDBACK: ...  → agent revises the same stage, presents, stops
        ├─ APPROVED       → agent records it in STATUS.md, stops
        └─ HALT           → agent stops
YOU run the next /brd-* command yourself
```

### Hard rules
1. One stage per command. The agent never starts the next stage.
2. The agent asks instead of guessing. Questions come in rounds of at most 5.
3. Every answer is written to `MEMORY.md` and the decisions log before the next question.
4. Every statement traces to a source (file + section/procedure) or a decision ID.
5. Conflicts are never merged silently; each becomes a gap-register entry.
6. Only a human message containing APPROVED approves a stage.
7. Stages 1-4 write documents only: no code, no schema changes, no terminal.
8. Stage 5 starts only when Stage 4 is APPROVED.

---

## 3. Stages and commands

| # | Command | Stage file | What happens | Needs approved |
|---|---------|-----------|--------------|----------------|
| 1 | `/brd-ingest` | `01-ingest.md` | Reads the 3 files into one tagged inventory; asks if anything is unreadable or unclear | — |
| 2 | `/brd-gaps` | `02-gap-analysis.md` | Finds conflicts, missing items, rules hidden in stored procedures | 1 |
| 3 | `/brd-clarify` | `03-clarify.md` | **Live Q&A**: asks you in rounds, records answers, updates memory | 2 |
| 4 | `/brd-consolidate` | `04-consolidate.md` | Builds the single readable HTML | 3 |
| 5 | `/brd-blueprint` | `05-blueprint.md` | Technical blueprint from the approved HTML | 4 |
| — | `/brd-status` | — | Shows where you are; changes nothing | — |

---

## 4. Folder layout

```
.github/
  copilot-instructions.md        standing rules
  agents/brd-consolidation.agent.md   the agent (read + edit + ask, no terminal)
  prompts/brd-*.prompt.md        the slash commands
brd-playbook/                    these instructions (do not edit during a run)
  MASTER.md, 01..05 stage files, templates/
brd-work/                        everything the agent produces
  sources/                       your 3 BRD files (agent never edits)
  MEMORY.md                      the agent's running understanding
  STATUS.md                      stage states and approvals
  00-source-register.md  10-inventory.md  20-gap-register.md
  30-questions.md  31-decisions-log.md
  40-consolidated-brd.html  50-technical-blueprint.md
```

---

## 5. Memory

Copilot chat does not keep memory between sessions, so the memory is a file.
`brd-work/MEMORY.md` holds the project summary, agreed terms, confirmed rules, decisions, who knows what, and what is still unclear. Every command reads it first and every answered round updates it. If you open a new chat tomorrow, run `/brd-status` and carry on.

---

## 6. Standard review prompt (end of every stage)

```
STAGE <n> — <name>: ready for your review.
Output: <file(s)>
Summary: <3-5 lines>
Open items needing you: <count>

Reply: FEEDBACK: <change>  |  APPROVED  |  HALT
To continue after approval, run the next stage's command yourself.
```

---

## 7. Settings (defaults; tell the agent to change any)

| Setting | Default |
|---------|---------|
| Conflict resolution | No file wins automatically; every conflict goes to you |
| Stored procedures | Reverse-engineer business rules from each one, with a checklist |
| Question rounds | Max 5 questions per round |
| HTML review | Readable page; approval by replying APPROVED in chat; optional per-section buttons |
| Blueprint platform | Asked at the start of Stage 5 |
