---
name: brd-status
description: Where are we - every stage and vertical, open questions, Databricks status, and the next command to type. Changes nothing.
agent: BRD Programme
tools: ['search/codebase', 'search', 'read', 'bp-helper/*']
---
Run `bp-helper` → `workspace_check` (if the tool is missing, say: "Command Palette → MCP: List Servers → bp-helper → Start"). Then read `brd-work/<project>/PROJECT.md`, `STATUS.md` and `MEMORY.md` (ask which project if there are several) and tell me briefly:

1. Project, Databricks evidence status
2. Each project stage and each vertical's stages: state, round, approved by
3. BRD versions per vertical (latest and approved)
4. Open counters: unanswered questions, unconfirmed Databricks findings, unconfirmed relationships, HIGH gaps open
5. A stage waiting for me (PRESENTED): which page, and that I can reply APPROVED / FEEDBACK there (offer to reopen the page)
6. **Next: type `<exact command>`** (with the vertical, in the approved order)

Change nothing. Run no stage. If no project exists yet, say: **Next: type `/brd-intake`**.
