---
name: brd-bp-assemble
description: Blueprint 8g - assemble the full current-state blueprint (MD + HTML)
agent: BRD Programme
---
Run **Blueprint part 8g** and nothing else.

Follow [08-blueprint.md](../../playbook/08-blueprint.md) (content depth: everything the evidence holds, labels on every statement, current state only), [08g-assemble.md](../../playbook/08g-assemble.md), [diagram-standard.md](../../playbook/diagram-standard.md), the review loop in [10-review-loop.md](../../playbook/10-review-loop.md), and (if Genie or Databricks SQL is in use) [11-genie-protocol.md](../../playbook/11-genie-protocol.md).

First read `brd-work/<project>/PROJECT.md`, `STATUS.md` and `MEMORY.md`, and check the stage's gate; if it is not met, tell me what is missing and stop.

This is a blueprint of the **existing** system built from the evidence: no target design, no technology choice. Draw every diagram the part requires (Mermaid). Under each one write its caption, **What this diagram shows**, a numbered **Walkthrough** of every step, and every **Scenario** (normal path, alternative paths, exceptions and failures, edge cases, unknown paths) in detail, then the key table.

End with the review page (check its diagrams with `bp-helper` → `check_diagrams`, then build and open it with `build_page`) and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do all file work yourself; never ask me to copy, move, convert, open or save a file. After APPROVED, tell me the exact next command. Do not start any other stage.
