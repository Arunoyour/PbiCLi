---
name: brd-arch-respond
description: Respond to the architect review and update the blueprint
agent: BRD Programme
---
Run **Architect review response (part B)** and nothing else.

Follow [09-architect-review.md](../../playbook/09-architect-review.md), [08g-assemble.md](../../playbook/08g-assemble.md), the review loop in [10-review-loop.md](../../playbook/10-review-loop.md), and (if Genie or Databricks SQL is in use) [11-genie-protocol.md](../../playbook/11-genie-protocol.md).

First read `brd-work/<project>/PROJECT.md`, `STATUS.md` and `MEMORY.md`, and check the stage's gate; if it is not met, tell me what is missing and stop.

Answer every finding: accepted and changed, accepted as risk, or disagree with reasons.

End with the review page (check its diagrams with `bp-helper` → `check_diagrams`, then build and open it with `build_page`) and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do all file work yourself; never ask me to copy, move, convert, open or save a file. After APPROVED, tell me the exact next command. Do not start any other stage.
