---
name: brd-feedback
description: Apply my review feedback (from the page or chat) to the stage in progress and redraft it
agent: BRD Programme
---
Apply my feedback to the stage that is currently PRESENTED or REVISING in `brd-work/<project>/STATUS.md`, following [10-review-loop.md](../../playbook/10-review-loop.md) section 2.

Collect the page feedback yourself: `bp-helper` → `collect_feedback` with the project and the page's `feedback_file` name (it looks in the project's feedback folder and in my Downloads folder). Also use anything I wrote or pasted in chat. If more than one stage is waiting, ask which one. If nothing is found, tell me to click **Export review** again or use **Copy for chat**; never ask me to move a file.

Update the working files, write the next round's review page with a "What changed since round N" section, build and open it with `build_page`, then stop. Do not approve anything and do not start another stage.
