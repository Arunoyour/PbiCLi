---
name: brd-next
description: Run the next step - works out from STATUS.md which stage (and vertical) comes next and runs only that one
agent: BRD Programme
---
Read `brd-work/<project>/PROJECT.md`, `STATUS.md` and `MEMORY.md` (ask which project if there are several; if none exists, run Intake: [00-intake.md](../../playbook/00-intake.md)).

Work out the next step from [MASTER.md](../../playbook/MASTER.md) section 3 and the approved order of verticals:
- If a stage is **PRESENTED** or **REVISING** (waiting for my review), do not start anything: reopen its page with `bp-helper` → `open_page` and remind me to reply APPROVED, FEEDBACK or HALT.
- If a stage is **HALTED** or **NEEDS-RECHECK**, that stage is next.
- Otherwise the first stage whose gate is met and which is NOT_STARTED, in this order: Intake → Read all → for each vertical in order: Understand → Gaps → Clarify → Relationships → Readiness → BRD update per vertical in order → Blueprint 8a for each vertical in order → 8b business → 8c technical → 8d data → 8e operations → 8f findings → 8g assemble → Architect review → Respond.

Say in one line which stage and vertical you are running (and the command that is equivalent, so I learn it). Then run **only that stage**, following its stage file in `playbook/`, the review loop in [10-review-loop.md](../../playbook/10-review-loop.md) and, if Databricks is in use, [11-genie-protocol.md](../../playbook/11-genie-protocol.md).

If the next stage is the **Architect review**, do not run it here (it needs the separate reviewer agent): tell me to type `/brd-arch-review`.

End with the review page (build and open it with `build_page`) and the review message, then stop. Never ask me to handle files. Do not start any other stage.
