---
name: brd-rebuild
description: Rebuild one vertical's BRD as a new version
agent: BRD Programme
---
Run **BRD rebuild** and nothing else.

Follow [07-brd-rebuild.md](../../playbook/07-brd-rebuild.md), the review loop in [10-review-loop.md](../../playbook/10-review-loop.md), and (if Genie or Databricks SQL is in use) [11-genie-protocol.md](../../playbook/11-genie-protocol.md).

First read `brd-work/<project>/PROJECT.md`, `STATUS.md` and `MEMORY.md` and the vertical's `MEMORY.md`, and check the stage's gate; if it is not met, tell me what is missing and stop.

Work only on this vertical: ${input:vertical:Vertical name or code, as in PROJECT.md}. Always create the next version; never overwrite an existing one.

End with the review page (check its diagrams with `bp-helper` → `check_diagrams`, then build and open it with `build_page`) and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do all file work yourself; never ask me to copy, move, convert, open or save a file. After APPROVED, tell me the exact next command. Do not start any other stage.
