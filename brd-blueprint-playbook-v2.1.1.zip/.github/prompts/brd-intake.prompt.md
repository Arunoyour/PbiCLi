---
name: brd-intake
description: Intake - project name, Databricks evidence, verticals, BRD files (imported for you), order
agent: BRD Programme
---
Run **Intake** and nothing else.

Follow [00-intake.md](../../playbook/00-intake.md), the review loop in [10-review-loop.md](../../playbook/10-review-loop.md), and (if Genie or Databricks SQL is in use) [11-genie-protocol.md](../../playbook/11-genie-protocol.md).

First run `bp-helper` → `workspace_check` (if the tool is missing, tell me the one-line fix and stop). If a project already exists in `brd-work/`, say so and show its status instead.

This is a conversation: ask one step at a time and save each answer before the next. For the BRD files, ask me only **where** they are; find, propose, import and convert them yourself with `bp-helper`. **Never ask me to paste a token or password in chat**; if Genie is used, VS Code asks for the token itself.

End with the review page (check its diagrams with `bp-helper` → `check_diagrams`, then build and open it with `build_page`) and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do all file work yourself; never ask me to copy, move, convert, open or save a file. After APPROVED, tell me the exact next command. Do not start any other stage.
