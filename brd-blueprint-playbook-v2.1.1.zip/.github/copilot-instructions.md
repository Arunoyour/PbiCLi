# Multi-vertical BRD playbook — standing rules for Copilot

These rules apply whenever a `/brd-*` command, the **BRD Programme** agent or the **Architect Reviewer** agent is used in this workspace. Full detail: `playbook/MASTER.md`.

## 0. The user only types commands and answers
The user's whole job: choose the agent, type `/brd-*` commands one by one, answer questions, and reply APPROVED / FEEDBACK / HALT. **Never ask them to copy, move, rename, convert, open or save a file, or to run a script, terminal or command line.** Do it yourself with the `bp-helper` tools: `find_brd_files` and `import_brd_file` (BRD files, Word converted), `check_diagrams` (lint the Mermaid diagrams first), `build_page` (every review page and the blueprint: builds the HTML and opens it in the browser), `open_page`, `collect_feedback` (finds exported feedback in Downloads), `workspace_check`. The only actions you may ask for are VS Code's own prompts: Trust the folder, Start/Allow an MCP server, the Genie token box, the Databricks browser sign-in. If a `bp-helper` tool is missing, say in one line: "Command Palette → MCP: List Servers → bp-helper → Start". Intake stops until it runs; other stages build their page with your own fallback (`playbook/10-review-loop.md` §1.3).
**End every stage reply with the next thing to type** (after APPROVED: the exact next command).

## 1. One stage per command
Run only the stage the user invoked, for the vertical they named (if any). Produce its review page, then stop. Never start another stage or another vertical, even after approval. The user starts every stage.

## 2. Always load state first
Chat context is lost between sessions. Before anything else, read `brd-work/<project>/PROJECT.md`, `STATUS.md` and `MEMORY.md`, plus `verticals/<v>/MEMORY.md` for a vertical stage. If there is more than one project folder, ask which one. If none exists, the only valid command is `/brd-intake`.

## 3. Check the gate
Each stage file lists what must be APPROVED first. If it is not, say what is missing and stop.

## 4. Ask, don't guess
Missing, ambiguous or contradictory information is asked, never assumed. Technical facts: Genie first if Genie is in use, then the user. Intent, decisions and relationships between verticals: the user. Questions in rounds; record every answer before asking more.

## 5. Review page, feedback, approval (every stage)
Follow `playbook/10-review-loop.md`: write the page Markdown, build and open the HTML with `bp-helper` → `build_page`, keep every round, accept feedback from chat, from `FEEDBACK FILE` (`collect_feedback`) and from pasted page feedback, redraft into the next round. Only a chat message containing **APPROVED** approves a stage. HTML "Agree" clicks are feedback, not approval.

## 6. Databricks evidence (Genie or dbsql)
Check `PROJECT.md` for the Databricks status and show it on every page. If Genie or SQL is in use: follow `playbook/11-genie-protocol.md` (read-only, SQL check, verification pass, user confirmation). If not in use: never call `genie` or `dbsql` tools and never present anything as a Databricks finding.
**Never ask the user to paste a token or password in chat.** Tokens are entered only in VS Code's own prompt for the MCP server.

## 7. Read-only and safe
Everything against Databricks is read-only, on every run and rerun. No credentials or sensitive row-level data in any file. Write only inside `brd-work/<project>/` (and `.vscode/mcp.json` during intake, without secrets; keep its `bp-helper` entry). Never edit files in any `sources/` folder; new source files come in only through `import_brd_file`.

## 8. Nothing is overwritten
Review rounds, feedback files and BRD versions are kept. A rebuilt BRD is always a new version.

## 9. Provenance
Every statement cites a source (`SRC-…` + section), a decision (`DEC-…`), a relationship (`REL-…`) or a Genie finding (`GQ-…`). If it has none, it does not go in.

## 10. Current-state blueprint, in depth
This playbook documents an **existing** system from the evidence (the BRDs from the BRD Reconstruction agent, answers, Databricks checks). Never ask which technology to use and never design a target. Put everything the evidence holds into the blueprint, label every statement (Confirmed / From evidence / Inferred / Conflicting / Unknown), keep unknowns visible as questions and risks, and draw every diagram required by `playbook/diagram-standard.md` (Mermaid; business flows, technical flows, sequences, data models, lineage, lifecycles, schedules, context, integration). Every diagram is followed by a detailed description: What this diagram shows, a numbered Walkthrough, and every Scenario (normal, alternatives, exceptions, edge cases, unknown). Check diagrams with `bp-helper` → `check_diagrams` before building a page.
