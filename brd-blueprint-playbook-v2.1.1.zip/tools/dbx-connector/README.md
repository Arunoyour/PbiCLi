# Databricks without a token: `dbx-connector`

Use this when nobody can create a Databricks personal access token (PAT). You sign in **with your normal company account in the browser**, exactly as you do for the Databricks web page. There is no token to create, copy or paste.

The connector is a small Python file that VS Code starts for you. It is named **`dbsql`**, so the BRD agents, `/brd-setup` and `/brd-connect` work without any change.

| | |
|---|---|
| Needs | Python 3.8 or newer (already used for the Word conversion), and your normal Databricks access with **CAN USE on a SQL warehouse** (if you can run a query in the Databricks SQL editor, you have it) |
| Downloads | None. Standard Python only, nothing from GitHub or pip |
| Sign-in | Browser, once per VS Code session. Renewed automatically while VS Code is open. Kept in memory only, never written to disk |
| Safety | Only `SELECT`, `WITH`, `SHOW`, `DESCRIBE`, `EXPLAIN`. Anything that could change data, objects, permissions or settings is refused **before** it reaches Databricks. One statement per call. Queries over 15 minutes are cancelled. 200 rows by default, 5,000 maximum |

## Set up (5 minutes, once per laptop)

### 1. Copy the folder
Put `tools/dbx-connector/` into the workspace, next to the other `tools/` folders.

### 2. Test it outside VS Code
Open a terminal in the workspace folder (VS Code: **Terminal → New Terminal**) and run, with your workspace address:

```
python tools/dbx-connector/dbx_readonly_mcp.py --host https://adb-XXXXXXXXXXXXXXXX.XX.azuredatabricks.net --test
```

If `python` is not recognised, use `py` instead of `python`.

A browser tab opens with the company sign-in. Sign in and you will see *"Signed in. You can close this tab and go back to VS Code."* The terminal then shows:

```
1/4 Signing in (browser)...       OK
2/4 SQL warehouses visible to you: ...
3/4 Who am I: your.name@company.com
4/4 Catalogs you can see: ...
All good
```

### 3. Point VS Code at it
Open `.vscode/mcp.json` and **replace** the `dbsql` entry (the one with `Bearer ${input:dbx_token}`) with the one in `.vscode/mcp.dbsql-nopat.example.json`, with your host filled in:

```json
{
  "servers": {
    "dbsql": {
      "type": "stdio",
      "command": "python",
      "args": [
        "${workspaceFolder}/tools/dbx-connector/dbx_readonly_mcp.py",
        "--host", "https://adb-XXXXXXXXXXXXXXXX.XX.azuredatabricks.net"
      ]
    }
  }
}
```

Keep any other servers (`genie`, `ado`) that are already in the file. Remove the `dbx_token` input if nothing else uses it.

### 4. Start it
1. Command Palette (**Ctrl+Shift+P**) → **MCP: List Servers** → `dbsql` → **Start** (or **Restart**).
2. In Copilot Chat, open the tool picker for the **BRD Reconstruction** agent and make sure the `dbsql` tools (`execute_sql`, `connection_info`, `list_warehouses`) are ticked.
3. New chat → **`/brd-connect`**. The first Databricks query opens the browser sign-in; sign in and the test continues.

## Options (add to `args` if needed)
| Option | When |
|---|---|
| `"--warehouse", "<warehouse id>"` | You have several SQL warehouses and want a specific one (the ID is in Databricks → SQL Warehouses → the warehouse → Connection details, or ask the agent to run `list_warehouses`). Otherwise a running warehouse is picked automatically |
| `"--auth", "azure-cli"` | Your company blocks the browser sign-in, but the Azure CLI is installed and `az login` works. Tokens are fetched from the Azure CLI automatically |
| `"--port", "8021"` | Port 8020 is already in use on your laptop. Only use this if the sign-in error says the port is busy; Databricks may refuse other ports |
| `"command": "py"` | `python` is not recognised on your laptop |

## Problems
| Message | Meaning | What to do |
|---|---|---|
| `python` / `py` not recognised | Python not installed or not on PATH | Install Python from the company software portal (tick *Add to PATH*) |
| Browser shows an error about the app or *OAuth application not available* | Your company disabled Databricks browser sign-in for desktop tools | Try `--auth azure-cli`. Otherwise ask the Databricks account admin to enable the **Databricks CLI** OAuth app (it is on by default) |
| `Port 8020 is busy` | Another sign-in window or the Databricks CLI is open | Close it, restart `dbsql` |
| `No SQL warehouse is visible to you` | No CAN USE on any SQL warehouse | Ask the admin for CAN USE on one warehouse |
| `Cannot reach ... Check VPN / proxy` | Laptop cannot reach the workspace | Connect to VPN; check the host |
| `HTTP 403 ... PERMISSION_DENIED` on a table | Your Unity Catalog rights do not cover it | Expected for objects outside your access; the agent records it |
| `REFUSED (read-only connection)` | The agent tried something that is not a read | Correct behaviour. If a column is literally named `update` or `delete`, write it in back-ticks |
| The sign-in page opens again after a long break | The sign-in expired | Sign in again; the query continues |

## What it does, exactly
- Signs you in with OAuth (authorization code with PKCE) against your workspace using Databricks' built-in desktop app `databricks-cli`, the same method the Databricks CLI uses. Your normal Databricks permissions apply. The connector cannot see anything you cannot see in the Databricks web page.
- Runs each statement on a SQL warehouse through the Databricks SQL Statement Execution API, waits for it (max 15 minutes, then cancels) and returns the rows as a table.
- Writes nothing anywhere except a short status line in the VS Code output log.
