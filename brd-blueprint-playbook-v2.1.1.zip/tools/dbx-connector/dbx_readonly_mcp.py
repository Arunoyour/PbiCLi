#!/usr/bin/env python3
"""
dbx_readonly_mcp.py - read-only Databricks connection for the BRD Reconstruction agent, WITHOUT a personal access token.

What it is
    A small MCP server (stdio) that VS Code starts for you. It is named "dbsql" in .vscode/mcp.json, so the agents'
    existing 'dbsql/*' tools and the playbook work unchanged. It runs SQL on a Databricks SQL warehouse through the
    Statement Execution API and refuses anything that is not read-only.

How you sign in (no token to copy, nothing to paste)
    --auth browser    (default) your browser opens the normal Databricks / company sign-in page once per VS Code session
                      (OAuth user-to-machine, the same method the Databricks CLI uses). The sign-in is kept in memory only
                      and renewed automatically; nothing is written to disk.
    --auth azure-cli  uses your existing 'az login' (Microsoft Entra ID). Tokens are fetched and renewed automatically.

Safety
    - Only SELECT / WITH / SHOW / DESCRIBE / EXPLAIN statements, one statement per call. Anything that could change data,
      objects, permissions, files or settings is refused before it reaches Databricks.
    - No query runs longer than 15 minutes (it is cancelled). Results are capped (default 200 rows, max 5,000).
    - No secrets in any file. Uses only the Python standard library (Python 3.8+), so nothing to download.

Test outside VS Code first:
    python tools/dbx-connector/dbx_readonly_mcp.py --host https://adb-123.11.azuredatabricks.net --test
"""
import argparse
import base64
import hashlib
import http.server
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser

VERSION = "1.0.0"
CLIENT_ID = "databricks-cli"            # Databricks' built-in public OAuth app (used by the Databricks CLI)
SCOPES = "all-apis offline_access"
AZURE_DATABRICKS_RESOURCE = "2ff814a6-3304-4ab8-85cb-cd0e6f879c1d"
MAX_RUN_SECONDS = 15 * 60
DEFAULT_ROWS = 200
MAX_ROWS = 5000
MAX_TEXT = 60000


def log(msg):
    sys.stderr.write("[dbx-connector] " + msg + "\n")
    sys.stderr.flush()


# --------------------------------------------------------------------------------------------- read-only guard
ALLOWED_START = {"SELECT", "WITH", "SHOW", "DESCRIBE", "DESC", "EXPLAIN", "VALUES", "TABLE", "FROM"}
FORBIDDEN = {
    "INSERT", "UPDATE", "DELETE", "MERGE", "CREATE", "DROP", "ALTER", "GRANT", "REVOKE", "DENY", "TRUNCATE",
    "COPY", "OPTIMIZE", "VACUUM", "ZORDER", "CALL", "EXEC", "EXECUTE", "REFRESH", "RESTORE", "REPAIR", "MSCK",
    "CACHE", "UNCACHE", "ANALYZE", "SET", "RESET", "USE", "PUT", "REMOVE", "INSTALL",
    "CLONE", "UNDROP", "SYNC", "APPLY", "DECLARE", "BEGIN", "COMMIT", "ROLLBACK", "LOAD", "IMPORT",
}
# Words that may legitimately follow SHOW / DESCRIBE and are not writes (e.g. SHOW CREATE TABLE, DESCRIBE HISTORY).
SHOW_OK = {"CREATE"}


def _strip(sql):
    """Remove comments and string/identifier literals so keywords inside them are ignored."""
    out, i, n = [], 0, len(sql)
    while i < n:
        c = sql[i]
        if sql.startswith("--", i):
            j = sql.find("\n", i)
            i = n if j < 0 else j
            out.append(" ")
        elif sql.startswith("/*", i):
            j = sql.find("*/", i + 2)
            i = n if j < 0 else j + 2
            out.append(" ")
        elif c in "'\"`":
            j = i + 1
            while j < n:
                if sql[j] == "\\":
                    j += 2
                    continue
                if sql[j] == c:
                    if j + 1 < n and sql[j + 1] == c:
                        j += 2
                        continue
                    break
                j += 1
            out.append(" x ")
            i = j + 1
        else:
            out.append(c)
            i += 1
    return "".join(out)


def check_read_only(sql):
    """Return None if the statement is read-only, otherwise the reason it was refused."""
    body = _strip(sql).strip()
    if not body:
        return "Empty statement."
    if ";" in body.rstrip(";").rstrip():
        return "Only one statement per call (found ';' inside the text)."
    words = re.findall(r"[A-Za-z_][A-Za-z0-9_]*", body.upper())
    if not words or words[0] not in ALLOWED_START:
        return "Only SELECT, WITH, SHOW, DESCRIBE and EXPLAIN are allowed (this starts with '%s')." % (words[0] if words else "?")
    for k, w in enumerate(words):
        if w == "COMMENT" and k + 1 < len(words) and words[k + 1] == "ON":
            return "Refused: COMMENT ON changes object comments. This connection is read-only."
        if w in FORBIDDEN:
            if w in SHOW_OK and words[0] in ("SHOW",) and k == 1:
                continue
            return ("Refused: the statement contains '%s', which can change data or settings. This connection is "
                    "read-only. If '%s' is a column or table name, put it in back-ticks (`%s`)." % (w, w, w.lower()))
    return None


# --------------------------------------------------------------------------------------------- HTTP helper
def http_json(method, url, token=None, body=None, form=None, timeout=120):
    headers = {"User-Agent": "brd-dbx-connector/" + VERSION, "Accept": "application/json"}
    data = None
    if token:
        headers["Authorization"] = "Bearer " + token
    if form is not None:
        data = urllib.parse.urlencode(form).encode()
        headers["Content-Type"] = "application/x-www-form-urlencoded"
    elif body is not None:
        data = json.dumps(body).encode()
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode("utf-8", "replace")
            return json.loads(raw) if raw.strip() else {}
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", "replace")
        try:
            detail = json.loads(raw)
            msg = detail.get("message") or detail.get("error_description") or detail.get("error") or raw
        except Exception:
            msg = raw[:500]
        raise RuntimeError("HTTP %s from %s: %s" % (e.code, urllib.parse.urlparse(url).path, msg))
    except urllib.error.URLError as e:
        raise RuntimeError("Cannot reach %s (%s). Check VPN / proxy / host name." % (urllib.parse.urlparse(url).netloc, e.reason))


# --------------------------------------------------------------------------------------------- authentication
class BrowserAuth:
    """OAuth user-to-machine with PKCE against the workspace (client 'databricks-cli'). Tokens live in memory only."""

    def __init__(self, host, port=8020):
        self.host, self.port = host, port
        self.access, self.refresh, self.expires = None, None, 0
        self.lock = threading.Lock()

    def _login(self):
        verifier = secrets.token_urlsafe(48)[:64]
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip("=")
        state = secrets.token_urlsafe(16)
        redirect = "http://localhost:%d" % self.port
        result = {}

        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):  # noqa: N802
                q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                if "code" in q or "error" in q:
                    result.update({k: v[0] for k, v in q.items()})
                    ok = "code" in q and q.get("state", [""])[0] == state
                    text = ("Signed in. You can close this tab and go back to VS Code." if ok else
                            "Sign-in failed: %s. Close this tab and try again." % q.get("error_description", q.get("error", ["state mismatch"]))[0])
                else:
                    text = "Waiting for Databricks sign-in..."
                page = "<html><body style='font-family:Segoe UI,Arial;padding:40px'><h2>BRD Databricks connection</h2><p>%s</p></body></html>" % text
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(page.encode())

            def log_message(self, *a):
                pass

        try:
            srv = http.server.HTTPServer(("localhost", self.port), Handler)
        except OSError:
            raise RuntimeError("Port %d is busy (another sign-in window or the Databricks CLI is using it). Close it and restart the dbsql server." % self.port)
        srv.timeout = 1
        params = {
            "client_id": CLIENT_ID, "redirect_uri": redirect, "response_type": "code", "scope": SCOPES,
            "state": state, "code_challenge": challenge, "code_challenge_method": "S256",
        }
        url = self.host + "/oidc/v1/authorize?" + urllib.parse.urlencode(params)
        log("Opening the browser for Databricks sign-in. If it does not open, paste this address into your browser:\n" + url)
        try:
            webbrowser.open(url)
        except Exception:
            pass
        deadline = time.time() + 300
        try:
            while "code" not in result and "error" not in result and time.time() < deadline:
                srv.handle_request()
        finally:
            srv.server_close()
        if "error" in result:
            raise RuntimeError("Sign-in refused: %s %s" % (result.get("error"), result.get("error_description", "")))
        if "code" not in result:
            raise RuntimeError("Sign-in not completed within 5 minutes. Restart the dbsql server to try again.")
        if result.get("state") != state:
            raise RuntimeError("Sign-in answer did not match (state). Try again.")
        tok = http_json("POST", self.host + "/oidc/v1/token", form={
            "grant_type": "authorization_code", "code": result["code"], "redirect_uri": redirect,
            "client_id": CLIENT_ID, "code_verifier": verifier,
        })
        self._store(tok)
        log("Signed in to Databricks.")

    def _store(self, tok):
        self.access = tok["access_token"]
        self.refresh = tok.get("refresh_token", self.refresh)
        self.expires = time.time() + int(tok.get("expires_in", 3600))

    def token(self):
        with self.lock:
            if self.access and time.time() < self.expires - 120:
                return self.access
            if self.refresh:
                try:
                    self._store(http_json("POST", self.host + "/oidc/v1/token", form={
                        "grant_type": "refresh_token", "refresh_token": self.refresh, "client_id": CLIENT_ID}))
                    return self.access
                except Exception as e:  # refresh expired: sign in again
                    log("Renewal failed (%s); signing in again." % e)
            self._login()
            return self.access


class AzureCliAuth:
    """Microsoft Entra ID token from the Azure CLI ('az login' done once by the user)."""

    def __init__(self, host):
        self.host = host
        self.access, self.expires = None, 0
        self.lock = threading.Lock()

    def token(self):
        with self.lock:
            if self.access and time.time() < self.expires - 120:
                return self.access
            az = shutil.which("az") or shutil.which("az.cmd")
            if not az:
                raise RuntimeError("Azure CLI ('az') not found. Use --auth browser, or install the Azure CLI and run 'az login'.")
            p = subprocess.run([az, "account", "get-access-token", "--resource", AZURE_DATABRICKS_RESOURCE, "-o", "json"],
                               capture_output=True, text=True, timeout=120)
            if p.returncode != 0:
                raise RuntimeError("Azure CLI could not get a token. Run 'az login' in a terminal first. (%s)" % p.stderr.strip()[:300])
            d = json.loads(p.stdout)
            self.access = d["accessToken"]
            exp = d.get("expires_on")
            self.expires = float(exp) if exp else time.time() + 3000
            return self.access


# --------------------------------------------------------------------------------------------- Databricks SQL
class Databricks:
    def __init__(self, host, auth, warehouse_id=None):
        self.host, self.auth, self.warehouse_id = host, auth, warehouse_id

    def api(self, method, path, body=None, timeout=120):
        return http_json(method, self.host + path, token=self.auth.token(), body=body, timeout=timeout)

    def warehouses(self):
        return self.api("GET", "/api/2.0/sql/warehouses").get("warehouses", [])

    def pick_warehouse(self):
        if self.warehouse_id:
            return self.warehouse_id
        whs = self.warehouses()
        if not whs:
            raise RuntimeError("No SQL warehouse is visible to you. Ask the Databricks admin for CAN USE on a SQL warehouse, "
                               "or put its ID in .vscode/mcp.json (--warehouse).")
        order = {"RUNNING": 0, "STARTING": 1, "STOPPED": 2}
        whs.sort(key=lambda w: (order.get(w.get("state"), 3), 0 if w.get("enable_serverless_compute") else 1))
        self.warehouse_id = whs[0]["id"]
        log("Using SQL warehouse '%s' (%s)." % (whs[0].get("name"), self.warehouse_id))
        return self.warehouse_id

    def run(self, sql, row_limit=DEFAULT_ROWS):
        reason = check_read_only(sql)
        if reason:
            return {"refused": reason}
        row_limit = max(1, min(int(row_limit or DEFAULT_ROWS), MAX_ROWS))
        wh = self.pick_warehouse()
        start = time.time()
        r = self.api("POST", "/api/2.0/sql/statements", body={
            "warehouse_id": wh, "statement": sql.strip().rstrip(";"), "wait_timeout": "30s",
            "on_wait_timeout": "CONTINUE", "disposition": "INLINE", "format": "JSON_ARRAY", "row_limit": row_limit + 1,
        }, timeout=90)
        sid = r.get("statement_id")
        while r.get("status", {}).get("state") in ("PENDING", "RUNNING"):
            if time.time() - start > MAX_RUN_SECONDS:
                try:
                    self.api("POST", "/api/2.0/sql/statements/%s/cancel" % sid)
                finally:
                    return {"error": "Cancelled after 15 minutes (playbook limit). Narrow the query: filter, sample or aggregate."}
            time.sleep(3)
            r = self.api("GET", "/api/2.0/sql/statements/%s" % sid)
        st = r.get("status", {})
        if st.get("state") != "SUCCEEDED":
            err = st.get("error", {})
            return {"error": "%s: %s" % (st.get("state"), err.get("message", "no detail"))}
        cols = [c.get("name") for c in r.get("manifest", {}).get("schema", {}).get("columns", [])]
        rows = (r.get("result") or {}).get("data_array") or []
        truncated = len(rows) > row_limit or bool(r.get("manifest", {}).get("truncated"))
        rows = rows[:row_limit]
        return {"columns": cols, "rows": rows, "row_count": len(rows), "truncated": truncated,
                "seconds": round(time.time() - start, 1), "warehouse_id": wh, "statement_id": sid}


def format_result(res):
    if "refused" in res:
        return "REFUSED (read-only connection): " + res["refused"], True
    if "error" in res:
        return "ERROR: " + res["error"], True
    cols, rows = res["columns"], res["rows"]

    def cell(v):
        s = "NULL" if v is None else str(v)
        return s.replace("|", "\\|").replace("\n", " ")

    lines = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    for row in rows:
        lines.append("| " + " | ".join(cell(v) for v in row) + " |")
    head = "%d row(s) in %ss%s. Warehouse %s. Statement %s." % (
        res["row_count"], res["seconds"], " (TRUNCATED: more rows exist; add a filter, LIMIT or aggregate)" if res["truncated"] else "",
        res["warehouse_id"], res["statement_id"])
    text = head + "\n\n" + "\n".join(lines)
    if len(text) > MAX_TEXT:
        text = text[:MAX_TEXT] + "\n... (output cut at %d characters; ask for fewer columns or rows)" % MAX_TEXT
    return text, False


# --------------------------------------------------------------------------------------------- MCP (stdio JSON-RPC)
TOOLS = [
    {
        "name": "execute_sql",
        "description": ("Run ONE read-only SQL statement on Databricks (Unity Catalog) through a SQL warehouse and return the rows. "
                        "Allowed: SELECT, WITH ... SELECT, SHOW, DESCRIBE (incl. DESCRIBE HISTORY ... / DESCRIBE DETAIL), "
                        "SHOW CREATE TABLE, EXPLAIN. Everything else is refused. Use three-part names catalog.schema.table. "
                        "Max 15 minutes per query; default 200 rows, max 5000."),
        "inputSchema": {
            "type": "object",
            "properties": {
                "statement": {"type": "string", "description": "One read-only SQL statement."},
                "row_limit": {"type": "integer", "description": "Max rows to return (default 200, max 5000)."},
            },
            "required": ["statement"],
        },
    },
    {
        "name": "connection_info",
        "description": "Show who is signed in, the workspace host, the sign-in method and the SQL warehouse in use. Runs SELECT current_user().",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "list_warehouses",
        "description": "List the SQL warehouses visible to the signed-in user (id, name, state, size).",
        "inputSchema": {"type": "object", "properties": {}},
    },
]


class Server:
    def __init__(self, dbx, auth_mode):
        self.dbx, self.auth_mode = dbx, auth_mode
        self.out_lock = threading.Lock()

    def send(self, msg):
        data = json.dumps(msg, ensure_ascii=False) + "\n"
        with self.out_lock:
            sys.stdout.buffer.write(data.encode("utf-8"))
            sys.stdout.buffer.flush()

    def call_tool(self, name, args):
        try:
            if name == "execute_sql":
                return format_result(self.dbx.run(args.get("statement", ""), args.get("row_limit")))
            if name == "connection_info":
                res = self.dbx.run("SELECT current_user() AS signed_in_as, current_catalog() AS default_catalog", 5)
                if "error" in res:
                    return "ERROR: " + res["error"], True
                who = res["rows"][0][0] if res["rows"] else "?"
                return ("Signed in as: %s\nHost: %s\nSign-in method: %s (no personal access token)\nSQL warehouse: %s\n"
                        "Connector: dbx_readonly_mcp %s (read-only guard on)" % (who, self.dbx.host, self.auth_mode,
                                                                               self.dbx.warehouse_id, VERSION)), False
            if name == "list_warehouses":
                whs = self.dbx.warehouses()
                lines = ["| id | name | state | size | serverless |", "|---|---|---|---|---|"]
                for w in whs:
                    lines.append("| %s | %s | %s | %s | %s |" % (w.get("id"), w.get("name"), w.get("state"),
                                                              w.get("cluster_size"), w.get("enable_serverless_compute")))
                return "\n".join(lines) if whs else "No SQL warehouses visible to this user.", False
            return "Unknown tool: " + name, True
        except Exception as e:
            return "ERROR: %s" % e, True

    def handle(self, msg):
        mid, method = msg.get("id"), msg.get("method")
        if mid is None:          # notification (e.g. notifications/initialized): no answer
            return
        try:
            if method == "initialize":
                pv = (msg.get("params") or {}).get("protocolVersion") or "2025-06-18"
                result = {"protocolVersion": pv, "capabilities": {"tools": {"listChanged": False}},
                          "serverInfo": {"name": "dbsql-readonly", "version": VERSION},
                          "instructions": "Read-only Databricks SQL. Use execute_sql for SELECT/SHOW/DESCRIBE only."}
            elif method == "ping":
                result = {}
            elif method == "tools/list":
                result = {"tools": TOOLS}
            elif method == "tools/call":
                p = msg.get("params") or {}
                text, is_err = self.call_tool(p.get("name"), p.get("arguments") or {})
                result = {"content": [{"type": "text", "text": text}], "isError": is_err}
            elif method in ("resources/list", "prompts/list"):
                result = {"resources": []} if method == "resources/list" else {"prompts": []}
            else:
                self.send({"jsonrpc": "2.0", "id": mid, "error": {"code": -32601, "message": "Method not found: %s" % method}})
                return
            self.send({"jsonrpc": "2.0", "id": mid, "result": result})
        except Exception as e:
            self.send({"jsonrpc": "2.0", "id": mid, "error": {"code": -32603, "message": str(e)}})

    def serve(self):
        for raw in sys.stdin.buffer:
            line = raw.decode("utf-8", "replace").strip()
            if not line:
                continue
            try:
                msg = json.loads(line)
            except ValueError:
                continue
            # tools/call can take minutes (sign-in, long query): answer it on its own thread
            if msg.get("method") == "tools/call":
                threading.Thread(target=self.handle, args=(msg,), daemon=True).start()
            else:
                self.handle(msg)


# --------------------------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description="Read-only Databricks MCP server (no personal access token).")
    ap.add_argument("--host", default=os.environ.get("DATABRICKS_HOST"), help="https://adb-....azuredatabricks.net")
    ap.add_argument("--auth", choices=["browser", "azure-cli"], default=os.environ.get("DBX_AUTH", "browser"))
    ap.add_argument("--warehouse", default=os.environ.get("DBX_WAREHOUSE_ID"), help="SQL warehouse ID (optional; picked automatically)")
    ap.add_argument("--port", type=int, default=8020, help="local sign-in port (browser mode; default 8020)")
    ap.add_argument("--test", action="store_true", help="sign in, run SELECT current_user() and a catalog list, then exit")
    ap.add_argument("--check-guard", metavar="SQL", help="only check whether a statement would be allowed")
    a = ap.parse_args()

    if a.check_guard:
        r = check_read_only(a.check_guard)
        print("ALLOWED" if r is None else "REFUSED: " + r)
        return
    if not a.host:
        sys.exit("Missing --host (for example --host https://adb-1234567890123456.7.azuredatabricks.net)")
    host = a.host.strip().rstrip("/")
    if not host.startswith("http"):
        host = "https://" + host
    auth = BrowserAuth(host, a.port) if a.auth == "browser" else AzureCliAuth(host)
    dbx = Databricks(host, auth, a.warehouse)

    if a.test:
        print("1/4 Signing in (%s)..." % a.auth)
        auth.token()
        print("    OK")
        print("2/4 SQL warehouses visible to you:")
        for w in dbx.warehouses():
            print("    - %s  %s  (%s)" % (w.get("id"), w.get("name"), w.get("state")))
        print("3/4 Who am I:")
        print("    " + format_result(dbx.run("SELECT current_user() AS signed_in_as", 5))[0].replace("\n", "\n    "))
        print("4/4 Catalogs you can see:")
        print("    " + format_result(dbx.run("SHOW CATALOGS", 100))[0].replace("\n", "\n    "))
        print("\nAll good: VS Code can now use this connection (MCP: List Servers -> dbsql -> Start).")
        return

    log("dbsql (read-only) %s ready for %s, sign-in: %s. The first query opens the sign-in page." % (VERSION, host, a.auth))
    Server(dbx, a.auth).serve()


if __name__ == "__main__":
    main()
