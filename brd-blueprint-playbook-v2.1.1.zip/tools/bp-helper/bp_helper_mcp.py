#!/usr/bin/env python3
"""
bp_helper_mcp.py - the BRD Programme agent's hands for file work, so the user never copies, moves, converts or opens files.

VS Code starts it from .vscode/mcp.json (server "bp-helper"). Standard library only.

Tools
    workspace_check   is everything in place (folders, templates, projects, Downloads folder)
    find_brd_files    list BRD files in a folder anywhere on this computer (Markdown, Word, text)
    import_brd_file   copy a BRD file into the project (Word is converted to Markdown); the original is never touched
    check_diagrams    lint the Mermaid diagrams in a Markdown file (syntax, captions, counts)
    build_page        turn a review page / blueprint Markdown file into its HTML page (viewer template) and open it
    open_page         open an HTML page from brd-work/ in the default browser
    collect_feedback  find the feedback file the reviewer exported (project feedback folder or the Downloads folder),
                      copy it into the project and return its content

Safety
    - Writes only inside <workspace>/brd-work/. Never deletes, never overwrites (a new name is used instead).
    - Never writes into any sources/ folder except through import_brd_file, and never edits an imported source afterwards.
    - Reads other locations only when the user names them (find_brd_files / import_brd_file) or the Downloads folder
      (collect_feedback, feedback-*.json files only).
"""
import contextlib
import datetime
import glob
import io
import json
import os
import re
import shutil
import sys
import threading
import webbrowser

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import docx_to_md  # noqa: E402  (same folder, standard library only)

VERSION = "2.1.1"
WS = os.path.abspath(os.environ.get("BP_WORKSPACE") or os.path.join(HERE, "..", ".."))
WORK = os.path.join(WS, "brd-work")
VIEWER = os.path.join(WS, "playbook", "templates", "viewer.html")
START, END = "<!-- BLUEPRINT-MARKDOWN-START -->", "<!-- BLUEPRINT-MARKDOWN-END -->"
BRD_EXT = (".md", ".markdown", ".txt", ".docx")


def log(m):
    sys.stderr.write("[bp-helper] " + m + "\n")
    sys.stderr.flush()


def ws_path(p):
    """Resolve a path given by the agent: absolute, or relative to the workspace."""
    p = os.path.expandvars(os.path.expanduser(p.strip().strip('"')))
    return os.path.abspath(p if os.path.isabs(p) else os.path.join(WS, p))


def inside_work(p):
    p = os.path.abspath(p)
    return os.path.commonpath([p, WORK]) == WORK


def safe_name(s):
    return re.sub(r"[^\w.-]+", "-", s).strip("-") or "file"


def no_overwrite(p):
    if not os.path.exists(p):
        return p
    stem, ext = os.path.splitext(p)
    i = 2
    while os.path.exists("%s-%d%s" % (stem, i, ext)):
        i += 1
    return "%s-%d%s" % (stem, i, ext)


def downloads_dirs():
    home = os.path.expanduser("~")
    cands = [os.path.join(home, "Downloads")]
    for k in ("OneDrive", "OneDriveCommercial", "OneDriveConsumer"):
        if os.environ.get(k):
            cands.append(os.path.join(os.environ[k], "Downloads"))
    cands += glob.glob(os.path.join(home, "OneDrive*", "Downloads"))
    seen, out = set(), []
    for c in cands:
        c = os.path.abspath(c)
        if c not in seen and os.path.isdir(c):
            seen.add(c)
            out.append(c)
    return out


def md_check(text):
    lines = text.splitlines()
    return {
        "lines": len(lines),
        "headings": sum(1 for l in lines if re.match(r"#{1,6} ", l)),
        "table_rows": sum(1 for l in lines if l.lstrip().startswith("|")),
        "code_blocks": sum(1 for l in lines if l.strip().startswith("```")) // 2,
        "first_headings": [l.strip() for l in lines if re.match(r"#{1,3} ", l)][:6],
    }


# --------------------------------------------------------------------------------------------- tools
def workspace_check(a):
    projects = sorted(d for d in os.listdir(WORK) if os.path.isdir(os.path.join(WORK, d))) if os.path.isdir(WORK) else []
    checks = [
        ("Workspace folder", WS, os.path.isdir(WS)),
        ("brd-work/ (agent's working area)", WORK, os.path.isdir(WORK)),
        ("Page template (playbook/templates/viewer.html)", VIEWER, os.path.isfile(VIEWER)),
        ("Guardrails (Databricks)", os.path.join(WS, "guardrails", "databricks"), os.path.isdir(os.path.join(WS, "guardrails", "databricks"))),
        ("Guardrails (Fabric)", os.path.join(WS, "guardrails", "fabric"), os.path.isdir(os.path.join(WS, "guardrails", "fabric"))),
    ]
    out = ["bp-helper %s running (Python %s)" % (VERSION, sys.version.split()[0])]
    out += ["%s %s: %s" % ("OK " if ok else "MISSING", name, path) for name, path, ok in checks]
    out.append("Projects in brd-work/: %s" % (", ".join(projects) or "none yet (first command: /brd-intake)"))
    dl = downloads_dirs()
    out.append("Downloads folder (for exported feedback): %s" % (", ".join(dl) or "not found - feedback can be pasted in chat instead"))
    return "\n".join(out)


def find_brd_files(a):
    root = ws_path(a.get("folder", ""))
    if not os.path.exists(root):
        return "Folder not found: %s. Ask the user to check the path (they can copy it from File Explorer's address bar)." % root, True
    if os.path.isfile(root):
        files = [root]
    else:
        depth = int(a.get("depth", 2))
        files = []
        base = root.rstrip(os.sep).count(os.sep)
        for d, dirs, fs in os.walk(root):
            if d.count(os.sep) - base >= depth:
                dirs[:] = []
            dirs[:] = [x for x in dirs if not x.startswith(".") and x not in ("node_modules", "__pycache__")]
            for f in fs:
                if f.lower().endswith(BRD_EXT) and not f.startswith("~$"):
                    files.append(os.path.join(d, f))
    rows = []
    for f in sorted(files)[:300]:
        size = os.path.getsize(f)
        hint = ""
        try:
            if f.lower().endswith(".docx"):
                buf = io.StringIO()
                tmp = os.path.join(WORK, ".tmp-preview.md")
                os.makedirs(WORK, exist_ok=True)
                with contextlib.redirect_stdout(buf):
                    docx_to_md.convert(f, tmp)
                with open(tmp, encoding="utf-8") as fh:
                    hint = " / ".join(md_check(fh.read())["first_headings"][:3])
                os.remove(tmp)
            else:
                with open(f, encoding="utf-8", errors="replace") as fh:
                    hint = " / ".join(md_check(fh.read(200000))["first_headings"][:3])
        except Exception as e:
            hint = "(could not preview: %s)" % e
        rows.append("| %s | %s | %.0f KB | %s |" % (os.path.relpath(f, root) if os.path.isdir(root) else os.path.basename(f),
                                                    os.path.splitext(f)[1].lower(), size / 1024.0, hint.replace("|", "/")))
    if not rows:
        return "No Markdown, Word or text files found in %s." % root
    return ("%d file(s) in %s\n\n| File | Type | Size | First headings |\n|---|---|---|---|\n" % (len(rows), root)) + "\n".join(rows)


def import_brd_file(a):
    src = ws_path(a["source_path"])
    if not os.path.isfile(src):
        return "File not found: %s" % src, True
    project, vertical, sid = safe_name(a["project"]), safe_name(a["vertical"]), safe_name(a["source_id"])
    dest_dir = os.path.join(WORK, project, "verticals", vertical, "sources")
    if not inside_work(dest_dir):
        return "Refused: destination outside brd-work/.", True
    os.makedirs(dest_dir, exist_ok=True)
    stem = safe_name(os.path.splitext(os.path.basename(src))[0])
    ext = os.path.splitext(src)[1].lower()
    if ext in (".md", ".markdown", ".txt"):   # same file imported before: report it, do not make a second copy
        with open(src, "rb") as fh:
            src_bytes = fh.read()
        for f in glob.glob(os.path.join(dest_dir, "%s_*.md" % sid)):
            with open(f, "rb") as fh:
                if fh.read() == src_bytes:
                    return json.dumps({"already_imported": os.path.relpath(f, WS).replace("\\", "/"), "from": src}, indent=2)
    dest = no_overwrite(os.path.join(dest_dir, "%s_%s.md" % (sid, stem)))
    if ext == ".docx":
        with contextlib.redirect_stdout(io.StringIO()):
            docx_to_md.convert(src, dest)
        how = "converted from Word (headings, lists and tables kept; pictures noted as [picture])"
    elif ext in (".md", ".markdown", ".txt"):
        shutil.copyfile(src, dest)
        how = "copied unchanged"
    else:
        return "Unsupported file type %s. Supported: .md, .txt, .docx. (.doc and .pdf: ask the user for a .docx or .md version.)" % ext, True
    with open(dest, encoding="utf-8", errors="replace") as fh:
        chk = md_check(fh.read())
    return json.dumps({"imported": os.path.relpath(dest, WS).replace("\\", "/"), "from": src, "how": how, "check": chk,
                       "original_untouched": True}, indent=2)


def build_page(a):
    md = ws_path(a["markdown_path"])
    if not inside_work(md) or not os.path.isfile(md):
        return "Markdown file not found inside brd-work/: %s" % md, True
    html = ws_path(a["html_path"]) if a.get("html_path") else os.path.splitext(md)[0] + ".html"
    if not inside_work(html):
        return "Refused: HTML must be written inside brd-work/.", True
    with open(VIEWER, encoding="utf-8") as fh:
        tpl = fh.read()
    if tpl.count(START) != 1 or tpl.count(END) != 1:
        return "The page template is damaged (markers missing): %s" % VIEWER, True
    with open(md, encoding="utf-8") as fh:
        text = fh.read()
    text = re.sub(r"</(script)", r"<\\/\1", text, flags=re.I)
    vendor = os.path.join(HERE, "vendor", "mermaid.min.js")
    if os.path.isfile(vendor):
        rel = os.path.relpath(vendor, os.path.dirname(html)).replace("\\", "/")
        tpl = tpl.replace('<html lang="en">', '<html lang="en" data-mermaid="%s">' % rel, 1)
    pre, rest = tpl.split(START, 1)
    _, post = rest.split(END, 1)
    out = pre + START + "\n" + text.rstrip("\n") + "\n" + END + post
    replaced = os.path.exists(html)   # rebuilding a page from its own Markdown (e.g. approval stamp) is allowed
    with open(html, "w", encoding="utf-8") as fh:
        fh.write(out)
    opened = False
    if a.get("open", True):
        try:
            opened = webbrowser.open("file:///" + html.replace("\\", "/").lstrip("/"))
        except Exception:
            opened = False
    return json.dumps({"page": os.path.relpath(html, WS).replace("\\", "/"), "markdown_lines": text.count("\n") + 1,
                       "opened_in_browser": opened, "rebuilt": replaced}, indent=2)


def open_page(a):
    p = ws_path(a["path"])
    if not inside_work(p) or not os.path.isfile(p) or not p.lower().endswith(".html"):
        return "Only existing .html pages inside brd-work/ can be opened: %s" % p, True
    ok = webbrowser.open("file:///" + p.replace("\\", "/").lstrip("/"))
    return "Opened %s in the browser." % os.path.relpath(p, WS) if ok else "Could not open a browser; the page is at %s" % p


def collect_feedback(a):
    project = safe_name(a["project"])
    want = os.path.basename(a["feedback_file"])
    stem, ext = os.path.splitext(want)
    fb_dir = os.path.join(WORK, project, "feedback")
    os.makedirs(fb_dir, exist_ok=True)
    pat = re.compile(r"^%s( ?\(\d+\)|-\d+)?%s$" % (re.escape(stem), re.escape(ext)), re.I)
    found = []
    for d in [fb_dir] + downloads_dirs():
        try:
            for f in os.listdir(d):
                if pat.match(f):
                    p = os.path.join(d, f)
                    found.append((os.path.getmtime(p), p))
        except OSError:
            pass
    if not found:
        where = ", ".join([fb_dir] + downloads_dirs())
        return ("No exported feedback named %s found (looked in: %s). Ask the user to click 'Export review' in the page "
                "(or 'Copy for chat' and paste it here)." % (want, where)), True
    found.sort(reverse=True)
    newest = found[0][1]
    try:
        with open(newest, encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception as e:
        return "Found %s but cannot read it as feedback (%s)." % (newest, e), True
    if os.path.dirname(os.path.abspath(newest)) != os.path.abspath(fb_dir):
        dest = no_overwrite(os.path.join(fb_dir, want))
        shutil.copyfile(newest, dest)
    else:
        dest = newest
    when = datetime.datetime.fromtimestamp(found[0][0]).strftime("%Y-%m-%d %H:%M")
    return ("Feedback file: %s (exported %s, kept in %s)\n\n%s" % (os.path.basename(newest), when,
            os.path.relpath(dest, WS).replace("\\", "/"), json.dumps(data, indent=2, ensure_ascii=False)))


MERMAID_TYPES = ("flowchart", "graph", "sequenceDiagram", "erDiagram", "stateDiagram-v2", "stateDiagram", "gantt", "mindmap",
                 "timeline", "pie", "quadrantChart", "classDiagram", "journey", "xychart-beta", "sankey-beta", "block-beta",
                 "requirementDiagram", "gitGraph", "C4Context", "C4Container", "C4Component", "architecture-beta")
_SPECIAL = re.compile(r"[()\[\]{}|;<>]")


def _lint_flow(lines, errs):
    body = [l for l in lines if l.strip() and not l.strip().startswith("%%")]
    subs = sum(1 for l in body if re.match(r"\s*subgraph\b", l))
    ends = sum(1 for l in body if l.strip() == "end")
    if subs != ends:
        errs.append("%d 'subgraph' but %d 'end' lines" % (subs, ends))
    for n, l in enumerate(body, 1):
        t = re.sub(r'"[^"]*"', '"Q"', l.strip())   # text inside quotes is safe; check only what is outside
        if t.count('"') % 2:
            errs.append("line %d: unbalanced double quote: %s" % (n, l.strip()[:80]))
            continue
        if re.match(r"(subgraph|classDef|class|style|linkStyle|click|direction)\b", t) or re.match(r"(flowchart|graph)\b", t):
            continue
        if re.search(r"(^|[\s;>-])end\s*[\[\(\{>]", t):
            errs.append("line %d: 'end' used as a node id: %s" % (n, t[:80]))
        for m in re.finditer(r"\b(\w+)\s*(\[\[|\[\(|\(\[|\(\(|\[/|\[\\|\[|\(|\{\{|\{)", t):
            rest = t[m.end():]
            if rest.startswith('"'):
                continue
            close = {"[[": "]]", "[(": ")]", "([": "])", "((": "))", "[/": "/]", "[\\": "\\]", "[": "]", "(": ")", "{{": "}}", "{": "}"}[m.group(2)]
            j = rest.find(close)
            label = rest[:j] if j >= 0 else rest
            if j < 0 or _SPECIAL.search(label.replace("<br/>", "").replace("<br>", "")):
                errs.append("line %d: unquoted label with special characters, write %s%s\"...\"%s: %s" % (n, m.group(1), m.group(2), close, t[:90]))
                break
        for m in re.finditer(r"\|([^|]*)\|", t):
            lab = m.group(1)
            if lab and not lab.startswith('"') and _SPECIAL.search(lab):
                errs.append("line %d: edge text with special characters must be quoted: |\"%s\"|" % (n, lab[:40]))


def _lint(kind, lines):
    errs = []
    if kind in ("flowchart", "graph"):
        _lint_flow(lines, errs)
    elif kind == "erDiagram":
        for n, l in enumerate(lines, 1):
            t = l.strip()
            m = re.match(r"([^\s{|}]+)\s*(\|\||\|o|o\||\}o|o\{|\}\||\|\{)", t)
            if m and "." in m.group(1):
                errs.append("line %d: entity names cannot contain dots (%s); use SALES_INVOICE and give the full name in the key table" % (n, m.group(1)))
            m = re.match(r"([^\s{]+)\s*\{\s*$", t)
            if m and "." in m.group(1):
                errs.append("line %d: entity name with a dot: %s" % (n, m.group(1)))
    elif kind == "gantt":
        if not any(l.strip().startswith("dateFormat") for l in lines):
            errs.append("gantt without dateFormat")
    return errs


def check_diagrams(a):
    md = ws_path(a["markdown_path"])
    if not os.path.isfile(md):
        return "File not found: %s" % md, True
    with open(md, encoding="utf-8") as fh:
        lines = fh.read().splitlines()
    section, i, diagrams = "(top)", 0, []
    while i < len(lines):
        l = lines[i]
        h = re.match(r"(#{2,4})\s+(.*)", l)
        if h:
            section = h.group(2).strip()[:60]
        if re.match(r"^```\s*mermaid\s*$", l.strip()):
            start, body = i + 1, []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                body.append(lines[i])
                i += 1
            first = next((b.strip() for b in body if b.strip() and not b.strip().startswith("%%")), "")
            kind = first.split()[0] if first else ""
            errs = [] if kind in MERMAID_TYPES else ["unknown or missing diagram type on the first line: '%s'" % first[:40]]
            errs += _lint(kind, body)
            if i >= len(lines):
                errs.append("block not closed with ```")
            nxt = next((x.strip() for x in lines[i + 1:i + 4] if x.strip()), "")
            caption = nxt if nxt.lower().startswith("figure") else ""
            # the description: text after the diagram, up to the next diagram or the next heading of level 2-3
            k, desc = i + 1, []
            while k < len(lines) and not re.match(r"^```\s*mermaid", lines[k].strip()) and not re.match(r"^#{2,3}\s", lines[k]):
                desc.append(lines[k])
                k += 1
            dtext = "\n".join(desc)
            missing = [m for m, pat in (("What this diagram shows", r"what this diagram shows"), ("Walkthrough", r"walkthrough"),
                                        ("Scenarios", r"scenario")) if not re.search(pat, dtext, re.I)]
            words = len(re.findall(r"[A-Za-z]{2,}", dtext))
            if words < 120:
                missing.append("only %d words of description (expected a detailed walkthrough and scenarios)" % words)
            diagrams.append({"line": start, "section": section, "type": kind, "nodes_or_lines": len(body),
                             "caption": caption[:80], "errors": errs, "desc_missing": missing, "words": words})
        i += 1
    by_type = {}
    for d in diagrams:
        by_type[d["type"]] = by_type.get(d["type"], 0) + 1
    n_err = sum(len(d["errors"]) for d in diagrams)
    no_cap = [d for d in diagrams if not d["caption"]]
    no_desc = [d for d in diagrams if d["desc_missing"]]
    out = ["%d diagram(s) · %d syntax error(s) · %d without a 'Figure n:' caption · %d without a full description"
           % (len(diagrams), n_err, len(no_cap), len(no_desc)),
           "By type: " + (", ".join("%s %d" % kv for kv in sorted(by_type.items())) or "none"),
           "A full description = 'What this diagram shows' + numbered 'Walkthrough' + 'Scenarios' (normal, alternatives, "
           "exceptions, edge cases, unknown) under the caption (playbook/diagram-standard.md section 2).", "",
           "| Line | Section | Type | Lines | Caption | Description | Problems |", "|---|---|---|---|---|---|---|"]
    for d in diagrams:
        out.append("| %d | %s | %s | %d | %s | %s | %s |" % (d["line"], d["section"].replace("|", "/"), d["type"], d["nodes_or_lines"],
                   (d["caption"] or "MISSING").replace("|", "/"),
                   ("%d words, ok" % d["words"]) if not d["desc_missing"] else "MISSING: " + "; ".join(d["desc_missing"]),
                   "; ".join(e.replace("|", "\\|") for e in d["errors"]) or "ok"))
    if d_big := [d for d in diagrams if d["nodes_or_lines"] > 60]:
        out.append("\nLarge diagrams (over 60 lines; consider splitting by phase): " + ", ".join("line %d" % d["line"] for d in d_big))
    return "\n".join(out), (n_err > 0 or bool(no_cap) or bool(no_desc))


S = lambda **p: {"type": "object", "properties": p}  # noqa: E731
STR = {"type": "string"}
TOOLS = [
    {"name": "workspace_check", "description": "Check the helper is running and the workspace is complete; list projects and the Downloads folder used for feedback.",
     "inputSchema": S()},
    {"name": "find_brd_files", "description": "List BRD files (.md, .txt, .docx) in a folder the user named (any path on this computer, or relative to the workspace), with size and first headings. Read-only.",
     "inputSchema": dict(S(folder=STR, depth={"type": "integer", "description": "sub-folder levels (default 2)"}), required=["folder"])},
    {"name": "import_brd_file", "description": "Copy one BRD file into brd-work/<project>/verticals/<vertical>/sources/<source_id>_<name>.md. Word (.docx) is converted to Markdown. Never overwrites; the original is never touched. Returns a conversion check (headings, tables, code blocks).",
     "inputSchema": dict(S(source_path=STR, project={"type": "string", "description": "project folder name"},
                           vertical={"type": "string", "description": "vertical folder name"},
                           source_id={"type": "string", "description": "e.g. SRC-CM-S"}), required=["source_path", "project", "vertical", "source_id"])},
    {"name": "build_page", "description": "Build the HTML page for a review page or blueprint Markdown file in brd-work/ (viewer template; the Markdown goes between the markers unchanged) and open it in the browser. Use this instead of editing HTML by hand.",
     "inputSchema": dict(S(markdown_path=STR, html_path={"type": "string", "description": "optional; default: same name .html"},
                           open={"type": "boolean", "description": "open in browser (default true)"}), required=["markdown_path"])},
    {"name": "open_page", "description": "Open an existing HTML page from brd-work/ in the user's browser.",
     "inputSchema": dict(S(path=STR), required=["path"])},
    {"name": "check_diagrams", "description": "Check every ```mermaid diagram in a Markdown file before building the page: that each has a caption and a full written description (What this diagram shows, Walkthrough, Scenarios), the diagram type, common syntax errors (unquoted labels with brackets, unbalanced subgraph/end, 'end' as a node id, dotted ER entity names, gantt without dateFormat), a 'Figure n:' caption after each, and counts by type and section. Fix every error it reports.",
     "inputSchema": dict(S(markdown_path=STR), required=["markdown_path"])},
    {"name": "collect_feedback", "description": "Find the feedback file exported from a review page (by its name, e.g. feedback-gaps-cm-r1.json) in the project's feedback folder or the user's Downloads folder, copy it into brd-work/<project>/feedback/ and return its content.",
     "inputSchema": dict(S(project=STR, feedback_file=STR), required=["project", "feedback_file"])},
]
FN = {t["name"]: globals()[t["name"]] for t in TOOLS}


class Server:
    def __init__(self):
        self.lock = threading.Lock()

    def send(self, m):
        b = (json.dumps(m, ensure_ascii=False) + "\n").encode("utf-8")
        with self.lock:
            sys.stdout.buffer.write(b)
            sys.stdout.buffer.flush()

    def handle(self, m):
        mid, meth = m.get("id"), m.get("method")
        if mid is None:
            return
        if meth == "initialize":
            r = {"protocolVersion": (m.get("params") or {}).get("protocolVersion") or "2025-06-18",
                 "capabilities": {"tools": {"listChanged": False}}, "serverInfo": {"name": "bp-helper", "version": VERSION}}
        elif meth == "ping":
            r = {}
        elif meth == "tools/list":
            r = {"tools": TOOLS}
        elif meth == "tools/call":
            p = m.get("params") or {}
            fn = FN.get(p.get("name"))
            try:
                if not fn:
                    raise ValueError("Unknown tool %s" % p.get("name"))
                res = fn(p.get("arguments") or {})
                text, err = res if isinstance(res, tuple) else (res, False)
            except KeyError as e:
                text, err = "Missing argument: %s" % e, True
            except Exception as e:
                text, err = "ERROR: %s" % e, True
            r = {"content": [{"type": "text", "text": text}], "isError": err}
        elif meth in ("resources/list", "prompts/list"):
            r = {meth.split("/")[0]: []}
        else:
            self.send({"jsonrpc": "2.0", "id": mid, "error": {"code": -32601, "message": "Method not found"}})
            return
        self.send({"jsonrpc": "2.0", "id": mid, "result": r})

    def serve(self):
        for raw in sys.stdin.buffer:
            line = raw.decode("utf-8", "replace").strip()
            if not line:
                continue
            try:
                m = json.loads(line)
            except ValueError:
                continue
            self.handle(m)


if __name__ == "__main__":
    if "--check" in sys.argv:
        print(workspace_check({}))
    else:
        log("bp-helper %s ready (workspace %s)" % (VERSION, WS))
        Server().serve()
