# BRD to Blueprint playbook v2.1.1 (VS Code + GitHub Copilot)

Builds a **detailed current-state blueprint of an existing, poorly documented system** split into **verticals** (modules), from whatever evidence there is: the BRDs the **BRD Reconstruction** agent produced for each vertical (Functional, Technical, Summary), your answers, and (optionally) Databricks checks. It explains how the system works today, business and technical, with **many diagrams**: context, capability map, business flows, technical flows, run sequences, schedule, dependencies, integration, data models, lineage, status lifecycles, evidence mix and risks. Every statement shows how sure we are (Confirmed / From evidence / Inferred / Conflicting / Unknown). **No target technology is asked for or designed.**

**v2.0 is command-only.** You choose the agent and type the commands, one by one. The agent does all the file work itself: it finds and imports your BRD files (Word is converted for you), builds and opens every review page, and picks up the feedback you export from a page. You never copy, move, rename or convert a file, and you never open a terminal.

## 1. Once per laptop (5 minutes)

1. Unzip the playbook into a new folder, for example `C:\Workspace\Blueprint-Customer360`.
2. VS Code → **File → Open Folder** → that folder. If VS Code asks whether you trust the folder, choose **Trust**.
3. Python 3.8 or newer must be installed (it already is if you use the BRD Reconstruction playbook). Nothing else to install.

That is all the setup. The helper the agent uses (`bp-helper`) is already configured in `.vscode/mcp.json` and starts by itself the first time the agent needs it. If VS Code asks *"Start MCP server bp-helper?"* or *"Allow tools?"*, choose **Start** / **Allow**.

## 2. How you use it

1. Open **Copilot Chat** and choose the **BRD Programme** agent in the agent picker.
2. Type **`/brd-intake`** and answer the questions. When it asks where the BRD files are, give the folder, for example `C:\BRDs\Customer360` (copy it from File Explorer's address bar). The agent finds the files, proposes which vertical each belongs to, and imports them.
3. Every step ends the same way:
   - the **review page opens in your browser** by itself;
   - you reply in chat: **`APPROVED`**, **`FEEDBACK: …`** or **`HALT`** (or give feedback in the page, see section 3);
   - after `APPROVED`, the agent tells you the **exact next command**. Type it. That is the whole flow.
4. Not sure where you are? Type **`/brd-status`**, or just **`/brd-next`** to run the next step.

| # | Command | You do |
|---|---|---|
| 1 | `/brd-intake` | Project name → Databricks connection (Genie / SQL with browser sign-in / none) → verticals → **folder with the BRD files** → order |
| 2 | `/brd-read-all` | Check the overview of every vertical, the first relationship map and the proposed order |
| 3 | `/brd-understand <vertical>` | Check the agent understood the vertical |
| 4 | `/brd-gaps <vertical>` | Check the gaps, including those at the edges with other verticals |
| 5 | `/brd-clarify <vertical>` | Answer the questions (in chat or the page) and confirm Databricks findings |
|   | *3–5 for each vertical, in the approved order (the agent tells you which is next)* | |
| 6 | `/brd-relationships` | Confirm how the verticals relate, shared definitions, build order |
| 7 | `/brd-readiness` | See what the evidence covers per vertical; answer what you know (the rest becomes Unknown + risk) |
| 8 | `/brd-rebuild <vertical>` | Review the updated BRD version (with your answers) for each vertical |
| 9 | `/brd-bp-vertical <vertical>` | Review each vertical's chapter: business flow, detailed technical flow, run sequences, every procedure, pipeline and table, calculations, data model, lineage, lifecycles, findings |
| 10 | `/brd-bp-business` | System context and business architecture (capabilities, end-to-end process, calendar, rules, entities, outputs) |
| 11 | `/brd-bp-technical` | Technology landscape, overall technical flow, schedule and dependencies, integration, environments, run behaviour |
| 12 | `/brd-bp-data` | Data architecture, end-to-end lineage, data stores, code sets, volumes; cross-vertical view |
| 13 | `/brd-bp-operations` | Controls, security and audit, non-functional observations, operations and support |
| 14 | `/brd-bp-findings` | Technical debt and findings, open questions and risks, evidence and confidence, considerations for future change |
| 15 | `/brd-bp-assemble` | Review the full blueprint (one document, MD + HTML) |
| 16 | `/brd-arch-review` | An independent Architect Reviewer challenges the blueprint (VS Code switches to that agent by itself) |
| 17 | `/brd-arch-respond` | The author answers every finding (switches back by itself); you approve the final blueprint |

Any time: `/brd-status` (where am I), `/brd-next` (run the next step), `/brd-feedback` (apply feedback from the page).

## 3. Giving feedback in the page (optional; chat is enough)

In the page: mark each section **Agree** or **Request a change**, answer the boxes under questions, type your name at the bottom, then either:
- **Export review** → in chat type **`FEEDBACK FILE`**. The agent finds the downloaded file in your Downloads folder by itself; or
- **Copy for chat** → paste into Copilot Chat and press Enter.

Clicking "Agree" in the page is feedback, not approval: only **`APPROVED`** typed in chat approves a step.

## 4. Databricks evidence (optional, chosen at `/brd-intake`)

| Option | When | What you do |
|---|---|---|
| **Genie** | A Genie space holds the technical metadata and you have a token | Nothing in chat: VS Code asks for the token in its own box. Never paste a token in chat |
| **Databricks SQL, browser sign-in** | No token available, but you can use Databricks | Sign in once in the browser page that opens. Read-only connector, `tools/dbx-connector/README.md` |
| **None** | No access | Everything comes from the BRD files and your answers; every page says so |

The agent writes the connection into `.vscode/mcp.json` itself. Everything against Databricks is read-only, on every run and rerun.

## 5. What gets kept
- Your original BRD files are never touched; the agent works on imported copies in `brd-work/<project>/verticals/<v>/sources/`.
- Every review round and feedback file is kept (`reviews/`, `feedback/`).
- Rebuilt BRDs are versioned (`BRD_v1`, `v2` …) with a `CHANGELOG.md`; the blueprint uses only approved versions.

## 6. If something does not work
| You see | Do |
|---|---|
| The agent says the **helper is not running** | Command Palette (**Ctrl+Shift+P**) → **MCP: List Servers** → `bp-helper` → **Start**. If it fails with "python not found", open `.vscode/mcp.json` and change `"python"` to `"py"` |
| The agent runs on into the next step | Type `HALT`; `/brd-status` shows where you are |
| The page did not open | The agent prints its path; it can also reopen it: type "open the page" |
| Feedback file not found | Click **Export review** again, or use **Copy for chat** |

## 7. What the blueprint contains
20 sections and 7 appendices (`playbook/templates/blueprint-template.md`), with at least 17 system-wide diagrams and 7–9 per vertical (`playbook/diagram-standard.md`). **Every diagram is followed by a detailed description**: what it shows, a step-by-step walkthrough, and every scenario (normal path, alternatives, exceptions and failures, edge cases, unknowns). Diagrams are drawn in the page (Mermaid, included in the playbook, works offline); click one to enlarge it.

What changed: `CHANGELOG.md`.
