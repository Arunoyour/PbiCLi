# Changelog

## 2.1.1 — 2026-11-06 · Every diagram explained in detail
- `diagram-standard.md` §2: under every diagram's caption, a written description is now mandatory: **What this diagram shows** (plain English), a numbered **Walkthrough** of every step (what, why, objects, rule and exact condition, data read/written, timing, label and evidence) and **Scenarios** — the normal path, every alternative path, exceptions and failures, edge cases (no rows, duplicates, late data, nulls, boundary dates, month-end, back-dated changes) and unknown paths — each with *When it applies*, *What happens*, *Outcome*, *How often* and the label. Extra points per diagram type (sequence, ER, state, gantt, lineage, charts).
- `check_diagrams` now reports any diagram without a caption or without a full description (the three parts and at least 120 words) and treats it as an error, so pages are fixed before they are built. The self-check counts a diagram without its description as missing.
- The worked example (`templates/example-vertical-chapter.md`) has a full description and scenarios under all 7 diagrams.

## 2.1.0 — 2026-11-06 · Current-state blueprint of the existing system, in depth, with many diagrams
**What the blueprint is now:** a detailed blueprint of the **existing** system, reconstructed from the BRDs the BRD Reconstruction agent produced (Functional, Technical, Summary per vertical), the answers given and Databricks checks. No target technology, no design.

- **No technology question.** Intake no longer asks Databricks or Fabric; the guardrail packs, guardrail gaps (GRD) and the guardrail compliance section are removed.
- **Inputs** are the BRD Reconstruction outputs: `SRC-<V>-F` / `-T` / `-S` / `-O1`. Their evidence labels and ids are carried through (`CM:OBJ-0042`, `CM:LQ-0112` …). Five labels everywhere: Confirmed, From evidence, Inferred, Conflicting, Unknown.
- **New blueprint structure** (`templates/blueprint-template.md`): 20 sections and 7 appendices: system context, business architecture (capabilities, end-to-end process, calendar, rules catalogue, entities and lifecycles, outputs), technical architecture (landscape, component inventory, overall technical flow, orchestration and schedule, integration, environments), data architecture (domains, conceptual model, lineage, stores, code sets, column lineage, volumes, sensitive data), cross-vertical view, **one detailed chapter per vertical (18 sub-sections)**, run behaviour, controls/security/audit, non-functional observations, operations, technical debt and findings, gaps/questions/risks, evidence and confidence, considerations for future change, traceability, glossary; appendices: objects, tables and columns, procedure catalogue, pipelines and jobs, full lineage, evidence register, diagram index.
- **New parts, built bottom-up:** `/brd-bp-vertical <vertical>` (each vertical first), then `/brd-bp-business`, `/brd-bp-technical`, `/brd-bp-data`, `/brd-bp-operations`, `/brd-bp-findings`, `/brd-bp-assemble`. Old parts (architecture, logic, nfr, quality, delivery: target design, STTM, migration, backlog) removed.
- **Content depth rule** (`08-blueprint.md`): everything the evidence holds goes in (every object, procedure, parameter, table, pipeline, schedule, calculation, rule, code value, integration, control); lists in batches, never summarised; exact names and values; unknowns visible as questions and risks.
- **Diagram standard** (`diagram-standard.md`): 17 required system-wide diagrams (overview, context, capability map, end-to-end business process, business calendar, lifecycles, landscape, overall technical flow, run schedule, dependency graph, integration map, environments, conceptual model, lineage, cross-vertical map, evidence mix, risk matrix) and 7–9 per vertical (business flow, detailed technical flow, run sequences, components, data model, lineage, status lifecycles, procedure logic, calculation flow), with caption, key table, label colours and syntax rules.
- **Diagrams are drawn in the pages:** the viewer renders Mermaid (11.4.1 bundled in `tools/bp-helper/vendor/`, works offline; cdnjs as fallback), on a white card in both themes, click to enlarge; a broken diagram shows a red box with the error instead of breaking the page.
- **`check_diagrams`** (new bp-helper tool): finds Mermaid errors before a page is built (unquoted labels, unbalanced subgraphs, `end` as a node id, dotted ER names, gantt without dateFormat), missing captions, counts by type and section.
- **Worked example:** `templates/example-vertical-chapter.md` shows the expected depth, labels and diagrams.
- Readiness is now an **evidence map** (Strong / Partial / Thin / Missing per area); nothing blocks for lack of information: unanswered items become Unknown + risk. "BRD rebuild" is now "BRD update" and keeps all the BRD Reconstruction detail.
- Architect review checks accuracy, completeness against the BRDs, diagrams against tables, honesty about unknowns.

## 2.0.0 — 2026-11-06 · Command-only flow
The user chooses the **BRD Programme** agent and types commands one by one. Everything else is done by the agent.

**No more manual file steps**
- New `tools/bp-helper/` (standard-library Python MCP server, preconfigured in `.vscode/mcp.json`, starts by itself via `.vscode/settings.json`):
  `find_brd_files`, `import_brd_file` (copies, or converts Word `.docx` to Markdown; originals never touched), `build_page` (builds the review page / blueprint HTML from the viewer and opens it in the browser), `open_page`, `collect_feedback` (finds the exported feedback in the Downloads folder), `workspace_check`. Writes only inside `brd-work/`, never overwrites.
- Intake asks only *where* the BRD files are; the agent lists them, proposes vertical and type, imports and converts them. No more "put the Markdown files in …" or running markitdown/pandoc.
- Review pages open in the browser by themselves. Feedback: chat, **Export review** + type `FEEDBACK FILE` (the agent picks the file up from Downloads), or the new **Copy for chat** button in the page. No more saving files into `feedback/`.
- Rule 11 (MASTER) / §0 (copilot-instructions): the agent never asks the user to copy, move, rename, convert, open or save files, or to run anything; only VS Code's own prompts (trust, start/allow server, token box, browser sign-in).

**Always know what to type next**
- After every APPROVED the agent gives the exact next command (with the vertical, in the approved order).
- New `/brd-next`: runs the next stage from `STATUS.md` (or reopens the page that is waiting for review).
- `/brd-status` ends with "Next: type …" and offers to reopen a waiting page.
- `/brd-arch-review` and `/brd-arch-respond` switch agents by themselves (prompt files name their agent).

**Databricks without a token**
- Intake offers three options: Genie (token in VS Code's box), **Databricks SQL with browser sign-in** (`tools/dbx-connector/`, read-only, no token), or none. The agent writes the connection into `.vscode/mcp.json` itself. `11-genie-protocol.md` covers both (same GQ log, verification and confirmation).

**Unchanged:** all stages, registers, templates, guardrail packs, review rounds, versioning, approval rules, read-only guarantee.
