Project folders are created here by /brd-intake (brd-work/<project>/). The agent manages everything in this folder; you do not need to put anything here.
