# Part 8g — Assemble the current-state blueprint (MD + HTML)

**Invoke:** `/brd-bp-assemble` · **Writes:** `blueprint/80-project-blueprint.md`, `blueprint/80-project-blueprint.html`
**Needs:** Parts 8a (every vertical) to 8f APPROVED. **Sections written here:** 1, 2, 3, 18, 20, Appendices F–G, and the assembly. Review page: the blueprint HTML itself.

## 0. Feedback from an earlier version
If blueprint feedback exists (`bp-helper` → `collect_feedback` with the blueprint's `feedback_file` name) that is newer than the last assembly: apply each "change" to the owning part file (`81-…` to `86-…`) or ask if unclear; record changes in the document control table; raise the version (v1.0 → v1.1).

## 1. Write the remaining sections
- **1 Document control:** versions; based on (approved BRD version per vertical, and the BRD Reconstruction versions they came from); evidence base (Databricks status and window); approvals; audience.
- **3 How to read this blueprint:** the five labels and their pills; the diagram classes (confirmed / evidence / inferred / conflicting / unknown) with a small legend diagram; id formats (`CM:OBJ-0042`, `BR`, `REL`, `DEC`, `Q`, `R`); how to give feedback.
- **18 Traceability matrix:** per vertical, business process → business rule → technical object(s) → table(s) → output → evidence; coverage figures; anything with no link either way.
- **20 Glossary:** business and technical terms across verticals (with the DEC that agreed differing ones), abbreviations, object naming conventions.
- **Appendix F Evidence register:** every evidence id cited, by vertical: `| Id | Kind (document / code / metadata / query / person / Databricks) | What it is | Sections that use it |`.
- **Appendix G Diagram index:** every figure: number, title, diagram id (D-xx / V-xx), section.
- **2 Executive summary,** last: ```figures (verticals, business processes, objects, procedures, tables, pipelines/jobs, integrations, rules, open questions, risks); **D-01** one-page overview; what the system does in five sentences; how it runs (one paragraph); the ten most important facts a newcomer must know; top risks; confidence in one paragraph (label mix).
- **19 Architect review:** leave the heading with "To be completed after the architect review."

## 2. Assemble
1. Front matter from `templates/blueprint-template.md` (`kind: blueprint`, BRD versions in `based_on`, `genie` = Databricks status, feedback file name).
2. Insert the sections in order 1–20 (9.1, 9.2 … in the approved order), then Appendices A–G, copying the part files **as written**: no shortening, summarising or rewording. Appendices A–E: merge the per-vertical rows into one table each, sorted by vertical then name.
3. Renumber figures 1…n through the document (captions `Figure n:`).
4. Save `80-project-blueprint.md`. Large documents: write in several edits, section by section.
5. `bp-helper` → `check_diagrams` on it: zero errors, every required diagram present (D-01 … D-17, and V-01 … V-07 per vertical).
6. `bp-helper` → `build_page` → `80-project-blueprint.html` (opens in the browser).

## 3. Check before presenting
- Same text in MD and HTML (the tool guarantees it; check the line count it reports).
- Every section present; every part's self-check had no Missing items.
- Coverage per vertical: objects, procedures, tables, pipelines, rules, calculations n of N against the BRD inventories.
- Every `[[…]]` pill is one of the known labels; every open gap appears in section 15 as a question and a risk.

Present with `10-review-loop.md`. After the user's feedback rounds, the blueprint goes to the **Architect review** before final approval.
