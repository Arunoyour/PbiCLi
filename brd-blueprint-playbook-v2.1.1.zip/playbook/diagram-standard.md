# Diagram standard (Mermaid) — every blueprint part and the assembled blueprint

The blueprint explains an existing system that few people fully understand. Diagrams carry much of that explanation, so they are **mandatory, many, and detailed**. One data-flow picture is never enough: every reader (business, analyst, developer, support, architect) must find the view they need.

All diagrams are written as ` ```mermaid ` blocks in the Markdown. The viewer draws them (Mermaid 11, bundled in `tools/bp-helper/vendor/`, works offline); a diagram that has a syntax error shows a red box with the error, so check them with `bp-helper` → `check_diagrams` before presenting. A worked example of a vertical chapter with its diagrams: `playbook/templates/example-vertical-chapter.md`.

## 1. Required diagrams

### 1a. Project level (in the blueprint sections named)
| Id | Diagram | Mermaid type | Section | What it must show |
|---|---|---|---|---|
| D-01 | **One-page system overview** | `flowchart LR` with `subgraph`s | 2 | The whole system on one page: verticals, main stores, integration, consumers |
| D-02 | **System context** | `flowchart LR` | 4 | The system boundary; every external system, user group, upstream source and downstream consumer, with what flows on each edge |
| D-03 | **Business capability map** | `mindmap` | 5.1 | Capabilities per vertical, two to three levels |
| D-04 | **End-to-end business process** | `flowchart TD` with one `subgraph` per actor or vertical (swimlanes) | 5.3 | Business events, decisions, hand-overs, outputs, in business words |
| D-05 | **Business calendar** | `timeline` or `gantt` | 5.4 | Daily / weekly / monthly / yearly business events and cut-offs |
| D-06 | **Entity lifecycles** | `stateDiagram-v2` (one per status field with code values) | 5.6 | Every state and transition, with the condition and the object that makes it |
| D-07 | **Technology landscape** | `flowchart LR` with `subgraph` per layer (sources · integration · SQL Server · Databricks · applications/APIs · consumers) | 6.1 | Every server, database, catalog, pipeline tool and application, with counts of objects |
| D-08 | **Overall technical flow** | `flowchart TD` | 6.3 | Trigger → pipeline → procedure → table → next system → consumer, across all verticals |
| D-09 | **Run schedule** | `gantt` (`dateFormat HH:mm`) | 6.4 | A normal run day: every job and pipeline in time order with duration (observed or inferred) |
| D-10 | **Job dependency graph** | `flowchart LR` | 6.4 | What must finish before what, across SQL Agent, ADF, Databricks jobs |
| D-11 | **Integration map** | `flowchart LR` | 6.5 | Every integration point: protocol, direction, frequency on the edges |
| D-12 | **Environment / deployment view** (as observed) | `flowchart TB` | 6.6 | Servers, workspaces, environments, which objects live where |
| D-13 | **Conceptual data model** | `erDiagram` | 7.2 | Main entities across all verticals and their relationships with cardinality |
| D-14 | **End-to-end data lineage** | `flowchart LR` | 7.3 | Table-level: source → staging → core → reporting → consumers, across verticals |
| D-15 | **Cross-vertical relationship map** | `flowchart LR` | 8 | Verticals as nodes, REL items as labelled edges (feeds / uses / overlaps / conflicts) |
| D-16 | **Evidence mix** | `pie` | 16 | Statements by label (Confirmed / From evidence / Inferred / Conflicting / Unknown) |
| D-17 | **Risk matrix** | `quadrantChart` | 15 | Every risk placed by likelihood and impact |

### 1b. Per vertical (chapter 9.x, every vertical)
| Id | Diagram | Mermaid type | What it must show |
|---|---|---|---|
| V-01 | **Business flow** | `flowchart TD` (lanes per actor) | The vertical's business process from trigger to outcome, decisions with their rules (BR ids) |
| V-02 | **Detailed technical flow** | `flowchart TD`, one `subgraph` per phase | Every pipeline activity, job step, procedure, table and file in run order, with parameters and schedule on the nodes |
| V-03 | **Run sequence** (one per main run or trigger) | `sequenceDiagram` with `autonumber` | Scheduler → pipeline → procedure → tables → downstream, with the calls, parameters and what is returned |
| V-04 | **Component view** | `flowchart LR` | Every object of the vertical grouped by database/catalog and schema, with read/write edges |
| V-05 | **Data model** | `erDiagram` | Every core and supporting table with keys (PK/FK) and main columns; cardinality |
| V-06 | **Data lineage** | `flowchart LR` | Table-level lineage of the vertical, and column-level for the main outputs (a second diagram if needed) |
| V-07 | **Status lifecycle** | `stateDiagram-v2` | For each status/flag column with code values (skip only if there are none, and say so) |
| V-08 | **Procedure logic** | `flowchart TD` | For every **core** procedure with more than three steps: its branches, loops, conditions and writes |
| V-09 | **Calculation flow** | `flowchart LR` | For each main calculation: inputs → formula steps → output column |

A diagram may be split (for example V-02 per phase) when it would exceed about 35 nodes; never drop content to make it fit.

## 2. Every diagram comes with
1. A caption line right after it: `Figure n: <what it shows>` (numbered through the document).
2. **A detailed written description — a diagram is never left to speak for itself.** Directly under the caption, in this order:
   - **`**What this diagram shows**`** — two to four sentences in plain English: the purpose of the flow, where it starts and ends, who and what takes part, how often it happens. Written for a business reader who has never seen the system.
   - **`**Walkthrough**`** — a numbered narrative of every step in the diagram, in order. Each step says: what happens and why (business meaning), the object(s) doing it (full names), the condition or rule applied (BR id and the exact condition), the data read and written, the timing, and the label with its evidence. One step per node or edge that matters; nothing in the picture is left unexplained.
   - **`**Scenarios**`** — every path through the diagram as its own scenario, each with: *When it applies* (trigger and conditions) · *What happens* (step by step, referring to the walkthrough numbers) · *Outcome* (data changed, outputs, who is told) · *How often / volume* (if known) · *Label and evidence*. Always cover, where they exist:
     1. the **normal path** (the everyday case),
     2. **alternative paths** (each decision branch, other triggers, manual runs),
     3. **exceptions and failures** (error handling, rollbacks, reruns, what the user or support sees),
     4. **edge cases** (no rows, duplicates, late or missing input, nulls, boundary dates, month-end / year-end, back-dated changes),
     5. **unknown paths** (branches the evidence cannot explain: the question id and the risk).
     A scenario the evidence does not cover is still listed, marked `[[Unknown]]` with its question.
   - **Key table** for anything not obvious: node → full object name → type → evidence (EV / OBJ / LQ / GQ / DEC) → label.
   - Diagram-type specifics:
     | Type | The description must also give |
     |---|---|
     | `sequenceDiagram` | each message in order (who calls whom, with which parameters, what comes back), transaction boundaries, duration |
     | `erDiagram` | each entity's meaning and grain, each relationship in words ("one store has many audit rows"), keys and how they are enforced (or not) |
     | `stateDiagram-v2` | each state's meaning, each transition's trigger, condition, object and timing, and transitions that are impossible or unexplained |
     | `gantt` | each job's start, duration and what it waits for; the critical path; what happens when something runs late |
     | lineage `flowchart` | each hop: source, mechanism, target, operation, columns and transformation |
     | `mindmap`, `pie`, `quadrantChart`, `timeline` | what each item / slice / point means, and what the reader should conclude |
3. Labels made visible in the picture with these classes (declare them in each diagram that uses them):
```
classDef confirmed fill:#E3F3EB,stroke:#1E7350,color:#0F2C4C
classDef evidence  fill:#E4EEF8,stroke:#2F6DB5,color:#0F2C4C
classDef inferred  fill:#FBF1DF,stroke:#9A5F0C,stroke-dasharray:4 3,color:#0F2C4C
classDef conflict  fill:#FBEAE6,stroke:#B83A2A,color:#0F2C4C
classDef unknown   fill:#F1F5F9,stroke:#9FB5CA,stroke-dasharray:2 2,color:#47627F
classDef external  fill:#FFFFFF,stroke:#47627F,color:#0F2C4C
```
   Inferred links are dashed edges `-.->` with the word "inferred" in the edge text. Unknowns are drawn as `unknown` nodes with a `?` and the question id, never left out.

## 3. Syntax rules (so every diagram draws)
- Node ids: letters, digits, underscore only (`SP_golive`, `T_store_master`). Never `end`, `graph`, `subgraph` as ids.
- **Every label in double quotes**: `SP_golive["usp_store_golive<br/>@run_date DATE"]`. Use `<br/>` for line breaks. Inside quotes write `#quot;` for a double quote.
- Shapes: `["…"]` process/object · `[("…")]` table/store · `{"…"}` decision · `(["…"])` start/end · `[["…"]]` job/pipeline · `[/"…"/]` file.
- Edge text in quotes: `A -->|"writes, daily 02:00"| B`.
- `subgraph S1["Phase 1 — Intake"]` … `end`, balanced. **Subgraph titles short (at most about 30 characters)**: long titles are cut off; put details (pipeline name, schedule) in the first node instead.
- Avoid `<` and `>` in labels (write "on or before", "more than"); `<br/>` is the only tag.
- `erDiagram` entity names without spaces or dots (`SALES_INVOICE`); put the full name in the key table. Attributes: `type name PK|FK "comment"`.
- `stateDiagram-v2` state names without spaces (`Pending`), description with `: text`.
- `gantt`: `dateFormat HH:mm`, `axisFormat %H:%M`; inferred durations go in a section named "inferred timing".
- `sequenceDiagram`: `participant P1 as ADF PL_Store_Daily`; `autonumber`; `Note over` for parameters.
- Real names from the evidence (exact object names, parameters, schedules). No invented systems; something suspected but not evidenced is an `inferred` or `unknown` node.
- Run `bp-helper` → `check_diagrams` on the Markdown before `build_page`; fix every error it reports.

## 4. Self-check line (every part's review page)
`Diagrams: required n · present n · with full description (What this diagram shows + Walkthrough + Scenarios) n · split n · not applicable n (reason) · errors 0` with the list from `check_diagrams`. A diagram without its description counts as missing.
