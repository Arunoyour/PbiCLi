# Stage — Current-state system blueprint (overview)

**What it is.** One blueprint of the **existing** system, reconstructed from the evidence we have: the BRDs built by the BRD Reconstruction agent (Functional, Technical, Summary per vertical), the answers given in this project, and Databricks checks if connected. It explains, in depth and with many diagrams, how the system works today: the business it supports, the processes, the technology, the data, every object, how it runs, what controls it, what is known for certain and what is not.

**What it is not.** It is **not** a design for a new platform. No target technology is chosen, nothing is designed, and no "to-be" is mixed in. Observations useful for any future change go only in section 17, as observations.

**Needs:** every vertical's BRD APPROVED in this project (`PROJECT.md` version register), Readiness APPROVED, no Databricks finding pending.
**Inputs:** approved BRD versions, the original imported BRD files (for detail the rebuild summarised), inventories, gap registers, decisions, relationship register, readiness file, MEMORY files, Databricks log (confirmed findings only).
**Final outputs:** `blueprint/80-project-blueprint.md` and `.html` (identical text, built with `bp-helper` → `build_page`).

## Built in seven parts, each reviewed — bottom-up
The vertical chapters come first, so the system-wide views are drawn from approved detail.

| Part | Command | Writes | Blueprint sections |
|---|---|---|---|
| 8a | `/brd-bp-vertical <vertical>` (each vertical, approved order) | `81-vertical-<v>.md` | 9.x for that vertical; its rows of Appendices A–E |
| 8b | `/brd-bp-business` | `82-business.md` | 4 System context, 5 Business architecture |
| 8c | `/brd-bp-technical` | `83-technical.md` | 6 Technical architecture, 10 Processing and run behaviour |
| 8d | `/brd-bp-data` | `84-data.md` | 7 Data architecture, 8 Cross-vertical view |
| 8e | `/brd-bp-operations` | `85-operations.md` | 11 Controls, security and audit, 12 Non-functional observations, 13 Operations and support |
| 8f | `/brd-bp-findings` | `86-findings.md` | 14 Technical debt and findings, 15 Gaps, questions, risks, 16 Evidence and confidence, 17 Considerations for future change |
| 8g | `/brd-bp-assemble` | `80-project-blueprint.md` + `.html` | 1, 2, 3, 18, 20, Appendices F–G, the assembly |

Then the **Architect review** (`09-architect-review.md`), which fills section 19.

Each part writes its sections into its own file and a review page (`reviews/blueprint-8x[-<v>]-r<N>.md`, built and opened with `build_page`) that shows those sections plus the self-check, and follows `10-review-loop.md`.

## Content depth (every part) — "each bit and byte"
1. **Everything the evidence holds goes in.** Every object, procedure, parameter, table, column that matters, pipeline, activity, job, schedule, calculation, formula, rule, code value, integration, control, volume and finding found in the BRDs and the Databricks log. Never summarise a list to save space; long lists are written **in batches** (one vertical, one schema, one table at a time) until complete, with full lists in the appendices.
2. **Repetition is expected.** A procedure appears in the vertical chapter, the technical flow, the lineage and the appendix; each place gives what that view needs.
3. **Exact values.** Real object names (server.database.schema.object, catalog.schema.table), parameters with types and defaults, schedules with time zone, formulas as implemented, code values with meanings, row counts with "as of" dates.
4. **Labels on every statement** (carried from the BRDs): **Confirmed** (person, date) · **From evidence** (EV / OBJ / LQ / GQ id) · **Inferred** (what it is based on; written "appears to") · **Conflicting** (both sides) · **Unknown** (the question id). Shown as pills (`[[Confirmed]]`, `[[From evidence]]`, `[[Inferred]]`, `[[Conflicting]]`, `[[Unknown]]`) in tables and as diagram classes.
5. **Evidence ids keep their vertical**: ids from a vertical's BRD are cited with its code (`CM:OBJ-0042`, `CM:BR-07`, `CM:LQ-0112`, `CM:EV-004`) so they never clash across verticals.
6. **Current state only.** "Will", "should", "to-be" statements found in sources are reported as such in section 14 (Discovery findings), never as behaviour.
7. **Unknowns are visible, not filled.** Something the evidence does not show is written as Unknown with its question (`Q-…`), drawn as an `unknown` node, and listed in section 15. Gaps still open when the part is written are flagged as **risks**.
8. **No personal or business row data.** Column names, counts, ranges and code values only.
9. **Diagrams with full descriptions:** every diagram required for the part by `diagram-standard.md`, each followed by its caption, **What this diagram shows**, a step-by-step **Walkthrough** and every **Scenario** (normal path, alternatives, exceptions and failures, edge cases, unknown paths), then the key table. The picture gives the overview; the text gives the detail. Check them with `bp-helper` → `check_diagrams` before building the page.
10. **Plain English first.** Each section opens with two or three sentences a business reader understands, then the detail a developer needs.

## Ask, don't guess
Anything the evidence does not say and the user could know (a schedule, an owner, a consumer, what a code value means) is asked on the part's review page as `### Q-…` and in chat (rounds of at most 5). Unanswered by the time the part is approved → stays Unknown, raised as a risk in section 15.

## Databricks (if in use)
Check facts read-only where the BRDs are thin or old (object exists, row counts and date ranges, last write time, code value shares, schedules from job tables), with the verification pass (`11-genie-protocol.md`). New findings are provisional until the user confirms them.

## Self-check (on every part's review page)
```
| Section | Minimum items | Present | Not applicable (reason) | Missing |
```
plus: objects covered n of N per vertical (against the BRD inventories) · procedures described n of N · tables described n of N · pipelines/jobs n of N · calculations n of N · rules n of N · diagrams required / present / errors (from `check_diagrams`) · statements by label · questions raised · Databricks verification table (or "not in use"). A part with any Missing item is not presented as complete; say what is missing and why.
