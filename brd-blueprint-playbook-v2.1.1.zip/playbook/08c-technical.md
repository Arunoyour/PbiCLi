# Part 8c — Technical architecture and run behaviour

**Invoke:** `/brd-bp-technical` · **Writes:** `blueprint/83-technical.md` · **Sections:** 6, 10
**Needs:** Part 8b APPROVED. Review page: `reviews/blueprint-8c-r<N>.html`.
Follow `08-blueprint.md` and `diagram-standard.md` (D-07 … D-12). Build from the approved vertical chapters (9.x.4–9.x.8, 9.x.14), the Technical BRDs and the Databricks log.

## Section 6 — Technical architecture (as it is today)
1. **6.1 Technology landscape** — plain-English overview, **D-07**, then `| Layer | Platform / product | Servers / workspaces | Databases / catalogs | Main objects (counts) | Verticals | Label |`.
2. **6.2 Component inventory** — counts by type per vertical (```figures and a table): databases, schemas, tables, views, procedures, functions, triggers, ADF pipelines, SQL Agent jobs, Databricks jobs/notebooks, files, APIs, applications; Active / Inactive / Unknown split. Full list: Appendix A.
3. **6.3 Overall technical flow** — **D-08** across all verticals; then the hop table `| # | From | Mechanism (pipeline / job / procedure / API / file) | To | Schedule | Vertical | Evidence |`.
4. **6.4 Orchestration and schedule** — **D-09** (a normal day; separate charts for month-end or other special runs if they differ) and **D-10**; table `| Job / pipeline | Platform | Trigger (schedule, time zone, event) | Steps / activities | Calls (with parameters) | Waits for | Followed by | Typical start / duration | Label |`. Timing not recorded anywhere is inferred from the data (load timestamps, table history) and labelled Inferred with its query.
5. **6.5 Integration architecture** — **D-11**; every integration point across verticals: `| Integration | Type (linked server, ADF copy, API, file, SFTP, foreign catalog, DB link, web app) | Direction | Method / protocol | Counterpart | Data exchanged | Frequency | Volume | Error handling | Owner | Label |`.
6. **6.6 Environments and deployment (as observed)** — **D-12**: servers, instances, workspaces, environments seen in the evidence and which objects live where; how code appears to be deployed (if known); environment notes only, never credentials.

## Section 10 — Processing and run behaviour across verticals
1. The end-to-end run as a narrative (a normal day, then month-end / special cycles).
2. Restart and rerun behaviour as observed (idempotent or not, what a rerun overwrites), failure handling, retries, alerts.
3. Manual steps and who does them.
4. Reconciliations and hand-over checks between verticals.
5. Known incidents or failure patterns found in the evidence.

## Minimum content (self-check)
D-07 … D-12 present and drawing · every server/database/catalog in the landscape · component counts per vertical match the vertical chapters · every pipeline and job in 6.4 (n of N) · every integration point (n of N) · run narrative · rerun / failure behaviour · manual steps.
