# Stage — Gaps (per vertical)

**Invoke:** `/brd-gaps <vertical>` · **Scope:** one vertical · **Needs:** Understand APPROVED (same vertical)
**Writes:** `verticals/<v>/20-gaps.md`, vertical `MEMORY.md`, REL updates
**Review page:** `reviews/gaps-<v>-r<N>.html`

## Purpose
Find everything missing, conflicting, ambiguous or undocumented, inside this vertical **and at its edges with other verticals**. Register each gap; resolve nothing yet.

## Gap types
| Code | Meaning |
|---|---|
| CON | The vertical's BRD files (Functional, Technical, Summary) say different things |
| XCON | This vertical conflicts with another vertical (definition, rule, key, format) |
| MIS | Expected content missing |
| HID | Rule exists only in stored procedure code |
| ORP | Business requirement with no technical implementation |
| ORT | Technical logic with no business requirement |
| AMB | Wording allows more than one reading |
| TRM | Term used differently (within the vertical or versus another) |
| SRC | Upstream input unclear: source, format, frequency, volume, owner |
| CNS | Downstream consumer unclear: who, what, grain, freshness, interface |
| ASM | Unstated assumption: errors, nulls, duplicates, history, restart, retention |
| BPX | Something the current-state blueprint needs that the BRDs do not say: schedule or trigger, owner, consumer, key, volume, code-value meaning, integration method, error handling, lineage hop |

## Work
1. Cross-check every inventory item between the two files; compare values, thresholds, names, formulas, ownership.
2. For each procedure: rules not in prose (`HID`); for each prose rule: the procedure that implements it (`ORP` if none).
3. **Across verticals:** for every REL item touching this vertical, check the definitions and keys on both sides. Differences are `XCON` or `TRM` gaps, cross-referenced to the REL.
4. **Upstream and downstream:** every input and every consumer needs: source/consumer, data, format, frequency/freshness, volume, owner, interface. Anything missing is `SRC` or `CNS`.
5. **Blueprint needs:** walk the vertical chapter outline in `08a-vertical.md` (18 sub-sections) and log a `BPX` gap for anything the evidence cannot fill. Items already labelled Inferred in the BRD are listed as `BPX` gaps to confirm.
6. **Genie (if in use):** settle fact gaps where possible (does the object exist, do types and keys match, does the data follow the rule: counts only). Settled gaps become `RESOLVED-PENDING-CONFIRM` with the GQ id; contradictions with the documents become `CON` gaps. Mandatory verification pass and SQL check.
7. Severity: HIGH (changes results, money, compliance, or leaves a core part of the blueprint unknown) · MEDIUM (leaves detail unknown) · LOW (wording).

Entry format: see `templates/registers.md` (gap entry).

## Review page
- Counts by type and severity; top HIGH gaps in full
- Cross-vertical gaps (`XCON`, `TRM`) with the other vertical named
- Upstream / downstream gaps
- Blueprint evidence gaps (`BPX`)
- Gaps settled by Genie, to confirm (`### GQ-nnn …` or a table)
- Genie verification table, or "not in use"
Then follow `10-review-loop.md`.

## Do NOT
Pick a winner between conflicting sources or verticals, or interview the human (that is Clarify). Ask only if you cannot continue.
