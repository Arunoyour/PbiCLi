# Part 8f — Findings, gaps, risks, evidence and considerations

**Invoke:** `/brd-bp-findings` · **Writes:** `blueprint/86-findings.md` · **Sections:** 14, 15, 16, 17
**Needs:** Part 8e APPROVED. Review page: `reviews/blueprint-8f-r<N>.html`.
Follow `08-blueprint.md` and `diagram-standard.md` (D-16, D-17).

## Section 14 — Technical debt and discovery findings
Collected from every vertical chapter and part, grouped: hard-coded values · duplicated logic · dead or commented-out code · inactive objects still deployed · undocumented behaviour · differences between documents, code and data · naming and structure inconsistencies · fragile dependencies (linked servers, manual files, single jobs) · "future state" statements found in sources. Each: `| Finding | Where (objects) | Why it matters | Label | Evidence |`.

## Section 15 — Gaps, open questions, risks and assumptions
1. Every open question and gap across all verticals and parts: `| Id | Vertical(s) | Question | What was searched | Options / likely answer | Owner | Needed for |`.
2. **Risks**: every gap still open is a risk, plus risks seen in the system itself (single points of failure, knowledge held by one person, unsupported technology, data quality): `| R | Risk | Impact | Likelihood | Rating | Evidence | Owner |`, and **D-17** risk matrix.
3. Assumptions: `| ASM | Assumption | Why we believe it | What happens if wrong |`.
4. Conflicts still open: each side with its evidence.

## Section 16 — Evidence and confidence
- **D-16** pie of statements by label for the whole blueprint, and a table per vertical and per section.
- Evidence base: BRD versions per vertical, number of source documents behind them, Databricks checks (asked, answered, SQL-verified), answers from people (by person, count).
- Where confidence is lowest and why (sections with most Inferred / Unknown).

## Section 17 — Considerations for future change (observations only)
What anyone planning a change, migration or replacement must know about this system: hard dependencies, logic that must be preserved exactly, timing that downstream relies on, data that needs special care, areas to clarify first. **No target design, no technology choice.** Each point references the sections and evidence behind it.

## Minimum content (self-check)
Every finding from the vertical chapters (n of N) · every open question and gap (n of N) · every open gap has a risk · D-16 and D-17 present and drawing · evidence table per vertical · considerations reference evidence.
