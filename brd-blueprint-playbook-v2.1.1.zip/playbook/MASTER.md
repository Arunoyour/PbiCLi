# Multi-Vertical BRD Playbook — MASTER

Turns an **existing application** made of several **verticals** (modules), each described by the BRDs the BRD Reconstruction agent built for it, into:
1. a confirmed understanding of every vertical and of how the verticals relate,
2. a rebuilt, versioned BRD per vertical with every gap closed or openly marked,
3. one **current-state system blueprint**: how the whole system works today, business and technical, in depth and with many diagrams, with every statement's evidence and every unknown visible.

It runs in **VS Code with GitHub Copilot**, as a conversation. **The user chooses the BRD Programme agent and types the commands, one by one; nothing else.** Every stage is invoked by the user, produces a review page that opens in the browser, takes their feedback, stops until they type **APPROVED**, and then tells them the exact next command. All file work (importing and converting BRD files, building and opening pages, collecting feedback) is done by the agent through the `bp-helper` tools.

---

## 1. Inputs

- **Project name** (for example "Customer 360 BRD process").
- **Verticals**: any number. Each has a name, a short purpose, and its BRD files.
- **Files per vertical**: the BRDs produced by the **BRD Reconstruction** agent for that vertical, in Markdown or Word (the agent imports and converts them from the folder the user names):
  - **Functional** BRD (code `F`): business process, rules, actors, outputs
  - **Technical** BRD (code `T`): procedures, pipelines, tables, calculations, lineage, integration, evidence
  - **Summary** BRD (code `S`)
  Any count works (a vertical may have only some of them, or extra files such as appendices or a lead register, tagged `O`). Their evidence labels and ids are carried into the blueprint.
- **Databricks evidence** (optional): a Genie space (token entered in VS Code's own box), or Databricks SQL with browser sign-in (`dbsql`, no token), connected at intake and used read-only. If neither, the project runs on the files and the user's answers only, and every page says so.

---

## 2. The loop (every stage, no exceptions)

```
YOU type a /brd-* command (BRD Programme agent selected)
  → AGENT loads PROJECT.md, STATUS.md, MEMORY.md (+ the vertical's MEMORY.md)
  → AGENT does the stage's work; asks you when it needs information (Databricks first for technical facts, if in use)
  → AGENT writes the stage's working files and the REVIEW PAGE (round 1), which OPENS IN YOUR BROWSER
  → AGENT stops and waits
YOU reply in chat:
  • FEEDBACK: ...  (or answer the questions; or use the page: Export review + "FEEDBACK FILE", or Copy for chat + paste)
      → AGENT collects the feedback itself, redrafts, opens the next round's page, stops again
  • APPROVED  → AGENT records the approval and TELLS YOU THE NEXT COMMAND, stops
  • HALT      → AGENT stops
YOU type the next command (or /brd-next)
```

Details: `10-review-loop.md`.

### Hard rules
1. One stage per command. The agent never starts the next stage, even after approval.
2. Only a chat message from you containing **APPROVED** approves a stage. HTML "Agree" clicks are feedback, not approval.
3. The agent asks instead of guessing. Technical facts: Genie first (if in use), then you. Intent and decisions: you.
4. Every statement cites its source: vertical + file + section, a Genie finding (GQ), or a decision (DEC).
5. Conflicts are never merged silently, within a vertical or across verticals.
6. Original BRD files are never edited. New BRDs are new versions (`07-brd-rebuild.md`).
7. Nothing is overwritten: review rounds, feedback files and BRD versions are all kept.
8. Everything against Databricks is **read-only**, on every run and rerun (`11-genie-protocol.md`).
9. Secrets are never typed in chat or written to files. The Genie token is entered only in VS Code's own prompt.
10. The agent writes only inside `brd-work/<project>/` (and `.vscode/mcp.json` at intake, to add the Databricks connection; never secrets).
11. **No manual file steps.** The agent never asks the user to copy, move, rename, convert, open or save a file, or to run a script or terminal command. It uses the `bp-helper` tools (`workspace_check`, `find_brd_files`, `import_brd_file`, `check_diagrams`, `build_page`, `open_page`, `collect_feedback`). The only actions it may ask for are VS Code's own prompts (Trust folder, Start/Allow an MCP server, the Genie token box, the Databricks browser sign-in). If `bp-helper` is not running, it gives the one-line fix (MCP: List Servers → bp-helper → Start); intake stops until it runs, and other stages build their page with the agent's own fallback (`10-review-loop.md` §1.3) so the user still does nothing by hand.
12. **Always end with the next step.** Every reply that ends a stage run says what the user should type next.

---

## 3. Stages and commands

| Stage | Command | Scope | Stage file | Needs approved |
|---|---|---|---|---|
| Intake | `/brd-intake` | project | `00-intake.md` | — |
| Read all | `/brd-read-all` | project | `01-read-all.md` | Intake |
| Understand | `/brd-understand <vertical>` | vertical | `02-understand.md` | Read all |
| Gaps | `/brd-gaps <vertical>` | vertical | `03-gaps.md` | Understand (same vertical) |
| Clarify | `/brd-clarify <vertical>` | vertical | `04-clarify.md` | Gaps (same vertical) |
| Relationships | `/brd-relationships` | project | `05-relationships.md` | Clarify, all verticals |
| Readiness | `/brd-readiness` | project | `06-readiness.md` | Relationships |
| BRD update | `/brd-rebuild <vertical>` | vertical | `07-brd-rebuild.md` | Readiness |
| Blueprint 8a | `/brd-bp-vertical <vertical>` | vertical | `08-blueprint.md`, `08a-vertical.md` | BRD update, all verticals; previous vertical's chapter |
| Blueprint 8b–8f | `/brd-bp-business` · `/brd-bp-technical` · `/brd-bp-data` · `/brd-bp-operations` · `/brd-bp-findings` | project | `08b`–`08f` | 8a for every vertical; previous part |
| Blueprint 8g | `/brd-bp-assemble` | project | `08g-assemble.md` | 8a–8f |
| Architect review | `/brd-arch-review` (Architect Reviewer agent) | project | `09-architect-review.md` | Blueprint 8g |
| Respond to review | `/brd-arch-respond` | project | `09-architect-review.md` | Architect review presented |
| Apply feedback | `/brd-feedback` (or type `FEEDBACK FILE`) | current stage | `10-review-loop.md` | a stage presented |
| Next step | `/brd-next` | — | runs the next stage per `STATUS.md` | — |
| Status | `/brd-status` | — | — | — |

**Order of verticals.** After *Read all*, the verticals are worked through in the **approved order**: your order if you gave one at intake; otherwise the order the agent proposes from the dependencies it found (verticals others depend on go first). If your order contradicts a dependency, the agent says so and asks. It never silently reorders.

**Why read all first.** Verticals depend on each other. Reading every vertical before digging into any one means each vertical's gaps and questions already include how it relates to the others, so you answer once instead of reopening approved work.

---

## 4. Folder layout

```
.github/                      Copilot: instructions, agents, prompts
.vscode/mcp.json              bp-helper (always) + genie or dbsql (added by the agent at intake); no token inside
.vscode/settings.json         starts the MCP servers automatically when the agent needs them
tools/bp-helper/              the agent's file helper (import, convert, build/open pages, collect feedback)
tools/dbx-connector/          read-only Databricks SQL with browser sign-in (no token)
playbook/                     these instructions and templates (do not edit during a run)
brd-work/<project>/
  PROJECT.md                  manifest: project, Databricks evidence status, verticals, files, order, BRD versions
  STATUS.md                   every stage x scope: state, round, approvals
  MEMORY.md                   project-level understanding: verticals, relationships, shared terms, decisions
  genie-config.md             only if Genie is used (no secrets)
  genie-log.md                every Genie question and answer (if used)
  programme/
    01-overview.md            read-all result
    05-relationships.md       relationship register (REL items)
    06-readiness.md           sources, consumers, checklist
  verticals/<vertical>/
    sources/                  imported copies of the BRD files (Word converted to Markdown); never edited
    MEMORY.md                 this vertical's understanding
    10-understanding.md       inventory
    20-gaps.md                gap register
    30-questions.md           question rounds
    31-decisions.md           decisions log
    brd/BRD_v1.md, BRD_v1.html, BRD_v2.md ...  rebuilt BRDs (versioned)
    brd/CHANGELOG.md
  blueprint/
    81-vertical-<v>.md (one per vertical), 82-business.md, 83-technical.md, 84-data.md,
    85-operations.md, 86-findings.md             blueprint parts
    80-project-blueprint.md / .html             final blueprint
    arch-review/findings-r1.md, responses-r1.md
  reviews/                    every review page: <stage>[-<vertical>]-r<N>.md and .html
  feedback/                   feedback from the pages (collected by the agent from Downloads, or saved from chat)
```

---

## 5. IDs used everywhere

`REQ-<V>-nnn` requirements (V = vertical code from PROJECT.md) · `BR-<V>-nn` business rules · `GAP-<V>-nnn` gaps · `Q-<V>-nnn` questions · `DEC-nnn` decisions (project-wide) · `REL-nnn` relationships between verticals · `GQ-nnn` Genie findings · `SRC-<V>-F` / `-T` / `-S` / `-O1` source files (Functional / Technical / Summary / other) · ids from a vertical's BRD keep their vertical code when cited (`CM:OBJ-0042`, `CM:BR-07`, `CM:LQ-0112`, `CM:EV-004`) · `ASM-nn` assumptions · `R-nn` risks.

---

## 6. Databricks evidence status

Recorded in `PROJECT.md` at intake and shown on **every** review page's title block (front-matter field `genie`):
- **Genie (read-only)** or **SQL, browser sign-in (read-only)**: findings appear with GQ ids, are checked against their SQL, and need your confirmation.
- **Not in use (no access details provided)**: the page says technical facts come only from the BRD files and your answers.

---

## 7. What the blueprint is
A **current-state** blueprint of the existing system, built from whatever evidence exists (`08-blueprint.md`): very detailed, every statement labelled, unknowns visible, and many Mermaid diagrams (`diagram-standard.md`): context, capability map, business flows, technical flows, run sequences, schedules, dependency graphs, integration maps, data models, lineage, lifecycles, evidence mix and risk matrix. No technology is chosen and nothing is designed.
