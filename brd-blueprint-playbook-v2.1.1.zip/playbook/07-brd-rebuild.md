# Stage — BRD update (per vertical, versioned)

**Invoke:** `/brd-rebuild <vertical>` · **Scope:** one vertical · **Needs:** Readiness APPROVED
**Writes:** `verticals/<v>/brd/BRD_v<n>.md`, `BRD_v<n>.html`, `brd/CHANGELOG.md`, `PROJECT.md` (version register)
**Review page:** the BRD HTML itself (it is built with the viewer as a review page)

## Purpose
Write the next version of the vertical's BRD: the BRD Reconstruction output, **keeping all its detail, ids and evidence labels**, corrected and completed with everything learned (gaps closed by answers and confirmed Genie findings, relationship decisions, readiness answers). Anything still open is shown as open, never smoothed over. This becomes the input to the blueprint. Never shorten the technical content of the original: procedures, pipelines, tables, calculations and lineage are carried in full (section 11 may reference the imported Technical BRD section by section where it is unchanged).

## Versioning rules
- Original files in `sources/` are never edited.
- Every run of this stage creates the **next version**: `BRD_v1`, `BRD_v2`, … Existing versions are never overwritten.
- Redrafts after feedback are new versions too (the review round and the version move together: round 1 → v1, round 2 → v2, unless the human asks otherwise).
- `brd/CHANGELOG.md` gets one entry per version: date, what changed, why (DEC / GQ / REL / feedback file), who asked.
- `PROJECT.md` version register: latest version, approved version, approver, date. The blueprint uses only the **approved** version.
- Re-running the stage later (for example after new information) starts from the latest approved version and produces the next number.

## Structure (`templates/brd-template.md`)
Front matter (kind: review, stage: BRD rebuild, vertical, round, `version: v<n>`, based_on: source files + previous version) and:
1. Summary and purpose
2. Scope in / out
3. Business requirements (REQ ids kept from the inventory)
4. Business rules (BR ids), including rules found only in code, marked as confirmed by DEC
5. Data: entities, fields, keys, history approach, classification
6. Processes and workflows
7. Upstream inputs (from Readiness)
8. Downstream consumers (from Readiness)
9. Relationships to other verticals (REL ids, agreed definitions, system of record)
10. Non-functional requirements (targets or assumptions)
11. Technical detail: tables, views, procedures and the rules each implements
12. Decisions applied (DEC table)
13. Open items: deferred gaps with owners and dates, assumptions, risks
14. What changed from the original BRD (summary table: section, original, now, reason)
15. Provenance: every requirement and rule shows its source (`SRC-…`, `DEC-…`, `GQ-…`)

Status pills: `[[Confirmed]]` for decided items, `[[Provisional GQ-nnn]]` for Genie facts not yet confirmed (there should be none by now), `[[Decision needed]]` / `[[Deferred]]` for open items.

## Work
1. Build from: the vertical's inventory, gap register, decisions, both MEMORY files, the relationship register and readiness file. **No new facts.**
2. Self-check: every REQ and BR from the inventory appears; every RESOLVED gap shows its decision; every open gap is in section 13; every REL touching this vertical is in section 9.
3. Write `BRD_v<n>.md`, then build `BRD_v<n>.html` with `bp-helper` → `build_page` (it opens in the browser), the CHANGELOG entry and the version register.
4. Present it as the review page (the BRD HTML is the page) and follow `10-review-loop.md`. Feedback produces the next version.

Run once per vertical, in the approved order. The blueprint needs every vertical's BRD approved.
