# Stage — Intake

**Invoke:** `/brd-intake` · **Scope:** project
**Never asks** which technology to use: this playbook documents the existing system as it is.
**Writes:** `brd-work/<project>/PROJECT.md`, `STATUS.md`, `MEMORY.md`, folder structure, the imported source files; `genie-config.md` and the connection entry in `.vscode/mcp.json` if a Databricks connection is chosen
**Review page:** `reviews/intake-r<N>.html`

A conversation, one step at a time. Save each answer to `PROJECT.md` before asking the next question. Use the `askQuestions` tool where it helps (pick lists for yes/no and choices); otherwise ask in chat.

**The user only answers questions.** You do every file action yourself with the `bp-helper` tools (`MASTER.md` rule 11). Never ask the user to copy, move, rename, convert or open a file, or to run anything.

## Step 0 — Helper check (silent)
Call `bp-helper` → `workspace_check`. If the tool is not available, say only: *"My file helper is not running. Command Palette → MCP: List Servers → bp-helper → Start, then type `/brd-intake` again."* and stop. If a project already exists, say so and offer `/brd-status`.

## Step 1 — Project name
Ask for the project name. Make a folder-safe short name (lowercase, hyphens), confirm it, and create `brd-work/<project>/` with the layout in `MASTER.md` section 4. Create `PROJECT.md`, `STATUS.md` and `MEMORY.md` from `playbook/templates/`.

## Step 2 — Databricks evidence (asked early, because it changes how every later stage works)
Ask (pick list): **"Can I check facts in Databricks?"**
1. **Genie** — a Genie space holds the technical metadata, and you can enter a token.
2. **Databricks SQL, sign in with the browser** — no token needed; uses your own read-only access.
3. **No Databricks access** — work from the BRD files and your answers only.

**Genie**
1. Ask only the **non-secret** details: workspace host, Genie space ID, the metadata tables (what each holds). Fill `genie-config.md` from the template.
2. Say once: **do not paste a token in chat**; VS Code will ask for it in its own password box.
3. Add the `genie` server and its `inputs` entry to `.vscode/mcp.json` yourself, from `.vscode/mcp.genie.example.json`, keeping the `bp-helper` entry.
4. Ask one harmless read-only question through the `genie` tools (for example how many tables are listed in the metadata registry). VS Code starts the server and shows the token box by itself. If the tools are not available yet, say: *"VS Code needs to start the Genie connection: Command Palette → MCP: List Servers → genie → Start, enter the token in the box it shows, then reply DONE."* That is the only action you may ask for.
5. Apply the SQL check from `11-genie-protocol.md`. Record in `PROJECT.md`: `Databricks: Genie (read-only)`, the test result and date.

**Databricks SQL, browser sign-in**
1. Ask the workspace address (for example `https://adb-123.11.azuredatabricks.net`).
2. Add the `dbsql` server to `.vscode/mcp.json` yourself, from `.vscode/mcp.dbsql.example.json`, with that host, keeping the `bp-helper` entry.
3. Run `dbsql` → `connection_info`. Say before it: *"A browser page will open: sign in with your usual company account, then come back here."* If the tools are not available yet, ask for the same single VS Code action as above (`dbsql` → Start), then reply DONE.
4. Record in `PROJECT.md`: `Databricks: SQL, browser sign-in (read-only)`, who is signed in, the warehouse, the date.

**No access, or the test fails**
Record `Databricks: Not in use (no access details provided)` (or `… (connection test failed: <reason in plain words>)`). Tell the user plainly that technical facts will come only from the BRD files and their answers. This status appears on every review page.

## Step 3 — Verticals
Ask how many verticals there are and their names, then for each: a one-line purpose, the business owner (if known), and a short code for IDs (2–4 letters, for example CM for Customer Master). Do not assume a fixed number. Confirm the list back.

## Step 4 — BRD files (you import them; the user only says where they are)
1. Ask: **"Where are the BRD files? Give me the folder (copy it from File Explorer's address bar), or one folder per vertical."** Files may be Markdown (`.md`), text or Word (`.docx`).
2. `bp-helper` → `find_brd_files` on each folder. Show the list and **propose** for every file: its vertical (from the name, the headings and the vertical purposes) and its type: `Functional` (F), `Technical` (T), `Summary` (S) — the three BRDs the BRD Reconstruction agent produces — or `Other` (O, with a short description, for example a lead register or an appendix). Ask the user to confirm or correct in one reply (a numbered table helps: "1 → CM, BT").
3. For each confirmed file: `bp-helper` → `import_brd_file` with the project, the vertical folder name and the source id (`SRC-<V>-F`, `SRC-<V>-T`, `SRC-<V>-S`, `SRC-<V>-O1` …). Word files are converted to Markdown on import; originals are never touched.
4. Read each imported file's conversion check (headings, tables, code blocks) and open the imported Markdown to spot-check: tables intact, stored-procedure code in code blocks, headings sensible. Report damage in plain words; do not repair the source. If a Word file lost something important (diagrams, tracked changes), note it as `ITEM-n` and ask the user to describe it in chat.
5. Flag and ask about: a vertical with no Technical or no Functional BRD (the blueprint can still be built, with more Unknowns), a file that seems to belong to two verticals, `.doc` or `.pdf` files (ask for a `.docx` or `.md` version), empty or unreadable files.
6. Record every file in `PROJECT.md` → *Source files* (original path, imported path, type, check result).

## Step 5 — Order of verticals
Ask: "Do you want to set the order in which we go through the verticals, or should I propose one after reading them all?" Record the order, or `Agent proposes after Read all`.

## Review page
Show: project, Databricks evidence status (with the test result), a table of verticals (code, purpose, owner, files with ids, types and conversion check), file issues found, order (or "to be proposed"), and anything still missing as `ITEM-n` headings. Then follow `10-review-loop.md`. On approval the next command is `/brd-read-all`.
