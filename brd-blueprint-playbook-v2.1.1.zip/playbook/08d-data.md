# Part 8d — Data architecture and cross-vertical view

**Invoke:** `/brd-bp-data` · **Writes:** `blueprint/84-data.md` · **Sections:** 7, 8
**Needs:** Part 8c APPROVED. Review page: `reviews/blueprint-8d-r<N>.html`.
Follow `08-blueprint.md` and `diagram-standard.md` (D-13 … D-15). Build from the vertical chapters (9.x.11–9.x.13), the relationship register and the Databricks log.

## Section 7 — Data architecture
1. **7.1 Data domains and ownership** — every domain and entity: system of record (vertical, database/catalog, table), copies held elsewhere, who writes and who reads.
2. **7.2 Conceptual data model** — **D-13** across all verticals (main entities, cardinality); split by domain if large.
3. **7.3 End-to-end data lineage** — **D-14** (source → staging → core → reporting → consumers); the full hop list in Appendix E.
4. **7.4 Data stores catalogue** — `| Database / catalog | Server / workspace | Purpose | Schemas (type: staging, core, reporting, reference, audit, archive) | Tables | Largest tables (rows, as of) | Growth (if known) | Verticals | Label |`.
5. **7.5 Reference data and code sets** — every lookup and code set: where it lives, values (count), meaning source, who maintains it, which verticals use it.
6. **7.6 Column-level lineage of the main outputs** — for each main output (report, extract, key table): `| Output column | Source column(s) | Transformation / formula | Objects on the way | Label |`, plus a lineage diagram per output.
7. **7.7 Volumes and history** — row counts and date ranges of the core tables (as of), history and soft-delete handling, retention and archiving as observed.
8. **7.8 Sensitive data (names only)** — columns that hold personal or sensitive data, by table, and how they appear to be protected. Never values.

## Section 8 — Cross-vertical view
1. **D-15** relationship map.
2. Relationship table from the register: `| REL | Type (feeds / uses / overlaps / conflicts / timing) | From → To | Keys / objects | Timing dependency | Status | Evidence |`.
3. Shared entities and keys: how each vertical identifies the same thing; key mappings; match issues (counts only, if checked).
4. Timing dependencies between verticals (what waits for what; what happens when one is late).
5. Definitions that differ between verticals: each side, the agreed definition (DEC) or Conflicting.

## Minimum content (self-check)
D-13 … D-15 present and drawing · every entity with a system of record · every database/catalog (n of N) · every code set · column lineage for every main output (n of N) · volumes for every core table (n of N) · sensitive columns named · every REL (n of N) · every shared key · every differing definition.
