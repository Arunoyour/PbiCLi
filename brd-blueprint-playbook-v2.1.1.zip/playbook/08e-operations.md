# Part 8e — Controls, security, non-functional observations, operations

**Invoke:** `/brd-bp-operations` · **Writes:** `blueprint/85-operations.md` · **Sections:** 11, 12, 13
**Needs:** Part 8d APPROVED. Review page: `reviews/blueprint-8e-r<N>.html`.
Follow `08-blueprint.md`. Everything here is **as observed** in the evidence; nothing is recommended. Unknowns are questions and risks.

## Section 11 — Controls, security and audit
1. **11.1 Controls** — every validation, constraint, check, reconciliation, approval or manual control: `| Control | What it protects | Implementation (check constraint, unique index, FK, trigger, validation step, pipeline condition, reconciliation, manual check) | Where (object, step) | On failure | Label | Evidence |`.
2. **11.2 Access and security as observed** — identities and roles seen (service accounts, linked server logins, ADF identities, Databricks principals; names of roles only, never credentials), who can run or change what, sensitive data handling.
3. **11.3 Audit and logging** — audit tables, log tables, run logs, what each records, retention.
4. A `flowchart` of control points along the main flow (where data is checked, what stops the run).

## Section 12 — Non-functional observations
`| Area | Observation | Figure (as of) | Label | Evidence |` for: volumes and growth · run times and run windows · peak periods (month-end, year-end) · performance hotspots (long procedures, big scans, blocking) · availability and dependency on other systems · retention and archiving · scalability limits seen. A `gantt` or `xychart-beta` where figures over time exist.

## Section 13 — Operations and support
Monitoring and alerts seen · runbooks or support notes found · manual interventions and who does them · known recurring failures and how they are fixed · reruns and data repairs · support contacts and escalation (names only where the BRDs give them) · dependencies on people (single points of knowledge).

## Minimum content (self-check)
Every control from the vertical chapters (n of N) · control-point flowchart · access as observed · audit/log tables · every NFR area with a figure or Unknown · monitoring · manual steps · known failures · support model.
