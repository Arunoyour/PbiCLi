# Stage — Relationships (across verticals)

**Invoke:** `/brd-relationships` · **Scope:** project · **Needs:** Clarify APPROVED for every vertical
**Writes:** `programme/05-relationships.md` (final register), `MEMORY.md`
**Review page:** `reviews/relationships-r<N>.html`

## Purpose
Produce the confirmed map of how the verticals form one ecosystem. Each relationship explained in plain English, with evidence, and confirmed by the human. If the agent cannot tell how two verticals relate, it asks.

## What a relationship covers (one REL item each)
- **Type:** shared entity (same business object) · data flow (A's output is B's input) · lookup/reference · shared key or code set · shared definition · timing dependency (B must run after A) · ownership (which vertical is the system of record)
- **Sides:** vertical A, vertical B (or more), and the objects on each side
- **Keys:** how records match (key on each side, mapping, cardinality, what happens on no match)
- **Definitions:** the term on each side; the agreed definition (DEC) or the open difference
- **Direction and timing:** who produces, who consumes, frequency, latency allowed
- **System of record:** which vertical owns the data when both hold it
- **Status:** Identified / Inferred / Unknown → after review: CONFIRMED / CORRECTED / REJECTED
- **Evidence:** file + section on each side, GQ ids, DEC ids

## Work
1. Consolidate all REL items raised in Read all, Understand, Gaps and Clarify. Merge duplicates (keep both ids, mark one as merged).
2. Fill every field above. Anything still unclear becomes a question for the human (`### REL-nnn …` on the page). Never fill a field with an assumption.
3. **Genie (if in use):** check key overlaps and match rates between verticals with counts only (for example how many Billing customer_ids exist in Customer Master), read-only, SQL-checked.
4. **Run and load order.** From the data flows and ownership, work out the order in which the verticals run and load today (what waits for what); flag circular dependencies as a risk and ask how they are broken.
5. **Shared data.** List the entities and code sets that several verticals use (candidates for shared, conformed data in the blueprint) and the agreed definition of each shared term.
6. Update `MEMORY.md` (relationships, shared terms, run order).

## Review page
- An ecosystem diagram: ```flow block of the main data flows, plus a ```layers block of verticals grouped by role (sources of record, processing, consumers)
- Relationship table (id, type, from → to, keys, status)
- Each relationship that is not CONFIRMED yet as `### REL-nnn …` with a 2–4 line explanation and its evidence
- Shared terms: definition per vertical, agreed definition or open question
- Run and load order with reasons; circular dependencies as `> [!RISK]`
- Genie verification table, or "not in use"
Then follow `10-review-loop.md`.
