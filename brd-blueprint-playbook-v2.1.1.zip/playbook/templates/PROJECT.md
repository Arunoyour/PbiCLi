# Project manifest

Written at intake; updated by the agent as the project moves. Every command reads this first.

## Project
- Name:
- Folder: `brd-work/<project>/`
- Started:
- Blueprint type: current state of the existing system (no target technology)

## Databricks evidence
- Status: Genie (read-only) | SQL, browser sign-in (read-only) | Not in use (no access details provided) | Not in use (connection test failed: …)
- Workspace host (no secrets):
- Genie space ID (Genie only):
- Signed-in user and SQL warehouse (SQL only):
- Connection test: date, question asked, result, SQL check
- Read-only identity confirmed by / date:

## Verticals
| # | Vertical | Code | Folder | Purpose | Business owner |
|---|---|---|---|---|---|

## Source files
| Vertical | Source id | Original file (where the user keeps it) | Imported copy (`verticals/<v>/sources/…`) | Type (S / BT / Other) | Conversion check |
|---|---|---|---|---|---|

## Order of verticals
- Set by: human at intake | agent proposal approved in Read all
- Order:
- Reasons / dependencies:

## BRD versions
| Vertical | Latest version | Approved version | Approved by | Date |
|---|---|---|---|---|

## Blueprint
| Item | Status | Version | Approved by | Date |
|---|---|---|---|---|
| Project blueprint | | | | |
| Architect review | | | | |
