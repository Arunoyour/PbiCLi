---
kind: blueprint
title: <Project name> — current-state system blueprint
subtitle: <One sentence: the existing system, what it does for the business, reconstructed from the evidence>
project: <Project name>
document_id: <BP-XXX-001>
version: <v1.0>
status: Draft for review
date: <YYYY-MM-DD>
based_on: <BRD versions per vertical: CM v3, BL v2, OR v2 (all approved)>
platform: <platforms seen in the evidence, e.g. SQL Server, Azure Data Factory, Databricks>
genie: <Databricks: Genie (read-only) | Databricks: SQL, browser sign-in (read-only) | Databricks: Not in use>
prepared_by: BRD Programme agent
approved_by: Pending
feedback_file: blueprint-review-v<x>.json
feedback_folder: brd-work/<project>/feedback/
---

<!--
CURRENT-STATE SYSTEM BLUEPRINT: how the existing system works today, reconstructed from the BRDs and evidence.
No target design. Every statement labelled. Every unknown visible. Many diagrams (playbook/diagram-standard.md).

- Single source for both outputs: 80-project-blueprint.md and 80-project-blueprint.html (bp-helper build_page).
- Every section has MINIMUM CONTENT (see the part files 08a–08g). A section is done when every item is present or
  marked "Not applicable: <reason>".
- Labels: [[Confirmed]] [[From evidence]] [[Inferred]] [[Conflicting]] [[Unknown]]; also [[Risk high]] [[Risk medium]] [[Risk low]]
- Ids: <V>:OBJ-nnnn, <V>:BR-nn, <V>:EV-nnn, <V>:LQ-nnnn (from the vertical's BRD) · REL-nnn · DEC-nnn · GQ-nnn · Q-… · R-nn · ASM-nn
- Callouts: > [!KEY] > [!NOTE] > [!RISK] > [!DECISION] > [!PROVISIONAL] > [!CONFIRMED]
- Blocks: ```mermaid (diagrams) · ```figures (Value | label) · ```flow (Step | detail) · ```layers (Name | note | part, part)
- Per-vertical chapters are numbered 9.1, 9.2, ... in the approved order of verticals.
- Every diagram: caption "Figure n: …" and a key table (node → object → evidence → label).
-->

## 1. Document control
<!-- versions · based on (BRD version per vertical and its BRD Reconstruction version) · evidence base · approvals · audience -->

## 2. Executive summary
<!-- ```figures · D-01 one-page overview · what the system does (5 sentences) · how it runs · ten key facts · top risks · confidence -->

## 3. How to read this blueprint
<!-- labels and pills · diagram classes with a legend diagram · id formats · how to give feedback -->

## 4. System context
<!-- D-02 · context table · system boundary -->

## 5. Business architecture
### 5.1 Capability map
<!-- D-03 · capability table -->
### 5.2 Actors and roles
### 5.3 End-to-end business process
<!-- D-04 (lanes) · narrative · process table -->
### 5.4 Business calendar
<!-- D-05 -->
### 5.5 Business rules catalogue
### 5.6 Business entities and lifecycles
<!-- D-06 per status field -->
### 5.7 Business outputs

## 6. Technical architecture
### 6.1 Technology landscape
<!-- D-07 -->
### 6.2 Component inventory
### 6.3 Overall technical flow
<!-- D-08 · hop table -->
### 6.4 Orchestration and schedule
<!-- D-09 gantt · D-10 dependency graph · job table -->
### 6.5 Integration architecture
<!-- D-11 · integration table -->
### 6.6 Environments and deployment (as observed)
<!-- D-12 -->

## 7. Data architecture
### 7.1 Data domains and ownership
### 7.2 Conceptual data model
<!-- D-13 -->
### 7.3 End-to-end data lineage
<!-- D-14 -->
### 7.4 Data stores catalogue
### 7.5 Reference data and code sets
### 7.6 Column-level lineage of the main outputs
### 7.7 Volumes and history
### 7.8 Sensitive data (names only)

## 8. Cross-vertical view
<!-- D-15 · REL table · shared keys · timing dependencies · differing definitions -->

## 9.1 Vertical: <name>
<!-- One chapter per vertical (9.1, 9.2 …), sub-sections 9.x.1 … 9.x.18 as in 08a-vertical.md:
purpose and scope · business flow (V-01) · inputs and outputs · detailed technical flow (V-02) · run sequences (V-03) ·
components (V-04) · pipelines and jobs · stored procedures and code objects (V-08) · calculations and formulas (V-09) ·
business rules as implemented · data model (V-05) · status lifecycles and code lists (V-07) · data lineage (V-06) ·
integration points · controls and data quality · discovery findings · open questions and risks · evidence and confidence -->

## 10. Processing and run behaviour across verticals
<!-- run narrative (normal day, month-end) · rerun / restart · failure handling · manual steps · reconciliations · known incidents -->

## 11. Controls, security and audit
<!-- controls table · control-point flowchart · access as observed · audit and logging -->

## 12. Non-functional observations

## 13. Operations and support

## 14. Technical debt and discovery findings

## 15. Gaps, open questions, risks and assumptions
<!-- questions table · risks table · D-17 risk matrix · assumptions · open conflicts -->

## 16. Evidence and confidence
<!-- D-16 · per vertical and per section · evidence base · lowest-confidence areas -->

## 17. Considerations for future change (observations only)

## 18. Traceability matrix

## 19. Architect review
<!-- filled after /brd-arch-respond -->

## 20. Glossary

## Appendix A. Object inventory
| Vertical | Id | Full name | Type | Ring | Activity | Purpose | Evidence |
|---|---|---|---|---|---|---|---|

## Appendix B. Tables and columns

## Appendix C. Stored procedure and code object catalogue

## Appendix D. Pipelines and jobs

## Appendix E. Full lineage (table level)

## Appendix F. Evidence register

## Appendix G. Diagram index
