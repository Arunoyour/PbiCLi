---
kind: review
title: <Vertical> BRD v<n>
subtitle: Rebuilt from the original BRD files with every gap closed or marked open.
project: <Project name>
stage: BRD rebuild
vertical: <Vertical name>
round: <N>
version: v<n>
status: Waiting for your review
date: <YYYY-MM-DD>
platform: <platforms seen in the evidence>
genie: <In use (read-only) | Not in use (no access details provided)>
based_on: <SRC-<V>-F, SRC-<V>-T, SRC-<V>-S, previous version BRD_v<n-1> (if any)>
feedback_file: feedback-brd-rebuild-<vertical>-r<N>.json
feedback_folder: brd-work/<project>/feedback/
---

<!-- Build only from approved facts. No new facts. Every requirement and rule shows its source. -->

## 1. Summary and purpose

```figures
<n> | requirements
<n> | business rules
<n> | gaps closed
<n> | items still open
```

## 2. Scope

## 3. Business requirements
| REQ | Requirement | Priority | Source |
|---|---|---|---|

## 4. Business rules
| BR | Rule (plain English) | Source | Status |
|---|---|---|---|

## 5. Data
### Entities
| Entity | Grain | Primary key | Business key | History | Classification |
|---|---|---|---|---|---|
### Fields
<per entity: field, type, meaning, source, rules>

## 6. Processes and workflows

## 7. Upstream inputs
| Input | Source system / vertical | Owner | Format / access | Frequency | Volume | Change capture | Known issues |
|---|---|---|---|---|---|---|---|

## 8. Downstream consumers
| Consumer | Data needed | Grain | Freshness | Interface | History | Security | SLA |
|---|---|---|---|---|---|---|---|

## 9. Relationships to other verticals
| REL | Other vertical | What | Keys | Agreed definition | System of record |
|---|---|---|---|---|---|

## 10. Non-functional requirements
| NFR | Requirement | Target or assumption | Source |
|---|---|---|---|

## 11. Technical detail
### Tables and views
### Stored procedures and the rules they implement
| Procedure | Purpose | Reads | Writes | Rules implemented | Status |
|---|---|---|---|---|---|

## 12. Decisions applied
| DEC | Decision | Decided by | Date |
|---|---|---|---|

## 13. Open items
> [!DECISION]
> <each open decision: options, owner, needed-by date>

| Item | Type (deferred gap / assumption / risk) | Owner | Due |
|---|---|---|---|

## 14. What changed from the original BRD
| Section | Original said | Now says | Why (DEC / GQ / REL) |
|---|---|---|---|

## 15. Change log
| Version | Date | Change | Asked by |
|---|---|---|---|
