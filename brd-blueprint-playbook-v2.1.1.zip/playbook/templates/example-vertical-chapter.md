---
kind: review
title: Example vertical chapter, 9.1 Store Opening (shortened)
subtitle: A model of the depth, labels and diagrams expected in every vertical chapter. Content is invented for illustration.
project: Example project
stage: Blueprint 8a
vertical: Store Opening
round: 1
status: Example
genie: Databricks SQL, browser sign-in (read-only)
feedback_file: feedback-example.json
feedback_folder: brd-work/example/feedback/
---

<!-- EXAMPLE ONLY. Shows the style: plain English first, then detail; labels on every statement; real names; a caption and a
key table after every diagram. A real chapter has all 18 sub-sections in full, every object, every procedure block. -->

## 9.1 Vertical: Store Opening

### 9.1.1 Purpose and scope

> [!KEY] Store Opening turns an approved new-store request into a live store in the store master every night, and tells Finance and the BI reports the next morning. [[From evidence]] (SO:EV-002, SO:OBJ-0102)

```figures
3 | business processes
7 | stored procedures
11 | tables
2 | ADF pipelines, 1 SQL Agent job
9 | business rules
4 | open questions
```

In scope: store go-live, store status changes, the go-live audit trail, the morning extract to Finance. Out of scope: store closure (vertical Store Lifecycle, REL-004). [[Confirmed]] (Arun, 2026-10-27)

### 9.1.2 Business flow

```mermaid
flowchart TD
  classDef evidence fill:#E4EEF8,stroke:#2F6DB5,color:#0F2C4C
  classDef confirmed fill:#E3F3EB,stroke:#1E7350,color:#0F2C4C
  classDef inferred fill:#FBF1DF,stroke:#9A5F0C,stroke-dasharray:4 3,color:#0F2C4C
  classDef unknown fill:#F1F5F9,stroke:#9FB5CA,stroke-dasharray:2 2,color:#47627F
  subgraph L1["Property team"]
    B1(["New store approved"]):::confirmed
    B2["Enter store request<br/>in Store Admin app"]:::evidence
  end
  subgraph L2["Store Management, nightly"]
    B3{"Go-live date reached<br/>and status = P?<br/>SO:BR-03"}:::evidence
    B4["Set store live<br/>status P to O"]:::evidence
    B5["Write audit row"]:::evidence
  end
  subgraph L3["Finance and reporting"]
    B6["Finance receives<br/>new-store extract 06:00"]:::evidence
    B7["BI store report<br/>shows the store"]:::inferred
    B8["? Who checks failed go-lives<br/>Q-SO-004"]:::unknown
  end
  B1 --> B2 --> B3
  B3 -->|"yes"| B4 --> B5 --> B6
  B3 -->|"no: wait for next night"| B3
  B5 -.->|"inferred: nightly copy"| B7
  B4 -.-> B8
```
Figure 1: Store Opening business flow, from approval to the morning reports

**What this diagram shows**
How a new store goes from "approved" to "trading and visible in the reports". Three groups take part: the Property team enters the request during the day, the Store Management system makes the store live overnight, and Finance and the BI reports receive the result the next morning. The flow runs every night; on a typical night 0 to 3 stores go live (SO:LQ-0201, last 12 months) [[From evidence]].

**Walkthrough**
1. **New store approved** — the business approves a new store outside the system (board or property decision). The system only sees the result of this decision. [[Confirmed]] (Arun, 2026-10-27)
2. **Enter store request** — the Property team enters the store in the Store Admin web application: name, region, planned go-live date. The application writes a row to `StoreAdmin.dbo.store_request` and a store row with status **P** (Pending). [[From evidence]] (SO:EV-002 §2, SO:OBJ-0098)
3. **Go-live check** — every night at 02:00 UTC the system checks each pending store: *status = P and golive_date on or before the run date* (rule SO:BR-03). Stores whose date has not come yet are left untouched and checked again the next night. [[From evidence]] (SO:OBJ-0102 lines 21–24)
4. **Set store live** — for each store that passes the check, the status changes from P to **O** (Open) in `Sales.dbo.store_master`. [[From evidence]]
5. **Write audit row** — the change is recorded in `Sales.dbo.store_audit` with old status, new status and time (rule SO:BR-05: every status change is audited). [[From evidence]]
6. **Finance extract** — at 06:00 UTC a file `new_stores_YYYYMMDD.csv` with the stores that went live that night is placed on the Finance share (rule SO:BR-07). Finance uses it to open cost centres. [[From evidence]] (SO:OBJ-0110, SO:EV-005)
7. **BI store report** — the store appears in the Power BI store report after the Databricks copy (`dim_store`) refreshes, which appears to happen at about 05:00 UTC. [[Inferred]] from the table history (SO:LQ-0215); the report owner has not confirmed it.
8. **Failed go-live follow-up** — nothing in the evidence shows who notices or acts when a store should have gone live but did not. [[Unknown]] Q-SO-004

**Scenarios**
1. **Normal path — store reaches its go-live date.** *When it applies:* a store has status P and its go-live date is today or earlier. *What happens:* steps 3 → 4 → 5 that night, step 6 at 06:00, step 7 in the morning. *Outcome:* status O, one audit row, the store in the Finance file and the BI report. *How often:* about 210 stores in the last 12 months, 0–3 per night (SO:LQ-0201). [[From evidence]]
2. **Alternative — go-live date in the future.** *When:* status P, go-live date after the run date. *What happens:* step 3 finds nothing to do for this store; it is checked again every night until its date comes. *Outcome:* no change, no audit row, not in the Finance file. [[From evidence]]
3. **Alternative — back-dated go-live date.** *When:* the request is entered with a go-live date in the past (late data entry). *What happens:* the store goes live at the next nightly run, not on the date entered; the audit row shows the actual change time. *Outcome:* Finance receives it one or more days late; the BI report shows it from that night. 14 stores went live 1–9 days after their go-live date (SO:LQ-0203). [[From evidence]]
4. **Exception — the nightly run fails.** *When:* the procedure raises an error (for example a lock timeout). *What happens:* the whole go-live is rolled back (no partial updates), ADF marks the pipeline failed, and the Finance file is produced **without** that night's stores. *Outcome:* the stores go live at the next successful run. Who is alerted is [[Unknown]] (Q-SO-004, risk R-07).
5. **Edge case — request cancelled before go-live.** *When:* a pending request is withdrawn. *What happens:* the status appears to change to **X** in the Store Admin application, and the nightly check ignores it. [[Inferred]] — the meaning of X is not documented (Q-SO-002).
6. **Edge case — manual go-live outside the run.** *When:* someone needs a store live immediately. *What happens:* the evidence shows 3 audit rows written outside 02:00–02:10, which suggests manual runs or direct updates. [[Inferred]] (SO:LQ-0216); who does this and how is [[Unknown]] (Q-SO-005).
7. **Unknown path — store opened and closed the same night.** Not seen in the data and not handled in the code; behaviour unknown (Q-SO-006).


| Step | What happens (business words) | Actor | Trigger / timing | Rule | Output | Label | Evidence |
|---|---|---|---|---|---|---|---|
| 1 | A new store is approved and entered | Property team | During the day | — | Store request (status P) | [[From evidence]] | SO:EV-002 §2 |
| 2 | The store goes live on its go-live date | System | Nightly 02:00 UTC | SO:BR-03 | Status O | [[From evidence]] | SO:OBJ-0102, SO:LQ-0201 |
| 3 | Finance gets the list of stores that went live | System → Finance | 06:00 UTC file | SO:BR-07 | CSV extract | [[From evidence]] | SO:OBJ-0110 |
| 4 | The BI report shows the new store | BI | Morning | — | Report row | [[Inferred]] | timing from table history (SO:LQ-0215) |
| 5 | Someone follows up failed go-lives | Unknown | — | — | — | [[Unknown]] | Q-SO-004 |

### 9.1.4 Detailed technical flow

```mermaid
flowchart TD
  classDef evidence fill:#E4EEF8,stroke:#2F6DB5,color:#0F2C4C
  classDef inferred fill:#FBF1DF,stroke:#9A5F0C,stroke-dasharray:4 3,color:#0F2C4C
  subgraph P1["Phase 1 — Load requests"]
    T1[["ADF PL_Store_Daily<br/>trigger TR_Daily_0200, 02:00 UTC"]]:::evidence
    A1["Lookup: active requests<br/>StoreAdmin.dbo.store_request"]:::evidence
    A2["Copy to staging<br/>Sales.stg.store_request"]:::evidence
  end
  subgraph P2["Phase 2 — Go-live"]
    S1["Sales.dbo.usp_store_golive<br/>@run_date DATE = GETDATE()"]:::evidence
    D1[("Sales.dbo.store_master<br/>UPDATE status")]:::evidence
    D2[("Sales.dbo.store_audit<br/>INSERT")]:::evidence
  end
  subgraph P3["Phase 3 — Publish"]
    S2["Sales.dbo.usp_store_extract<br/>@run_date"]:::evidence
    F1[/"Finance file<br/>new_stores_YYYYMMDD.csv"/]:::evidence
    C1[("prod_sales.store_gold.dim_store<br/>Databricks job 4411")]:::inferred
  end
  T1 --> A1 --> A2 --> S1
  S1 -->|"reads"| A2
  S1 -->|"UPDATE status P to O"| D1
  S1 -->|"INSERT one row per store"| D2
  D1 --> S2 --> F1
  D1 -.->|"inferred: copy about 05:00"| C1
```
Figure 2: Store Opening detailed technical flow, three phases

**What this diagram shows**
The same go-live, seen from the technology: which pipeline, procedures and tables do the work, in which order, with which parameters. It runs in three phases every night from 02:00 UTC: Phase 1 copies new requests from the Store Admin database into Sales staging; Phase 2 makes due stores live and audits the change; Phase 3 publishes the result to Finance (file) and, it appears, to Databricks. The whole run takes about 3–5 minutes (SO:LQ-0215) [[Inferred]].

**Walkthrough**
1. **Trigger `TR_Daily_0200`** starts ADF pipeline `PL_Store_Daily` at 02:00 UTC every day, including weekends. [[From evidence]] (ADF definition, SO:LQ-0207)
2. **Lookup activity** reads the active requests from `StoreAdmin.dbo.store_request` (condition `is_active = 1`). [[From evidence]]
3. **Copy activity** copies those rows into `Sales.stg.store_request`, truncating the staging table first (full reload every night). [[From evidence]]
4. **Stored procedure activity** calls `Sales.dbo.usp_store_golive` with `@run_date` = the pipeline's trigger date (UTC). The default `GETDATE()` is only used when someone runs it by hand. [[From evidence]] (SO:OBJ-0102)
5. **`usp_store_golive` reads** staging and `store_master` to find stores with status P and golive_date on or before `@run_date`. [[From evidence]]
6. **UPDATE** `store_master.status` from P to O for those stores, inside one transaction. [[From evidence]]
7. **INSERT** one row per changed store into `store_audit`. [[From evidence]]
8. **`usp_store_extract @run_date`** selects the stores whose audit rows were written for that run date and writes `new_stores_YYYYMMDD.csv` to `\\fs01\finance\stores\` (format: store_id, store_name, region_code, golive_date). [[From evidence]] (SO:OBJ-0110)
9. **Databricks job 4411** appears to copy `store_master` to `prod_sales.store_gold.dim_store` at about 05:00 UTC. The job definition was not available; the timing comes from `DESCRIBE HISTORY` (SO:LQ-0212). [[Inferred]]

**Scenarios**
1. **Normal nightly run.** *When:* 02:00 UTC trigger, both databases available. *What happens:* steps 1–8 in order, step 9 about three hours later. *Outcome:* staging reloaded, due stores live, audit rows, Finance file. [[From evidence]]
2. **No store due tonight.** *When:* no pending store has reached its date. *What happens:* steps 1–5 run; steps 6–7 change nothing; step 8 still writes the file **with a header only**. *Outcome:* Finance receives an empty file (seen on 241 of the last 365 days, SO:LQ-0218). [[From evidence]]
3. **Store Admin database unavailable.** *When:* the lookup or copy fails. *What happens:* the pipeline stops at step 2 or 3; staging keeps the previous night's data; steps 4–8 do **not** run. *Outcome:* no go-lives, no Finance file that night. [[From evidence]] (ADF dependency conditions "on success")
4. **Go-live procedure fails.** *When:* error inside step 6 or 7. *What happens:* CATCH block rolls back and raises the error; ADF marks the activity failed; step 8 does not run. *Outcome:* nothing changed; next night picks the stores up again. [[From evidence]]
5. **Manual rerun the same day.** *When:* support reruns the pipeline after a failure. *What happens:* staging is reloaded; stores already live are not changed again (status is no longer P), so no duplicate audit rows; the Finance file is overwritten with the same name. [[Inferred]] from the code; not confirmed by support (Q-SO-007).
6. **Month-end.** No difference in this flow was found. [[From evidence]] (no date logic other than golive_date)
7. **Unknown — Databricks copy timing.** Whether job 4411 waits for this pipeline or simply runs at 05:00 is [[Unknown]] (Q-SO-008); if the pipeline overruns, the BI report may miss that night's stores.


| # | Phase | Object (full name) | Type | Operation | Parameters | Schedule | Reads | Writes | Label | Evidence |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | ADF PL_Store_Daily, activity "Lookup requests" | ADF activity | lookup | — | TR_Daily_0200, 02:00 UTC | StoreAdmin.dbo.store_request | — | [[From evidence]] | SO:LQ-0207 |
| 2 | 2 | SQLPROD01.Sales.dbo.usp_store_golive | procedure | update, insert | @run_date DATE = GETDATE() | called by step 1's pipeline | Sales.stg.store_request, Sales.dbo.store_master | store_master (status), store_audit | [[From evidence]] | SO:OBJ-0102 |

### 9.1.5 Run sequences

```mermaid
sequenceDiagram
  autonumber
  participant TR as Trigger TR_Daily_0200
  participant PL as ADF PL_Store_Daily
  participant SP as usp_store_golive
  participant SM as dbo.store_master
  participant AU as dbo.store_audit
  TR->>PL: start 02:00 UTC
  PL->>SP: EXEC @run_date = pipeline date
  Note over SP: BEGIN TRAN
  SP->>SM: UPDATE status = 'O' WHERE status = 'P' AND golive_date <= @run_date
  SP->>AU: INSERT store_id, old P, new O, changed_at
  Note over SP: COMMIT, returns rows updated
  SP-->>PL: return code 0
```
Figure 3: Nightly go-live run (about 3 minutes, from table history SO:LQ-0215) [[Inferred]]

**What this diagram shows**
The calls made during one nightly go-live, in time order, between the trigger, the ADF pipeline, the procedure and the two tables. It shows where the transaction starts and ends, which parameter is passed and what comes back to ADF.

**Walkthrough**
1. The trigger starts the pipeline at 02:00 UTC.
2. The pipeline executes `usp_store_golive` with `@run_date` = the trigger date.
3. The procedure opens a transaction (BEGIN TRAN), so steps 4 and 5 succeed or fail together.
4. It updates the status of every due store from P to O.
5. It inserts one audit row per updated store.
6. It commits and returns the number of rows updated; ADF receives return code 0 and moves to the extract.

**Scenarios**
1. **Normal:** messages 1–6 as above; about 3 minutes end to end. [[Inferred]] (SO:LQ-0215)
2. **Error during message 4 or 5:** the CATCH block rolls back, no rows change, RAISERROR returns severity 16 to ADF, which fails the activity and stops the pipeline. [[From evidence]]
3. **No due stores:** message 4 updates 0 rows, message 5 inserts nothing, the procedure still commits and returns 0. [[From evidence]]
4. **Long-running lock on store_master** (for example a report holding a lock): the update waits; ADF's activity timeout is 1 hour, after which the run fails as in scenario 2. [[From evidence]] (ADF activity policy)


### 9.1.8 Stored procedures and code objects

```
SO:OBJ-0102 · SQLPROD01.Sales.dbo.usp_store_golive · procedure · core · Active (last run 2026-11-05)
Called by: ADF PL_Store_Daily, activity "Go-live" (daily 02:00 UTC)
Parameters: @run_date DATE = GETDATE()
Purpose: sets every pending store whose go-live date has come to Open, and records the change.
Steps: 1 BEGIN TRAN · 2 UPDATE store_master SET status='O' WHERE status='P' AND golive_date <= @run_date ·
       3 INSERT store_audit (store_id, old_status, new_status, changed_at) for those rows · 4 COMMIT · 5 RETURN @@ROWCOUNT
Reads: Sales.stg.store_request, Sales.dbo.store_master   Writes: store_master.status (UPDATE), store_audit (INSERT)
Business rules implemented: SO:BR-03 (go-live date), SO:BR-05 (audit every change)
Error handling: TRY/CATCH, ROLLBACK, RAISERROR to ADF (fails the pipeline)
Label / evidence: From evidence, SO:OBJ-0102 (code, lines 12–58), SO:LQ-0201
```

```mermaid
flowchart TD
  classDef evidence fill:#E4EEF8,stroke:#2F6DB5,color:#0F2C4C
  S(["Start @run_date"]):::evidence --> T["BEGIN TRAN"]:::evidence
  T --> U["UPDATE store_master<br/>status P to O where golive_date is on or before @run_date"]:::evidence
  U --> R{"Any rows updated?"}:::evidence
  R -->|"yes"| A["INSERT store_audit<br/>one row per store"]:::evidence
  R -->|"no"| C
  A --> C["COMMIT"]:::evidence
  C --> E(["RETURN rows"]):::evidence
  U -.->|"error"| X["CATCH: ROLLBACK, RAISERROR"]:::evidence
```
Figure 4: Logic of usp_store_golive

**What this diagram shows**
The decision logic inside `usp_store_golive`: one transaction, one update, an audit insert only when something changed, and a single error path that undoes everything.

**Walkthrough**
1. **Start** with `@run_date` (from ADF, or today when run by hand).
2. **BEGIN TRAN** — all changes below are one unit of work.
3. **UPDATE store_master** — status P becomes O where golive_date is on or before `@run_date` (SO:BR-03).
4. **Any rows updated?** — checks `@@ROWCOUNT`.
5. **Yes → INSERT store_audit** — one row per changed store, old status P, new status O, `changed_at = SYSUTCDATETIME()` (SO:BR-05).
6. **COMMIT** and **RETURN** the number of stores changed.
7. **Error at any point → CATCH** — ROLLBACK and RAISERROR, so ADF sees the failure.

**Scenarios**
1. **Stores due:** steps 1 → 2 → 3 → 4 (yes) → 5 → 6. [[From evidence]]
2. **Nothing due:** steps 1 → 2 → 3 → 4 (no) → 6; returns 0. [[From evidence]]
3. **Error in the update or the insert:** step 7; no partial change is possible. [[From evidence]]
4. **Edge — store with a NULL golive_date:** never matches the condition, so it stays P for ever; 2 such stores exist today (SO:LQ-0219). [[From evidence]]; whether this is intended is [[Unknown]] (Q-SO-009).


### 9.1.11 Data model

```mermaid
erDiagram
  STORE_REQUEST ||--o| STORE_MASTER : "becomes"
  STORE_MASTER ||--o{ STORE_AUDIT : "is audited by"
  STORE_MASTER }o--|| REGION : "belongs to"
  STORE_MASTER {
    int store_id PK
    varchar store_name
    char status "P O C"
    date golive_date
    char region_code FK
  }
  STORE_AUDIT {
    int audit_id PK
    int store_id FK
    char old_status
    char new_status
    datetime changed_at
  }
  STORE_REQUEST {
    int request_id PK
    int store_id
    date requested_golive
  }
  REGION {
    char region_code PK
    varchar region_name
  }
```
Figure 5: Store Opening data model

**What this diagram shows**
The four tables behind store opening and how they relate: a request becomes a store, a store belongs to one region, and every change to a store's status leaves an audit row.

**Walkthrough**
1. **STORE_REQUEST** (one row per request; Store Admin database) holds what the Property team entered. `store_id` links it to the store; there is **no foreign key** in the database, the link is by value only. [[From evidence]] (SO:OBJ-0098 definition)
2. **STORE_MASTER** (one row per store) is the system of record for stores: identity, name, region, status and go-live date. Primary key `store_id`. [[From evidence]]
3. **REGION** (one row per region, 14 rows) is a lookup; `store_master.region_code` references it with a declared foreign key. [[From evidence]]
4. **STORE_AUDIT** (one row per status change) records old and new status and the time; foreign key to `store_master.store_id`. [[From evidence]]

**Scenarios**
1. **A request without a store:** possible because there is no foreign key from request to store; 6 such requests exist (SO:LQ-0220). [[From evidence]] Whether they are abandoned requests is [[Unknown]] (Q-SO-010).
2. **A store without an audit row:** stores created before the audit table existed (before 2019-03) have none; 312 stores (SO:LQ-0221). [[From evidence]]
3. **Region removed:** prevented by the foreign key; the delete would fail. [[From evidence]]


| Entity in diagram | Full name | Rows (as of 2026-11-05) | Label | Evidence |
|---|---|---|---|---|
| STORE_MASTER | SQLPROD01.Sales.dbo.store_master | 1,284 | [[From evidence]] | SO:LQ-0211 |
| STORE_AUDIT | SQLPROD01.Sales.dbo.store_audit | 6,902 | [[From evidence]] | SO:LQ-0212 |

### 9.1.12 Status lifecycles and code lists

```mermaid
stateDiagram-v2
  [*] --> P: request entered (Store Admin app)
  P --> O: go-live date reached (usp_store_golive, nightly)
  O --> C: store closed (vertical Store Lifecycle, REL-004)
  P --> X: request cancelled (Q-SO-002, meaning unconfirmed)
  C --> [*]
```
Figure 6: store_master.status lifecycle

**What this diagram shows**
Every status a store can have and what moves it from one to the next. Status is the single most important field in this vertical: Finance and BI select stores by it.

**Walkthrough**
1. **Entered → P (Pending):** the Store Admin application creates the store with status P. [[From evidence]]
2. **P → O (Open):** `usp_store_golive`, nightly, when the go-live date is reached (SO:BR-03). [[From evidence]]
3. **O → C (Closed):** done by the Store Lifecycle vertical (REL-004), not by this one. [[From evidence]]
4. **P → X:** status X exists in the data (1% of rows) but no code in this vertical sets it. [[Unknown]] (Q-SO-002)

**Scenarios**
1. **Normal life of a store:** P → O → (years later) C. [[From evidence]]
2. **Cancelled request:** P → X, appears to be set by the Store Admin application. [[Inferred]]
3. **Re-opening a closed store:** no transition C → O exists in any code; 4 stores show C then O in the audit (SO:LQ-0222), so it was done manually. [[Conflicting]] between code and data (Q-SO-011).


| Column | Value | Meaning | Share of rows (2026-11-05) | Source of meaning |
|---|---|---|---|---|
| status | P | Pending go-live | 3% | SO:BR-03 [[Confirmed]] |
| status | O | Open | 91% | SO:BR-03 [[Confirmed]] |
| status | C | Closed | 5% | REL-004 [[From evidence]] |
| status | X | Cancelled? | 1% | [[Unknown]] Q-SO-002 |

### 9.1.13 Data lineage

```mermaid
flowchart LR
  classDef evidence fill:#E4EEF8,stroke:#2F6DB5,color:#0F2C4C
  classDef inferred fill:#FBF1DF,stroke:#9A5F0C,stroke-dasharray:4 3,color:#0F2C4C
  classDef external fill:#FFFFFF,stroke:#47627F,color:#0F2C4C
  R1[("StoreAdmin.dbo.store_request")]:::external -->|"ADF copy"| R2[("Sales.stg.store_request")]:::evidence
  R2 -->|"usp_store_golive"| R3[("Sales.dbo.store_master")]:::evidence
  R3 -->|"usp_store_golive"| R4[("Sales.dbo.store_audit")]:::evidence
  R3 -->|"usp_store_extract"| R5[/"new_stores_YYYYMMDD.csv"/]:::evidence
  R3 -.->|"inferred: job 4411"| R6[("prod_sales.store_gold.dim_store")]:::inferred
```
Figure 7: Store Opening table-level lineage

**What this diagram shows**
Where store data comes from and where it goes, table by table: from the Store Admin database, through Sales staging and the store master, to the audit table, the Finance file and Databricks.

**Walkthrough**
1. **store_request → stg.store_request:** ADF copy, full reload nightly, all columns. [[From evidence]]
2. **stg.store_request → store_master:** `usp_store_golive` uses staging to confirm the request is still active; it changes only `status`. [[From evidence]]
3. **store_master → store_audit:** `usp_store_golive` writes store_id, old/new status, time. [[From evidence]]
4. **store_master → Finance CSV:** `usp_store_extract` writes store_id, store_name, region_code, golive_date for that night's go-lives. [[From evidence]]
5. **store_master → dim_store:** Databricks job 4411 copies all stores; columns appear to be the same plus a load timestamp. [[Inferred]] (SO:LQ-0212)

**Scenarios**
1. **Normal night:** hops 1–4 between 02:00 and 02:10, hop 5 at about 05:00. [[Inferred]] timing.
2. **Store renamed in Store Admin:** the new name does **not** flow to store_master (no hop updates names); store_master keeps the original name. [[From evidence]] from the code; whether this is intended is [[Unknown]] (Q-SO-012).
3. **Pipeline failure:** hops 2–4 do not happen; hop 5 still copies yesterday's state. [[Inferred]]


### 9.1.17 Open questions and risks

### Q-SO-004 Who follows up a store that did not go live?
Nothing in the code or documents alerts anyone when a go-live fails. Searched: procedure code, ADF failure paths, SQL Agent alerts. Risk R-07 until answered.
