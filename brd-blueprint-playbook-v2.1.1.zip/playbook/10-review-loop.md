# Review loop — review page, feedback, approval (every stage)

Every stage ends the same way: a review page that opens in the user's browser, the user's feedback (in chat, in the page, or both), redrafts until they are satisfied, their typed approval, and the exact next command. **The user never handles a file**: you build and open pages and collect feedback with the `bp-helper` tools.

## 1. Writing the review page (end of every stage run)

1. **Round number.** Look in `STATUS.md` for this stage and scope. First run is round 1; each redraft is the next round.
2. **Page Markdown.** Write `brd-work/<project>/reviews/<stage>[-<vertical>]-r<N>.md` using `templates/review-page-template.md`:
   - front matter: `kind: review`, title, subtitle, project, stage, vertical (if any), round, `status: Waiting for your review`, date, platform, genie (exact Databricks status from PROJECT.md), `feedback_file: feedback-<stage>[-<vertical>]-r<N>.json`, `feedback_folder: brd-work/<project>/feedback/`
   - plain English, written for someone who has not read the source files
   - every item you need the user to answer or confirm as a `###` heading starting with its id (`Q-…`, `REL-…`, `GQ-…`, `GAP-…`, `ITEM-n`), so the page gives it an answer box
3. **Page HTML.** If the page has ```mermaid diagrams, run `bp-helper` → `check_diagrams` first and fix every error. Then `bp-helper` → `build_page` with the Markdown path. It writes `<same name>.html` from the viewer template (identical text) and **opens it in the browser**. Never edit page HTML by hand.
   *Only if `bp-helper` is not available:* copy `playbook/templates/viewer.html` to the `.html` path and put the Markdown between the `BLUEPRINT-MARKDOWN-START` / `-END` markers (several edits if large, each before the END marker; rewrite any line containing `</script`), and tell the user the helper is off (one line, `README.md` §6).
4. **Never overwrite an earlier round.** Each round is a new pair of files.
5. **Update `STATUS.md`**: state `PRESENTED`, round N, path of the page.
6. **Tell the user, in chat**, then stop:

```
<STAGE> — <scope>: round N is ready. The page has opened in your browser.
(If it did not: brd-work/<project>/reviews/<file>.html — say "open the page" and I'll reopen it.)

Summary: <3–5 lines>
Needs you: <n questions / items to confirm, or "nothing: please check and approve">
Databricks: <Genie / SQL in use: asked N · answered M · pending your confirmation C>  |  <not in use>

Reply with:
  • APPROVED            → I record it and tell you the next command
  • FEEDBACK: <changes> → I redraft (you can also answer the questions right here)
  • In the page: mark sections / answer the boxes, then "Export review" and type FEEDBACK FILE,
    or "Copy for chat" and paste it here
  • HALT                → I stop
```

## 2. Taking feedback

Feedback can arrive four ways, and can be combined:
- **Chat**: `FEEDBACK: …`, or direct answers to the questions.
- **`FEEDBACK FILE`** (or `/brd-feedback`): call `bp-helper` → `collect_feedback` with the project and the page's `feedback_file` name. It finds the export in the project's `feedback/` folder or the user's Downloads folder, keeps a copy in `feedback/` and returns its content. Never ask the user to move the file.
- **Pasted page feedback**: a chat message starting `FEEDBACK (from the review page …)` followed by JSON (the page's *Copy for chat* button). Save it as `feedback/<feedback_file>` yourself, then apply it.
- **Both**: apply both; if they contradict each other, ask which one stands.

For every piece of feedback:
1. Apply it to the stage's **working files** (registers, decisions, memory).
2. Answers to questions become decisions (`DEC-nnn` rows) with basis "answered in review round N" and the reviewer's name.
3. "Agree" on a Databricks finding marks it CONFIRMED; "Correct it" records the correction as the fact (new DEC) and re-checks read-only.
4. "Agree" on a relationship marks it CONFIRMED; "Correct it" updates it and re-checks every place that used it.
5. Anything unclear: ask a short follow-up in chat. Do not interpret loosely.
6. Write the next round's page with a **"What changed since round N"** section listing every change and its source (page, file or chat), build and open it (§1.3).
7. Stop again.

If `collect_feedback` finds nothing, say: *"I can't find the exported feedback. Click Export review again, or use Copy for chat and paste it here."*

## 3. Approval

- Only a chat message containing **APPROVED** approves the stage.
- Before recording it, check the latest round:
  - unanswered questions or items marked "change" that are not yet applied → list them and ask: "Approve anyway, leaving these open?" Record the answer.
  - Databricks findings still unconfirmed that this stage relies on → list them; they must be confirmed or rejected before approval (or explicitly accepted as open by the user).
- On approval: update `STATUS.md` (APPROVED, round, approver, date), update the latest page's front matter `status: Approved by <name> on <date>` and rebuild it with `build_page` (`open: false`), update `MEMORY.md`.
- Then **tell the user the next command** and stop. Work it out from `MASTER.md` §3 and `STATUS.md` (the approved vertical order):

```
Approved: <stage> — <scope> (round N, <name>, <date>).
Next: type  /brd-<command> <vertical if any>      (or /brd-next)
```
  If several commands are possible (for example the next vertical or the project stage), give the one in the approved order first and mention the other in one line.
- Do not start the next stage.

## 4. HALT
Stop immediately. Record `HALTED` in `STATUS.md` with the round. Say: *"Stopped. Type `/brd-status` to see where we are, or the stage's command to continue."*

## 5. Re-opening an approved stage
If later work shows an approved stage is wrong (for example a relationship found in Clarify contradicts an approved Understanding), do not edit it silently. Say which stage and why, and give the command to re-run it; the next run creates a new round and needs approval again. Downstream stages that relied on it are marked `NEEDS-RECHECK` in `STATUS.md`.
