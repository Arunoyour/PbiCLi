# Stage — Readiness (evidence check before the BRD update and the blueprint)

**Invoke:** `/brd-readiness` · **Scope:** project · **Needs:** Relationships APPROVED
**Writes:** `programme/06-readiness.md`, `MEMORY.md`
**Review page:** `reviews/readiness-r<N>.html`

## Purpose
The blueprint documents an old system with little documentation, so it must be built from whatever exists. This stage checks, vertical by vertical, what the blueprint will be able to say and what it will have to show as Unknown, and asks the user once for everything they may know. **Nothing here blocks for lack of information**: an unanswered item becomes an Unknown with its question and a risk.

## 1. Evidence map per vertical
For each vertical, against the chapter outline in `08a-vertical.md`, mark each area **Strong** (From evidence or Confirmed), **Partial** (some Inferred), **Thin** (mostly Inferred) or **Missing**:
business flow · triggers and schedules · inputs (source, format, frequency, volume, owner) · outputs and consumers (what, grain, freshness, interface) · objects (procedures, tables, pipelines, jobs) · procedure logic · calculations · rules · data model and keys · code values · lineage · integration points · controls · volumes · run behaviour (reruns, failures, manual steps) · owners and support.

## 2. Upstream and downstream, per vertical
| Field | Asked if the evidence does not say |
|---|---|
| Source / consumer | Where does this come from / who uses it? |
| Owner | Who owns it, who is called when it breaks? |
| Format and access | Files, database, API, linked server, copy activity? |
| Frequency and timing | How often, at what time, with what delay? |
| Volume | Rows / files per run (an estimate is fine) |
| Grain and freshness (consumers) | One row per what? How up to date? |
| Known issues | Duplicates, late data, manual fixes? |

## 3. System-wide items
Servers, databases, catalogs and environments seen · the normal run day and special cycles (month-end, year-end) · who supports the system · known incidents · systems outside the verticals that the system depends on.

## 4. Must have (the only blockers)
- every vertical's BRD imported and understood (Understand, Gaps, Clarify APPROVED)
- every relationship between verticals CONFIRMED or explicitly deferred with an owner

## Work
1. Build the evidence map from the inventories, gap registers, decisions and the Databricks log.
2. If Databricks is in use: fill Thin or Missing facts read-only where the data can tell (row counts, date ranges, last write times, schedules from job tables, code value shares), with the verification pass.
3. Ask the user for every remaining item in one or two rounds (`### Q-…` on the page and in chat). Unanswered at approval → **Unknown**, recorded as `ASM-nn` (if a reasonable assumption exists) and `R-nn` with an owner.

## Review page
- Evidence map per vertical (a table with Strong / Partial / Thin / Missing, and a ```figures summary)
- Upstream and downstream tables per vertical, missing fields as questions
- System-wide items
- What the blueprint will show as Unknown, and the risks recorded
- Databricks verification table, or "not in use"
Then follow `10-review-loop.md`.
