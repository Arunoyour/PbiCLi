# Stage — Architect review (separate reviewer agent) and response

The blueprint is challenged by a **different agent** from the one that wrote it, so the work is not grading itself.

## A. Review — `/brd-arch-review` (runs as the **Architect Reviewer** agent)
**Needs:** Blueprint 8g PRESENTED (feedback rounds done; the human has asked for the review).
**Writes:** `blueprint/arch-review/findings-r<N>.md` and its review page `reviews/arch-review-r<N>.html`.
**May not:** edit the blueprint, the BRDs or any register. It writes only its findings.

### What the reviewer does
Read the blueprint, the approved BRD versions, the relationship register, readiness, decisions, the Databricks log and the imported BRD files. Then challenge, as a senior architect on a design review board:

1. **Accuracy:** does the blueprint say what the evidence says? Spot-check statements against the BRDs and their evidence ids; labels used correctly (nothing Inferred presented as fact).
2. **Completeness:** objects, procedures, tables, pipelines, jobs, calculations, rules and integration points from every vertical BRD are all in the blueprint (sample at least 10 per vertical); every required diagram present.
3. **Diagrams:** each diagram matches its tables and the evidence (no node without an object, no edge without a hop); business and technical flows agree with each other; schedules agree with job tables.
4. **Cross-vertical integrity:** every relationship shown on both sides; shared entities have one system of record; timing dependencies explained; differing definitions visible.
5. **Run behaviour:** the run day, special cycles, reruns, failures and manual steps are explained well enough for a support person.
6. **Data:** keys, grain, history, code values, volumes and lineage of the main outputs are clear; sensitive columns named.
7. **Controls and risks:** controls seen are listed; single points of failure and knowledge are visible as risks.
8. **Honesty:** every unknown is visible in section 15 with a question and a risk; nothing smoothed over; no target design slipped in.
9. **Usability:** a newcomer can find, for any business step, the objects behind it and the evidence (traceability matrix, appendices).
10. **Evidence (Databricks, if in use):** may spot-check facts read-only with the SQL check; never writes anything.

Each finding uses the format in `templates/registers.md` (F-nnn, area, severity, sections, finding, why it matters, evidence, recommendation). Also list what is **good** about the blueprint briefly, so the response does not undo it.

Review page: findings by severity, each as `### F-nnn …` with an answer box. Stop.

## B. Response — `/brd-arch-respond` (runs as the main **BRD Programme** agent)
**Needs:** Architect review PRESENTED.
For every finding, one of:
- **Accepted and changed:** fix the owning part file (`81-…`–`86-…`), note the change.
- **Accepted as a risk:** add to section 15, with owner.
- **Disagree:** give the reason and evidence. The human decides on the review page or in chat.

Then reassemble (8g steps 2–6), fill **section 19 Architect review** (findings, responses, what changed, human verdicts), raise the blueprint version, and present the blueprint HTML with `10-review-loop.md`.

The human may ask for a second review round (`/brd-arch-review` again → `findings-r2.md`).

## C. Final approval
The project blueprint is APPROVED when the human types APPROVED after the response round. Then set `status: Approved` and `approved_by` in the front matter, rebuild MD and HTML one last time, and update `PROJECT.md`.
