# Part 8a — Vertical chapter (one per vertical)

**Invoke:** `/brd-bp-vertical <vertical>` · **Writes:** `blueprint/81-vertical-<v>.md` · **Sections:** 9.x for this vertical, and this vertical's rows of Appendices A–E
**Needs:** the gate in `08-blueprint.md`; the previous vertical's chapter APPROVED (approved order). Review page: `reviews/blueprint-8a-<v>-r<N>.html`.
Follow `08-blueprint.md` (content depth) and `diagram-standard.md` (V-01 … V-09). Model the style on `templates/example-vertical-chapter.md` (a shortened example): plain English first, labels on every statement, after every diagram a caption, **What this diagram shows**, a step-by-step **Walkthrough**, every **Scenario** (normal, alternatives, exceptions, edge cases, unknown) and a key table.

## Read first, in full
The vertical's approved BRD version **and** the imported original Functional, Technical and Summary files (`verticals/<v>/sources/`), its inventory, gap register, questions, decisions, MEMORY, the REL items touching it, its readiness rows and its Databricks findings. The Technical BRD from the BRD Reconstruction agent is the richest source: procedures with steps and key queries, pipelines with activities, tables with columns, calculations, lineage, integration points, evidence. Carry all of it.

## Write section 9.x, in this order (batches allowed: one sub-section per edit)
1. **9.x.1 Purpose and scope** — what the vertical does for the business, in plain English; in scope / out of scope; owners and users; figures (```figures: processes, procedures, tables, pipelines/jobs, rules, open questions).
2. **9.x.2 Business flow** — V-01 diagram, then a step table: `| Step | What happens (business words) | Actor | Trigger / timing | Rule (BR) | Output | Label | Evidence |`.
3. **9.x.3 Inputs and outputs** — every input (system, database/catalog, object/file/API, format, frequency, arrival time, volume, owner) and every output and consumer (what, grain, freshness, interface). Unknown fields shown as Unknown with the question.
4. **9.x.4 Detailed technical flow** — V-02 diagram (one `subgraph` per phase), then the run in order: `| # | Phase | Object (full name) | Type | Operation (read / insert / update / merge / delete / call / copy) | Parameters (name, type, value passed) | Schedule / trigger | Reads | Writes | Label | Evidence |`.
5. **9.x.5 Run sequences** — V-03 sequence diagram for every main run or trigger, each followed by two or three sentences on what happens and how long it takes (observed or inferred).
6. **9.x.6 Components** — V-04 diagram, then the object list grouped by database/catalog and schema: `| Object | Type | Ring (core / supporting / interface) | Activity (Active / Inactive / Unknown) | Purpose | Called / used by | Evidence |`.
7. **9.x.7 Pipelines and jobs** — every ADF pipeline, SQL Agent job, Databricks job: trigger and schedule (with time zone), activities or steps in order, procedures/notebooks called with parameters, sources and targets, upstream and downstream dependencies, last run / duration / failures where known.
8. **9.x.8 Stored procedures and code objects** — for **every** procedure, view, function and trigger in the vertical, a block:
   ```
   CM:OBJ-0042 · Sales.sales.usp_calc_rebate · procedure · core · Active
   Called by: ADF PL_Rebate_Daily, activity "Calc rebate" (daily 02:00 UTC)
   Parameters: @run_date DATE = GETDATE(), @region CHAR(2) = NULL
   Purpose (plain English): …
   Steps: 1 … 2 … 3 … (exact conditions, thresholds, defaults)
   Reads: …   Writes: … (operation, columns)
   Business rules implemented: CM:BR-07, CM:BR-09
   Key query (from the BRD, with its location): …
   Error handling / transactions / logging: …
   Label / evidence: …
   ```
   plus V-08 logic diagrams for every core procedure with more than three steps.
9. **9.x.9 Calculations and formulas** — `| Calculation | Formula as implemented | Variables (column ← source) | Rounding / nulls / defaults | Worked example (no real data) | Where (object, step) | Label |`, and a V-09 diagram per main calculation.
10. **9.x.10 Business rules as implemented** — every rule: `| BR | Rule (business words) | Object · step | Exact condition | Data check (LQ / GQ) | Differences (code vs documents vs data) | Label |`.
11. **9.x.11 Data model** — V-05 diagram, then per table: full name, type, purpose, grain, row count (as of), date range, PK / business key, FKs, written by, read by, and the column table `| Column | Type | Null | Key | Meaning | Code values | Used by |` (main columns here; all columns in Appendix B).
12. **9.x.12 Status lifecycles and code lists** — V-07 diagram per status/flag column; code list `| Column | Value | Meaning | Share of rows (as of) | Source of meaning |`.
13. **9.x.13 Data lineage** — V-06 diagram(s); table-level hop list `| Source | Via | Target | Operation | Evidence |`; column-level lineage for the main outputs.
14. **9.x.14 Integration points** — `| Integration | Type | Direction | Method / protocol | Counterpart | Data exchanged | Frequency | Volume | Error handling | Evidence |`.
15. **9.x.15 Controls and data quality as observed** — validations, constraints, reconciliations, manual checks, what happens on failure.
16. **9.x.16 Discovery findings** — hard-coded values, commented-out or dead logic, duplicate copies, inactive objects, undocumented behaviour, data anomalies, differences between documents, code and data.
17. **9.x.17 Open questions and risks for this vertical** — every open gap and question with its id; gaps still open are risks (`R-…`).
18. **9.x.18 Evidence and confidence** — statements by label for this chapter; the main evidence used.

Then append this vertical's rows to Appendices A (object inventory), B (tables and columns), C (procedure catalogue), D (pipelines and jobs) and E (lineage) in the same file under `## Appendix rows — <vertical>`.

## Minimum content (self-check)
All 18 sub-sections · V-01 … V-07 (+ V-08 per core procedure over three steps, V-09 per main calculation) · every object in the vertical's inventory covered (n of N) · every procedure with a block (n of N) · every table with a row in 9.x.11 or Appendix B (n of N) · every pipeline/job (n of N) · every BR (n of N) · every calculation (n of N) · every open gap listed.
