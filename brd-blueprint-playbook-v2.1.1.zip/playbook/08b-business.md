# Part 8b — System context and business architecture

**Invoke:** `/brd-bp-business` · **Writes:** `blueprint/82-business.md` · **Sections:** 4, 5
**Needs:** every vertical chapter (8a) APPROVED. Review page: `reviews/blueprint-8b-r<N>.html`.
Follow `08-blueprint.md` and `diagram-standard.md` (D-02 … D-06). Build from the approved vertical chapters, the Functional and Summary BRDs, the relationship register and readiness.

## Section 4 — System context
- Plain-English description of the system: what it is for, who uses it, how old and how well documented it is (as the evidence shows).
- **D-02** context diagram and the context table: `| External party / system | Role (source / consumer / user / scheduler / monitor) | What flows (in / out) | Interface | Frequency | Verticals | Label | Evidence |`.
- System boundary: what is inside the system and what is outside, with the reason.

## Section 5 — Business architecture
1. **5.1 Capability map** — **D-03**; then `| Capability | Sub-capability | Vertical | Processes | Main objects | Label |`.
2. **5.2 Actors and roles** — every team, role and user group: what they do, what they receive, manual steps they perform, decisions they make. Names only where the BRDs give them; never personal data.
3. **5.3 End-to-end business process** — **D-04** across all verticals (lanes); then a narrative from first trigger to last output, and the process table `| # | Business step | Vertical | Actor | Trigger / timing | Rules (BR) | Systems involved | Output | Label |`. If one diagram would exceed ~35 nodes, draw one per major process plus a top-level one.
4. **5.4 Business calendar** — **D-05**: daily, weekly, monthly, yearly events, cut-offs, month-end and year-end behaviour; table with the evidence.
5. **5.5 Business rules catalogue** — every rule from every vertical: `| BR (with vertical) | Rule in business words | Vertical(s) | Where implemented | Label | Evidence |`; rules that span verticals marked; differing definitions listed with the agreed one (DEC) or as Conflicting.
6. **5.6 Business entities and lifecycles** — every business entity (customer, store, order …): meaning, owner vertical (system of record), identifiers, where it is stored; **D-06** for each status field with code values.
7. **5.7 Business outputs** — reports, files, extracts, KPIs and decisions the system supports: `| Output | Consumer | Content | Frequency / deadline | Produced by (objects) | Label |`.

## Minimum content (self-check)
D-02 … D-06 present and drawing · context table covers every input and consumer in the vertical chapters (n of N) · every capability linked to processes · every actor · end-to-end process table · calendar · every BR from every vertical (n of N) · every entity with owner · every status field with a lifecycle (n of N) · every output (n of N).
