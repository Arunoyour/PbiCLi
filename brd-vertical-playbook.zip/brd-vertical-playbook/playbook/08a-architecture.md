# Part 8a — Ecosystem and solution architecture

**Invoke:** `/brd-bp-architecture` · **Writes:** `blueprint/81-architecture.md` · **Sections:** 3, 6, Appendix A
Follow `08-blueprint.md`. Review page: `reviews/blueprint-8a-r<N>.html`.

## Opening questions (only what PROJECT.md / MEMORY.md / readiness do not already answer)
Environments available · mandatory house standards or reference architecture · network and identity constraints · services that must or must not be used · deadlines and budget ceiling.

## Work
1. **Section 3, ecosystem overview:** verticals by role as a ```layers block (systems of record / processing / consumers); main data flows between verticals as a ```flow block; relationship table from the register; build and load order with reasons; how any circular dependency is broken.
2. **Section 6, solution architecture:**
   - context table: every source, consumer, scheduler, identity provider, monitoring tool
   - layer design following the guardrail pack's layering rules, as a ```layers block listing the real objects per layer for every vertical, and a table of each layer's rules (append-only, cleansed, conformed, aggregated, served)
   - how verticals map onto the platform's structure (Databricks: catalogs / schemas; Fabric: workspaces / lakehouses / warehouses), following the guardrails
   - component table with REQ ids; technology choices with reasons and rejected options
   - interfaces in and out (format, frequency, contract owner, failure handling)
3. **ADRs:** table in section 6; full ADR text in Appendix A for HIGH-impact decisions. Undecided ones are `[[Decision needed]]` and asked in chat.
4. Guardrail check for this part's items.

## Minimum content (self-check)
Ecosystem ```layers + ```flow · relationship table · build order · context table · layer design with real objects per vertical · platform structure mapping · component table with REQ ids · technology choices · interfaces · ADRs.
