# Stage — Intake

**Invoke:** `/brd-intake` · **Scope:** project
**Writes:** `brd-work/<project>/PROJECT.md`, `STATUS.md`, `MEMORY.md`, folder structure; `genie-config.md` and `.vscode/mcp.json` if Genie is used
**Review page:** `reviews/intake-r<N>.html`

A conversation, one step at a time. Save each answer to `PROJECT.md` before asking the next question. Use the `askQuestions` tool if it waits for the user; otherwise ask in chat.

## Step 1 — Project name
Ask for the project name. Make a folder-safe short name (lowercase, hyphens), confirm it, and create `brd-work/<project>/` with the layout in `MASTER.md` section 4. Copy `templates/PROJECT.md`, `templates/STATUS.md` and `templates/MEMORY.md` into it.

## Step 2 — Genie (asked early, because it changes how every later stage works)
Ask: "Is there a Databricks Genie space with the technical metadata for this project (tables, views, stored procedures)?"

**If yes**
1. Collect the **non-secret** details only: workspace host, Genie space ID, and the metadata tables (what each holds). Fill `genie-config.md` from the template.
2. Say clearly: **do not paste the access token in chat.** Anything typed in chat is sent to the model and kept in the chat history.
3. Write `.vscode/mcp.json` from `.vscode/mcp.json.example` with the host and space ID. The token stays as `${input:dbx_token}`, so VS Code asks for it in its own password box and stores it securely.
4. Ask the human to start the server: Command Palette → "MCP: List Servers" → `genie` → Start, and enter the token when VS Code asks. Remind them the token must belong to a **read-only** identity (checklist in `genie-config.md`).
5. Test with one harmless read-only question (for example: how many tables are listed in the metadata registry). Apply the SQL check from `11-genie-protocol.md`.
6. Record in `PROJECT.md`: `Genie: In use (read-only)`, the test result and date.

**If no, or the test fails**
Record `Genie: Not in use (no access details provided)` (or `… (connection test failed: <reason>)`). Tell the human plainly: technical facts will come only from the BRD files and their answers. This status appears on every review page.

## Step 3 — Verticals
Ask how many verticals there are and their names, then for each: a one-line purpose, the business owner (if known), and a short code for IDs (2–4 letters, for example CM for Customer Master). Do not assume a fixed number. Confirm the list back.

## Step 4 — Files per vertical
For each vertical, ask the human to place its Markdown files in `brd-work/<project>/verticals/<vertical>/sources/` (or give their current paths, and copy them there). Then tag each file:
- type: `Summary` (code `S`), `Business + Technical` (code `BT`), or `Other` (with a short description)
- source id: `SRC-<V>-S`, `SRC-<V>-BT`, `SRC-<V>-O1` …

Flag and ask about: a vertical with no Summary or no Business + Technical file, a file that seems to belong to two verticals, a file that is not Markdown, an empty or unreadable file.

Quick conversion check on each file: tables intact, code blocks intact, headings sensible. Report any damage; do not repair the source.

## Step 5 — Technology
Ask: **Databricks or Fabric?** (one per project). Record it; the matching guardrail pack (`guardrails/databricks/` or `guardrails/fabric/`) will be loaded from now on. Mention that the choice is confirmed again before the blueprint.

## Step 6 — Order of verticals
Ask: "Do you want to set the order in which we go through the verticals, or should I propose one after reading them all?" Record the order, or `Agent proposes after Read all`.

## Review page
Show: project, Genie status (with the test result), technology and guardrail pack, a table of verticals (code, purpose, owner, files with ids and types), file issues found, order (or "to be proposed"), and anything still missing as `ITEM-n` headings. Then follow `10-review-loop.md`.
