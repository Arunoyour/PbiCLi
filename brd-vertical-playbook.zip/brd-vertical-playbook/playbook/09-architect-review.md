# Stage — Architect review (separate reviewer agent) and response

The blueprint is challenged by a **different agent** from the one that wrote it, so the work is not grading itself.

## A. Review — `/brd-arch-review` (runs as the **Architect Reviewer** agent)
**Needs:** Blueprint 8g PRESENTED (feedback rounds done; the human has asked for the review).
**Writes:** `blueprint/arch-review/findings-r<N>.md` and its review page `reviews/arch-review-r<N>.html`.
**May not:** edit the blueprint, the BRDs or any register. It writes only its findings.

### What the reviewer does
Read the blueprint, the approved BRD versions, the relationship register, readiness, decisions, the Genie log and the guardrail pack. Then challenge, as a senior architect on a design review board:

1. **Requirements fit:** every REQ is covered; nothing is designed that nobody asked for; rules are implemented as the approved BRDs say.
2. **Cross-vertical integrity:** every relationship has a contract, keys and timing; shared entities have one owner; definitions agree; build order works; no hidden circular dependency.
3. **Data design:** grain and keys are right; history and late corrections flow through every layer and every consuming vertical; STTM complete; DQ rules protect the rules that matter.
4. **Failure modes:** late, missing, duplicate, out-of-order or malformed data; partial loads; reruns; upstream schema change; one vertical failing while others run.
5. **Scale and cost:** volumes now and in three years; bottlenecks; the cost estimate's assumptions.
6. **Security and compliance:** least privilege, sensitive data, audit, retention.
7. **Operability:** monitoring, alerting, runbooks; can support tell what went wrong and fix it.
8. **Guardrails:** spot-check the compliance table; challenge any Exception.
9. **Alternatives:** where a major choice is weak, name the alternative and why it might be better.
10. **Honesty:** every unknown is visible in section 19 or 18; nothing important smoothed over.
11. **Evidence (Genie, if in use):** may spot-check facts read-only with the SQL check; never writes anything.

Each finding uses the format in `templates/registers.md` (F-nnn, area, severity, sections, finding, why it matters, evidence, recommendation). Also list what is **good** about the design briefly, so the response does not undo it.

Review page: findings by severity, each as `### F-nnn …` with an answer box. Stop.

## B. Response — `/brd-arch-respond` (runs as the main **BRD Programme** agent)
**Needs:** Architect review PRESENTED.
For every finding, one of:
- **Accepted and changed:** fix the owning part file (`81`–`86`), note the change.
- **Accepted as a risk:** add to section 18 (and 19 if it needs a decision), with owner.
- **Disagree:** give the reason and evidence. The human decides on the review page or in chat.

Then reassemble (8g steps 2–3), fill **section 22 Architect review** (findings, responses, what changed, human verdicts), raise the blueprint version, and present the blueprint HTML with `10-review-loop.md`.

The human may ask for a second review round (`/brd-arch-review` again → `findings-r2.md`).

## C. Final approval
The project blueprint is APPROVED when the human types APPROVED after the response round. Then set `status: Approved` and `approved_by` in the front matter, rebuild MD and HTML one last time, and update `PROJECT.md`.
