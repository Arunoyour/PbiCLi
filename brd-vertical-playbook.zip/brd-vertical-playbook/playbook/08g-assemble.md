# Part 8g — Assemble the project blueprint (MD + HTML)

**Invoke:** `/brd-bp-assemble` · **Writes:** `blueprint/80-project-blueprint.md`, `blueprint/80-project-blueprint.html`
**Sections:** 1, 2, 4, 5, 17, 20, 21, 23 and the assembly. Review page: the blueprint HTML itself.

## 0. Feedback from an earlier version
If a blueprint feedback file exists in `feedback/` that is newer than the last assembly: apply each "change" to the owning part file (`81`–`86`) or ask if unclear; record changes in the document control table; raise the version (v1.0 → v1.1).

## 1. Write the remaining sections
- **1 Document control:** versions, sources (BRD versions per vertical, registers, guardrail pack), approvals.
- **4 What we are fixing:** every gap that affects the build, per vertical and cross-vertical, with its resolution, DEC/GQ and who decided; differing definitions and the agreed one.
- **5 Requirements baseline:** approved BRD version per vertical; REQ summary per vertical with the sections that cover it; out of scope; deferred items.
- **17 Guardrail compliance:** every item in `guardrails/<tech>/CHECKLIST.md` with Pass / Exception (DEC) / Fail and the evidence section. A Fail must be fixed in the owning part or raised as a decision before presenting.
- **20 Traceability matrix:** per vertical, REQ → BR → section/component → STTM/job → stories → tests; coverage; orphans both ways.
- **21 Genie usage:** counts and relied-on findings with confirmation, or the "not used" statement.
- **23 Glossary.**
- **2 Executive summary,** last.
- **22 Architect review:** leave the heading with "To be completed after the architect review."

## 2. Assemble
1. Fill the front matter of `templates/blueprint-template.md` (`kind: blueprint`, BRD versions in `based_on`, platform, genie status, feedback file name).
2. Insert sections in order 1–23 (8.1, 8.2 … in the approved order), then Appendices A–C, copying the part files **as written**: no shortening, summarising or rewording.
3. Remove guidance comments. Save `80-project-blueprint.md`.
4. Copy `templates/viewer.html` to `80-project-blueprint.html` and put the identical Markdown between the marker comments (several edits if large, each before the END marker). Do not touch CSS or JavaScript; rewrite any line containing `</script`.

## 3. Check before presenting
- Same text in MD and HTML (section headings and line counts match).
- Every section present; every part's self-check had no Missing items.
- Coverage figures per vertical; no orphans unexplained.
- Every `[[…]]` pill uses a known status; every ```layers / ```flow / ```figures block has the right columns.
- No guardrail item at Fail; no Genie finding relied on is unconfirmed.

Present with `10-review-loop.md`. After the human's feedback rounds, the blueprint goes to the **Architect review** before final approval.
