# Stage — Readiness (architect's gate before the BRDs are rebuilt and the blueprint starts)

**Invoke:** `/brd-readiness` · **Scope:** project · **Needs:** Relationships APPROVED
**Writes:** `programme/06-readiness.md`, `MEMORY.md`
**Review page:** `reviews/readiness-r<N>.html`

## Purpose
Think like a senior architect: before anything is designed, make sure every input and every consumer is known, the data is understood well enough to model, and the guardrails are satisfied or knowingly excepted. Ask the human for anything the BRDs do not say.

## 1. Confirm the technology
Re-confirm Databricks or Fabric (from intake). Load `guardrails/<tech>/GUARDRAILS.md` and `CHECKLIST.md`.

## 2. Upstream: every input, per vertical
| Field | Question asked if the BRD does not say |
|---|---|
| Source system / vertical | Where does this data come from? |
| Owner | Who owns it, who to call when it breaks? |
| Format and access | Files, database, API, stream? How do we connect? |
| Frequency and arrival | How often, at what time, with what delay? |
| Volume | Rows / size per load, and growth (an estimate is fine) |
| Change capture | Full extract, incremental, CDC? Can it send deletes? |
| Quality | Known issues: duplicates, nulls, late data? |
| History | Does the source keep history? Do we need to? |

## 3. Downstream: every consumer, per vertical
| Field | Question asked if the BRD does not say |
|---|---|
| Consumer | Which application, team, report or vertical uses it? |
| Data needed | Which entities and fields? |
| Grain | One row per what? |
| Freshness | How up to date must it be? |
| Interface | Table, view, API, file, Power BI? |
| History | Current only, or point-in-time history? |
| Security | Who may see what? Any masking? |
| SLA and support | When must it be ready, what if it is late? |

The downstream answers decide the shape of the gold / serving layer, so they are never guessed.

## 4. Architect checklist
**Must have (blocks the BRD rebuild and the blueprint until answered or explicitly decided):**
- every input has a source, owner, format and frequency
- every consumer has data needed, grain, freshness and interface
- every entity has a grain, primary/business key and history approach
- every relationship between verticals is CONFIRMED or explicitly deferred with an owner
- shared terms have an agreed definition
- system of record decided for every shared entity
- data classification known for sensitive data
- no HIGH gap open without an owner and a decision date

**Should have (never blocks; if unknown, recorded as an assumption `ASM-nn` plus a risk `R-nn` with an owner):**
- volumes and growth, peak loads
- business impact if late or wrong, impact hours, run windows
- non-functional targets (run time, availability, recovery)
- cost expectations

**Guardrails:** walk `guardrails/<tech>/CHECKLIST.md` items that need business input; record answers or exceptions.

## Work
1. Fill sections 2 and 3 from the rebuilt understanding; ask the human for every missing field (rounds of questions on the page as `### Q-…` and in chat).
2. If Genie is in use: confirm volumes, key uniqueness, null rates read-only, SQL-checked.
3. Evaluate the checklist; show pass / fail / decided-exception for each item.

## Review page
- Upstream table per vertical, downstream table per vertical (missing fields highlighted as questions)
- Must-have checklist with status; anything failing as `### ITEM-n …`
- Should-have items: answers, or the assumption and risk recorded
- Guardrail items needing business input
- Genie verification table, or "not in use"
Then follow `10-review-loop.md`. The stage can be APPROVED only when every must-have passes or carries an explicit human decision.
