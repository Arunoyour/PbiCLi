# Relationship register (`programme/05-relationships.md`)

One entry per relationship between verticals. Raised in any stage; finalised in the Relationships stage.

## Summary
| REL | Type | From → To | Keys | Status |
|---|---|---|---|---|

## Entries

```
### REL-001 · <Type> · <Vertical A> → <Vertical B> · <Identified | Inferred | Unknown | CONFIRMED | CORRECTED | REJECTED>
Plain-English explanation (2-4 lines):
Objects: A: <table/entity> · B: <table/entity>
Keys and matching: <key A> ↔ <key B>, cardinality, what happens on no match
Definitions: A says "…" · B says "…" · Agreed: "…" (DEC-nnn) | open
Direction and timing: who produces, who consumes, frequency, latency allowed
System of record: <vertical>
Evidence: SRC-… <loc> (A side) · SRC-… <loc> (B side) · GQ-… · DEC-…
Raised in: <stage, vertical, round>     Confirmed by / date:
Questions open:
```

Types: shared entity · data flow · lookup/reference · shared key or code set · shared definition · timing dependency · ownership
