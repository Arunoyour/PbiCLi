# Project memory

The agent's running understanding of the whole project. Read at the start of every command; updated after every answered round. Every line cites a source (`SRC-…`), a decision (`DEC-…`), a relationship (`REL-…`) or a Genie finding (`GQ-…`).
A copy of this template (without the project-only sections) is used as `verticals/<v>/MEMORY.md`.

## The project in one paragraph

## Verticals at a glance
| Vertical | Code | What it does | System of record for | Depends on | Used by |
|---|---|---|---|---|---|

## Relationships (summary; full register in programme/05-relationships.md)
| REL | Between | What | Status |
|---|---|---|---|

## Shared terms
| Term | Definition per vertical | Agreed definition | DEC |
|---|---|---|---|

## Key decisions
| DEC | Decision | Scope (project / vertical) | Date |
|---|---|---|---|

## Genie findings relied on
| GQ | Fact | Vertical | Status |
|---|---|---|---|

## Upstream and downstream (from Readiness)
| Vertical | Inputs (source, frequency) | Consumers (who, interface, freshness) |
|---|---|---|

## Assumptions and risks
| ID | Statement | Owner |
|---|---|---|

## Still unclear (waiting on the human)
-

## Changed understanding
(what we used to think, what changed it, when)

## Session log
| Date | Command | Scope | What happened |
|---|---|---|---|
