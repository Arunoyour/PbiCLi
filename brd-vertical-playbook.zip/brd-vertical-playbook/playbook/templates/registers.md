# Register formats

## Inventory row (`verticals/<v>/10-understanding.md`)
| ID | Category | Statement | Source | Location | Confidence |
|---|---|---|---|---|---|
| REQ-CM-001 | Requirement | … | SRC-CM-BT | §3.2 | CLEAR |

## Gap entry (`verticals/<v>/20-gaps.md`)
```
### GAP-CM-001 · CON · HIGH · OPEN
Topic:
What each source says:
  - SRC-CM-S <loc>: "…"
  - SRC-CM-BT <loc>: "…"
  - Other vertical (for XCON/TRM): SRC-BL-BT <loc>: "…"  (REL-nnn)
  - Genie: GQ-nnn (if any)
Why it matters:
Candidate readings:
Status: OPEN | RESOLVED (DEC) | RESOLVED-PENDING-CONFIRM (GQ) | DEFERRED (owner, date) | STILL-OPEN
```

## Question entry (`verticals/<v>/30-questions.md`)
```
### Q-CM-001 · closes GAP-CM-001, GAP-CM-004 · HIGH · round 1
Context (with sources):
Question:
Options: A) …  B) …  C) …  Other
Proposed default (a proposal, not a fact):
Other vertical involved: (REL-nnn, if any)
Answer:                       Answered by / date / where (page or chat):
```

## Decision row (`verticals/<v>/31-decisions.md`; project-level decisions in MEMORY.md)
| DEC | Gaps / REL | Decision | Decided by | Date | Basis (answer / accepted default / Genie confirmed / deferred) | Supersedes |
|---|---|---|---|---|---|---|

## Architect review finding (`blueprint/arch-review/findings-r<N>.md`)
```
### F-001 · <area> · HIGH | MEDIUM | LOW
Section(s): <blueprint section numbers>
Finding: <what is wrong, missing or risky>
Why it matters: <consequence if not addressed>
Evidence: <BRD / REL / DEC / GQ / guardrail id>
Recommendation:
Author response: (filled in /brd-arch-respond: Accepted and changed / Accepted as risk / Disagree because …)
Human verdict:
```
