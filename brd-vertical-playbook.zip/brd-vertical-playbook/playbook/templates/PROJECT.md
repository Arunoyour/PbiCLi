# Project manifest

Written at intake; updated by the agent as the project moves. Every command reads this first.

## Project
- Name:
- Folder: `brd-work/<project>/`
- Started:
- Technology: Databricks | Fabric
- Guardrail pack: `guardrails/<databricks|fabric>/`

## Genie
- Status: In use (read-only) | Not in use (no access details provided) | Not in use (connection test failed: …)
- Workspace host (no secrets):
- Genie space ID:
- Connection test: date, question asked, result, SQL check
- Read-only identity confirmed by / date:

## Verticals
| # | Vertical | Code | Folder | Purpose | Business owner |
|---|---|---|---|---|---|

## Source files
| Vertical | Source id | File | Type (S / BT / Other) | Notes (conversion check) |
|---|---|---|---|---|

## Order of verticals
- Set by: human at intake | agent proposal approved in Read all
- Order:
- Reasons / dependencies:

## BRD versions
| Vertical | Latest version | Approved version | Approved by | Date |
|---|---|---|---|---|

## Blueprint
| Item | Status | Version | Approved by | Date |
|---|---|---|---|---|
| Project blueprint | | | | |
| Architect review | | | | |
