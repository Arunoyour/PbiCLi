---
kind: blueprint
title: <Project name> technical blueprint
subtitle: <One sentence: the ecosystem being built from the verticals, and the outcome>
project: <Project name>
document_id: <BP-XXX-001>
version: <v1.0>
status: Draft for review
date: <YYYY-MM-DD>
based_on: <BRD versions: CM v3, BL v2, OR v2 (all approved)>
platform: <Databricks | Fabric>
genie: <In use (read-only) | Not in use (no access details provided)>
prepared_by: BRD Programme agent
approved_by: Pending
feedback_file: blueprint-review-v<x>.json
feedback_folder: brd-work/<project>/feedback/
---

<!--
PROJECT BLUEPRINT: the document the team walks the client through before implementation.
It shows what will be built, how the verticals combine into one ecosystem, what gaps in the BRDs were fixed,
the data model and source-to-target mapping, the risks of this approach, and what still needs clarifying.

- Single source for both outputs: 80-project-blueprint.md and 80-project-blueprint.html (viewer, same text).
- Every section has MINIMUM CONTENT. A section is done when every item is present or marked "Not applicable: <reason>".
- IDs: REQ-<V>-nnn, BR-<V>-nn, DQ-nn, ADR-nn, NFR-nn, EP/FT/ST, TC-nnn, R-nn, ASM-nn, DEC-nnn, REL-nnn, GQ-nnn, GR-<DBX|FAB>-nn.
- Pills: [[Confirmed]] [[Provisional GQ-nnn]] [[Decision needed]] [[Deferred]] [[Risk high]] [[Risk medium]] [[Risk low]]
  [[Pass]] [[Exception]] [[Fail]]
- Callouts: > [!DECISION] > [!RISK] > [!PROVISIONAL] > [!CONFIRMED] > [!NOTE]
- Diagram blocks: ```layers (Name | note | part, part) · ```flow (Step | detail) · ```figures (Value | label). No Mermaid.
- Per-vertical chapters are numbered 8.1, 8.2, ... in the approved order of verticals.
-->

## 1. Document control
<!-- MINIMUM: version table · sources (BRD versions per vertical, relationship register, readiness, DEC/GQ ranges,
     guardrail pack and version) · approvals table (role, name, decision, date) · audience -->

## 2. Executive summary
<!-- MINIMUM (written last): ```figures (verticals, requirements, gaps fixed, items still open, tables designed) ·
     what we are building and why in 5 sentences · scope in/out · top 5 design decisions (ADR) · top 3 risks ·
     open decisions as > [!DECISION] -->

## 3. Ecosystem overview
<!-- MINIMUM: the verticals and their role (system of record / processing / consumer) as a ```layers block ·
     main data flows between verticals as a ```flow block · relationship table (REL, type, from → to, keys, status) ·
     build and load order with reasons · circular dependencies and how they are broken -->

## 4. What we are fixing
<!-- MINIMUM: every gap found in the BRDs that affects the build, per vertical and cross-vertical:
     | Gap | Vertical(s) | What was wrong or missing | Resolution | DEC / GQ | Decided by |
     · summary counts per vertical and type · definitions that differed between verticals and the agreed definition -->

## 5. Requirements baseline
<!-- MINIMUM: approved BRD version per vertical · requirement summary per vertical (REQ id, title, priority,
     blueprint sections that cover it) · out of scope · deferred items with owners -->

## 6. Solution architecture
<!-- MINIMUM: context table (sources, consumers, schedulers, identity, monitoring) · layer design as ```layers with real
     objects (e.g. bronze / silver / gold or the Fabric equivalent) · component table (component, responsibility,
     technology, owner, REQ ids) · technology choices with reasons and rejected options · ADR table (full ADRs in
     Appendix A for HIGH impact) · interfaces in and out -->

## 7. Shared data and cross-vertical design
<!-- MINIMUM: shared / conformed entities (customer, product, calendar …): owner vertical, grain, keys, history ·
     shared code sets and reference data · key mapping between verticals (from REL items) and no-match handling ·
     agreed definitions of shared terms (DEC) · integration contracts between verticals (what, format, timing, owner) -->

## 8.1 Vertical: <name>
<!-- One chapter per vertical, numbered 8.1, 8.2 … MINIMUM for each:
### Role in the ecosystem      (what it owns, what it consumes, what consumes it; REL ids)
### Upstream inputs            (from Readiness: source, format, frequency, volume, change capture)
### Downstream consumers       (from Readiness: who, data, grain, freshness, interface)
### Data model                 (entity table: layer, grain, PK, business key, history type, partition/cluster idea)
### Source-to-target mapping   (summary per target table: columns mapped n of N, rules involved; full in Appendix B)
### Business rules and logic   (BR id → where implemented, logic summary, edge cases)
### Stored procedure migration (every procedure: replicate / redesign / retire, new home, rules, evidence)
### Data quality rules         (DQ id, rule, layer, severity, action on failure)
### Open items for this vertical
-->

## 9. Processing and orchestration
<!-- MINIMUM: end-to-end run across verticals as ```flow · job/pipeline table (job, verticals, tasks, trigger,
     dependencies incl. cross-vertical, duration, SLA) · incremental vs full, watermarks, idempotency ·
     restart and recovery · error handling and quarantine · reconciliation between layers, between verticals,
     and against legacy -->

## 10. Non-functional design
<!-- MINIMUM: NFR table with targets (or ASM + risk if unknown) and design response · volumes with source ·
     sizing assumptions and monthly cost estimate -->

## 11. Security and compliance
<!-- MINIMUM: access model (role, objects, privileges) · sensitive data and protection · audit and lineage ·
     retention · secrets and identities · regulations and how each is met -->

## 12. Operations
<!-- MINIMUM: monitoring with thresholds · alert table · runbook (top failure scenarios incl. a vertical's feed
     arriving late) · support model · housekeeping -->

## 13. Environments and release
<!-- MINIMUM: environments · promotion flow (```flow) · CI/CD gates and deployment method · configuration per
     environment · release and rollback -->

## 14. Quality and testing
<!-- MINIMUM: strategy by level · test case summary per vertical (every BR and DQ rule has a test; full list per
     vertical) · cross-vertical integration tests (every REL with a data flow has a test) · reconciliation plan
     with tolerance · test data approach · entry/exit criteria -->

## 15. Migration and cutover
<!-- MINIMUM: approach and why · order of verticals for go-live · history load · parallel run and pass criteria ·
     cutover ```flow with go/no-go · rollback · decommissioning -->

## 16. Delivery plan
<!-- MINIMUM: epics (per vertical + shared platform + cross-vertical) · features · story summary per epic
     (full backlog in Appendix C, with Given/When/Then) · plan by sprint or milestone respecting build order ·
     RACI · estimate with assumptions · dependencies on teams and systems -->

## 17. Guardrail compliance
<!-- MINIMUM: every item of guardrails/<tech>/CHECKLIST.md: | GR id | Check | Result [[Pass]] / [[Exception]] / [[Fail]] |
     Evidence (section) | Exception decision (DEC) | · no [[Fail]] in an approved blueprint -->

## 18. Risks and assumptions
<!-- MINIMUM: risk table (R id, risk, impact, likelihood, mitigation, owner, rating) covering delivery, data,
     technical, cross-vertical and adoption risks, and the risks of this approach itself · assumptions table
     (assumption, why we believe it, what happens if wrong) -->

## 19. Clarifications still needed
<!-- MINIMUM: every open question, deferred gap and unconfirmed relationship, as > [!DECISION] callouts or a table:
     | Item | Vertical(s) | Question | Options | Recommendation | Owner | Needed by | Impact if late | -->

## 20. Traceability matrix
<!-- MINIMUM: REQ → BR → design section / component → STTM or job → stories → tests, per vertical; coverage
     figures; orphans in both directions -->

## 21. Genie usage
<!-- MINIMUM: if in use: counts (asked, answered, SQL-verified, partial, not answered, mismatches, not read-only = 0),
     findings the blueprint relies on and their confirmation, read-only statement, as-of window.
     If not in use: "Genie was not used (no access details provided). Technical facts come from the BRD files and the
     answers recorded in the decisions logs." -->

## 22. Architect review
<!-- MINIMUM (filled after /brd-arch-respond): reviewer findings by severity, the author's response to each,
     what changed, and the human's verdict on findings marked "Accepted as risk" or "Disagree" -->

## 23. Glossary
<!-- MINIMUM: agreed terms across verticals (with the DEC that agreed them) and technical terms used -->

## Appendix A. Architecture decision records

## Appendix B. Full source-to-target mapping, per vertical

## Appendix C. Full backlog
