# Status

Updated by the agent at the end of every stage run. A stage becomes APPROVED only after the human types APPROVED in chat.
States: NOT_STARTED · PRESENTED · REVISING · APPROVED · HALTED · NEEDS-RECHECK

## Project stages
| Stage | State | Round | Review page | Approved by | Date |
|---|---|---|---|---|---|
| Intake | NOT_STARTED | 0 | | | |
| Read all | NOT_STARTED | 0 | | | |
| Relationships | NOT_STARTED | 0 | | | |
| Readiness | NOT_STARTED | 0 | | | |
| Blueprint 8a Architecture | NOT_STARTED | 0 | | | |
| Blueprint 8b Data | NOT_STARTED | 0 | | | |
| Blueprint 8c Logic and processing | NOT_STARTED | 0 | | | |
| Blueprint 8d NFR, security, ops | NOT_STARTED | 0 | | | |
| Blueprint 8e Quality and migration | NOT_STARTED | 0 | | | |
| Blueprint 8f Delivery and risks | NOT_STARTED | 0 | | | |
| Blueprint 8g Assemble | NOT_STARTED | 0 | | | |
| Architect review | NOT_STARTED | 0 | | | |

## Vertical stages
One block per vertical, added at intake in the approved order.

### <Vertical name> (<code>)
| Stage | State | Round | Review page | Approved by | Date |
|---|---|---|---|---|---|
| Understand | NOT_STARTED | 0 | | | |
| Gaps | NOT_STARTED | 0 | | | |
| Clarify | NOT_STARTED | 0 | | | |
| BRD rebuild | NOT_STARTED | 0 | | | |

## Open counters
- Genie findings pending confirmation: 0
- HIGH gaps open (all verticals): 0
- Relationships not confirmed: 0

## Log
| Date | Stage | Scope | Round | What happened |
|---|---|---|---|---|
