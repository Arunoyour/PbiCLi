---
kind: review
title: <Vertical or Project>: <stage in plain words>
subtitle: <One sentence: what this page asks the reviewer to check>
project: <Project name>
stage: <Intake | Read all | Understand | Gaps | Clarify | Relationships | Readiness | BRD rebuild | Blueprint 8a … | Architect review>
vertical: <Vertical name, or leave out for project stages>
round: <N>
status: Waiting for your review
date: <YYYY-MM-DD>
platform: <Databricks | Fabric>
genie: <In use (read-only) | Not in use (no access details provided)>
feedback_file: feedback-<stage>[-<vertical>]-r<N>.json
feedback_folder: brd-work/<project>/feedback/
---

<!--
Review page skeleton. Keep the five standard sections; add stage-specific sections between 2 and 4.
- Plain English for someone who has not read the source files.
- Every item needing an answer or confirmation: a ### heading starting with its id
  (Q-CM-001, REL-004, GQ-012, GAP-CM-007, ITEM-1 ...). The page adds an answer box under it.
- Status pills: [[Confirmed]] [[Provisional GQ-nnn]] [[Decision needed]] [[Deferred]]
  [[Identified]] [[Inferred]] [[Unknown]] [[Risk high]] [[Risk medium]] [[Risk low]] [[SQL-verified]] [[Partial]]
- Blocks: ```figures (Value | label), ```flow (Step | detail), ```layers (Name | note | part, part)
- Callouts: > [!NOTE] > [!DECISION] > [!RISK] > [!PROVISIONAL] > [!CONFIRMED]
-->

## 1. Summary

```figures
<n> | <what>
<n> | <what>
<n> | <what>
```

<3-5 sentences: what this stage did, what it found, what it needs from you.>

> [!NOTE]
> <Genie line: "Genie is in use for this project, read-only. Facts from Genie carry a GQ id and need your confirmation."
>  or: "Genie is not in use (no access details provided). Technical facts come only from the BRD files and your answers.">

## 2. <Stage-specific: what I understood / what I found>

## 3. Needs your answer

### Q-<V>-001 <the question in one line>
<context with sources> · options A / B / C · proposed default and why · [[Decision needed]]

## 4. Genie findings to confirm

<table, plus ### GQ-nnn headings for the important ones; or "Genie not in use for this project.">

## 5. What changed since the last round

<round 1: "First round.">
