# Part 8d — Non-functional, security, operations, environments

**Invoke:** `/brd-bp-nfr` · **Writes:** `blueprint/84-nfr-security-ops.md` · **Sections:** 10, 11, 12, 13
Follow `08-blueprint.md`. Review page: `reviews/blueprint-8d-r<N>.html`.

## Opening questions (only what readiness and MEMORY do not answer)
Run windows and SLAs per consumer · recovery targets · data classification and regulations · retention · support hours and team · CI/CD tooling and approvals · cost ceiling.

## Work
1. **Section 10, non-functional:** NFR table with a target (or the ASM and risk from readiness) and the design response; volumes per vertical with source (GQ if Genie provided them); compute sizing assumptions; monthly cost estimate with its assumptions, following the guardrail pack's cost rules.
2. **Section 11, security:** access model (role / group, objects, privileges, least privilege) per vertical and for shared data; sensitive columns and protection (masking, row filters); audit and lineage; retention and deletion; secrets and service identities; each applicable regulation and how it is met. Use the guardrail pack's security model for the chosen platform.
3. **Section 12, operations:** monitoring (freshness per vertical feed, volumes, DQ failures, run time, cost) with thresholds; alerts with severity and responder; runbook for the top failure scenarios, including "an upstream vertical's data is late or wrong"; support model and escalation; housekeeping per the guardrails.
4. **Section 13, environments and release:** environments and the data each uses; promotion flow (```flow); CI/CD gates and deployment method per the guardrails; configuration per environment; release and rollback; how verticals can be released independently where the build order allows.

## Minimum content (self-check)
NFR targets or assumptions · volumes per vertical · cost estimate · access model incl. shared data · sensitive data · audit · retention · secrets · monitoring with thresholds · alerts · runbook (top 5 scenarios incl. late upstream vertical) · support model · environments · promotion flow · CI/CD gates · rollback.
