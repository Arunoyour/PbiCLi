# Stage — Read all

**Invoke:** `/brd-read-all` · **Scope:** project · **Needs:** Intake APPROVED
**Writes:** `programme/01-overview.md`, first entries in `programme/05-relationships.md`, `MEMORY.md`
**Review page:** `reviews/read-all-r<N>.html`

## Purpose
Read **every** vertical before digging into any one, so the later per-vertical work already knows how the verticals relate. This is a broad pass, not the full extraction (that is *Understand*).

## Work
1. For each vertical, read its Summary and Business + Technical files end to end (section by section if long). Note for each:
   - purpose and scope in a few lines
   - main business entities (customer, account, order …) and key identifiers
   - main data objects (tables, views, procedures) named
   - inputs it receives and outputs it produces, as far as the files say
   - terms it defines (and how)
2. **First view of relationships.** Look across verticals for:
   - the same entity or identifier appearing in more than one vertical
   - one vertical's output being another's input
   - the same term defined differently (for example "active customer")
   - procedures or tables referenced by more than one vertical
   Record each as a `REL-nnn` in `programme/05-relationships.md` (template `templates/relationship-register.md`) with status **Identified** (clear evidence), **Inferred** (the agent's reading) or **Unknown** (a link is suspected but unclear), and its evidence (vertical + file + section).
3. **If Genie is in use:** check, read-only, which of the named objects exist and which are referenced across verticals (shared tables, procedures reading other verticals' tables). Log in `genie-log.md` and apply the SQL check.
4. **Order.** If the human gave an order, check it against the dependencies found; if a vertical comes before one it depends on, say so and ask. If no order was given, propose one: verticals that others depend on first, then the rest; explain each placement in one line.
5. Write `programme/01-overview.md` and update `MEMORY.md` (verticals at a glance, early relationships, terms with differing definitions).

## Review page
- One short card per vertical: purpose, entities, inputs/outputs, notable terms
- An ecosystem picture: a ```flow block of how data moves between verticals (as far as known), plus a table of the REL items
- Each `Inferred` or `Unknown` relationship as a `### REL-nnn …` heading (answer box)
- Terms defined differently across verticals
- The proposed or checked order, with reasons, as `### ITEM-1 Order of verticals`
- Genie status line
Then follow `10-review-loop.md`.

## Do NOT
Start gap analysis or ask detailed questions about a single vertical. That comes in the per-vertical stages.
