# Stage — Project blueprint (overview)

One blueprint for the whole project: what will be built, how the verticals combine into one ecosystem, the model and mapping, the gaps fixed, the risks, and what is still unclear. It is the document walked through with the client before implementation.

**Needs:** every vertical's rebuilt BRD APPROVED (`PROJECT.md` version register), Readiness APPROVED, no Genie finding pending.
**Inputs:** approved BRD versions only, relationship register, readiness file, MEMORY files, decisions, Genie log (confirmed findings only), the guardrail pack for the chosen technology.
**Final outputs:** `blueprint/80-project-blueprint.md` and `blueprint/80-project-blueprint.html` (viewer, `kind: blueprint`, identical text).

## Built in seven parts, each reviewed

| Part | Command | Writes | Blueprint sections |
|---|---|---|---|
| 8a | `/brd-bp-architecture` | `81-architecture.md` | 3 Ecosystem overview, 6 Solution architecture, Appendix A |
| 8b | `/brd-bp-data` | `82-data.md` | 7 Shared data, 8.x data model + STTM + DQ per vertical, Appendix B |
| 8c | `/brd-bp-logic` | `83-logic-processing.md` | 8.x rules + procedure migration per vertical, 9 Processing |
| 8d | `/brd-bp-nfr` | `84-nfr-security-ops.md` | 10, 11, 12, 13 |
| 8e | `/brd-bp-quality` | `85-quality-migration.md` | 14, 15 |
| 8f | `/brd-bp-delivery` | `86-delivery-risks.md` | 16, 18, 19, Appendix C |
| 8g | `/brd-bp-assemble` | `80-project-blueprint.md` + `.html` | 1, 2, 4, 5, 17, 20, 21, 23 and the assembly |

Then the **Architect review** (`09-architect-review.md`) and the author's response, which fills section 22 and produces the final version.

Each part writes its sections into its own file and a **review page** (`reviews/blueprint-8x-r<N>.html`) that shows those sections plus the self-check, and follows `10-review-loop.md`.

## Shared rules for every part

1. **Gate:** check the needs above and that the previous part is APPROVED.
2. **Structure:** headings, numbering and IDs exactly as in `templates/blueprint-template.md`, so 8g assembles without rewriting. Per-vertical chapters are `8.1`, `8.2` … in the approved order of verticals.
3. **Guardrails:** load `guardrails/<tech>/GUARDRAILS.md`. Design to it. Every deviation is a `> [!DECISION]` with options and a recommendation, asked in chat.
4. **Depth:** every MINIMUM item for the part's sections is present or marked "Not applicable: <reason>". Long lists (mappings, procedures, tests, stories) are written **in batches, one vertical or one table at a time**, until complete. Never summarise a list to save space; put full lists in the appendices.
5. **Traceability:** every design element cites REQ / BR / REL / DEC / GQ. Anything with no requirement behind it is labelled **Proposed addition** and raised as a decision.
6. **Ask, don't guess:** design choices that are really decisions, and any requirement found to be unclear, go to the human (rounds of at most 5 questions). An unclear requirement becomes a new gap on the vertical and is flagged for a BRD re-version.
7. **Genie (if in use):** check design assumptions read-only (volumes, key uniqueness, match rates between verticals, null rates), with the verification pass and SQL check. New findings are provisional until confirmed.
8. **No code:** design only; pseudo-SQL allowed to explain logic.

## Architect's lens (apply in every part)

Write as a senior data architect who has to defend this design to a review board:
- **Contracts:** for every flow between verticals and to every consumer: schema, grain, keys, timing, owner, and what happens when it breaks or changes.
- **Failure modes:** late, missing, duplicated, out-of-order or malformed data; partial loads; reruns; schema changes upstream.
- **Scale and cost:** today's volume and three years out; what grows; what it costs; where the bottleneck will be.
- **History and correction:** how late corrections and restatements flow through every layer and every downstream vertical.
- **Ownership:** a single owner for every shared entity and every rule.
- **Alternatives:** for each major choice, what else was considered and why it lost.
- **Security:** least privilege, sensitive data protection, audit.
- **Operability:** how support will know something is wrong, and what they do next.
- **What we don't know:** every unknown stated plainly, with its risk and owner.

## Self-check (shown on every part's review page)

```
| Section | Minimum items | Present | Not applicable (reason) | Missing |
```
plus counts (for example: columns mapped n of N per vertical, procedures dispositioned n of N, rules with tests n of N, REL items with a contract n of N), proposed additions, decisions raised, guardrail exceptions, and the Genie verification table (or "not in use"). A part with any Missing item is not presented as complete; say what is missing and why.
