# Part 8e — Quality, testing, migration and cutover

**Invoke:** `/brd-bp-quality` · **Writes:** `blueprint/85-quality-migration.md` · **Sections:** 14, 15
Follow `08-blueprint.md`. Review page: `reviews/blueprint-8e-r<N>.html`.

## Work — section 14 (quality and testing)
1. Strategy by level (unit, integration, data quality, reconciliation, performance, UAT): purpose, owner, tooling, environment.
2. **Test cases per vertical,** in batches: `| TC | What is tested | BR / REQ / DQ | Type | Expected result | Test data |`. Every BR (with its edge cases from 8c) and every DQ rule has a test.
3. **Cross-vertical integration tests:** every REL with a data flow or shared key has at least one test (keys match, totals carry across, late-arrival handling).
4. Reconciliation against legacy per vertical: measures, tolerance, read-only comparison approach, sign-off owner.
5. Test data approach (masked / synthetic / subset) and privacy rules; entry and exit criteria per level.

## Work — section 15 (migration and cutover)
6. Approach (big bang / phased by vertical / parallel run) and why; **go-live order of verticals** consistent with the build order.
7. History load per vertical, and its validation.
8. Parallel run: cycles, comparison, pass criteria.
9. Cutover as a ```flow block with go / no-go criteria and owners; rollback (trigger, steps, time); decommissioning of legacy procedures and jobs.

## Minimum content (self-check)
Strategy · tests for every BR and DQ per vertical (n of N) · integration test for every flow REL (n of N) · reconciliation plan · test data · entry/exit · migration approach · go-live order · history load · parallel run criteria · cutover flow · rollback · decommissioning.
