# Part 8b — Shared data and per-vertical data design

**Invoke:** `/brd-bp-data` · **Writes:** `blueprint/82-data.md` · **Sections:** 7, the data parts of 8.x, Appendix B
Follow `08-blueprint.md`. Review page: `reviews/blueprint-8b-r<N>.html`.

## Work
1. **Section 7, shared data (first, because the verticals build on it):**
   - conformed / shared entities: owner vertical (system of record), grain, keys, history type, which verticals use them
   - shared code sets and reference data: source, refresh, owner
   - key mapping between verticals for every REL with a key: mapping rule, cardinality, no-match handling (check match rates with Genie, counts only, if in use)
   - agreed definitions of shared terms (DEC)
   - integration contracts between verticals: dataset, schema summary, grain, timing, owner, change process
2. **For each vertical, in the approved order (one batch per vertical), section 8.x:**
   - **Data model:** entity table: layer, grain, primary key, business key, history type (SCD1 / SCD2 / append / snapshot), clustering or partitioning idea per the guardrails
   - **Relationships inside the vertical:** from, to, cardinality, join keys
   - **Source-to-target mapping**, one target table at a time:
     `| Target column | Type | Nullable | Source object.column | Transformation | Rule | Status |`
     Every in-scope column mapped; unmapped columns listed with the reason. Section 8.x holds a summary per table (n of N columns, rules); the full mapping goes in Appendix B.
   - **Data quality rules:** DQ id, rule, layer, severity, action on failure, BR protected; sized with Genie (counts, null rates) if in use
3. Naming and placement follow the guardrail pack.

## Minimum content (self-check)
Shared entities with owners · code sets · key mappings for every keyed REL · agreed definitions · integration contracts · per vertical: entity table, relationships, STTM coverage n of N for every target table, DQ rules.
