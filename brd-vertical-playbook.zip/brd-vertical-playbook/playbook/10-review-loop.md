# Review loop — HTML review page, feedback, approval (every stage)

Every stage ends the same way: an HTML review page, your feedback (in the page, in chat, or both), redrafts until you are satisfied, and your typed approval.

## 1. Writing the review page (end of every stage run)

1. **Round number.** Look in `STATUS.md` for this stage and scope. First run is round 1; each redraft is the next round.
2. **Page Markdown.** Write `brd-work/<project>/reviews/<stage>[-<vertical>]-r<N>.md` using `templates/review-page-template.md`:
   - front matter: `kind: review`, title, subtitle, project, stage, vertical (if any), round, `status: Waiting for your review`, date, platform, genie (exact status from PROJECT.md), `feedback_file: feedback-<stage>[-<vertical>]-r<N>.json`, `feedback_folder: brd-work/<project>/feedback/`
   - plain English, written for someone who has not read the source files
   - every item you need the human to answer or confirm as a `###` heading starting with its id (`Q-…`, `REL-…`, `GQ-…`, `GAP-…`, `ITEM-n`), so the page gives it an answer box
3. **Page HTML.** Copy `playbook/templates/viewer.html` to `…/reviews/<same name>.html` and replace everything between the `BLUEPRINT-MARKDOWN-START` / `BLUEPRINT-MARKDOWN-END` marker comments with the page Markdown (identical text). Do not touch the CSS or JavaScript. Large pages: insert in several edits, each just before the END marker.
4. **Never overwrite an earlier round.** Each round is a new pair of files.
5. **Update `STATUS.md`**: state `PRESENTED`, round N, path of the page.
6. **Tell the human, in chat**, then stop:

```
<STAGE> — <scope>: round N ready for your review.
Open: brd-work/<project>/reviews/<file>.html
Summary: <3-5 lines>
Needs you: <n questions / items to confirm>
Genie: <in use: asked N · answered M (SQL-verified V) · pending your confirmation C>  |  <not in use>

How to respond:
  • In the page: mark sections, answer the boxes, click Export review, save the file in
    brd-work/<project>/feedback/, then type FEEDBACK FILE (or run /brd-feedback)
  • In chat: FEEDBACK: <what to change>
  • APPROVED  → I record it and stop
  • HALT      → I stop
To continue after approval, run the next command yourself.
```

## 2. Taking feedback

Feedback can arrive three ways, and can be combined:
- **Feedback file** from the page (`feedback/feedback-<stage>[-<vertical>]-r<N>.json`): `sections` (agree / change + comment) and `items` (agree / change + answer).
- **Chat**: `FEEDBACK: ...`, or direct answers to questions.
- **Both**: apply both; if they contradict each other, ask which one stands.

For every piece of feedback:
1. Apply it to the stage's **working files** (registers, decisions, memory).
2. Answers to questions become decisions (`DEC-nnn` rows) with basis "answered in review round N" and the reviewer's name.
3. "Agree" on a Genie finding marks it CONFIRMED; "Correct it" records the correction as the fact (new DEC) and re-checks with Genie, read-only.
4. "Agree" on a relationship marks it CONFIRMED; "Correct it" updates it and re-checks every place that used it.
5. Anything unclear: ask a short follow-up in chat. Do not interpret loosely.
6. Write the next round's page with a **"What changed since round N"** section listing every change and its source (file or chat).
7. Stop again.

If the feedback file is missing or cannot be read, say so and ask the human to save it again or paste the feedback in chat.

## 3. Approval

- Only a chat message containing **APPROVED** approves the stage.
- Before recording it, check the latest round:
  - unanswered questions or items marked "change" that are not yet applied → list them and ask: "Approve anyway, leaving these open?" Record the answer.
  - Genie findings still unconfirmed that this stage relies on → list them; they must be confirmed or rejected before approval (or explicitly accepted as open by the human).
- On approval: update `STATUS.md` (APPROVED, round, approver, date), update the latest page's front matter `status: Approved by <name> on <date>` and rebuild its HTML, update `MEMORY.md`.
- Then stop. Do not start the next stage.

## 4. HALT
Stop immediately. Record `HALTED` in `STATUS.md` with the round. `/brd-status` shows where to resume.

## 5. Re-opening an approved stage
If later work shows an approved stage is wrong (for example a relationship found in Clarify contradicts an approved Understanding), do not edit it silently. Say which stage and why, and ask the human to re-run that stage's command; the next run creates a new round and needs approval again. Downstream stages that relied on it are marked `NEEDS-RECHECK` in `STATUS.md`.
