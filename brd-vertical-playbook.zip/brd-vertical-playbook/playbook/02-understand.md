# Stage — Understand (per vertical)

**Invoke:** `/brd-understand <vertical>` · **Scope:** one vertical · **Needs:** Read all APPROVED
**Writes:** `verticals/<v>/10-understanding.md`, `verticals/<v>/MEMORY.md`, new REL items if found
**Review page:** `reviews/understand-<v>-r<N>.html`

## Purpose
Build a complete, sourced inventory of everything this vertical's files say, so the human can check that the agent understood it correctly before any gap analysis.

## Work
1. **Order check.** If this vertical is not next in the approved order, say so and ask whether to continue.
2. **Read both files fully,** section by section, with a checklist of sections ticked as covered.
3. **Extract into the inventory** (one row per item: id, category, statement, source `SRC-<V>-S|BT` + section, confidence CLEAR / AMBIGUOUS):
   - objectives, scope in / out
   - business requirements (`REQ-<V>-nnn`)
   - business rules and calculations (`BR-<V>-nn`)
   - entities, fields, keys
   - processes and workflows
   - **upstream inputs** (what it receives, from which system or vertical) and **downstream outputs** (who consumes what)
   - non-functional statements (volume, timing, security, audit)
   - roles and owners
   - glossary terms and how this vertical defines them
   - assumptions, constraints, dependencies
4. **Technical detail** (from the Business + Technical file): every table, view and stored procedure: purpose, inputs, outputs, tables read/written, and the **business rules each procedure actually implements** (conditions, thresholds, filters, defaults). Rules not stated anywhere in prose are marked `IMPLIED-IN-CODE`.
5. **Summary vs Business + Technical.** Note (do not resolve) where the two files differ; Gaps will register them.
6. **Relationships.** Anything that touches another vertical (shared entity, key, input from or output to another vertical, a term defined elsewhere) is linked to an existing `REL-nnn` or added as a new one in `programme/05-relationships.md`.
7. **Genie (if in use).** Verify the technical inventory read-only: objects exist, columns/types, procedure text and the tables it touches. Apply the mandatory verification pass and SQL check (`11-genie-protocol.md`). Unverified items are flagged on the page.
8. Update the vertical's `MEMORY.md`.

## Review page
- Summary figures (requirements, rules, entities, objects, procedures, relationships touched)
- "What this vertical does" in plain English
- Requirements and rules tables; procedures with the rules they implement (`IMPLIED-IN-CODE` highlighted)
- Upstream and downstream as the files describe them (gaps here are expected; they will be asked later)
- Places where Summary and Business + Technical differ (listed, not judged)
- New or updated relationships as `### REL-nnn …`
- Genie verification table, or the "not in use" line
- Coverage checklist: every section of both files read
- Anything the agent could not read or understand as `### ITEM-n …`
Then follow `10-review-loop.md`.

## Do NOT
Judge conflicts, propose fixes, or interview the human about gaps yet.
