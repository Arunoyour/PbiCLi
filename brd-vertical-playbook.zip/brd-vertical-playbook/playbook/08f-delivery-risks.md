# Part 8f — Delivery plan, risks and clarifications still needed

**Invoke:** `/brd-bp-delivery` · **Writes:** `blueprint/86-delivery-risks.md` · **Sections:** 16, 18, 19, Appendix C
Follow `08-blueprint.md`. Review page: `reviews/blueprint-8f-r<N>.html`.

## Opening questions (only what MEMORY does not answer)
Team size and roles · sprint length · target dates · backlog tool (Azure DevOps, Jira, other) and required fields · estimation unit.

## Work — section 16 (delivery plan)
1. **Epics:** one for the shared platform and shared data, one per vertical, one for cross-vertical integration and cutover. Every REQ belongs to an epic.
2. **Features** per epic, with acceptance summary.
3. **Stories, one epic at a time, backlog-ready:** "As a … I want … so that …", acceptance criteria as Given / When / Then (at least two, including a negative case where relevant), REQ / BR / REL ids, TC ids, estimate, dependencies. Section 16 keeps a summary per epic; the full list goes in Appendix C.
4. Plan by sprint or milestone that respects the build order between verticals; RACI; estimate with assumptions and confidence; dependencies on other teams and systems.

## Work — section 18 (risks and assumptions)
5. Risk table covering delivery, data, technical, cross-vertical (for example a vertical changing a shared definition) and adoption risks, **plus the risks of this design approach itself**; every risk with owner and mitigation.
6. Assumptions: every ASM from readiness and design, why we believe it, what happens if wrong.

## Work — section 19 (clarifications still needed)
7. Collect everything still open across all verticals and parts: deferred gaps, unconfirmed relationships, open decisions, unknown volumes. For each: question, options, recommendation, owner, needed-by date, impact if late. These are what the client walkthrough must close.

## Minimum content (self-check)
Epics covering every REQ (n of N) · features · stories covering every BR (n of N) with Given/When/Then and tests · plan respecting build order · RACI · estimate · dependencies · risk table incl. approach risks · assumptions · every open item listed in section 19 with owner and date.
