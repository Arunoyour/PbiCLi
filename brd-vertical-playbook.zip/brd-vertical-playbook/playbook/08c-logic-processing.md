# Part 8c — Business logic, procedure migration and processing

**Invoke:** `/brd-bp-logic` · **Writes:** `blueprint/83-logic-processing.md` · **Sections:** the logic parts of 8.x, 9
Follow `08-blueprint.md`. Review page: `reviews/blueprint-8c-r<N>.html`.

## Work — per vertical, in the approved order (section 8.x)
1. **Business rules:** every BR → where implemented (layer, object, job), logic summary (pseudo-SQL allowed), edge cases (nulls, zero, negative, duplicates, late data, boundaries), and the test it will need.
2. **Stored procedure migration:** every legacy procedure:
   `| Procedure | Disposition (replicate / redesign / retire) | New home | Rules | Evidence | Reason |`
   Retire needs evidence it is unused (Genie, read-only) or a human decision. Redesign needs a DEC for any behaviour change.
3. **Cross-vertical logic:** rules that span verticals (for example billing eligibility depends on customer status) are designed once, in the owning vertical, and referenced by the others.

## Work — section 9 (processing, across verticals)
4. End-to-end run as a ```flow block, showing where each vertical's processing waits on another's.
5. Job / pipeline table: job, verticals, tasks, trigger or schedule, dependencies (including cross-vertical), expected duration, SLA.
6. Load patterns: incremental vs full, watermarks, change capture handling, idempotency (a rerun gives the same result).
7. Restart and recovery per step; what happens downstream when an upstream vertical's load fails or is late.
8. Error handling and quarantine.
9. Reconciliation: between layers, between verticals (keys and totals across each data flow), and against legacy output (read-only comparison described, not run).

## Minimum content (self-check)
Per vertical: every BR implemented with edge cases (n of N) and every procedure dispositioned (n of N) · cross-vertical rules placed once · ```flow · job table with cross-vertical dependencies · load patterns · restart / late-upstream handling · error handling · reconciliation (layers, verticals, legacy).
