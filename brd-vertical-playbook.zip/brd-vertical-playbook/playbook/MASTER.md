# Multi-Vertical BRD Playbook — MASTER

Turns a project made of several **verticals** (modules of a larger application), each described by its own BRD files, into:
1. a confirmed understanding of every vertical and of how the verticals relate,
2. a rebuilt, versioned BRD per vertical with every gap closed or openly marked,
3. one **project blueprint** that shows how the verticals combine into one ecosystem, ready to walk the client through before implementation.

It runs in **VS Code with GitHub Copilot**, as a conversation. Every stage is invoked by you, produces an HTML review page, takes your feedback, and stops until you type **APPROVED**.

---

## 1. Inputs

- **Project name** (for example "Customer 360 BRD process").
- **Verticals**: any number. Each has a name, a short purpose, and its BRD files.
- **Files per vertical**: usually two, already in Markdown:
  - **Summary** BRD
  - **Business + Technical** BRD (requirements, rules, tables, stored procedures, views)
  The count is dynamic; extra files (appendices) are allowed and tagged at intake.
- **Technology**: Databricks **or** Fabric (one per project). Loads the matching guardrail pack from `guardrails/`.
- **Genie** (optional): if a Databricks Genie space holds the technical metadata, it is connected at intake and used read-only. If not, the project runs on the files and your answers only, and every page says so.

---

## 2. The loop (every stage, no exceptions)

```
YOU run a /brd-* command
  → AGENT loads PROJECT.md, STATUS.md, MEMORY.md (+ the vertical's MEMORY.md)
  → AGENT does the stage's work; asks you when it needs information (Genie first for technical facts, if in use)
  → AGENT writes the stage's working files and an HTML REVIEW PAGE (round 1)
  → AGENT stops and waits
YOU review the page, then either:
  • give feedback in the page (Agree / Request a change / answer boxes → Export review → save the file)
    or in chat (FEEDBACK: ...), or both
      → AGENT redrafts the working files and writes the next round's page, stops again
  • type APPROVED  → AGENT records the approval, stops
  • type HALT      → AGENT stops
YOU run the next command yourself
```

Details: `10-review-loop.md`.

### Hard rules
1. One stage per command. The agent never starts the next stage, even after approval.
2. Only a chat message from you containing **APPROVED** approves a stage. HTML "Agree" clicks are feedback, not approval.
3. The agent asks instead of guessing. Technical facts: Genie first (if in use), then you. Intent and decisions: you.
4. Every statement cites its source: vertical + file + section, a Genie finding (GQ), or a decision (DEC).
5. Conflicts are never merged silently, within a vertical or across verticals.
6. Original BRD files are never edited. New BRDs are new versions (`07-brd-rebuild.md`).
7. Nothing is overwritten: review rounds, feedback files and BRD versions are all kept.
8. Everything against Databricks is **read-only**, on every run and rerun (`11-genie-protocol.md`).
9. Secrets are never typed in chat or written to files. The Genie token is entered only in VS Code's own prompt.
10. The agent writes only inside `brd-work/<project>/`.

---

## 3. Stages and commands

| Stage | Command | Scope | Stage file | Needs approved |
|---|---|---|---|---|
| Intake | `/brd-intake` | project | `00-intake.md` | — |
| Read all | `/brd-read-all` | project | `01-read-all.md` | Intake |
| Understand | `/brd-understand <vertical>` | vertical | `02-understand.md` | Read all |
| Gaps | `/brd-gaps <vertical>` | vertical | `03-gaps.md` | Understand (same vertical) |
| Clarify | `/brd-clarify <vertical>` | vertical | `04-clarify.md` | Gaps (same vertical) |
| Relationships | `/brd-relationships` | project | `05-relationships.md` | Clarify, all verticals |
| Readiness | `/brd-readiness` | project | `06-readiness.md` | Relationships |
| BRD rebuild | `/brd-rebuild <vertical>` | vertical | `07-brd-rebuild.md` | Readiness |
| Blueprint 8a–8g | `/brd-bp-architecture` … `/brd-bp-assemble` | project | `08-blueprint.md`, `08a`–`08g` | Rebuild, all verticals |
| Architect review | `/brd-arch-review` (Architect Reviewer agent) | project | `09-architect-review.md` | Blueprint 8g |
| Respond to review | `/brd-arch-respond` | project | `09-architect-review.md` | Architect review presented |
| Apply feedback | `/brd-feedback` | current stage | `10-review-loop.md` | a stage presented |
| Status | `/brd-status` | — | — | — |

**Order of verticals.** After *Read all*, the verticals are worked through in the **approved order**: your order if you gave one at intake; otherwise the order the agent proposes from the dependencies it found (verticals others depend on go first). If your order contradicts a dependency, the agent says so and asks. It never silently reorders.

**Why read all first.** Verticals depend on each other. Reading every vertical before digging into any one means each vertical's gaps and questions already include how it relates to the others, so you answer once instead of reopening approved work.

---

## 4. Folder layout

```
.github/                      Copilot: instructions, agents, prompts
.vscode/mcp.json              Genie connection (written at intake if Genie is used; no token inside)
playbook/                     these instructions and templates (do not edit during a run)
guardrails/databricks/        pre-built guardrail pack (loaded if technology = Databricks)
guardrails/fabric/            pre-built guardrail pack (loaded if technology = Fabric)
brd-work/<project>/
  PROJECT.md                  manifest: project, technology, Genie status, verticals, files, order, BRD versions
  STATUS.md                   every stage x scope: state, round, approvals
  MEMORY.md                   project-level understanding: verticals, relationships, shared terms, decisions
  genie-config.md             only if Genie is used (no secrets)
  genie-log.md                every Genie question and answer (if used)
  programme/
    01-overview.md            read-all result
    05-relationships.md       relationship register (REL items)
    06-readiness.md           sources, consumers, checklist
  verticals/<vertical>/
    sources/                  the original Markdown BRD files (never edited)
    MEMORY.md                 this vertical's understanding
    10-understanding.md       inventory
    20-gaps.md                gap register
    30-questions.md           question rounds
    31-decisions.md           decisions log
    brd/BRD_v1.md, BRD_v1.html, BRD_v2.md ...  rebuilt BRDs (versioned)
    brd/CHANGELOG.md
  blueprint/
    81-architecture.md ... 86-delivery.md       blueprint parts
    80-project-blueprint.md / .html             final blueprint
    arch-review/findings-r1.md, responses-r1.md
  reviews/                    every review page: <stage>[-<vertical>]-r<N>.md and .html
  feedback/                   exported feedback files you save here
```

---

## 5. IDs used everywhere

`REQ-<V>-nnn` requirements (V = vertical code from PROJECT.md) · `BR-<V>-nn` business rules · `GAP-<V>-nnn` gaps · `Q-<V>-nnn` questions · `DEC-nnn` decisions (project-wide) · `REL-nnn` relationships between verticals · `GQ-nnn` Genie findings · `SRC-<V>-S` / `SRC-<V>-BT` source files (Summary / Business + Technical) · `ASM-nn` assumptions · `R-nn` risks.

---

## 6. Genie status

Recorded in `PROJECT.md` at intake and shown on **every** review page's title block:
- **In use (read-only)**: findings appear with GQ ids, are checked against their SQL, and need your confirmation.
- **Not in use (no access details provided)**: the page says technical facts come only from the BRD files and your answers.

---

## 7. Guardrails

The technology chosen at intake loads `guardrails/databricks/` or `guardrails/fabric/`. Gaps and readiness use them to ask the right questions; the blueprint is checked against the pack's checklist, and every exception is a recorded decision.
