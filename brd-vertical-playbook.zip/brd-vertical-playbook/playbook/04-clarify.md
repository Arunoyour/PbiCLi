# Stage — Clarify (per vertical)

**Invoke:** `/brd-clarify <vertical>` · **Scope:** one vertical · **Needs:** Gaps APPROVED (same vertical)
**Writes:** `verticals/<v>/30-questions.md`, `31-decisions.md`, `20-gaps.md` statuses, both `MEMORY.md` files, REL updates
**Review page:** `reviews/clarify-<v>-r<N>.html`

## Purpose
Close the gaps by asking: Genie first for facts (if in use), then the human for everything else, including **how this vertical relates to the others**.

## Work
1. **Split every open gap:**
   - fact question (object, column, procedure behaviour, data contents) → ask Genie now (if in use), read-only, with the SQL check. Answered and SQL-verified → `RESOLVED-PENDING-CONFIRM`. Otherwise → a question for the human, marked "Genie could not answer" (or, if Genie is not in use, simply a question).
   - intent or decision → question for the human.
2. **Prepare questions** (`templates/registers.md`, question entry), grouped by topic so one answer closes several gaps, ordered by severity and dependency:
   - context in one or two lines with sources
   - the question
   - options A/B/C from the candidate readings, plus "Other"
   - the agent's proposed default and why, labelled as a proposal
   - gaps it closes, and the other vertical involved for cross-vertical questions
3. **Ask** in the review page (each question a `### Q-<V>-nnn …` heading with an answer box) **and** offer to take answers in chat. At most about 8 questions per round; the rest go to the next round.
4. **Relationship questions.** For every `Inferred` or `Unknown` REL touching this vertical, ask how the verticals actually relate: which side owns the data, which definition wins, how keys map, timing between them. Never assume a relationship.
5. **Record each answer** immediately: DEC row (basis, who, when), gap status (RESOLVED / DEFERRED with owner / STILL-OPEN), REL update, both MEMORY files. Accepting a proposed default counts only if the human says so.
6. If an answer contradicts an approved stage or another vertical's decision, flag it (`10-review-loop.md` section 5).
7. Repeat rounds until no HIGH or MEDIUM gap is open, or the human says "enough for now" or defers items.

## Review page
- Round summary: gaps resolved / deferred / still open; questions this round
- Questions (`### Q-…`), each with options and the proposed default
- Relationship questions (`### REL-…`)
- Genie findings to confirm (`### GQ-…` for important ones, a table for the rest)
- Decisions recorded so far (DEC table)
- "What changed since round N"
Then follow `10-review-loop.md`.
