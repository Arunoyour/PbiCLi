# Multi-vertical BRD playbook (VS Code + GitHub Copilot)

For projects where a large application has been split into **verticals** (modules), each with its own BRD files: a **Summary** and a **Business + Technical** file, in Markdown. The playbook reads every vertical, works out how they relate, closes the gaps with you, rebuilds a versioned BRD per vertical, and produces **one project blueprint** (Markdown + styled HTML) to walk the client through before implementation.

Every step ends with an **HTML review page**. You give feedback in the page or in chat, the agent redrafts, and nothing moves on until you type **APPROVED**.

## 1. Set up (once per workspace)

1. Copy into the root of your workspace: `.github/`, `.vscode/`, `playbook/`, `guardrails/`, `brd-work/`.
2. Open Copilot Chat. In the agent picker you should see **BRD Programme** and **Architect Reviewer**; typing `/brd` lists the commands.
3. Check the agents' tools in the tool picker: read, search, edit, ask-questions (and `genie` once connected). **No terminal.** If your VS Code shows different tool names, adjust the `tools:` line in `.github/agents/*.agent.md`.
4. Have your BRD Markdown files ready (two per vertical, more allowed).

### Genie (optional, set up during intake)
If a Databricks Genie space holds the project's technical metadata, intake connects it:
- You give the **non-secret** details in chat (workspace host, space ID, metadata tables). The agent writes `.vscode/mcp.json`.
- **Never paste the token in chat.** Start the server from the Command Palette (*MCP: List Servers → genie → Start*); VS Code asks for the token in its own password box and stores it securely.
- The token must belong to a **read-only** identity: `USE CATALOG`, `USE SCHEMA`, `SELECT` on the metadata tables, `CAN RUN` on the Genie space, `CAN USE` on the SQL warehouse, nothing more. Check it with a write attempt that must fail (checklist in `playbook/templates/genie-config.md`).
- If you have no Genie access, say so: the project runs on the files and your answers, and every page says "Genie: Not in use".

## 2. Run

| # | Command | You do |
|---|---|---|
| 1 | `/brd-intake` | Answer: project name → Genie (yes/no) → verticals → files per vertical → Databricks or Fabric → order (or let the agent propose) |
| 2 | `/brd-read-all` | Check the overview of every vertical, the first relationship map and the proposed order |
| 3 | `/brd-understand <vertical>` | Check the agent understood the vertical correctly |
| 4 | `/brd-gaps <vertical>` | Check the gaps, including those at the edges with other verticals |
| 5 | `/brd-clarify <vertical>` | Answer the questions (in the page or in chat), confirm Genie findings |
|   | *repeat 3–5 for each vertical, in the approved order* | |
| 6 | `/brd-relationships` | Confirm how the verticals relate, the shared definitions and the build order |
| 7 | `/brd-readiness` | Fill in missing sources and consumers; must-haves must pass |
| 8 | `/brd-rebuild <vertical>` | Review the new BRD version for each vertical |
| 9 | `/brd-bp-architecture`, `-data`, `-logic`, `-nfr`, `-quality`, `-delivery` | Review each blueprint part |
| 10 | `/brd-bp-assemble` | Review the full project blueprint (MD + HTML) |
| 11 | `/brd-arch-review` | The Architect Reviewer challenges the blueprint (findings only) |
| 12 | `/brd-arch-respond` | The author answers every finding; you approve the final blueprint |

After **every** step: reply `FEEDBACK: …`, or give feedback in the page and save the export, or type `APPROVED` or `HALT`. Then run the next command yourself.
`/brd-status` shows where you are and the next command, at any time, in a new chat too.

## 3. Giving feedback in the HTML page

1. Open the review page the agent names (in `brd-work/<project>/reviews/`) in your browser.
2. For each section: **Agree** or **Request a change** (with a comment). For each question, relationship or Genie finding: **Agree** or **Correct it**, and type your answer in its box.
3. Type your name at the bottom, click **Export review**, and save the file into `brd-work/<project>/feedback/` (the page suggests the file name and folder).
4. In chat, type `FEEDBACK FILE` (or run `/brd-feedback`). The agent applies it and writes the next round.
5. When you are happy, type `APPROVED` in chat. Clicking "Agree" in the page is feedback, not approval.

To preview the look, open `playbook/templates/viewer.html`; it ships with an example review page.

## 4. What gets kept

- Original BRD files: never edited (`verticals/<v>/sources/`).
- Every review round: kept (`reviews/…-r1`, `-r2` …), with your feedback files (`feedback/`).
- Rebuilt BRDs: versioned (`verticals/<v>/brd/BRD_v1`, `v2` …) with a `CHANGELOG.md`; `PROJECT.md` records which version is approved. The blueprint uses only approved versions.

## 5. Guardrails

Choosing **Databricks** or **Fabric** at intake loads `guardrails/databricks/` or `guardrails/fabric/`: design rules and a pass/fail checklist. The blueprint shows the result of every check (section 17); exceptions need your decision. Baseline October 2026; replace or extend with the client's standards where they exist.

## 6. Things to know

- **The stop between stages is instruction-based.** Each command loads only its own stage and the agents have no terminal, but Copilot can still run on. If it starts another stage, type `HALT` and check `STATUS.md`. Only your `APPROVED` may approve a stage.
- **Asking questions:** the agent uses VS Code's ask-questions tool when it waits properly; otherwise it asks in chat. The review page also has answer boxes.
- **Large projects:** stages work in batches (one vertical, one table, one epic at a time) so nothing is cut short. Use `/brd-status` to resume in a new chat; the memory is in the files, not the chat.
- **Custom agents** are `.agent.md` files in `.github/agents/` (the older `.chatmode.md` format is no longer supported by VS Code).
- Everything against Databricks is **read-only**, on every run and rerun.
