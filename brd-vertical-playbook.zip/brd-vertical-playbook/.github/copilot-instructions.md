# Multi-vertical BRD playbook — standing rules for Copilot

These rules apply whenever a `/brd-*` command, the **BRD Programme** agent or the **Architect Reviewer** agent is used in this workspace. Full detail: `playbook/MASTER.md`.

## 1. One stage per command
Run only the stage the user invoked, for the vertical they named (if any). Produce its review page, then stop. Never start another stage or another vertical, even after approval. The user starts every stage.

## 2. Always load state first
Chat context is lost between sessions. Before anything else, read `brd-work/<project>/PROJECT.md`, `STATUS.md` and `MEMORY.md`, plus `verticals/<v>/MEMORY.md` for a vertical stage. If there is more than one project folder, ask which one. If none exists, the only valid command is `/brd-intake`.

## 3. Check the gate
Each stage file lists what must be APPROVED first. If it is not, say what is missing and stop.

## 4. Ask, don't guess
Missing, ambiguous or contradictory information is asked, never assumed. Technical facts: Genie first if Genie is in use, then the user. Intent, decisions and relationships between verticals: the user. Questions in rounds; record every answer before asking more.

## 5. Review page, feedback, approval (every stage)
Follow `playbook/10-review-loop.md`: write the page Markdown and the HTML page (viewer template, markers only), keep every round, accept feedback from the exported file and from chat, redraft into the next round. Only a chat message containing **APPROVED** approves a stage. HTML "Agree" clicks are feedback, not approval.

## 6. Genie
Check `PROJECT.md` for the Genie status and show it on every page. If in use: follow `playbook/11-genie-protocol.md` (read-only, SQL check, verification pass, user confirmation). If not in use: never call Genie tools and never present anything as a Genie finding.
**Never ask the user to paste a token or password in chat.** Tokens are entered only in VS Code's own prompt for the MCP server.

## 7. Read-only and safe
Everything against Databricks is read-only, on every run and rerun. No credentials or sensitive row-level data in any file. Write only inside `brd-work/<project>/` (and `.vscode/mcp.json` during intake, without secrets). Never edit files in any `sources/` folder.

## 8. Nothing is overwritten
Review rounds, feedback files and BRD versions are kept. A rebuilt BRD is always a new version.

## 9. Provenance
Every statement cites a source (`SRC-…` + section), a decision (`DEC-…`), a relationship (`REL-…`) or a Genie finding (`GQ-…`). If it has none, it does not go in.

## 10. Guardrails
Use the pack for the project's technology (`guardrails/databricks/` or `guardrails/fabric/`) in Gaps, Readiness and every blueprint part.
