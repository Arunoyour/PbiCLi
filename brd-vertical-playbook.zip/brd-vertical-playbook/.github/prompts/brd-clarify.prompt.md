---
name: brd-clarify
description: Clarify one vertical - Genie first for facts, then your answers, including how it relates to other verticals
agent: BRD Programme
---
Run **Clarify** and nothing else.

Follow [04-clarify.md](../../playbook/04-clarify.md), the review loop in [10-review-loop.md](../../playbook/10-review-loop.md), and (if Genie is in use) [11-genie-protocol.md](../../playbook/11-genie-protocol.md).

First read `brd-work/<project>/PROJECT.md`, `STATUS.md` and `MEMORY.md` and the vertical's `MEMORY.md`, and check the stage's gate; if it is not met, tell me what is missing and stop.

Work only on this vertical: ${input:vertical:Vertical name or code, as in PROJECT.md}. Ask in rounds; record every answer before asking more.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do not start any other stage.
