---
name: brd-readiness
description: Architect's readiness gate - sources, consumers, checklist
agent: BRD Programme
---
Run **Readiness** and nothing else.

Follow [06-readiness.md](../../playbook/06-readiness.md), the review loop in [10-review-loop.md](../../playbook/10-review-loop.md), and (if Genie is in use) [11-genie-protocol.md](../../playbook/11-genie-protocol.md).

First read `brd-work/<project>/PROJECT.md`, `STATUS.md` and `MEMORY.md`, and check the stage's gate; if it is not met, tell me what is missing and stop.

Ask me for every missing upstream or downstream detail. Must-have items block; should-have items become assumptions and risks.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do not start any other stage.
