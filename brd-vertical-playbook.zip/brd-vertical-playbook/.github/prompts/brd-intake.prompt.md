---
name: brd-intake
description: Intake - project name, Genie, verticals, files, technology, order
agent: BRD Programme
---
Run **Intake** and nothing else.

Follow [00-intake.md](../../playbook/00-intake.md), the review loop in [10-review-loop.md](../../playbook/10-review-loop.md), and (if Genie is in use) [11-genie-protocol.md](../../playbook/11-genie-protocol.md).

First read `brd-work/<project>/PROJECT.md`, `STATUS.md` and `MEMORY.md`, and check the stage's gate; if it is not met, tell me what is missing and stop.

This is a conversation: ask one step at a time and save each answer before the next. **Never ask me to paste a token or password in chat**; if Genie is used, VS Code asks for the token itself.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do not start any other stage.
