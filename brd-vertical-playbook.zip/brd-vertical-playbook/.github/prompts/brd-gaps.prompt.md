---
name: brd-gaps
description: Gaps for one vertical - including gaps at its edges with other verticals
agent: BRD Programme
---
Run **Gaps** and nothing else.

Follow [03-gaps.md](../../playbook/03-gaps.md), the review loop in [10-review-loop.md](../../playbook/10-review-loop.md), and (if Genie is in use) [11-genie-protocol.md](../../playbook/11-genie-protocol.md).

First read `brd-work/<project>/PROJECT.md`, `STATUS.md` and `MEMORY.md` and the vertical's `MEMORY.md`, and check the stage's gate; if it is not met, tell me what is missing and stop.

Work only on this vertical: ${input:vertical:Vertical name or code, as in PROJECT.md}. Register gaps; do not resolve them.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do not start any other stage.
