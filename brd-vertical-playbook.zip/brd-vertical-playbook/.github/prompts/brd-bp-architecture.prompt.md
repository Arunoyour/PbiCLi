---
name: brd-bp-architecture
description: Blueprint 8a - ecosystem and solution architecture
agent: BRD Programme
---
Run **Blueprint part 8a** and nothing else.

Follow [08-blueprint.md](../../playbook/08-blueprint.md), [08a-architecture.md](../../playbook/08a-architecture.md), the review loop in [10-review-loop.md](../../playbook/10-review-loop.md), and (if Genie is in use) [11-genie-protocol.md](../../playbook/11-genie-protocol.md).

First read `brd-work/<project>/PROJECT.md`, `STATUS.md` and `MEMORY.md`, and check the stage's gate; if it is not met, tell me what is missing and stop.

Use the guardrail pack for the project's technology.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do not start any other stage.
