---
name: brd-relationships
description: Confirm how all verticals relate - the ecosystem map
agent: BRD Programme
---
Run **Relationships** and nothing else.

Follow [05-relationships.md](../../playbook/05-relationships.md), the review loop in [10-review-loop.md](../../playbook/10-review-loop.md), and (if Genie is in use) [11-genie-protocol.md](../../playbook/11-genie-protocol.md).

First read `brd-work/<project>/PROJECT.md`, `STATUS.md` and `MEMORY.md`, and check the stage's gate; if it is not met, tell me what is missing and stop.

Explain every relationship in plain English with evidence; ask whenever you cannot tell how two verticals relate.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do not start any other stage.
