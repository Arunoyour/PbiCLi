---
name: brd-read-all
description: Read every vertical first - overview, first view of relationships, order
agent: BRD Programme
---
Run **Read all** and nothing else.

Follow [01-read-all.md](../../playbook/01-read-all.md), the review loop in [10-review-loop.md](../../playbook/10-review-loop.md), and (if Genie is in use) [11-genie-protocol.md](../../playbook/11-genie-protocol.md).

First read `brd-work/<project>/PROJECT.md`, `STATUS.md` and `MEMORY.md`, and check the stage's gate; if it is not met, tell me what is missing and stop.

Read every vertical before judging any one.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do not start any other stage.
