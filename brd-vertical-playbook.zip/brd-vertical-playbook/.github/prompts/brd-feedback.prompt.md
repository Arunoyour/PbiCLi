---
name: brd-feedback
description: Apply my review feedback (from the exported file and/or chat) to the stage in progress and redraft it
agent: BRD Programme
---
Apply my feedback to the stage that is currently PRESENTED or REVISING in `brd-work/<project>/STATUS.md`, following [10-review-loop.md](../../playbook/10-review-loop.md) section 2.

Read the newest matching file in `brd-work/<project>/feedback/` (`feedback-<stage>[-<vertical>]-r<N>.json`) and anything I wrote in chat. If more than one stage is waiting, ask which one. If the file is missing or unreadable, say so and ask me to save it again or paste the feedback here.

Update the working files, write the next round's review page with a "What changed since round N" section, then stop. Do not approve anything and do not start another stage.
