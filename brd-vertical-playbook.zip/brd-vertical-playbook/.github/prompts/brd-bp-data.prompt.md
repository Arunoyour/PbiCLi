---
name: brd-bp-data
description: Blueprint 8b - shared data and per-vertical data model and mapping
agent: BRD Programme
---
Run **Blueprint part 8b** and nothing else.

Follow [08-blueprint.md](../../playbook/08-blueprint.md), [08b-data.md](../../playbook/08b-data.md), the review loop in [10-review-loop.md](../../playbook/10-review-loop.md), and (if Genie is in use) [11-genie-protocol.md](../../playbook/11-genie-protocol.md).

First read `brd-work/<project>/PROJECT.md`, `STATUS.md` and `MEMORY.md`, and check the stage's gate; if it is not met, tell me what is missing and stop.

Write long lists in batches, one vertical or one table at a time, until complete.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do not start any other stage.
