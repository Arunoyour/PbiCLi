---
name: brd-arch-review
description: Independent architect review of the blueprint (findings only)
agent: Architect Reviewer
---
Run **Architect review (part A)** and nothing else.

Follow [09-architect-review.md](../../playbook/09-architect-review.md), [08-blueprint.md](../../playbook/08-blueprint.md), the review loop in [10-review-loop.md](../../playbook/10-review-loop.md), and (if Genie is in use) [11-genie-protocol.md](../../playbook/11-genie-protocol.md).

First read `brd-work/<project>/PROJECT.md`, `STATUS.md` and `MEMORY.md`, and check the stage's gate; if it is not met, tell me what is missing and stop.

You are the reviewer: write findings only; do not edit the blueprint.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do not start any other stage.
