---
name: brd-status
description: Where are we - every stage and vertical, open questions, Genie status, next command. Changes nothing.
agent: BRD Programme
tools: ['search/codebase', 'search', 'read']
---
Read `brd-work/<project>/PROJECT.md`, `STATUS.md` and `MEMORY.md` (ask which project if there are several) and tell me briefly:

1. Project, technology, Genie status
2. Each project stage and each vertical's stages: state, round, approved by
3. BRD versions per vertical (latest and approved)
4. Open counters: unanswered questions, unconfirmed Genie findings, unconfirmed relationships, HIGH gaps open
5. The next command to run (and for which vertical, in the approved order)

Change nothing. Run no stage. If no project exists yet, say the first command is `/brd-intake`.
