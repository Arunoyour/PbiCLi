---
name: brd-bp-assemble
description: Blueprint 8g - assemble the project blueprint as MD and HTML
agent: BRD Programme
---
Run **Blueprint part 8g** and nothing else.

Follow [08-blueprint.md](../../playbook/08-blueprint.md), [08g-assemble.md](../../playbook/08g-assemble.md), the review loop in [10-review-loop.md](../../playbook/10-review-loop.md), and (if Genie is in use) [11-genie-protocol.md](../../playbook/11-genie-protocol.md).

First read `brd-work/<project>/PROJECT.md`, `STATUS.md` and `MEMORY.md`, and check the stage's gate; if it is not met, tell me what is missing and stop.

Produce both `blueprint/80-project-blueprint.md` and `blueprint/80-project-blueprint.html` with identical text. Do not shorten anything during assembly.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do not start any other stage.
