# Guardrail checklist — Microsoft Fabric

Used in blueprint section 17. Each item: **Pass**, **Exception** (with a DEC explaining why and the risk), or **Fail** (must be fixed before the blueprint is presented). *Must* items cannot be Exception without the human's explicit decision.

| ID | Level | Check | Where evidenced |
|---|---|---|---|
| GR-FAB-01 | Must | Workspace structure defined: environments separated; layers / verticals organised; domains used | 6 |
| GR-FAB-02 | Must | Medallion layers as lakehouses (gold lakehouse or warehouse, choice justified); consumers read gold only | 6 |
| GR-FAB-03 | Must | Cross-vertical flows use silver/gold contracts, not another vertical's bronze | 7 |
| GR-FAB-04 | Must | Shared / conformed data has one owner and is reused through OneLake shortcuts, not copied | 7 |
| GR-FAB-05 | Must | Every table has documented grain, primary key, business key, history type | 8.x |
| GR-FAB-06 | Must | History handled idempotently (MERGE / T-SQL) with SCD columns defined | 8.x |
| GR-FAB-07 | Must | Every load idempotent; rerun procedure defined | 9 |
| GR-FAB-08 | Must | Every BR implemented in exactly one place, traced to its BR id | 8.x |
| GR-FAB-09 | Must | DQ checks for every BRD rule on silver; action per rule; no silent drops for HIGH rules | 8.x |
| GR-FAB-10 | Must | Upstream schema-change handling defined | 9 |
| GR-FAB-11 | Must | Workspace roles on least privilege; consumers are not Contributors | 11 |
| GR-FAB-12 | Must | OneLake security / warehouse security for row- and column-level access where needed | 11 |
| GR-FAB-13 | Must | Workspace identity or service principals for pipelines and connections | 11 |
| GR-FAB-14 | Must | Secrets only in Key Vault–backed connections | 11 |
| GR-FAB-15 | Must | Sensitive data classified; sensitivity labels applied | 11 |
| GR-FAB-16 | Must | Retention and deletion rules implemented through all layers | 11 |
| GR-FAB-17 | Must | Separate dev / test / prod workspaces; production isolated | 13 |
| GR-FAB-18 | Must | Git integration and deployment pipelines for promotion | 13 |
| GR-FAB-19 | Must | Failure alerts; freshness checks per source and per vertical feed | 12 |
| GR-FAB-20 | Must | Reconciliation between layers, between verticals, and against legacy | 9, 14 |
| GR-FAB-21 | Must | Only generally available features in production, or a recorded decision per preview feature | 6 |
| GR-FAB-22 | Should | Pipelines for copies; mirroring considered for supported sources; Eventstreams for streaming | 9 |
| GR-FAB-23 | Should | Spark notebooks for heavy logic; Dataflows Gen2 only for light shaping | 9 |
| GR-FAB-24 | Should | Gold as star schema with conformed dimensions across verticals, Direct Lake–friendly | 7, 8.x |
| GR-FAB-25 | Should | Money as DECIMAL; timestamps in UTC | 8.x |
| GR-FAB-26 | Should | Table maintenance (OPTIMIZE, VACUUM, V-Order) scheduled | 12 |
| GR-FAB-27 | Should | Capacity sized per workload with Capacity Metrics monitoring; throttling plan | 10, 12 |
| GR-FAB-28 | Should | Non-production capacity paused or scaled when idle; cost estimate per environment | 10 |
| GR-FAB-29 | Should | Runbooks for late source, schema change, DQ failure, rerun, throttling, late dependent vertical | 12 |
| GR-FAB-30 | Should | Environment settings via deployment rules / variable libraries, not edited by hand | 13 |
| GR-FAB-31 | Should | CI tests: notebook logic, DQ, reconciliation on test data | 13, 14 |
