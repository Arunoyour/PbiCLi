# Guardrails — Microsoft Fabric

Loaded when the project's technology is **Fabric**. Used by Gaps (what the BRD must tell us), Readiness (business inputs needed), every blueprint part (design rules), and the blueprint's compliance section (`CHECKLIST.md`).

> Pack baseline: October 2026. Fabric changes quickly; features move from preview to general availability often (OneLake security, for example, is now generally available). Use only generally available features for production designs unless the client accepts a preview feature as a recorded decision. Where the client has its own standards, they win; record the difference as a decision.

## 1. What the BRD must tell us (missing → `GRD` gap)
- Grain and business key of every entity; history needed (current only / full history / point-in-time)
- Source systems: format, frequency, change capture, deletes, late data; whether the source can be **mirrored**
- Consumers: Power BI (Direct Lake / import), SQL endpoint, files, other workspaces; freshness, history, security
- Data classification of every sensitive field; sensitivity labels required
- Retention and deletion rules
- Owner of each entity (system of record) and each business rule
- Expected volumes and growth, and the Fabric capacity (F SKU) available or budgeted

## 2. Platform structure
- **Workspaces** separate environments (dev / test / prod) and, per the client's standard, layers or domains. Use Fabric **domains** to group a vertical's workspaces.
- Medallion as items: a **lakehouse per layer** (bronze, silver) and gold as a lakehouse or a **warehouse** depending on consumers (warehouse when T-SQL write patterns, multi-table transactions or SQL-first teams require it).
- Use **lakehouse schemas** to organise tables by vertical inside a layer, if enabled in the client's tenant; otherwise one lakehouse per vertical per layer.
- **OneLake shortcuts** to reuse shared / conformed data across workspaces instead of copying it. One owning workspace per shared entity.
- Names: consistent pattern showing environment, layer and vertical (for example `prod_silver_customer_master`).

## 3. Medallion layers
| Layer | Holds | Rules |
|---|---|---|
| Bronze lakehouse | Files and tables as received | Append-only; load metadata (source, load time, batch id); no business logic |
| Silver lakehouse | Cleansed, conformed, de-duplicated Delta tables | Types fixed; keys enforced; history applied; DQ checks; one row per business key per version |
| Gold lakehouse / warehouse | Business-ready star schemas and aggregates | Modelled for consumers; contracts documented; feeds Power BI semantic models |

- Each layer reads only from the layer below (or shared conformed data through shortcuts). Consumers read gold.
- Cross-vertical flows go through silver or gold contracts, never another vertical's bronze.

## 4. Modelling
- Every table documents grain, primary key, business key and history type.
- SCD type 2 implemented in Spark notebooks (Delta `MERGE`) or warehouse T-SQL, idempotently, with effective dates and current flag.
- Gold for Power BI: **star schema**, conformed dimensions across verticals, designed for **Direct Lake** semantic models where possible (V-Order enabled, sensible file sizes, avoid features that force fallback to DirectQuery).
- Money as `DECIMAL`; timestamps in UTC.
- Partition only large tables on low-cardinality columns; keep files well-sized with table maintenance.

## 5. Ingestion and processing
- Bulk and scheduled copies: **Data Factory pipelines** (Copy activity). Supported operational databases: consider **mirroring**. Streaming: **Eventstreams** into a lakehouse or eventhouse.
- Transformations: **Spark notebooks** for heavy or complex logic; **Dataflows Gen2** only for light, low-volume shaping; warehouse T-SQL for SQL-first gold logic.
- Orchestration: pipelines calling notebooks / dataflows / stored procedures with dependencies that express cross-vertical order.
- Every load **idempotent** (MERGE on business keys, watermarks, batch ids); rerun gives the same result.
- Schema changes upstream: detected, alerted, handled by an explicit rule.

## 6. Data quality
- Checks in notebooks or warehouse procedures for every BRD rule on silver: keys not null, valid ranges, referential checks to shared data.
- Action per rule: warn, quarantine (quarantine table with reason), or fail the pipeline. HIGH-severity rules never silently drop data.
- DQ results stored per run and monitored.

## 7. Security
- **Workspace roles** (Admin, Member, Contributor, Viewer) on least privilege; production workspaces have very few Admins/Members; consumers get Viewer or item-level access, not Contributor.
- **OneLake security** data access roles for table / folder access, row-level and column-level security on lakehouse data; **warehouse / SQL endpoint** security (RLS, CLS, dynamic data masking) for SQL consumers. Semantic models apply their own RLS for report users.
- **Sensitivity labels** (Microsoft Purview) on items holding sensitive data.
- Pipelines and connections authenticate with **workspace identity or service principals**; secrets in Azure Key Vault–backed connections, never in notebooks or pipeline parameters.
- Audit via Fabric / Purview audit logs; lineage via the workspace lineage view and Purview.
- Retention: Delta `VACUUM` aligned with recovery needs and deletion rules; deletions propagate through every layer.

## 8. Operations
- **Monitoring hub** for runs; failure alerts on pipelines; freshness checks per source and per vertical feed (Activator alerts where suitable).
- **Capacity Metrics app** to watch capacity use and throttling; plan heavy jobs around peak report usage.
- Table maintenance (`OPTIMIZE`, `VACUUM`, V-Order) scheduled for lakehouse tables.
- Runbooks for: source late or missing, schema change, DQ failure, pipeline failure and rerun, capacity throttling, a dependent vertical's data late.

## 9. Environments and CI/CD
- Separate dev / test / prod workspaces, ideally on separate capacities (or at least prod isolated).
- **Git integration** (Azure DevOps or GitHub) for workspace items; promotion with **deployment pipelines** and deployment rules / variable libraries for environment-specific settings.
- No manual changes in production; connections and parameters per environment.
- Tests: notebook logic tests, DQ checks, reconciliation on test data.

## 10. Cost (capacity)
- Size the **F SKU** from expected workloads (engineering, warehouse, Power BI); separate or isolate production capacity.
- Pause / scale non-production capacities when idle; understand smoothing and throttling behaviour before sizing.
- Estimate capacity cost per environment in the blueprint, with assumptions; tag workspaces by project and vertical for chargeback.

## 11. Anti-patterns (each one found in a design is a finding)
One workspace for everything · Contributor access for consumers · copying shared master data into every vertical instead of shortcuts · Dataflows Gen2 for heavy transformations · non-idempotent loads · consumers reading bronze · credentials in notebooks · personal accounts running production pipelines · no Git integration · preview features in production without a decision · ignoring capacity throttling · float for money · undocumented grain.
