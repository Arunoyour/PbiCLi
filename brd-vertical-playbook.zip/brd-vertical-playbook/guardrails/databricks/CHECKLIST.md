# Guardrail checklist — Databricks

Used in blueprint section 17. Each item: **Pass**, **Exception** (with a DEC explaining why and the risk), or **Fail** (must be fixed before the blueprint is presented). *Must* items cannot be Exception without the human's explicit decision.

| ID | Level | Check | Where evidenced |
|---|---|---|---|
| GR-DBX-01 | Must | All objects in Unity Catalog; none in hive_metastore; no mounts or DBFS root | 6 |
| GR-DBX-02 | Must | Catalog / schema convention defined and applied to every vertical and environment | 6 |
| GR-DBX-03 | Must | Medallion layers defined with rules; consumers read gold (or approved views) only | 6 |
| GR-DBX-04 | Must | Cross-vertical flows use silver/gold contracts, not another vertical's bronze | 7 |
| GR-DBX-05 | Must | Shared / conformed data has one owner and one copy | 7 |
| GR-DBX-06 | Must | Every table has documented grain, primary key, business key, history type | 8.x |
| GR-DBX-07 | Must | History handled with declarative CDC flows or idempotent MERGE; SCD columns defined | 8.x |
| GR-DBX-08 | Must | Every load idempotent; rerun procedure defined | 9 |
| GR-DBX-09 | Must | Every BR implemented in exactly one place, traced to its BR id | 8.x |
| GR-DBX-10 | Must | DQ expectations for every BRD rule on silver; action per rule; no silent drops for HIGH rules | 8.x |
| GR-DBX-11 | Must | Upstream schema-change handling defined (evolve / rescue / fail) | 9 |
| GR-DBX-12 | Must | Grants to groups, least privilege per layer | 11 |
| GR-DBX-13 | Must | Jobs run as service principals | 11 |
| GR-DBX-14 | Must | Secrets only in secret scopes / key vault | 11 |
| GR-DBX-15 | Must | Sensitive columns classified and protected (masks / row filters) | 11 |
| GR-DBX-16 | Must | Retention and deletion rules implemented through all layers | 11 |
| GR-DBX-17 | Must | Separate dev / test / prod with separate permissions | 13 |
| GR-DBX-18 | Must | Code in Git; deployment via Declarative Automation Bundles from CI/CD | 13 |
| GR-DBX-19 | Must | Failure and SLA notifications; freshness checks per source and per vertical feed | 12 |
| GR-DBX-20 | Must | Reconciliation between layers, between verticals, and against legacy | 9, 14 |
| GR-DBX-21 | Should | Auto Loader for files; managed connectors where available | 9 |
| GR-DBX-22 | Should | Lakeflow Spark Declarative Pipelines where logic fits; Lakeflow Jobs for orchestration | 9 |
| GR-DBX-23 | Should | Change Data Feed on silver tables feeding incremental loads | 8.x, 9 |
| GR-DBX-24 | Should | Liquid clustering for new tables; partitioning justified where used | 8.x |
| GR-DBX-25 | Should | Money as DECIMAL; timestamps in UTC | 8.x |
| GR-DBX-26 | Should | Gold for reporting as star schema with conformed dimensions across verticals | 7, 8.x |
| GR-DBX-27 | Should | Serverless or job compute for scheduled work; cluster policies; auto-termination | 10 |
| GR-DBX-28 | Should | Compute and jobs tagged by project and vertical; cost estimate per vertical | 10 |
| GR-DBX-29 | Should | Predictive optimization or scheduled OPTIMIZE / VACUUM | 12 |
| GR-DBX-30 | Should | Runbooks for late source, schema change, DQ failure, rerun, late dependent vertical | 12 |
| GR-DBX-31 | Should | Table and column comments in Unity Catalog from the STTM | 8.x |
| GR-DBX-32 | Should | CI tests: transformation unit tests, DQ, reconciliation on test data | 13, 14 |
