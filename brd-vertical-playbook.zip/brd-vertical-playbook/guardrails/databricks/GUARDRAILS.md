# Guardrails — Databricks

Loaded when the project's technology is **Databricks**. Used by Gaps (what the BRD must tell us), Readiness (business inputs needed), every blueprint part (design rules), and the blueprint's compliance section (`CHECKLIST.md`).

> Pack baseline: October 2026. Product names change often (for example *Delta Live Tables* is now **Lakeflow Spark Declarative Pipelines**, *Workflows* is **Lakeflow Jobs**, *Databricks Asset Bundles* is **Declarative Automation Bundles**). Where the client has its own standards, they win; record the difference as a decision. Verify feature availability for the client's cloud and region before relying on it.

## 1. What the BRD must tell us (missing → `GRD` gap)
- Grain and business key of every entity; history needed (current only / full history / point-in-time)
- Source systems: format, frequency, change capture (full / incremental / CDC), deletes, late data
- Consumers: interface (table, view, SQL warehouse, API, Power BI), freshness, history, security
- Data classification of every sensitive field (personal, financial, confidential)
- Retention and deletion rules (including right-to-erasure if applicable)
- Who owns each entity (system of record) and each business rule
- Expected volumes and growth (estimates are acceptable; unknown → assumption + risk)

## 2. Platform structure (Unity Catalog)
- Everything is governed by **Unity Catalog**: three-level names `catalog.schema.object`. No new objects in `hive_metastore`, no DBFS root storage, no mounts.
- **Catalogs** separate environments (for example `dev_`, `test_`, `prod_` prefixes) or business domains, per the client's standard; **schemas** separate layers and verticals (for example `bronze_customer_master`, `silver_customer_master`, `gold_shared`). Choose one convention and apply it to every vertical.
- **Managed tables** by default; external locations and volumes only for landing raw files and for data other systems must read in place.
- Shared / conformed data lives in its own schema owned by the system-of-record vertical, not copied into each vertical.
- Names: lowercase, snake_case, no spaces, singular or plural consistently; layer and vertical visible in the schema name.

## 3. Medallion layers
| Layer | Holds | Rules |
|---|---|---|
| Landing (volume) | Files as delivered | Immutable; folder per source and load date; retention set |
| Bronze | Source data as received, in Delta | Append-only; add load metadata (source file, load time, batch id); no business logic; schema drift captured, not dropped |
| Silver | Cleansed, conformed, de-duplicated | Types fixed; keys enforced; history (SCD) applied; DQ expectations; joins to reference data; one row per business key per version |
| Gold | Business-ready, modelled for consumers | Star schemas / aggregates / data products per consumer need; documented contracts; no raw columns |

- Each layer reads only from the layer below (or shared conformed data). Consumers read gold (or approved silver views), never bronze.
- Cross-vertical data flows go through silver or gold contracts, never through another vertical's bronze.

## 4. Modelling
- Every table documents grain, primary key, business key and history type (table and column comments in Unity Catalog).
- History: SCD type 2 for dimensions that need history, using the declarative CDC flows (`AUTO CDC` / `APPLY CHANGES`) or an idempotent `MERGE`; effective-from / effective-to / is-current columns.
- Surrogate keys only where needed (stable across reloads; never row numbers that change on rerun).
- Money as `DECIMAL(p,s)`, never float; timestamps stored in UTC with the source time zone recorded if relevant.
- Prefer **liquid clustering** for new tables over hand-tuned partitioning; partition only very large tables on a low-cardinality column.
- Gold for Power BI: star schema, conformed dimensions shared across verticals, measures defined once.

## 5. Ingestion and processing
- Files: **Auto Loader** (incremental, with schema evolution and a rescue column). Databases / SaaS: managed connectors (Lakeflow Connect) where available; otherwise a controlled extract.
- Pipelines: **Lakeflow Spark Declarative Pipelines** for bronze → silver → gold where possible (expectations, lineage, CDC flows); notebooks or SQL tasks for logic that does not fit.
- Orchestration: **Lakeflow Jobs**, with task dependencies expressing cross-vertical order; no chains of manually triggered notebooks.
- Every load is **idempotent**: a rerun gives the same result (MERGE on business keys, watermarks, batch ids). No `INSERT` that duplicates on rerun.
- Change Data Feed on silver tables that feed incremental downstream processing.
- Schema changes upstream: detected, alerted, and handled by an explicit rule (evolve / rescue / fail), never silently dropped.

## 6. Data quality
- Expectations on every silver table for the BRD's rules: not null keys, valid ranges, referential checks to shared data.
- Action per rule: warn (keep and count), drop, quarantine (keep in a quarantine table with reason), or fail the pipeline. HIGH-severity business rules fail or quarantine; never silently drop.
- DQ results are stored and monitored (counts per rule per run).

## 7. Security
- Grants to **groups**, never to individuals; least privilege per layer (engineers write bronze/silver, consumers read gold).
- Jobs and pipelines run as **service principals**, not personal accounts.
- Secrets in secret scopes (backed by the cloud key vault); never in notebooks, code, job parameters or config files.
- Sensitive columns: **column masks**; restricted rows: **row filters**; tag sensitive columns with governed tags / classifications.
- Audit and lineage from Unity Catalog and **system tables**; access to production data is logged and reviewed.
- Retention: Delta `VACUUM` retention aligned with recovery needs and deletion rules; deletion requests propagate through every layer.

## 8. Operations
- Job and pipeline notifications on failure and on SLA breach; freshness checks per source and per vertical feed.
- Monitoring from system tables (job runs, billing, audit) and DQ results; a dashboard per environment.
- Table maintenance: predictive optimization where available, otherwise scheduled `OPTIMIZE` / `VACUUM`.
- Runbooks for: source late or missing, schema change, DQ failure, job failure and rerun, a dependent vertical's data late.

## 9. Environments and CI/CD
- Separate dev / test / prod (separate workspaces, or at least separate catalogs with separate permissions).
- Code in Git (Databricks Git folders); deploy with **Declarative Automation Bundles** (formerly Databricks Asset Bundles) from CI/CD, using a service principal.
- No manual changes in production; configuration per environment through bundle variables.
- Tests in CI: unit tests for transformation logic, DQ expectations, a reconciliation test on test data.

## 10. Cost
- Serverless compute for jobs, pipelines and SQL where available and cost-effective; otherwise job clusters (never all-purpose clusters for scheduled work).
- Cluster policies limit size and type; auto-termination on interactive compute.
- Tag all compute and jobs with project and vertical for cost reporting; review cost from system tables.
- Estimate monthly cost per vertical and environment in the blueprint, with assumptions.

## 11. Anti-patterns (each one found in a design is a finding)
New objects in `hive_metastore` · mounts or DBFS root storage · credentials in code · personal accounts running production jobs · all-purpose clusters for scheduled jobs · non-idempotent loads · consumers reading bronze · each vertical keeping its own copy of shared master data · business logic in bronze · silently dropping bad records · `SELECT *` in gold contracts · `collect()` of large data to the driver · float for money · undocumented grain.
