Project folders are created here by /brd-intake (brd-work/<project>/).
