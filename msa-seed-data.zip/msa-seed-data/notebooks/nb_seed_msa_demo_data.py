# =============================================================================
# NOTEBOOK:      nb_seed_msa_demo_data
# PURPOSE:       Load all MSA demo data into Databricks Unity Catalog tables.
#                Run this ONCE in the DEV environment before the demo.
# TARGET:        finance_dev catalog (or pass p_catalog as widget)
# OWNER:         data-team
# =============================================================================

# ── CELL 1: PARAMETERS ────────────────────────────────────────────────────────
dbutils.widgets.text("p_catalog", "finance_dev")
CATALOG = dbutils.widgets.get("p_catalog")
print(f"Seeding demo data into catalog: {CATALOG}")

# ── CELL 2: CREATE SCHEMAS ────────────────────────────────────────────────────
for schema in ["bronze","silver","gold","ref","control"]:
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.{schema}")
    print(f"  ✓ Schema: {CATALOG}.{schema}")

# ── CELL 3: CONTROL — MSA BASE VOLUMES (1997 legal constant) ─────────────────
spark.sql(f"DROP TABLE IF EXISTS {CATALOG}.control.msa_base_volumes")
spark.sql(f"""
    CREATE TABLE {CATALOG}.control.msa_base_volumes (
        year                 INTEGER     NOT NULL,
        units                BIGINT      NOT NULL COMMENT 'Total OPM cigarette equivalent units — 1997 calendar year',
        source_description   STRING      NOT NULL,
        loaded_at            TIMESTAMP   NOT NULL,
        loaded_by            STRING      NOT NULL,
        is_read_only         BOOLEAN     NOT NULL DEFAULT TRUE
    )
    USING DELTA
    TBLPROPERTIES (
        'layer'       = 'control',
        'description' = 'MSA 1997 base year volume — legal constant per BRD A-001. READ ONLY.',
        'owner'       = 'finance-data-team'
    )
""")
spark.sql(f"""
    INSERT INTO {CATALOG}.control.msa_base_volumes VALUES (
        1997,
        667754000000,
        'MSA legal constant — confirmed by Robert Chen (Legal) 2025-01-15. MSA Section IX(d)(1).',
        TIMESTAMP '2025-01-15T10:00:00.000Z',
        'marcus.webb@company.com',
        TRUE
    )
""")
# Deny modification to all except admin
spark.sql(f"DENY MODIFY ON TABLE {CATALOG}.control.msa_base_volumes TO `analysts`")
print(f"✓ control.msa_base_volumes — 1997 base = 667,754,000,000 units (READ ONLY)")

# ── CELL 4: REF — MSA STATE ALLOCATIONS ──────────────────────────────────────
spark.sql(f"DROP TABLE IF EXISTS {CATALOG}.ref.msa_state_allocations")
spark.sql(f"""
    CREATE TABLE {CATALOG}.ref.msa_state_allocations (
        state_code       STRING         NOT NULL,
        state_name       STRING         NOT NULL,
        allocation_pct   DECIMAL(14,10) NOT NULL COMMENT 'Legal constant from MSA Exhibit A (1998). Never recalculate.',
        is_settling_state BOOLEAN       NOT NULL,
        source           STRING         NOT NULL
    )
    USING DELTA
    TBLPROPERTIES (
        'layer'       = 'reference',
        'description' = 'MSA state payment allocation percentages — legal constants from MSA Exhibit A 1998.',
        'owner'       = 'finance-data-team'
    )
""")

# 46 settling states with allocation percentages (from MSA Exhibit A)
state_allocations = [
    ("AL","Alabama",2.0177308614),("AK","Alaska",0.3517122837),
    ("AZ","Arizona",2.1795102856),("AR","Arkansas",1.1542083314),
    ("CA","California",12.7617439285),("CO","Colorado",1.5823021941),
    ("CT","Connecticut",1.5402051234),("DE","Delaware",0.3929213847),
    ("DC","District of Columbia",0.5133028471),("HI","Hawaii",0.5312043812),
    ("ID","Idaho",0.5034038291),("IL","Illinois",5.7393417283),
    ("IN","Indiana",2.5688192304),("IA","Iowa",1.3285098231),
    ("KS","Kansas",1.1628088471),("KY","Kentucky",1.8837143821),
    ("LA","Louisiana",1.9927152384),("ME","Maine",0.5991045729),
    ("MD","Maryland",2.4826189743),("MA","Massachusetts",3.2458248312),
    ("MI","Michigan",4.3528332841),("MN","Minnesota",2.2048168573),
    ("MS","Mississippi",1.2991099214),("MO","Missouri",2.6433201748),
    ("MT","Montana",0.4088031284),("NE","Nebraska",0.7783059421),
    ("NV","Nevada",0.9543072839),("NH","New Hampshire",0.5823044472),
    ("NJ","New Jersey",3.7614287394),("NM","New Mexico",0.7292055712),
    ("NY","New York",9.5163727813),("NC","North Carolina",2.1822166721),
    ("ND","North Dakota",0.2985022814),("OH","Ohio",4.7556363192),
    ("OK","Oklahoma",1.3782105314),("OR","Oregon",1.4285109128),
    ("PA","Pennsylvania",5.1785395728),("RI","Rhode Island",0.4765036384),
    ("SC","South Carolina",1.4228108714),("SD","South Dakota",0.3212024591),
    ("TN","Tennessee",2.3518179814),("UT","Utah",0.7832059817),
    ("VT","Vermont",0.2784021284),("VA","Virginia",2.9623226492),
    ("WA","Washington",2.5793197148),("WV","West Virginia",0.7912060471),
    ("WI","Wisconsin",2.2477171894),("WY","Wyoming",0.2122016234),
]

rows_sql = ",\n".join([f"('{s[0]}','{s[1]}',{s[2]},TRUE,'MSA Exhibit A (1998) — legal constant')"
                        for s in state_allocations])
spark.sql(f"INSERT INTO {CATALOG}.ref.msa_state_allocations VALUES {rows_sql}")

# Validate: sum must equal 100.0000000000
total_check = spark.sql(f"SELECT SUM(allocation_pct) as total FROM {CATALOG}.ref.msa_state_allocations").collect()[0][0]
print(f"✓ ref.msa_state_allocations — 48 rows | SUM(allocation_pct) = {total_check:.10f}")
assert abs(float(total_check) - 100.0) < 0.0001, "ALLOCATION SUM != 100 — ABORT"

# ── CELL 5: SILVER — NPM ADJUSTMENT RATES ────────────────────────────────────
spark.sql(f"DROP TABLE IF EXISTS {CATALOG}.silver.npm_adjustment_rates")
spark.sql(f"""
    CREATE TABLE {CATALOG}.silver.npm_adjustment_rates (
        state_code                  STRING       NOT NULL,
        state_name                  STRING       NOT NULL,
        effective_year              INTEGER      NOT NULL,
        npm_adjustment_rate_pct     DOUBLE       NOT NULL COMMENT 'Percentage (e.g. 8.25 = 8.25%)',
        npm_adjustment_rate_decimal DOUBLE       NOT NULL COMMENT 'Decimal form (e.g. 0.082500)',
        is_npm_disputed             BOOLEAN      NOT NULL,
        source                      STRING,
        loaded_at                   TIMESTAMP,
        note                        STRING
    )
    USING DELTA
    TBLPROPERTIES ('layer'='silver','owner'='finance-data-team')
""")

npm_data = [
    ("AZ","Arizona",8.25,False,""), ("ID","Idaho",12.5,False,""),
    ("MO","Missouri",15.75,False,""), ("OK","Oklahoma",9.0,False,""),
    ("MI","Michigan",0.0,True,"DISPUTED: State claims diligent enforcement. Arbitration pending Case #2025-MSA-MI-001. Payment HELD per Robert Chen."),
]
# Insert the 4 states with NPM reductions
for sc,sn,rate,disp,note in npm_data:
    spark.sql(f"""
        INSERT INTO {CATALOG}.silver.npm_adjustment_rates VALUES
        ('{sc}','{sn}',2025,{rate},{round(rate/100,6)},{str(disp).lower()},
         'Legal Counsel — Annual NPM Rate Letter FY2025',
         TIMESTAMP '2025-01-20T09:00:00.000Z', '{note}')
    """)
# All other settling states: 0% NPM adjustment
zero_states = [s for s in state_allocations if s[0] not in [x[0] for x in npm_data]]
for s in zero_states:
    spark.sql(f"""
        INSERT INTO {CATALOG}.silver.npm_adjustment_rates VALUES
        ('{s[0]}','{s[1]}',2025,0.0,0.0,false,
         'Legal Counsel — Annual NPM Rate Letter FY2025',
         TIMESTAMP '2025-01-20T09:00:00.000Z', '')
    """)

disp_count = spark.sql(f"SELECT COUNT(*) FROM {CATALOG}.silver.npm_adjustment_rates WHERE is_npm_disputed=TRUE").collect()[0][0]
print(f"✓ silver.npm_adjustment_rates — {len(state_allocations)+len(npm_data)} rows | Disputed states: {disp_count} (Michigan)")

# ── CELL 6: CONTROL — PAYMENT SCHEDULE ───────────────────────────────────────
spark.sql(f"DROP TABLE IF EXISTS {CATALOG}.control.msa_payment_schedule")
spark.sql(f"""
    CREATE TABLE {CATALOG}.control.msa_payment_schedule (
        calculation_year              INTEGER        NOT NULL,
        aggregate_base_payment_usd    DECIMAL(18,2)  NOT NULL,
        aggregate_base_payment_source STRING,
        calculation_status            STRING         NOT NULL,
        auditor_file_status           STRING         NOT NULL,
        auditor_file_received_at      TIMESTAMP,
        reconciliation_status         STRING         NOT NULL,
        reconciliation_cleared_at     TIMESTAMP,
        calculation_completed_at      TIMESTAMP,
        days_from_auditor_to_calc     INTEGER,
        payment_due_date              DATE           NOT NULL,
        is_submitted                  BOOLEAN        NOT NULL DEFAULT FALSE,
        lock_status                   STRING         NOT NULL DEFAULT 'ACTIVE',
        submitted_at                  TIMESTAMP,
        total_net_payment_ready_usd   DECIMAL(18,4),
        total_disputed_gross_usd      DECIMAL(18,4),
        states_disputed_count         INTEGER,
        states_disputed_list          STRING,
        states_with_npm_reduction     STRING,
        notes                         STRING
    )
    USING DELTA
    TBLPROPERTIES ('layer'='control','owner'='finance-data-team')
""")
spark.sql(f"""
    INSERT INTO {CATALOG}.control.msa_payment_schedule VALUES (
        2025, 4150000000.00,
        'MSA Settlement Office annual notification — received 2025-01-10',
        'CALCULATION_COMPLETE', 'APPROVED',
        TIMESTAMP '2025-02-28T14:30:00.000Z', 'CLEARED',
        TIMESTAMP '2025-03-02T16:45:00.000Z',
        TIMESTAMP '2025-03-05T09:14:22.000Z', 5,
        DATE '2026-04-15', FALSE, 'ACTIVE', NULL,
        1305168998.1214, 59009985.1620, 1, 'MI',
        'AZ (8.25%), ID (12.5%), MO (15.75%), OK (9.0%)',
        'FY2025 complete. Pending Patricia Lawson approval. Michigan disputed — HELD.'
    )
""")
print(f"✓ control.msa_payment_schedule — FY2025 status: CALCULATION_COMPLETE | Due: 2026-04-15")

# ── CELL 7: GOLD — RMS CALCULATION ───────────────────────────────────────────
spark.sql(f"DROP TABLE IF EXISTS {CATALOG}.gold.msa_rms_calculation")
spark.sql(f"""
    CREATE TABLE {CATALOG}.gold.msa_rms_calculation (
        calculation_year                         INTEGER        NOT NULL,
        version_id                               STRING         NOT NULL,
        is_submitted                             BOOLEAN        NOT NULL DEFAULT FALSE,
        company_cigarette_units                  BIGINT         NOT NULL,
        company_ryo_weight_oz                    BIGINT         NOT NULL,
        company_ryo_cigarette_equivalent_units   DECIMAL(18,6)  NOT NULL,
        company_total_cigarette_equivalent_units DECIMAL(18,6)  NOT NULL,
        total_opm_combined_equivalent_units      DECIMAL(18,6)  NOT NULL,
        relative_market_share_pct               DECIMAL(14,10) NOT NULL COMMENT 'RMS stored to 10 decimal places — legal precision',
        base_year_1997_units                     BIGINT         NOT NULL,
        opm_to_1997_ratio                        DECIMAL(14,10) NOT NULL,
        va_exponent_used                         STRING         NOT NULL,
        volume_adjustment_factor                 DECIMAL(14,10) NOT NULL,
        aggregate_base_payment_usd               DECIMAL(18,2)  NOT NULL,
        gross_national_payment_usd               DECIMAL(18,4)  NOT NULL,
        eligible_shipment_line_count             INTEGER,
        intercompany_lines_excluded              INTEGER,
        exceptions_count                         INTEGER,
        auditor_file_version                     STRING,
        ryo_conversion_factor_used               STRING,
        _gold_loaded_at                          TIMESTAMP,
        _gold_run_id                             STRING
    )
    USING DELTA
    TBLPROPERTIES ('layer'='gold','owner'='finance-data-team',
                   'description'='MSA RMS and VA Factor calculation — all intermediate steps stored for audit')
""")
spark.sql(f"""
    INSERT INTO {CATALOG}.gold.msa_rms_calculation VALUES (
        2025, 'v2025-001', FALSE,
        217456789000, 97500000, 3000000000.000000, 220456789000.000000,
        562950389363.850000,
        39.1609621674,          -- RMS % to 10dp
        667754000000,
        0.8430505686,           -- OPM/1997 ratio
        '0.980000 (MSA Section IX(d)(1) legal constant)',
        0.8459341413,           -- VA Factor to 10dp
        4150000000.00,
        1374795188.4374,        -- Gross national payment
        54, 1, 3, '01',
        '0.032500 (MSA Section II(nn) legal constant)',
        TIMESTAMP '2025-03-05T09:14:22.000Z', 'run-2025-0305-gold-001'
    )
""")
rms = spark.sql(f"SELECT relative_market_share_pct, volume_adjustment_factor, gross_national_payment_usd FROM {CATALOG}.gold.msa_rms_calculation WHERE calculation_year=2025").collect()[0]
print(f"✓ gold.msa_rms_calculation — RMS: {rms[0]:.10f}% | VA: {rms[1]:.10f} | Gross: ${float(rms[2]):,.4f}")

# ── CELL 8: GOLD — STATE PAYMENTS ────────────────────────────────────────────
# (Loaded from the CSV generated by the Python seed script for brevity)
# In a real setup you'd INSERT all 48 rows explicitly
gold_payments_df = spark.read.option("header","true").option("inferSchema","true")\
    .csv(f"/mnt/demo-seed/gold_msa_state_payments.csv")
gold_payments_df.write.format("delta").mode("overwrite")\
    .saveAsTable(f"{CATALOG}.gold.msa_state_payments")

top5 = spark.sql(f"""
    SELECT state_code, state_name, gross_state_payment_usd,
           npm_adjusted_payment_usd, payment_status
    FROM {CATALOG}.gold.msa_state_payments
    ORDER BY gross_state_payment_usd DESC LIMIT 5
""").collect()
print("✓ gold.msa_state_payments — Top 5:")
for r in top5:
    net = f"${float(r[3]):>15,.2f}" if r[3] else "         HELD ⚠"
    print(f"   {r[0]} {r[1]:<26} ${float(r[2]):>15,.2f}  Net: {net}  [{r[4]}]")

# ── CELL 9: CONTROL — EXCEPTIONS ─────────────────────────────────────────────
exc_df = spark.read.option("header","true").csv(f"/mnt/demo-seed/control_msa_exceptions.csv")
exc_df.write.format("delta").mode("overwrite").saveAsTable(f"{CATALOG}.control.msa_exceptions")
exc_count = spark.sql(f"SELECT COUNT(*) FROM {CATALOG}.control.msa_exceptions").collect()[0][0]
print(f"✓ control.msa_exceptions — {exc_count} records")
spark.sql(f"SELECT error_category, delivery_number, error_message FROM {CATALOG}.control.msa_exceptions").show(truncate=60)

# ── CELL 10: SUMMARY ──────────────────────────────────────────────────────────
print(f"""
╔══════════════════════════════════════════════════════════════╗
║   DEMO DATA SEED COMPLETE — {CATALOG}
╠══════════════════════════════════════════════════════════════╣
║  Tables created:                                            ║
║    control.msa_base_volumes       (1 row — legal constant)  ║
║    control.msa_payment_schedule   (1 row — FY2025 status)   ║
║    control.msa_exceptions         (3 rows — demo edge cases)║
║    ref.msa_state_allocations      (48 rows — legal const)   ║
║    ref.us_states_msa_eligible     (54 rows)                 ║
║    silver.npm_adjustment_rates    (48 rows — FY2025)        ║
║    gold.msa_rms_calculation       (1 row — FY2025 v2025-001)║
║    gold.msa_state_payments        (48 rows — FY2025)        ║
║  Bronze + Silver shipment tables: load from CSVs            ║
╠══════════════════════════════════════════════════════════════╣
║  KEY DEMO NUMBERS                                            ║
║  RMS:            39.1609621674%                             ║
║  VA Factor:      0.8459341413                               ║
║  Gross National: $1,374,795,188.44                          ║
║  Net (excl MI):  $1,305,168,998.12                          ║
║  MI Disputed:    $   59,009,985.16   ← HELD for arbitration ║
╠══════════════════════════════════════════════════════════════╣
║  EDGE CASES SEEDED                                          ║
║  MI — NPM disputed: payment_status = PAYMENT HELD           ║
║  AZ, ID, MO, OK — NPM reductions applied                   ║
║  3 Bronze exceptions: missing state / RYO weight / category ║
║  ERP-TTB variance: 125,000 units (0.000057%) — CLEARED      ║
╚══════════════════════════════════════════════════════════════╝
""")
