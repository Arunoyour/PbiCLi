# React — Hooks, State & Forms

---

## Server State with TanStack Query

```typescript
// orderApi.ts — pure fetch functions, no React
export const orderApi = {
  getAll:    (): Promise<Order[]>    => fetch('/api/orders').then(r => r.json()),
  getById:   (id: string)            => fetch(`/api/orders/${id}`).then(r => r.json()),
  create:    (data: CreateOrderDto)  => fetch('/api/orders', { method:'POST', body: JSON.stringify(data), headers:{'Content-Type':'application/json'} }).then(r => r.json()),
  delete:    (id: string)            => fetch(`/api/orders/${id}`, { method:'DELETE' }).then(r => r.json()),
};

// useOrders.ts — TanStack Query hook
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export const ORDER_KEYS = {
  all:    ['orders'] as const,
  detail: (id: string) => ['orders', id] as const,
};

export function useOrders() {
  return useQuery({
    queryKey:  ORDER_KEYS.all,
    queryFn:   orderApi.getAll,
    staleTime: 1000 * 60 * 5,
  });
}

export function useOrder(id: string) {
  return useQuery({
    queryKey: ORDER_KEYS.detail(id),
    queryFn:  () => orderApi.getById(id),
    enabled:  Boolean(id),  // don't fetch until id exists
  });
}

export function useCreateOrder() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: orderApi.create,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ORDER_KEYS.all }),
  });
}

// Component usage
function OrderList() {
  const { data: orders, isLoading, isError, error } = useOrders();

  if (isLoading) return <OrderListSkeleton />;
  if (isError)   return <ErrorMessage message={error.message} />;
  if (!orders?.length) return <EmptyState message="No orders found" />;

  return <ul>{orders.map(o => <OrderCard key={o.id} order={o} />)}</ul>;
}
```

---

## Client State with Zustand

```typescript
// stores/orderStore.ts
import { create } from 'zustand';

interface OrderStore {
  selectedOrderId: string | null;
  filterStatus:    string;
  setSelectedOrder: (id: string | null) => void;
  setFilterStatus:  (status: string) => void;
}

// Only client-side UI state in Zustand (selection, filter, modal open)
// Server data goes in TanStack Query — never duplicate it here
export const useOrderStore = create<OrderStore>((set) => ({
  selectedOrderId: null,
  filterStatus:    'all',
  setSelectedOrder: id     => set({ selectedOrderId: id }),
  setFilterStatus:  status => set({ filterStatus: status }),
}));
```

---

## Forms with React Hook Form + Zod

```typescript
// createOrderSchema.ts
import { z } from 'zod';

export const createOrderSchema = z.object({
  reference: z.string().min(3, 'Minimum 3 characters').max(50),
  amount:    z.number({ invalid_type_error: 'Amount must be a number' }).positive('Must be greater than 0'),
  email:     z.string().email('Invalid email address'),
  notes:     z.string().optional(),
});

export type CreateOrderFormData = z.infer<typeof createOrderSchema>;
```

```tsx
// CreateOrderForm.tsx
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { createOrderSchema, CreateOrderFormData } from './createOrderSchema';
import { useCreateOrder } from './useOrders';

export function CreateOrderForm({ onSuccess }: { onSuccess: () => void }) {
  const createOrder = useCreateOrder();

  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<CreateOrderFormData>({
    resolver: zodResolver(createOrderSchema),
  });

  async function onSubmit(data: CreateOrderFormData) {
    await createOrder.mutateAsync(data);
    onSuccess();
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate>
      <div>
        <label htmlFor="reference">Order Reference *</label>
        <input
          id="reference"
          {...register('reference')}
          aria-invalid={Boolean(errors.reference)}
          aria-describedby={errors.reference ? 'reference-error' : undefined}
        />
        {errors.reference && (
          <span id="reference-error" role="alert">{errors.reference.message}</span>
        )}
      </div>

      <div>
        <label htmlFor="amount">Amount *</label>
        <input
          id="amount"
          type="number"
          step="0.01"
          {...register('amount', { valueAsNumber: true })}
          aria-invalid={Boolean(errors.amount)}
          aria-describedby={errors.amount ? 'amount-error' : undefined}
        />
        {errors.amount && (
          <span id="amount-error" role="alert">{errors.amount.message}</span>
        )}
      </div>

      {createOrder.isError && (
        <div role="alert" className="form-error">
          {createOrder.error.message}
        </div>
      )}

      <button type="submit" disabled={isSubmitting || createOrder.isPending}>
        {isSubmitting || createOrder.isPending ? 'Creating...' : 'Create Order'}
      </button>
    </form>
  );
}
```
