# React — UI Constitution CORE
> Version: 1.0 | Load before generating any React component, hook, or context.

---

## ⚠️ Rule Zero — Ask Before You Build

- [ ] React version? (18+ concurrent features / v19 compiler — behaviour differs)
- [ ] TypeScript or JavaScript? (default: TypeScript)
- [ ] Styling approach? (Tailwind / CSS Modules / styled-components / Emotion)
- [ ] Data fetching? (TanStack Query v5 / SWR / plain fetch)
- [ ] Global state? (Zustand / Jotai / Redux Toolkit / Context API)
- [ ] Form library? (React Hook Form / Formik)
- [ ] Is this inside a Next.js app? → Load `/nextjs/CORE.md` instead
- [ ] Testing? (Vitest + Testing Library / Jest)

---

## Cardinal Rules

### 1. Functional Components Only
```tsx
// ✅ Always functional
function OrderCard({ order }: OrderCardProps) {
  return <div>{order.id}</div>;
}

// ❌ Never class components for new code
class OrderCard extends React.Component<OrderCardProps> { }
```

### 2. One Responsibility Per Component
If you need a second `useState` for unrelated state, or the JSX exceeds 100 lines — split.

```tsx
// ❌ Component doing too much
function OrderPage() {
  const [orders, setOrders] = useState([]);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [isFiltering, setIsFiltering] = useState(false);
  const [filterValues, setFilterValues] = useState({});
  const [isExporting, setIsExporting] = useState(false);
  // 150 lines of JSX...
}

// ✅ Composed from focused pieces
function OrderPage() {
  return (
    <OrderLayout>
      <OrderFilterPanel />
      <OrderList />
      <OrderDetailDrawer />
    </OrderLayout>
  );
}
```

### 3. No `useEffect` for Data Fetching
```tsx
// ❌ useEffect for fetching — race conditions, no caching, no loading/error states
useEffect(() => {
  fetch('/api/orders').then(r => r.json()).then(setOrders);
}, []);

// ✅ TanStack Query — caching, deduplication, loading/error built in
const { data: orders, isLoading, isError } = useQuery({
  queryKey: ['orders'],
  queryFn:  () => apiClient.getOrders(),
});
```

### 4. Never Call Hooks Conditionally
```tsx
// ❌ Breaks React's rules of hooks
if (isLoggedIn) {
  const orders = useOrders(); // WRONG
}

// ✅ Call unconditionally — conditionally use the result
const orders = useOrders();
if (!isLoggedIn) return null;
```

### 5. Explicit Key Props — Never Use Array Index
```tsx
// ❌ Index as key — causes state bugs on reorder/insert
{orders.map((o, i) => <OrderCard key={i} order={o} />)}

// ✅ Stable unique ID
{orders.map(order => <OrderCard key={order.id} order={order} />)}
```

### 6. Avoid Prop Drilling Beyond 2 Levels
```tsx
// ❌ Prop drilling through intermediate components that don't use the value
<Page user={user}>
  <Layout user={user}>
    <Sidebar user={user}>
      <Avatar user={user} />
    </Sidebar>
  </Layout>
</Page>

// ✅ Context for genuinely global values (auth, theme)
const { user } = useAuthContext();

// ✅ Zustand / Jotai for shared feature state
const user = useAuthStore(state => state.user);
```

### 7. Derived State — Compute, Don't Sync
```tsx
// ❌ Duplicates state — can go out of sync
const [orders, setOrders] = useState<Order[]>([]);
const [activeOrders, setActiveOrders] = useState<Order[]>([]);  // ← derived!
useEffect(() => {
  setActiveOrders(orders.filter(o => o.active));
}, [orders]);

// ✅ Derive directly
const [orders, setOrders] = useState<Order[]>([]);
const activeOrders = orders.filter(o => o.active);  // computed on each render
// Or memoize if expensive:
const activeOrders = useMemo(() => orders.filter(o => o.active), [orders]);
```

### 8. Wrap Callbacks in `useCallback` Only When Passed to Memoised Children
```tsx
// ❌ useCallback everywhere — premature optimisation, adds noise
const handleClick = useCallback(() => console.log('click'), []);

// ✅ useCallback when the function is a dep of useEffect or passed to React.memo child
const handleSubmit = useCallback(async (data: FormData) => {
  await orderService.create(data);
}, [orderService]);

<MemoizedForm onSubmit={handleSubmit} />  // MemoizedForm = React.memo(Form)
```

---

## Preferred Stack

| Need | Preferred | Avoid |
|---|---|---|
| Server state / data fetching | TanStack Query v5 | `useEffect` + `fetch` directly |
| Global client state | Zustand | Redux (unless existing) |
| Atom-level state | Jotai | Context for frequently-updating values |
| Form handling | React Hook Form + Zod | Formik (performance), controlled inputs for complex forms |
| Validation schemas | Zod | Yup |
| Styling | Tailwind + shadcn/ui | CSS-in-JS for new projects |
| Icons | Lucide React | FontAwesome CDN |
| Dates | date-fns | moment.js (heavy) |
| Tables | TanStack Table v8 | hand-rolled tables with sort/filter/pagination |
| Charts | Recharts / Visx | Chart.js (for React, prefer native) |
| Testing | Vitest + Testing Library | Enzyme |

---

## Component Template

```tsx
// OrderCard.tsx
import { memo } from 'react';
import type { Order } from '@/types/order';

interface OrderCardProps {
  order:      Order;
  isSelected: boolean;
  onSelect:   (id: string) => void;
}

// memo only when parent re-renders frequently and props rarely change
export const OrderCard = memo(function OrderCard({
  order, isSelected, onSelect,
}: OrderCardProps) {
  return (
    <article
      className={`order-card ${isSelected ? 'order-card--selected' : ''}`}
      aria-selected={isSelected}
    >
      <h3 className="order-card__title">{order.reference}</h3>
      <p>{order.status}</p>
      <button
        type="button"
        onClick={() => onSelect(order.id)}
        aria-label={`Select order ${order.reference}`}
      >
        Select
      </button>
    </article>
  );
});
```

```tsx
// useOrders.ts — custom hook encapsulates fetching logic
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { orderApi } from '@/api/orderApi';

export function useOrders() {
  return useQuery({
    queryKey:  ['orders'],
    queryFn:   orderApi.getAll,
    staleTime: 1000 * 60 * 5,   // 5 minutes
  });
}

export function useDeleteOrder() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: orderApi.delete,
    onSuccess:  () => queryClient.invalidateQueries({ queryKey: ['orders'] }),
  });
}
```

---

## File Structure

```
/src/
  /app/                     ← Next.js App Router pages (if Next.js)
  /components/
    /ui/                    ← generic, reusable UI atoms (Button, Input, Badge)
    /layout/                ← layout shells (DashboardLayout, AuthLayout)
  /features/
    /orders/                ← one folder per feature domain
      OrderList.tsx
      OrderCard.tsx
      OrderDetailDrawer.tsx
      useOrders.ts           ← data fetching hook
      orderStore.ts          ← Zustand slice (if needed)
      orderApi.ts            ← API calls
      orderTypes.ts          ← TypeScript types
      OrderList.spec.tsx     ← co-located tests
  /hooks/                   ← shared custom hooks
  /lib/                     ← utilities, helpers, constants
  /types/                   ← shared TypeScript types
  /api/                     ← API client setup, base instance
```

---

## Generation Checklist

- [ ] Functional component (no class components)
- [ ] All props typed with explicit `interface` — no `any`
- [ ] `key` prop on every list item — stable ID, never array index
- [ ] Loading, error, and empty states rendered
- [ ] `useEffect` has correct dependency array (empty if run-once, exhaustive otherwise)
- [ ] No derived state duplicated in `useState`
- [ ] `useMemo` and `useCallback` only where justified — not by default
- [ ] TanStack Query used for all server data (not raw `useEffect`)
- [ ] No `dangerouslySetInnerHTML` without DOMPurify sanitisation first
- [ ] `type="button"` on all buttons not inside a form (prevents accidental submit)
- [ ] `aria-label` on all icon-only buttons
- [ ] `alt` text on all images
- [ ] Form validation via React Hook Form + Zod schema
