# Angular — Services, State & Forms

---

## Services — the Single Source of Truth

```typescript
// order.service.ts — business logic lives here, never in components
import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, throwError } from 'rxjs';
import { environment } from '@/environments/environment';

@Injectable({ providedIn: 'root' })
export class OrderService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/orders`;

  getOrders() {
    return this.http.get<Order[]>(this.baseUrl).pipe(
      catchError(this.handleError)
    );
  }

  getOrderById(id: string) {
    return this.http.get<Order>(`${this.baseUrl}/${id}`).pipe(
      catchError(this.handleError)
    );
  }

  createOrder(payload: CreateOrderDto) {
    return this.http.post<Order>(this.baseUrl, payload).pipe(
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse) {
    const message = error.error?.message ?? error.message ?? 'Unknown error';
    return throwError(() => new Error(message));
  }
}
```

---

## Signals-Based State Store (Angular 16+)

```typescript
// order.store.ts — signals store (no NgRx required for moderate complexity)
import { Injectable, signal, computed } from '@angular/core';
import { OrderService } from './order.service';

@Injectable({ providedIn: 'root' })
export class OrderStore {
  private orderService = inject(OrderService);

  // State
  readonly orders    = signal<Order[]>([]);
  readonly isLoading = signal(false);
  readonly error     = signal<string | null>(null);

  // Derived
  readonly activeOrders = computed(() => this.orders().filter(o => o.active));
  readonly orderCount   = computed(() => this.orders().length);

  loadOrders(): void {
    this.isLoading.set(true);
    this.error.set(null);
    this.orderService.getOrders()
      .pipe(takeUntilDestroyed())
      .subscribe({
        next:  orders => { this.orders.set(orders); this.isLoading.set(false); },
        error: err    => { this.error.set(err.message); this.isLoading.set(false); },
      });
  }

  addOrder(order: Order): void {
    this.orders.update(current => [...current, order]);
  }

  removeOrder(id: string): void {
    this.orders.update(current => current.filter(o => o.id !== id));
  }
}
```

---

## Reactive Forms — Always Typed

```typescript
// create-order.component.ts
import { Component, inject } from '@angular/core';
import { FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import type { AbstractControl } from '@angular/forms';

@Component({
  standalone: true,
  imports: [ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CreateOrderFormComponent {
  private fb = inject(FormBuilder);

  // Typed form group
  form = this.fb.group({
    reference: ['', [Validators.required, Validators.minLength(3)]],
    amount:    [null as number | null, [Validators.required, Validators.min(0.01)]],
    email:     ['', [Validators.required, Validators.email]],
    notes:     [''],
  });

  // Helper to reduce template verbosity
  get reference(): AbstractControl { return this.form.controls.reference; }
  get amount():    AbstractControl { return this.form.controls.amount; }

  onSubmit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched(); // show all validation messages
      return;
    }
    // form.getRawValue() preserves disabled controls
    const payload = this.form.getRawValue();
    // submit...
  }
}
```

```html
<!-- create-order.component.html -->
<form [formGroup]="form" (ngSubmit)="onSubmit()" novalidate>

  <div class="field">
    <label for="reference">Order Reference *</label>
    <input
      id="reference"
      formControlName="reference"
      [attr.aria-invalid]="reference.invalid && reference.touched"
      aria-describedby="reference-error"
    />
    <span
      id="reference-error"
      role="alert"
      *ngIf="reference.invalid && reference.touched"
    >
      <span *ngIf="reference.errors?.['required']">Reference is required</span>
      <span *ngIf="reference.errors?.['minlength']">Minimum 3 characters</span>
    </span>
  </div>

  <button type="submit" [disabled]="isLoading()">
    <span *ngIf="!isLoading()">Create Order</span>
    <span *ngIf="isLoading()">Creating...</span>
  </button>

</form>
```

---

## HTTP Interceptor — Auth + Error Handling

```typescript
// api.interceptor.ts
export const apiInterceptor: HttpInterceptorFn = (req, next) => {
  // Add auth header
  const authReq = req.clone({
    headers: req.headers.set('Authorization', `Bearer ${getToken()}`),
  });

  return next(authReq).pipe(
    catchError((error: HttpErrorResponse) => {
      if (error.status === 401) router.navigate(['/login']);
      if (error.status === 403) notificationService.error('Access denied');
      return throwError(() => error);
    })
  );
};
```

---

## Generation Checklist (State & Forms)

- [ ] Services use `inject()` not constructor injection (Angular 14+)
- [ ] All HTTP calls have `catchError` — no unhandled observable errors
- [ ] Reactive Forms use typed `FormGroup` — not `UntypedFormGroup`
- [ ] `markAllAsTouched()` called on invalid submit to show all errors
- [ ] Form validation messages use `role="alert"` + `aria-describedby`
- [ ] Submit button disabled during async operations
- [ ] `ngIf` shows loading/error/empty states
