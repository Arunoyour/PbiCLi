# Angular — UI Constitution CORE
> Version: 1.0 | Load this file before generating any Angular component, service, directive, or pipe.

---

## ⚠️ Rule Zero — Ask Before You Build

- [ ] Angular version? (check `workspace.config.md` — behaviour differs between v14/v15/v16/v17+)
- [ ] Standalone components or NgModule-based? (v17+ default is standalone)
- [ ] Signals (`signal()` / `computed()`) or RxJS-only? (v16+)
- [ ] Which state management? (Signals / NgRx / Akita / service-based)
- [ ] Reactive Forms or Template-Driven Forms?
- [ ] Server-Side Rendering? (Angular Universal / Angular SSR v17+)
- [ ] Testing framework? (Jest or Karma/Jasmine)

---

## Cardinal Rules

### 1. Strong Typing — No `any`
```typescript
// ❌ Never
fetchOrder(id: any): any { }

// ✅ Always
fetchOrder(id: string): Observable<Order> { }
```

### 2. Smart / Dumb Component Split
- **Smart (Container) components**: inject services, manage state, pass data down as `@Input()`
- **Dumb (Presentational) components**: `@Input()` only, `@Output()` for events, no service injection, fully reusable

### 3. OnPush Change Detection — Always
```typescript
@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,  // ← always
})
export class OrderCardComponent { }
```
With OnPush: mutate observable streams or signals — never mutate objects in place.

### 4. Unsubscribe from Every Observable
```typescript
// ✅ Option A — takeUntilDestroyed (Angular 16+, preferred)
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
this.orderService.orders$.pipe(takeUntilDestroyed()).subscribe(...);

// ✅ Option B — async pipe in template (auto-unsubscribes)
<div *ngFor="let order of orders$ | async">...</div>

// ✅ Option C — DestroyRef in Angular 16+
constructor(private destroyRef: DestroyRef) {
  this.orderService.orders$.pipe(
    takeUntilDestroyed(this.destroyRef)
  ).subscribe(...);
}

// ❌ Never — memory leak
ngOnInit() {
  this.orderService.orders$.subscribe(orders => this.orders = orders);
}
```

### 5. Services Contain Business Logic — Components Display
```typescript
// ❌ Logic in component
fetchAndProcess() {
  this.http.get('/api/orders').pipe(
    map(o => o.filter(x => x.active)),
    catchError(...)
  ).subscribe(orders => this.orders = orders);
}

// ✅ Logic in service
// order.service.ts
getActiveOrders(): Observable<Order[]> {
  return this.http.get<Order[]>('/api/orders').pipe(
    map(orders => orders.filter(o => o.active)),
    catchError(this.handleError)
  );
}
// component.ts — just calls the service
ngOnInit() {
  this.orders$ = this.orderService.getActiveOrders();
}
```

### 6. Lazy Load Every Feature Module / Route
```typescript
// app.routes.ts
export const routes: Routes = [
  {
    path: 'orders',
    loadComponent: () => import('./orders/orders.component').then(m => m.OrdersComponent),
  },
  {
    path: 'admin',
    loadChildren: () => import('./admin/admin.routes').then(m => m.adminRoutes),
  },
];
```

### 7. Use Angular's DI — Never Instantiate Services with `new`
```typescript
// ❌
const service = new OrderService(httpClient);  // bypasses DI, untestable

// ✅
constructor(private orderService: OrderService) { }  // Angular manages lifecycle
```

### 8. Never Manipulate the DOM Directly
```typescript
// ❌
document.getElementById('order-title').textContent = title;
document.querySelector('.card').classList.add('active');

// ✅ Use Renderer2 when DOM interaction is unavoidable
constructor(private renderer: Renderer2, private el: ElementRef) { }
this.renderer.setProperty(this.el.nativeElement, 'textContent', title);
this.renderer.addClass(this.el.nativeElement, 'active');

// ✅ Or better — bind in template
<span>{{ title }}</span>
<div [class.active]="isActive">...</div>
```

---

## Preferred Stack

| Need | Preferred | Avoid |
|---|---|---|
| Component state (v16+) | `signal()`, `computed()`, `effect()` | Mutable class properties |
| Async state in template | `async` pipe | Manual subscription |
| Server state / data fetching | Angular HttpClient + service | Direct fetch in component |
| Form handling | Reactive Forms (`FormBuilder`) | Template-driven for complex forms |
| Global/shared state | Signals service or NgRx | Component-level `BehaviorSubject` for shared state |
| Side effects | `effect()` (signals) or `tap()` (RxJS) | `ngOnChanges` for everything |
| Styling | Component-scoped CSS (default) | Global styles for component-specific rules |
| SSR | Angular SSR (`@angular/ssr`) | Manual hydration |

---

## File Structure

```
/src/app/
  /core/                        ← singletons: auth, interceptors, guards
    auth.service.ts
    api.interceptor.ts
    auth.guard.ts
  /shared/                      ← reusable components/pipes/directives
    /components/
      status-badge/
        status-badge.component.ts
        status-badge.component.html
        status-badge.component.scss
        status-badge.component.spec.ts
    /pipes/
      format-currency.pipe.ts
    /directives/
      click-outside.directive.ts
  /features/
    /orders/                    ← one folder per feature
      orders.routes.ts
      /components/
        order-list/
        order-card/
        order-detail/
      /services/
        order.service.ts
      /models/
        order.model.ts
      /store/                   ← NgRx or signals store if needed
```

---

## Component Template

```typescript
// ✅ Standalone component (Angular 17+ default)
import { Component, OnInit, inject, signal, computed, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-order-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './order-list.component.html',
  styleUrl: './order-list.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OrderListComponent implements OnInit {
  private orderService = inject(OrderService);

  // Signals for local state
  isLoading = signal(false);
  error     = signal<string | null>(null);
  orders    = signal<Order[]>([]);

  // Computed values — derived, never duplicated
  activeOrders = computed(() => this.orders().filter(o => o.status === 'active'));

  ngOnInit(): void {
    this.loadOrders();
  }

  private loadOrders(): void {
    this.isLoading.set(true);
    this.error.set(null);

    this.orderService.getOrders()
      .pipe(takeUntilDestroyed())
      .subscribe({
        next:  orders => { this.orders.set(orders); this.isLoading.set(false); },
        error: err    => { this.error.set(err.message); this.isLoading.set(false); },
      });
  }
}
```

---

## Generation Checklist

- [ ] `changeDetection: ChangeDetectionStrategy.OnPush` on every component
- [ ] `standalone: true` (Angular 17+)
- [ ] All observables unsubscribed via `takeUntilDestroyed()` or `async` pipe
- [ ] No `any` type anywhere
- [ ] No direct DOM manipulation — `Renderer2` or template binding only
- [ ] Business logic in service, not component
- [ ] Feature modules / routes are lazy-loaded
- [ ] `trackBy` on all `*ngFor` loops with mutable data
- [ ] All `@Input()` have explicit types
- [ ] All `@Output()` use `EventEmitter<ExplicitType>` — not `EventEmitter<any>`
- [ ] Loading, error, and empty states handled in template
- [ ] `aria-label` on all icon-only buttons
- [ ] Form fields use `ReactiveFormsModule` with typed `FormControl<T>`
