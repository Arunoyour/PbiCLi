# Vue.js — Composables, Pinia & Forms

---

## Composables — Reusable Logic

```typescript
// composables/useOrders.ts
import { ref, onMounted } from 'vue';
import { orderApi } from '@/api/orderApi';

export function useOrders() {
  const orders    = ref<Order[]>([]);
  const isLoading = ref(false);
  const error     = ref<string | null>(null);

  async function fetchOrders() {
    isLoading.value = true;
    error.value     = null;
    try {
      orders.value = await orderApi.getAll();
    } catch (e) {
      error.value = (e as Error).message;
    } finally {
      isLoading.value = false;
    }
  }

  onMounted(fetchOrders);
  return { orders, isLoading, error, fetchOrders };
}
```

---

## Pinia Store

```typescript
// stores/orderStore.ts
import { defineStore } from 'pinia';
import { ref, computed } from 'vue';

export const useOrderStore = defineStore('orders', () => {
  const orders    = ref<Order[]>([]);
  const isLoading = ref(false);
  const error     = ref<string | null>(null);

  const activeOrders = computed(() => orders.value.filter(o => o.active));

  async function fetchOrders() {
    isLoading.value = true;
    error.value     = null;
    try {
      orders.value = await orderApi.getAll();
    } catch (e) {
      error.value = (e as Error).message;
    } finally {
      isLoading.value = false;
    }
  }

  function addOrder(order: Order) {
    orders.value = [...orders.value, order];  // immutable update
  }

  return { orders, isLoading, error, activeOrders, fetchOrders, addOrder };
});
```

---

## Forms with VeeValidate + Zod

```typescript
// schemas/createOrderSchema.ts
import { z } from 'zod';
export const createOrderSchema = z.object({
  reference: z.string().min(3, 'Minimum 3 characters'),
  amount:    z.number().positive('Must be greater than 0'),
  email:     z.string().email('Invalid email'),
});
export type CreateOrderForm = z.infer<typeof createOrderSchema>;
```

```vue
<!-- CreateOrderForm.vue -->
<script setup lang="ts">
import { useForm } from 'vee-validate';
import { toTypedSchema } from '@vee-validate/zod';
import { createOrderSchema } from '@/schemas/createOrderSchema';

const emit = defineEmits<{ success: [] }>();

const { handleSubmit, defineField, errors, isSubmitting } = useForm({
  validationSchema: toTypedSchema(createOrderSchema),
});

const [reference, referenceAttrs] = defineField('reference');
const [amount, amountAttrs]       = defineField('amount');

const onSubmit = handleSubmit(async (values) => {
  await orderApi.create(values);
  emit('success');
});
</script>

<template>
  <form @submit.prevent="onSubmit" novalidate>

    <div class="field">
      <label for="reference">Order Reference *</label>
      <input
        id="reference"
        v-model="reference"
        v-bind="referenceAttrs"
        :aria-invalid="Boolean(errors.reference)"
        :aria-describedby="errors.reference ? 'reference-error' : undefined"
      />
      <span v-if="errors.reference" id="reference-error" role="alert">
        {{ errors.reference }}
      </span>
    </div>

    <div class="field">
      <label for="amount">Amount *</label>
      <input
        id="amount"
        type="number"
        step="0.01"
        v-model.number="amount"
        v-bind="amountAttrs"
        :aria-invalid="Boolean(errors.amount)"
      />
      <span v-if="errors.amount" role="alert">{{ errors.amount }}</span>
    </div>

    <button type="submit" :disabled="isSubmitting">
      {{ isSubmitting ? 'Creating...' : 'Create Order' }}
    </button>

  </form>
</template>
```
