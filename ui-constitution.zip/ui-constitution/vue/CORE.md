# Vue.js — UI Constitution CORE
> Version: 1.0 | Load before generating any Vue component, composable, or store.

---

## ⚠️ Rule Zero — Ask Before You Build

- [ ] Vue version? (Vue 3 is default — Vue 2 is EOL. Confirm before writing any code)
- [ ] Composition API or Options API? (Composition API for all new Vue 3 code)
- [ ] `<script setup>` syntax? (Yes — it is the Vue 3 standard)
- [ ] State management? (Pinia for new projects — not Vuex)
- [ ] Build tool? (Vite preferred / Nuxt for SSR)
- [ ] TypeScript? (Yes by default for new projects)
- [ ] Is this a Nuxt project? → Ask for Nuxt-specific considerations

---

## Cardinal Rules

### 1. Composition API + `<script setup>` for All New Code
```vue
<!-- ✅ Modern Vue 3 — script setup -->
<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';
import { useOrderStore } from '@/stores/orderStore';

const orderStore = useOrderStore();
const isLoading  = ref(false);
</script>

<!-- ❌ Options API — do not use for new components -->
<script>
export default {
  data() { return { isLoading: false }; },
  mounted() { this.loadOrders(); },
}
</script>
```

### 2. `v-for` Always Has `:key` — Never Use Index
```vue
<!-- ❌ Index as key — breaks reactivity on sort/insert -->
<OrderCard v-for="(order, i) in orders" :key="i" :order="order" />

<!-- ✅ Stable unique ID -->
<OrderCard v-for="order in orders" :key="order.id" :order="order" />
```

### 3. Props Down — Emits Up — Never Mutate Props
```vue
<!-- ❌ Mutating a prop directly — Vue will warn, causes bugs -->
<script setup>
const props = defineProps<{ order: Order }>();
props.order.status = 'active'; // ← WRONG
</script>

<!-- ✅ Emit an event and let the parent update -->
<script setup>
const props  = defineProps<{ order: Order }>();
const emit   = defineEmits<{ 'update:order': [order: Order] }>();

function markActive() {
  emit('update:order', { ...props.order, status: 'active' });
}
</script>
```

### 4. Use `computed()` for Derived State — Never Duplicate State
```vue
<script setup lang="ts">
const orders       = ref<Order[]>([]);

// ❌ Watching orders to set another ref — duplication
const activeOrders = ref<Order[]>([]);
watch(orders, val => { activeOrders.value = val.filter(o => o.active); });

// ✅ Computed — reactive, efficient, derived
const activeOrders = computed(() => orders.value.filter(o => o.active));
</script>
```

### 5. Pinia for Shared State — Not Vuex, Not Event Bus
```typescript
// stores/orderStore.ts
import { defineStore } from 'pinia';
import { ref, computed } from 'vue';

export const useOrderStore = defineStore('orders', () => {
  const orders    = ref<Order[]>([]);
  const isLoading = ref(false);
  const error     = ref<string | null>(null);

  const activeOrders = computed(() => orders.value.filter(o => o.active));

  async function fetchOrders() {
    isLoading.value = true;
    error.value     = null;
    try {
      orders.value = await orderApi.getAll();
    } catch (e) {
      error.value = (e as Error).message;
    } finally {
      isLoading.value = false;
    }
  }

  return { orders, isLoading, error, activeOrders, fetchOrders };
});
```

### 6. No Direct DOM Manipulation — Use Template Refs and `v-` Directives
```vue
<!-- ❌ -->
<script setup>
document.getElementById('order-input').focus();
</script>

<!-- ✅ Use templateRef -->
<script setup>
import { ref, onMounted } from 'vue';
const orderInput = ref<HTMLInputElement | null>(null);
onMounted(() => orderInput.value?.focus());
</script>
<template>
  <input ref="orderInput" type="text" />
</template>
```

### 7. `v-if` vs `v-show` — Know the Difference
```vue
<!-- v-if: DOM element is destroyed/created — use for infrequent toggles -->
<ErrorMessage v-if="error" :message="error" />

<!-- v-show: CSS display toggle — use for frequent show/hide -->
<LoadingSpinner v-show="isLoading" />

<!-- NEVER v-if and v-for on the same element -->
<!-- ❌ -->
<li v-for="order in orders" v-if="order.active" :key="order.id">

<!-- ✅ Filter first, then render -->
<li v-for="order in activeOrders" :key="order.id">
```

### 8. Define Composables for Reusable Logic
```typescript
// composables/useOrders.ts
import { ref, onMounted } from 'vue';

export function useOrders() {
  const orders    = ref<Order[]>([]);
  const isLoading = ref(false);
  const error     = ref<string | null>(null);

  async function fetchOrders() {
    isLoading.value = true;
    try {
      orders.value = await orderApi.getAll();
    } catch (e) {
      error.value = (e as Error).message;
    } finally {
      isLoading.value = false;
    }
  }

  onMounted(fetchOrders);

  return { orders, isLoading, error, fetchOrders };
}
```

---

## Preferred Stack

| Need | Preferred | Avoid |
|---|---|---|
| State management | Pinia | Vuex (legacy) |
| Data fetching | VueUse `useFetch` / TanStack Query for Vue | Raw `fetch` in `onMounted` |
| Forms | VeeValidate + Zod | v-model on complex nested forms manually |
| SSR | Nuxt 3 | Vue + manual SSR |
| Routing | Vue Router 4 | Manual history API |
| Utilities | VueUse | Custom implementations of common tasks |
| Styling | Tailwind / scoped `<style>` | Global styles for component-specific rules |
| Build | Vite | Webpack (for new projects) |
| Testing | Vitest + Vue Test Utils | Jest |
| Icons | Lucide Vue Next | FontAwesome CDN |

---

## Single File Component Structure

```vue
<!-- OrderCard.vue -->
<script setup lang="ts">
// 1. Imports
import { computed } from 'vue';
import type { Order } from '@/types/order';

// 2. Props and Emits
const props = defineProps<{
  order:      Order;
  isSelected: boolean;
}>();

const emit = defineEmits<{
  select: [id: string];
}>();

// 3. Computed
const statusClass = computed(() =>
  `status--${props.order.status.toLowerCase()}`
);

// 4. Methods
function handleSelect() {
  emit('select', props.order.id);
}
</script>

<template>
  <article
    class="order-card"
    :class="{ 'order-card--selected': isSelected }"
    :aria-selected="isSelected"
  >
    <h3 class="order-card__title">{{ order.reference }}</h3>
    <span :class="['status-badge', statusClass]">{{ order.status }}</span>
    <button
      type="button"
      :aria-label="`Select order ${order.reference}`"
      @click="handleSelect"
    >
      Select
    </button>
  </article>
</template>

<style scoped>
/* Scoped to this component only */
.order-card { }
.order-card--selected { }
.order-card__title { }
</style>
```

---

## File Structure

```
/src/
  /assets/
  /components/
    /ui/               ← generic reusable (Button.vue, Input.vue, Badge.vue)
    /layout/           ← layout shells (DashboardLayout.vue)
  /composables/        ← shared logic (useOrders.ts, useAuth.ts)
  /features/
    /orders/
      OrderList.vue
      OrderCard.vue
      OrderDetailDrawer.vue
      orderStore.ts     ← Pinia store for this feature
      orderApi.ts       ← API calls
      orderTypes.ts     ← TypeScript types
  /router/
    index.ts
  /stores/             ← global stores (auth, ui settings)
  /types/              ← shared types
  /lib/                ← utilities, constants
```

---

## Generation Checklist

- [ ] `<script setup lang="ts">` on every component
- [ ] `defineProps<T>()` with explicit TypeScript generic — no `PropType` from Vue 2
- [ ] `defineEmits<{ eventName: [payload type] }>()` with explicit types
- [ ] `:key` on every `v-for` — stable unique ID, never index
- [ ] No `v-if` and `v-for` on the same element
- [ ] No prop mutation — emit to parent instead
- [ ] No `any` type
- [ ] `v-model` binds only to local state — not a prop directly
- [ ] Pinia store used for state shared across components
- [ ] `computed()` for all derived values — no duplicate state
- [ ] `<style scoped>` on all component styles
- [ ] Loading, error, and empty states in template
- [ ] `aria-label` on all icon-only buttons
