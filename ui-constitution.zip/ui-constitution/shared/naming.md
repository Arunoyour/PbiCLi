# UI — Shared Naming Conventions
> Applies to all frameworks. Load alongside the framework CORE.md.

---

## Files and Folders

| Artifact | Convention | Example |
|---|---|---|
| Component file (React/Next) | PascalCase | `UserCard.tsx`, `OrderTable.tsx` |
| Component file (Angular) | kebab-case | `user-card.component.ts` |
| Component file (Vue) | PascalCase (SFC) | `UserCard.vue` |
| Page / route file (Next.js) | lowercase with hyphens | `order-detail/page.tsx` |
| Hook (React/Next) | camelCase, `use` prefix | `useOrderData.ts` |
| Composable (Vue) | camelCase, `use` prefix | `useOrderData.ts` |
| Service (Angular) | kebab-case, `.service.ts` | `order-data.service.ts` |
| Store (Pinia/Zustand) | camelCase, `use` prefix + `Store` | `useOrderStore.ts` |
| Style file | Same name as component | `UserCard.module.css` |
| Test file | Same name + spec/test | `UserCard.spec.ts` |
| Type / interface file | PascalCase | `OrderTypes.ts` |
| Utility function file | camelCase | `formatCurrency.ts` |
| Constant file | SCREAMING_SNAKE in file | `API_ROUTES.ts` |

---

## Component Naming

Name components after **what they render** (noun phrases), not what they do (verb phrases).

```
✅  UserCard          OrderTable         PaymentSummary
✅  DashboardLayout   FilterPanel        StatusBadge
✅  LoginForm         SearchInput        ConfirmDialog

❌  ManageUser        HandleOrder        ProcessPayment
❌  DoSearch          RenderList         ShowData
```

### Naming by Component Type

| Type | Pattern | Example |
|---|---|---|
| Page / screen | `{Subject}Page` | `OrderDetailPage` |
| Layout wrapper | `{Context}Layout` | `DashboardLayout` |
| List container | `{Item}List` | `OrderList` |
| Single item | `{Subject}Card` or `{Subject}Item` | `OrderCard` |
| Form | `{Action}{Subject}Form` | `CreateOrderForm` |
| Modal / dialog | `{Subject}Dialog` or `{Subject}Modal` | `ConfirmDeleteDialog` |
| Button | `{Action}Button` | `SubmitOrderButton` (only if specialised) |
| Input | `{Subject}Input` or use generic | `CurrencyInput` |
| Table | `{Subject}Table` | `OrderTable` |
| Skeleton/loader | `{Subject}Skeleton` | `OrderCardSkeleton` |

---

## Props and Emits / Outputs

### Props (all frameworks)
- **camelCase** in code, even though HTML attributes use kebab-case
- **Boolean props** use `is` / `has` / `can` prefix: `isLoading`, `hasError`, `canSubmit`
- **Callback props** use `on` prefix (React): `onSubmit`, `onChange`, `onClose`
- **Avoid generic names**: `data`, `info`, `value` → use `order`, `userProfile`, `selectedDate`

```typescript
// ✅ Good prop names
interface OrderCardProps {
  order: Order;
  isSelected: boolean;
  hasUnsavedChanges: boolean;
  onSelect: (id: string) => void;
}

// ❌ Bad prop names
interface OrderCardProps {
  data: any;
  selected: boolean;
  flag: boolean;
  handler: Function;
}
```

### Angular `@Output` EventEmitters
- Name the emitter as the event: `orderSelected`, `formSubmitted`, `dialogClosed`
- Name the `$event` payload type explicitly — never `any`

### Vue `emits`
- Event names in camelCase in script, kebab-case in template: `emit('orderSelected')` → `@order-selected`

---

## Variables and Functions

```typescript
// State variables — noun or noun phrase
const isLoading = ref(false);          // boolean: is/has/can prefix
const orders = ref<Order[]>([]);       // arrays: plural noun
const selectedOrderId = ref<string>(); // nullable: camelCase noun
const errorMessage = ref<string>('');

// Functions — verb phrase
function fetchOrders() {}
function handleSubmit() {}
function formatCurrency(amount: number): string {}
async function deleteOrder(id: string): Promise<void> {}

// Event handlers — handle prefix (React) or on prefix (Vue/Angular)
function handleOrderClick(event: MouseEvent) {}  // React
function onOrderClick(event: MouseEvent) {}      // Vue / Angular
```

---

## CSS / Tailwind Class Naming

**If using CSS Modules:**
- Classes: camelCase — `.cardWrapper`, `.headerTitle`, `.errorText`
- Never use global classes for component-specific styles

**If using Tailwind:**
- Extract repeated utility groups into components, not custom classes
- If a custom class is needed: BEM-style `.order-card__title` scoped to the component

**If using BEM (vanilla CSS):**
```css
/* Block */     .order-card {}
/* Element */   .order-card__title {}
/* Modifier */  .order-card--selected {}
               .order-card__title--truncated {}
```

---

## Constants

```typescript
// API routes — in dedicated API_ROUTES.ts
export const API_ROUTES = {
  orders:    '/api/v1/orders',
  orderById: (id: string) => `/api/v1/orders/${id}`,
  customers: '/api/v1/customers',
} as const;

// Never hardcode URLs in components:
// ❌ fetch('https://api.company.com/orders')
// ✅ fetch(API_ROUTES.orders)

// Environment variables
// ❌ const baseUrl = 'https://api.company.com'
// ✅ const baseUrl = process.env.NEXT_PUBLIC_API_URL  (Next.js)
// ✅ const baseUrl = import.meta.env.VITE_API_URL     (Vite / Vue)
// ✅ const baseUrl = environment.apiUrl               (Angular)
```
