# UI — Accessibility Standards (WCAG 2.1 AA)
> All frameworks. Non-negotiable minimum. Load when building any component users interact with.

---

## The Standard

Target: **WCAG 2.1 Level AA**. Every component must meet this before it ships.

---

## Semantic HTML First

Use the correct HTML element before reaching for ARIA. ARIA supplements — it does not replace.

```html
<!-- ✅ Correct: button for actions -->
<button type="button" onclick="handleDelete()">Delete Order</button>

<!-- ❌ Wrong: div with click handler -->
<div onclick="handleDelete()">Delete Order</div>

<!-- ✅ Correct: nav landmark for navigation -->
<nav aria-label="Main navigation">...</nav>

<!-- ✅ Correct: heading hierarchy -->
<h1>Orders</h1>          <!-- page title — one per page -->
<h2>Open Orders</h2>     <!-- section -->
<h3>Order #1234</h3>     <!-- sub-section -->

<!-- ✅ Correct: link for navigation, button for action -->
<a href="/orders/1234">View order</a>    <!-- goes somewhere -->
<button>Cancel order</button>             <!-- does something -->
```

---

## Labels — Every Input Must Have One

```html
<!-- ✅ Explicit label (preferred) -->
<label for="order-date">Order Date</label>
<input id="order-date" type="date" />

<!-- ✅ Wrapped label -->
<label>
  Order Date
  <input type="date" />
</label>

<!-- ✅ aria-label for icon buttons -->
<button aria-label="Delete order #1234">
  <svg aria-hidden="true">...</svg>
</button>

<!-- ✅ aria-labelledby for inputs with visible heading label -->
<h2 id="shipping-section">Shipping Address</h2>
<input aria-labelledby="shipping-section" type="text" />

<!-- ❌ Placeholder is NOT a label — it disappears on input -->
<input placeholder="Enter your email" type="email" />

<!-- ❌ No label at all -->
<input type="text" />
```

---

## Focus Management

```typescript
// Modal / Dialog: move focus to first interactive element on open
// Return focus to the trigger element on close

// ✅ Angular — use ViewChild to manage focus
@ViewChild('firstInput') firstInput!: ElementRef;
ngAfterViewInit() {
  this.firstInput.nativeElement.focus();
}

// ✅ React — use useRef and useEffect
const firstInputRef = useRef<HTMLInputElement>(null);
useEffect(() => {
  if (isOpen) firstInputRef.current?.focus();
}, [isOpen]);

// ✅ Route change — scroll to top and announce page title
// (framework-specific — see individual CORE.md files)

// ❌ Never remove focus outlines
// outline: none; ← this breaks keyboard navigation
// Instead: style the focus ring, never remove it
:focus-visible {
  outline: 2px solid #005FCC;
  outline-offset: 2px;
}
```

---

## ARIA Roles and States

```html
<!-- Loading state -->
<div role="status" aria-live="polite">Loading orders...</div>
<div aria-busy="true">...</div>

<!-- Error state -->
<div role="alert" aria-live="assertive">
  Error: Could not load orders. Please try again.
</div>

<!-- Form field error -->
<input id="email" aria-describedby="email-error" aria-invalid="true" />
<span id="email-error" role="alert">Email address is required</span>

<!-- Expandable / collapsible -->
<button aria-expanded="false" aria-controls="order-details">
  Show details
</button>
<div id="order-details" hidden>...</div>

<!-- Icon-only buttons -->
<button aria-label="Close dialog">
  <svg aria-hidden="true" focusable="false">...</svg>
</button>

<!-- Modals -->
<div role="dialog" aria-modal="true" aria-labelledby="dialog-title">
  <h2 id="dialog-title">Confirm Deletion</h2>
  ...
</div>

<!-- Progress / loading bars -->
<progress aria-label="Loading orders" value="60" max="100"></progress>
```

---

## Keyboard Navigation

All users must be able to use the application using only a keyboard.

| Component | Required Keyboard Behaviour |
|---|---|
| Button | `Enter` and `Space` activate |
| Link | `Enter` activates |
| Dropdown menu | `Arrow keys` navigate, `Escape` closes, `Enter` selects |
| Modal dialog | `Tab` cycles within modal, `Escape` closes, focus trapped inside |
| Data table | `Tab` to table, arrow keys between cells |
| Tabs | `Arrow keys` switch tabs, `Tab` moves to tab panel content |
| Date picker | `Arrow keys` navigate calendar, `Enter` selects |
| Select / combobox | `Arrow keys` navigate options, `Escape` closes |

```typescript
// Trap focus inside modal — example utility
function trapFocus(element: HTMLElement) {
  const focusable = element.querySelectorAll<HTMLElement>(
    'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
  );
  const first = focusable[0];
  const last  = focusable[focusable.length - 1];

  element.addEventListener('keydown', (e: KeyboardEvent) => {
    if (e.key !== 'Tab') return;
    if (e.shiftKey) {
      if (document.activeElement === first) { e.preventDefault(); last.focus(); }
    } else {
      if (document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });
}
```

---

## Colour and Contrast

- **Text contrast ratio**: minimum **4.5:1** for normal text, **3:1** for large text (18pt+ or 14pt bold)
- **UI component contrast**: minimum **3:1** for borders, icons, focus rings
- **Never use colour alone** to convey meaning — pair with text, icon, or pattern

```html
<!-- ❌ Colour alone — inaccessible -->
<span style="color: red">Error</span>

<!-- ✅ Colour + icon + text -->
<span class="error">
  <svg aria-hidden="true"><!-- error icon --></svg>
  Error: Email is required
</span>
```

---

## Images and Media

```html
<!-- ✅ Meaningful image — describe what it conveys -->
<img src="order-status.png" alt="Order #1234 status: Shipped on 15 Jan" />

<!-- ✅ Decorative image — empty alt, no role -->
<img src="background-pattern.png" alt="" />

<!-- ✅ SVG icon used inline — hidden from screen readers -->
<svg aria-hidden="true" focusable="false">...</svg>

<!-- ✅ SVG with meaning — labelled -->
<svg role="img" aria-label="Revenue trending upward">...</svg>

<!-- ✅ Video — captions required -->
<video controls>
  <track kind="captions" src="captions.vtt" srclang="en" label="English" />
</video>
```

---

## Testing Accessibility

Before shipping any component:

- [ ] Tab through the component — every interactive element is reachable in a logical order
- [ ] Screen reader test (VoiceOver / NVDA / JAWS) — all content announced correctly
- [ ] Check colour contrast — use browser DevTools or axe extension
- [ ] Test with keyboard only — no mouse — entire flow completable
- [ ] Run `axe-core` or Lighthouse accessibility audit — zero critical violations
- [ ] Zoom to 200% — content still readable, no horizontal scroll on 1280px viewport
