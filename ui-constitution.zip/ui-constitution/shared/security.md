# UI — Security Standards
> All frameworks. Load for any component that handles user input or displays external data.

---

## ⚠️ Ask First

- Does this component display data from an external source or user input? → XSS rules apply
- Does this component handle authentication tokens or sensitive data? → Token storage rules apply
- Does this component make API calls? → CORS and header rules apply

---

## XSS Prevention — Never Render Raw HTML

```typescript
// ❌ NEVER — allows XSS injection
element.innerHTML = userInput;                    // Vanilla JS
this.el.nativeElement.innerHTML = data;           // Angular
<div dangerouslySetInnerHTML={{ __html: data }} />// React
<div v-html="data" />                             // Vue

// ✅ Use framework text binding — it escapes automatically
// Angular:
<span>{{ userContent }}</span>
// React:
<span>{userContent}</span>
// Vue:
<span>{{ userContent }}</span>

// ✅ If rich text IS required — sanitise FIRST, then bind
import DOMPurify from 'dompurify';
const clean = DOMPurify.sanitize(richTextFromServer, {
  ALLOWED_TAGS: ['p','b','i','em','strong','a','ul','ol','li'],
  ALLOWED_ATTR: ['href'],
});
// Then and only then use innerHTML / v-html / dangerouslySetInnerHTML
```

---

## Token Storage — Never localStorage

```typescript
// ❌ localStorage is accessible via XSS — never store tokens here
localStorage.setItem('accessToken', token);
sessionStorage.setItem('user', JSON.stringify(user));

// ✅ Access tokens: httpOnly cookies (set by the server, invisible to JS)
// The server sets: Set-Cookie: access_token=xxx; HttpOnly; Secure; SameSite=Strict

// ✅ Non-sensitive UI state only in localStorage
localStorage.setItem('theme', 'dark');           // OK — not sensitive
localStorage.setItem('sidebarCollapsed', 'true');// OK — not sensitive

// ✅ In-memory for session-lived values
// Store in React state, Angular service, Vue reactive ref — cleared on tab close
```

---

## Environment Variables — Never Hardcode

```typescript
// ❌ Never hardcode API URLs, client IDs, or keys
const apiUrl = 'https://api.company.com';
const clientId = 'abc123def456';

// ✅ Angular — environment files
// src/environments/environment.ts
export const environment = { apiUrl: 'http://localhost:3000', production: false };
// src/environments/environment.prod.ts
export const environment = { apiUrl: 'https://api.company.com', production: true };

// ✅ React / Vite (Vue, Next.js SPA mode)
const apiUrl = import.meta.env.VITE_API_URL;     // must start with VITE_

// ✅ Next.js — server-only (never exposed to browser)
const secret = process.env.SECRET_KEY;           // no NEXT_PUBLIC_ prefix
// ✅ Next.js — safe for browser
const apiUrl = process.env.NEXT_PUBLIC_API_URL;  // NEXT_PUBLIC_ prefix required

// ✅ jQuery / vanilla — injected at build time or from server-rendered meta tag
const apiUrl = document.querySelector('meta[name="api-url"]')?.getAttribute('content');
```

---

## Console — Never Log Sensitive Data

```typescript
// ❌ Never log tokens, passwords, or PII
console.log('User:', user);             // contains email, name
console.log('Response:', apiResponse);  // may contain tokens
console.log('Token:', accessToken);     // direct token exposure

// ✅ Log only what is safe and needed for debugging
console.log('Order loaded:', order.id);
console.error('API error:', error.status, error.message);

// ✅ Strip console.log in production builds
// Vite / webpack: minification removes console.log automatically when configured
// Angular: use environment.production guard
if (!environment.production) {
  console.log('Debug info:', ...);
}
```

---

## Input Validation — Client Side Is Not Enough

```typescript
// ✅ Always validate on the server — client validation is UX, not security
// ✅ Client-side validation for immediate feedback only

// ✅ Never trust input type="number" to guarantee a number
const value = parseFloat(input.value);
if (isNaN(value)) { /* handle */ }

// ✅ Sanitise URL inputs before navigation
function safeRedirect(url: string): void {
  try {
    const parsed = new URL(url);
    // Only allow same-origin or known safe origins
    const ALLOWED_ORIGINS = ['https://app.company.com'];
    if (parsed.origin === window.location.origin ||
        ALLOWED_ORIGINS.includes(parsed.origin)) {
      window.location.href = url;
    }
  } catch {
    // Invalid URL — do not navigate
  }
}

// ❌ Never construct URLs from user input without validation
window.location.href = userInput; // open redirect vulnerability
```

---

## Content Security Policy

Set via HTTP response headers (not meta tags — they can be bypassed):

```
Content-Security-Policy:
  default-src 'self';
  script-src 'self';
  style-src 'self' 'unsafe-inline';
  img-src 'self' data: https://cdn.company.com;
  connect-src 'self' https://api.company.com;
  font-src 'self';
  frame-ancestors 'none';
```

Rules:
- No `unsafe-eval` — prevents `eval()` and `new Function()`
- No `unsafe-inline` for scripts — use nonce or hash if inline scripts needed
- `frame-ancestors 'none'` — prevents clickjacking

---

## CSRF Protection

- All state-mutating requests (POST/PUT/PATCH/DELETE) must include a CSRF token
- Use `SameSite=Strict` or `SameSite=Lax` on session cookies
- The CSRF token is sent in a request header (not a cookie): `X-CSRF-Token: {token}`

```typescript
// ✅ Include CSRF token on all mutating requests
async function apiPost(url: string, body: unknown) {
  const csrfToken = document.querySelector<HTMLMetaElement>('meta[name="csrf-token"]')?.content;
  return fetch(url, {
    method: 'POST',
    credentials: 'include',  // include cookies
    headers: {
      'Content-Type': 'application/json',
      'X-CSRF-Token': csrfToken ?? '',
    },
    body: JSON.stringify(body),
  });
}
```
