# jQuery — UI Constitution CORE
> Version: 1.0 | Load before generating any jQuery code, plugin, or DOM manipulation.

---

## ⚠️ Rule Zero — Ask Before You Build

- [ ] jQuery version? (3.x is current — 1.x/2.x lack security patches. Confirm before writing code.)
- [ ] Is this a new build or maintaining legacy code? (If new: strongly recommend React/Vue instead. If the team insists on jQuery, proceed with these standards.)
- [ ] Is the page server-rendered? (Django / PHP / Rails / ASP.NET templates)
- [ ] Which module system? (ES Modules / CommonJS / no bundler — affects import syntax)
- [ ] Is there a bundler? (Webpack / Vite / none — affects plugin inclusion)
- [ ] What backend renders the HTML? (Affects CSRF token approach)

---

## Cardinal Rules

### 1. Cache Every Selector — Never Re-Query the DOM
```javascript
// ❌ Queries the DOM on every call — slow and fragile
function updateStatus(id, status) {
  $('#order-' + id + ' .status').text(status);
  $('#order-' + id + ' .status').addClass('updated');
  $('#order-' + id + ' .badge').show();
}

// ✅ Cache the selector — one query, multiple uses
function updateStatus(id, status) {
  const $order  = $('#order-' + id);
  const $status = $order.find('.status');
  const $badge  = $order.find('.badge');
  $status.text(status).addClass('updated');
  $badge.show();
}

// ✅ Cache on page load for elements that always exist
const $orderList  = $('#order-list');
const $searchInput = $('#search-input');
const $submitBtn   = $('#submit-btn');
```

### 2. Event Delegation for Dynamic Content
```javascript
// ❌ Direct binding — does not work for elements added after page load
$('.order-delete-btn').on('click', handleDelete);  // misses dynamically-added rows

// ✅ Event delegation — binds once to stable ancestor, works for future elements
$(document).on('click', '.order-delete-btn', handleDelete);
// Or better — bind to closest stable container, not document
$('#order-list').on('click', '.order-delete-btn', handleDelete);
```

### 3. Namespace All Events to Prevent Conflicts
```javascript
// ❌ Unnamespaced events — impossible to remove selectively
$(window).on('resize', updateLayout);
$(window).off('resize');  // removes ALL resize handlers, including third-party!

// ✅ Namespaced events — removable without affecting others
$(window).on('resize.orderModule', updateLayout);
$(window).off('resize.orderModule');  // removes only your handler

// ✅ Namespace pattern: {moduleName}.{context}
$('#order-form').on('submit.orders', handleSubmit);
$('#order-form').on('input.orders', validateField);
// Remove all handlers from your module at once:
$('#order-form').off('.orders');
```

### 4. Use the Module Pattern — No Global Variables
```javascript
// ❌ Global variables — pollutes window, causes conflicts
var orders = [];
var currentPage = 1;
function fetchOrders() { ... }

// ✅ IIFE module pattern — private scope
const OrderModule = (function($) {
  'use strict';

  // Private state
  let orders      = [];
  let currentPage = 1;
  let $list;

  // Private functions
  function renderOrders(data) { ... }

  // Public API
  return {
    init() {
      $list = $('#order-list');
      $list.on('click.orders', '.delete-btn', handleDelete);
      loadOrders();
    },
    destroy() {
      $list.off('.orders');
    },
  };
})(jQuery);

// Initialise on DOM ready
$(function() {
  OrderModule.init();
});
```

### 5. Use `$.ajax` or `fetch` — Never Synchronous XHR
```javascript
// ❌ Synchronous — blocks the browser thread
const xhr = new XMLHttpRequest();
xhr.open('GET', '/api/orders', false);  // false = synchronous
xhr.send();

// ✅ Deferred-based $.ajax
function fetchOrders() {
  return $.ajax({
    url:      '/api/orders',
    method:   'GET',
    headers:  { 'X-CSRF-Token': getCsrfToken() },
    dataType: 'json',
  })
  .done(function(data)  { renderOrders(data); })
  .fail(function(xhr)   { showError(xhr.responseJSON?.message); })
  .always(function()    { hideSpinner(); });
}

// ✅ Modern fetch (works alongside jQuery — no conflict)
async function fetchOrders() {
  const response = await fetch('/api/orders', {
    headers: { 'X-CSRF-Token': getCsrfToken() },
    credentials: 'include',
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.json();
}
```

### 6. Manipulate Classes — Never Inline Styles
```javascript
// ❌ Inline styles — hard to override, not maintainable
$('.order-card').css({ color: 'red', fontWeight: 'bold' });
$('.order-card').css('display', 'none');

// ✅ CSS classes — separation of concerns
$('.order-card').addClass('order-card--error');
$('.order-card').hide();       // only for show/hide — uses display
$('.order-card').toggleClass('order-card--expanded', isExpanded);
```

### 7. Detach Heavy DOM Manipulation from the Live Document
```javascript
// ❌ 1,000 DOM insertions — reflows on every append
$.each(orders, function(_, order) {
  $('#order-list').append('<li>' + order.name + '</li>');
});

// ✅ Build a fragment, append once
const $fragment = $('<ul>');
$.each(orders, function(_, order) {
  $fragment.append($('<li>').text(order.name));  // .text() escapes XSS
});
$('#order-list').empty().append($fragment);

// ✅ Or detach, manipulate, re-attach
const $list = $('#order-list').detach();
// ... many manipulations ...
$('body').append($list);
```

### 8. Escape Output — `.text()` Not `.html()` for User Data
```javascript
// ❌ XSS vulnerability
$('#user-name').html(userInput);              // executes scripts
$('#error-msg').html(serverErrorMessage);     // server data = untrusted

// ✅ .text() escapes HTML entities automatically
$('#user-name').text(userInput);
$('#error-msg').text(serverErrorMessage);

// ✅ If HTML structure is required — build with jQuery methods, not string concat
const $card = $('<div class="order-card">')
  .append($('<h3>').text(order.reference))   // .text() on every user value
  .append($('<p>').text(order.status));
$('#order-list').append($card);

// ❌ String concatenation — open to XSS
$('#order-list').append('<li>' + order.name + '</li>');
```

---

## jQuery Plugin Pattern (when writing reusable plugins)

```javascript
// ✅ Correct plugin pattern
(function($) {
  'use strict';

  const PLUGIN_NAME = 'orderCard';
  const defaults = {
    selectable: true,
    onSelect:   function() {},
  };

  function OrderCard($el, options) {
    this.$el    = $el;
    this.options = $.extend({}, defaults, options);
    this._init();
  }

  OrderCard.prototype = {
    _init() {
      this.$el.on('click.' + PLUGIN_NAME, this._onClick.bind(this));
    },
    _onClick() {
      this.$el.toggleClass('order-card--selected');
      this.options.onSelect.call(this.$el[0]);
    },
    destroy() {
      this.$el.off('.' + PLUGIN_NAME);
      this.$el.removeData(PLUGIN_NAME);
    },
  };

  $.fn[PLUGIN_NAME] = function(options) {
    return this.each(function() {
      const $el = $(this);
      if (!$el.data(PLUGIN_NAME)) {
        $el.data(PLUGIN_NAME, new OrderCard($el, options));
      }
    });
  };

})(jQuery);

// Usage
$('.order-card').orderCard({ onSelect: function() { ... } });
// Destroy
$('.order-card').data('orderCard').destroy();
```

---

## AJAX Error Handling Standard

```javascript
// Global AJAX setup — set once, applies to all $.ajax calls
$.ajaxSetup({
  headers:     { 'X-Requested-With': 'XMLHttpRequest' },
  contentType: 'application/json',
  dataType:    'json',
});

// Global error handler for auth failures
$(document).on('ajaxError', function(event, xhr) {
  if (xhr.status === 401) window.location.href = '/login';
  if (xhr.status === 403) showError('You do not have permission to do this.');
  if (xhr.status === 500) showError('Server error. Please try again.');
});

// Per-request error handling for specific cases
$.ajax({ url: '/api/orders' })
  .done(renderOrders)
  .fail(function(xhr) {
    const message = xhr.responseJSON?.message ?? 'Could not load orders.';
    showError(message);
  });
```

---

## File Structure (Server-Rendered App)

```
/static/js/
  /modules/
    orders.js          ← OrderModule IIFE
    customers.js
    reports.js
  /plugins/
    order-card.js      ← reusable jQuery plugin
    data-table.js
  /shared/
    api.js             ← $.ajax wrapper with CSRF + error handling
    utils.js           ← formatCurrency, formatDate, etc.
    validation.js      ← form validation helpers
  app.js               ← bootstraps modules on DOM ready
```

---

## Generation Checklist

- [ ] All selectors cached in variables with `$` prefix
- [ ] Dynamic content uses event delegation, not direct binding
- [ ] All events namespaced with module name (e.g. `.orders`)
- [ ] No global variables — IIFE module pattern used
- [ ] No synchronous XHR — `$.ajax()` or `fetch()` only
- [ ] No inline styles — CSS class manipulation only
- [ ] `.text()` used for all user-supplied content (not `.html()`)
- [ ] CSRF token included in all non-GET AJAX requests
- [ ] Large DOM builds use detach or fragment
- [ ] Plugin follows standard plugin pattern with `destroy()` method
- [ ] Loading state shown before AJAX, hidden in `.always()`
- [ ] Error state handled in `.fail()` — not silently swallowed
- [ ] DOM ready wrapped in `$(function() { ... })` not `$(document).ready()`
