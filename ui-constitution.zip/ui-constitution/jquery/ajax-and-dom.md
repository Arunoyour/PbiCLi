# jQuery — AJAX, DOM Patterns & Validation

---

## AJAX Wrapper — Use This, Not Raw $.ajax Every Time

```javascript
// shared/api.js — central AJAX wrapper
const Api = (function($) {
  'use strict';

  function getCsrfToken() {
    return $('meta[name="csrf-token"]').attr('content') ?? '';
  }

  function request(method, url, data) {
    const options = {
      url,
      method:      method.toUpperCase(),
      contentType: 'application/json',
      dataType:    'json',
      headers:     { 'X-CSRF-Token': getCsrfToken() },
    };
    if (data) options.data = JSON.stringify(data);
    return $.ajax(options);
  }

  return {
    get:    url          => request('GET',    url),
    post:   (url, data)  => request('POST',   url, data),
    put:    (url, data)  => request('PUT',    url, data),
    patch:  (url, data)  => request('PATCH',  url, data),
    delete: url          => request('DELETE', url),
  };
})(jQuery);

// Usage
Api.get('/api/orders')
  .done(renderOrders)
  .fail(handleError);

Api.post('/api/orders', { reference: 'ORD-001', amount: 250 })
  .done(order => appendOrderRow(order))
  .fail(handleError);
```

---

## Loading State — Always Shown During AJAX

```javascript
// shared/utils.js — spinner helpers
const Spinner = (function($) {
  const $spinner = $('#page-spinner');  // global spinner element

  return {
    show() { $spinner.removeClass('hidden').attr('aria-hidden', 'false'); },
    hide() { $spinner.addClass('hidden').attr('aria-hidden', 'true'); },
  };
})(jQuery);

// Usage — always show/hide around AJAX
function loadOrders() {
  Spinner.show();
  Api.get('/api/orders')
    .done(renderOrders)
    .fail(showApiError)
    .always(Spinner.hide.bind(Spinner));  // hide in always — even on error
}
```

---

## DOM Rendering — Safe and Efficient

```javascript
// ✅ Render a list of orders safely (no XSS, one DOM update)
function renderOrders(orders) {
  const $list = $('#order-list');

  if (!orders.length) {
    $list.html('<li class="empty-state">No orders found</li>');
    return;
  }

  const $fragment = $('<ul>');
  orders.forEach(function(order) {
    $fragment.append(buildOrderRow(order));
  });

  $list.empty().append($fragment);
}

function buildOrderRow(order) {
  // ✅ .text() for all user data — escapes HTML automatically
  return $('<li class="order-row">')
    .attr('data-id', order.id)
    .append(
      $('<span class="order-ref">').text(order.reference),
      $('<span class="order-status">').text(order.status),
      $('<span class="order-amount">').text(formatCurrency(order.amount)),
      $('<button class="delete-btn" type="button">')
        .text('Delete')
        .attr('aria-label', 'Delete order ' + order.reference)
    );
}
```

---

## Form Validation

```javascript
// shared/validation.js
const Validate = (function($) {
  'use strict';

  function showError($input, message) {
    const errorId = $input.attr('id') + '-error';
    let $error = $('#' + errorId);

    if (!$error.length) {
      $error = $('<span class="field-error" role="alert">')
        .attr('id', errorId);
      $input.after($error);
    }

    $error.text(message);
    $input.addClass('input--error').attr('aria-invalid', 'true')
          .attr('aria-describedby', errorId);
  }

  function clearError($input) {
    const errorId = $input.attr('id') + '-error';
    $('#' + errorId).remove();
    $input.removeClass('input--error')
          .removeAttr('aria-invalid aria-describedby');
  }

  function validateRequired($input) {
    if (!$input.val().trim()) {
      showError($input, $input.data('label') + ' is required');
      return false;
    }
    clearError($input);
    return true;
  }

  function validateEmail($input) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test($input.val())) {
      showError($input, 'Enter a valid email address');
      return false;
    }
    clearError($input);
    return true;
  }

  return { showError, clearError, validateRequired, validateEmail };
})(jQuery);

// Usage in form module
const OrderForm = (function($, Api, Validate) {
  'use strict';

  let $form, $submitBtn;

  function init() {
    $form      = $('#create-order-form');
    $submitBtn = $form.find('[type="submit"]');

    // Validate on blur (not on every keystroke)
    $form.on('blur.orderForm', '[required]', function() {
      Validate.validateRequired($(this));
    });

    $form.on('submit.orderForm', handleSubmit);
  }

  function handleSubmit(e) {
    e.preventDefault();

    let isValid = true;
    $form.find('[required]').each(function() {
      if (!Validate.validateRequired($(this))) isValid = false;
    });
    if (!isValid) return;

    const data = {
      reference: $('#reference').val(),
      amount:    parseFloat($('#amount').val()),
    };

    $submitBtn.prop('disabled', true).text('Creating...');

    Api.post('/api/orders', data)
      .done(function(order) { appendOrderRow(order); $form[0].reset(); })
      .fail(function(xhr)   { showFormError(xhr.responseJSON?.message); })
      .always(function()    { $submitBtn.prop('disabled', false).text('Create Order'); });
  }

  function showFormError(message) {
    let $alert = $form.find('.form-error-alert');
    if (!$alert.length) {
      $alert = $('<div class="form-error-alert" role="alert">').prependTo($form);
    }
    $alert.text(message ?? 'An error occurred. Please try again.');
  }

  return { init };
})(jQuery, Api, Validate);

$(function() { OrderForm.init(); });
```

---

## Common Anti-Patterns to Avoid

```javascript
// ❌ Multiple document.ready calls — unpredictable order
$(document).ready(function() { ... });
$(document).ready(function() { ... });
// ✅ One $(function() { ... }) entry point per module

// ❌ Selector in a loop — DOM hit every iteration
for (let i = 0; i < 100; i++) {
  $('#order-' + i).addClass('processed');  // 100 DOM queries
}
// ✅ Cache or select once
$('[id^="order-"]').addClass('processed');

// ❌ .html() with untrusted data
$('#message').html(response.message);  // XSS if message contains <script>
// ✅
$('#message').text(response.message);

// ❌ Unbounded document event listener
$(document).on('click', handleClick);  // fires on EVERY click on the page
// ✅ Scope to a container
$('#order-panel').on('click', '.action-btn', handleClick);

// ❌ $.each when native forEach works and is faster
$.each(orders, function(index, order) { ... });
// ✅
orders.forEach(order => { ... });

// ❌ Deprecated methods (jQuery 3.x removed these)
$.parseJSON(jsonString);   // use JSON.parse()
$.type(value);             // use typeof / Array.isArray()
.success()  .error()       // use .done()  .fail()
.live()  .die()            // use .on()  .off() with delegation
```
