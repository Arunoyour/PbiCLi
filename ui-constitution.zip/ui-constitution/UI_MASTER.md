# UI Layer Constitution — Master Orchestrator
> Version: 1.0 | Load this file FIRST before generating any UI code regardless of framework.

---

## ⚠️ Rule Zero — Ask Before You Build

Stop and ask the user if any of the following are missing:

- [ ] **Which framework?** Angular / React / Vue.js / Next.js / jQuery — never assume
- [ ] **What is the component's single responsibility?** If you cannot state it in one sentence, the design is wrong
- [ ] **What data does this component need and where does it come from?** API call / store / props / context
- [ ] **What user interactions must it handle?** Every click, submit, error state, and loading state
- [ ] **What are the accessibility requirements?** Screen reader labels, keyboard nav, ARIA roles
- [ ] **What is the error state?** Every component that fetches data must have one
- [ ] **What is the loading state?** Never render partial data without a loading indicator
- [ ] **Is there an empty state?** What shows when a list has zero items?
- [ ] **What breakpoints / responsive behaviour is required?**
- [ ] **Are there any PII or sensitive fields?** Never log or expose to DevTools

**Never invent component names, API endpoints, store slice names, or route paths.**
**Never assume a framework version — check `workspace.config.md` first.**

---

## Constitution File Map

```
/ui-constitution/
  UI_MASTER.md                     ← this file
  /shared/
    naming.md                      ← naming conventions (all frameworks)
    accessibility.md               ← WCAG 2.1 AA standards
    security.md                    ← XSS, CSP, sensitive data (all frameworks)
    api-integration.md             ← how UI calls the API layer
  /angular/
    CORE.md                        ← cardinal rules + checklist
    components.md                  ← smart/dumb, lifecycle, templates
    services-and-state.md          ← services, signals, RxJS
    forms.md                       ← reactive forms, validation
  /react/
    CORE.md
    components.md                  ← functional components, composition
    hooks-and-state.md             ← hooks, TanStack Query, Zustand
    forms.md                       ← React Hook Form, Zod
  /vue/
    CORE.md
    components.md                  ← SFC, Composition API, script setup
    composables-and-state.md       ← composables, Pinia
    forms.md                       ← VeeValidate, Zod
  /nextjs/
    CORE.md
    routing-and-rendering.md       ← App Router, RSC, SSR/SSG/ISR
    data-and-state.md              ← Server Actions, fetch caching, Zustand
    forms.md                       ← Server Actions forms, React Hook Form
  /jquery/
    CORE.md
    dom-and-events.md              ← selectors, delegation, caching
    ajax-and-data.md               ← $.ajax, fetch, error handling
    plugins-and-modules.md         ← plugin pattern, module pattern
```

---

## Step 1 — Load Framework CORE.md

| Framework | Load First |
|---|---|
| Angular | `/angular/CORE.md` |
| React | `/react/CORE.md` |
| Vue.js | `/vue/CORE.md` |
| Next.js | `/nextjs/CORE.md` (builds on `/react/CORE.md`) |
| jQuery | `/jquery/CORE.md` |

Always also load `/shared/security.md` for any component that handles user input or displays external data.

---

## Step 2 — Universal Rules (All Frameworks)

These apply regardless of which framework is in use.

### Component Design
- **One responsibility per component.** If it does two things, split it.
- **Name components for what they render, not what they do.** `UserCard` not `UserManager`.
- **Keep components small.** If a component file exceeds 250 lines, decompose it.
- **Separate data-fetching from display.** Container/Presenter or equivalent pattern.

### State
- **Server state ≠ client state.** Use the right tool for each (see framework-specific files).
- **Derive, don't duplicate.** If a value can be computed from existing state, compute it. Never store derived values.
- **State lives at the lowest level that shares it.** Lift only when necessary.

### Forms
- **Every field has a label.** No placeholder-as-label.
- **Validation fires on blur first, then on change after first error.**
- **Submit button shows loading state during async submission.**
- **Error messages are specific.** "Email is required" not "Invalid input".

### API Integration
- **Every API call has three states: loading / success / error.** Handle all three.
- **Never expose API keys or tokens in client-side code.**
- **Requests are cancellable** where the framework allows (AbortController / RxJS unsubscribe).
- **See `/shared/api-integration.md` for error handling patterns.**

### Accessibility (minimum — see `/shared/accessibility.md` for full requirements)
- All interactive elements are keyboard-reachable.
- All images have descriptive `alt` text (or `alt=""` if decorative).
- Focus is managed on route changes and modal open/close.
- Colour is never the sole differentiator.

### Security (minimum — see `/shared/security.md` for full requirements)
- Never use `innerHTML`, `dangerouslySetInnerHTML`, `v-html`, or `[innerHTML]` with unsanitised data.
- Never store tokens in `localStorage` — use `httpOnly` cookies.
- Never log user input or API responses containing PII to the console.

---

## Step 3 — Generation Checklist (All Frameworks)

Before delivering any UI output, confirm:

- [ ] Component has a single, stateable responsibility
- [ ] Loading state rendered — not just success path
- [ ] Error state rendered — not just success path
- [ ] Empty state rendered (if component shows a list or async data)
- [ ] All form fields have `<label>` elements
- [ ] No hardcoded API URLs — read from environment config
- [ ] No `any` type (TypeScript projects) without explicit justification
- [ ] No secrets or tokens in component code
- [ ] `key` prop on every list item (React / Vue)
- [ ] `alt` text on every `<img>`
- [ ] Component is keyboard-navigable
- [ ] `aria-label` or `aria-labelledby` on all icon buttons
- [ ] Console is clean — no warnings in dev mode

---

## Version History

| Version | Date | Summary |
|---|---|---|
| 1.0 | 2025-01 | Initial release — all 5 frameworks |
