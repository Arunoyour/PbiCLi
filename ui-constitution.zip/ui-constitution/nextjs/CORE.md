# Next.js — UI Constitution CORE
> Version: 1.0 | Load alongside `/react/CORE.md`. Next.js is React — all React rules apply here too.

---

## ⚠️ Rule Zero — Ask Before You Build

- [ ] Next.js version? (14+ with App Router is default)
- [ ] App Router or Pages Router? (App Router for new projects — they work differently)
- [ ] Is this a Server Component or Client Component? (Default is Server Component — ask before adding `"use client"`)
- [ ] What is the rendering strategy? SSR / SSG / ISR / CSR — confirm per route
- [ ] Is there sensitive data that must NOT be sent to the client? (Server-only rules apply)
- [ ] What deployment target? (Vercel / self-hosted / Docker)
- [ ] Is this using Server Actions or a separate API layer?

---

## Cardinal Rules

### 1. Server Components by Default — `"use client"` Only When Needed
```tsx
// ✅ Server Component (no directive — default)
// Runs on server. Can: await, access DB directly, read env vars.
// Cannot: useState, useEffect, browser APIs, event handlers.
async function OrderList() {
  const orders = await db.orders.findMany(); // direct DB access in Server Component
  return (
    <ul>
      {orders.map(o => <OrderCard key={o.id} order={o} />)}
    </ul>
  );
}

// ✅ Client Component — only when interactivity is needed
"use client";
// Runs in browser. Can: useState, useEffect, event handlers.
// Cannot: async at component level, direct DB access.
function OrderFilterPanel() {
  const [filter, setFilter] = useState('');
  return <input value={filter} onChange={e => setFilter(e.target.value)} />;
}
```

**Rule: Push `"use client"` as far DOWN the component tree as possible.** A single interactive button inside a large Server Component should be extracted as a tiny Client Component — not the entire component.

### 2. Server Actions for Mutations (App Router)
```tsx
// ✅ Server Action — runs on server, called from Client Component or form
// app/actions/orderActions.ts
'use server';
import { db } from '@/lib/db';
import { revalidatePath } from 'next/cache';

export async function createOrder(formData: FormData) {
  const data = {
    reference: formData.get('reference') as string,
    amount:    Number(formData.get('amount')),
  };
  await db.orders.create({ data });
  revalidatePath('/orders');
}

// Client Component consuming it
'use client';
import { createOrder } from '@/app/actions/orderActions';

function CreateOrderForm() {
  return (
    <form action={createOrder}>  {/* No API route needed */}
      <input name="reference" />
      <input name="amount" type="number" />
      <button type="submit">Create</button>
    </form>
  );
}
```

### 3. Use `next/image` for All Images
```tsx
// ❌ Plain <img> — no optimisation, no lazy loading, LCP hurt
<img src="/hero.png" width={800} height={600} alt="Hero" />

// ✅ next/image — auto-optimised, lazy loaded, responsive
import Image from 'next/image';
<Image src="/hero.png" width={800} height={600} alt="Hero" priority />
// priority — only on above-the-fold images
```

### 4. Use `next/font` — Never CDN Font Links
```tsx
// ❌ CDN link in <head> — layout shift, external request
<link href="https://fonts.googleapis.com/css?family=Inter" rel="stylesheet" />

// ✅ next/font — zero layout shift, self-hosted, tree-shaken
import { Inter } from 'next/font/google';
const inter = Inter({ subsets: ['latin'], display: 'swap' });
// Apply to root layout: className={inter.className}
```

### 5. Never Access Environment Secrets in Client Components
```typescript
// ❌ NEXT_PUBLIC_ prefix exposes to browser bundle — never for secrets
process.env.NEXT_PUBLIC_DATABASE_URL   // anyone can see this in DevTools
process.env.NEXT_PUBLIC_SECRET_KEY     // exposed to every user

// ✅ No prefix = server-only (throws if accessed in Client Component)
process.env.DATABASE_URL               // only on server
process.env.API_SECRET_KEY             // only on server

// ✅ NEXT_PUBLIC_ only for genuinely public values
process.env.NEXT_PUBLIC_APP_URL        // OK — not secret
process.env.NEXT_PUBLIC_ANALYTICS_ID  // OK — public tracking ID
```

### 6. Choose the Right Rendering Strategy Per Route
```tsx
// SSG — build time (default for pages with no dynamic data)
// Perfect for: marketing pages, blog posts, docs
// Limitation: stale until next build

// ISR — incremental static regeneration
export const revalidate = 3600; // revalidate page every 1 hour
// Perfect for: product pages, news articles

// SSR — every request, always fresh
export const dynamic = 'force-dynamic';
// Perfect for: dashboards with personalised data, real-time

// CSR — fully client-rendered (use TanStack Query for fetching)
'use client';
// Perfect for: highly interactive UIs, user-specific data after initial load
```

### 7. `loading.tsx` and `error.tsx` Are Required for Every Route Segment
```
/app/orders/
  page.tsx         ← the main content
  loading.tsx      ← shown while page.tsx is loading (React Suspense)
  error.tsx        ← shown when page.tsx throws
  not-found.tsx    ← shown when notFound() is called
```

### 8. Type `params` and `searchParams` Explicitly
```tsx
// ✅ App Router — typed page props
interface OrderDetailPageProps {
  params:      { id: string };
  searchParams: { tab?: string };
}

export default async function OrderDetailPage({
  params, searchParams
}: OrderDetailPageProps) {
  const order = await fetchOrder(params.id);
  // ...
}
```

---

## Routing Conventions (App Router)

```
/app/
  layout.tsx            ← root layout (html + body)
  page.tsx              ← home page  (/)
  loading.tsx           ← root loading state
  error.tsx             ← root error boundary
  /orders/
    page.tsx            ← /orders
    loading.tsx
    error.tsx
    /[id]/
      page.tsx          ← /orders/:id
      /edit/
        page.tsx        ← /orders/:id/edit
  /api/
    /orders/
      route.ts          ← GET/POST /api/orders
    /orders/[id]/
      route.ts          ← GET/PUT/DELETE /api/orders/:id
```

---

## File Structure

```
/src/ (or root if no src/)
  /app/                     ← App Router pages and layouts
    /orders/
      page.tsx
      loading.tsx
      error.tsx
    /api/                   ← API route handlers
  /components/
    /ui/                    ← shadcn/ui components or custom atoms
    /layout/                ← shells (DashboardLayout, etc.)
  /features/
    /orders/                ← co-located feature code
      OrderList.tsx         ← Client Component
      OrderCard.tsx         ← Server Component (can be)
      useOrders.ts          ← TanStack Query hook (client-side fetching)
      orderActions.ts       ← Server Actions
      orderApi.ts           ← API client (used in Server Components)
  /lib/
    db.ts                   ← Prisma / database client
    auth.ts                 ← NextAuth config
  /types/                   ← shared TypeScript types
```

---

## Generation Checklist

- [ ] `"use client"` added ONLY when interactivity is actually needed
- [ ] Server Components `await` data directly — no `useEffect`, no TanStack Query
- [ ] Client Components use TanStack Query for server state (not `useEffect + fetch`)
- [ ] `loading.tsx` exists for every route with async data
- [ ] `error.tsx` exists for every route
- [ ] All images use `next/image`
- [ ] All fonts use `next/font`
- [ ] No secrets in `NEXT_PUBLIC_` env variables
- [ ] `revalidate` or `dynamic` export set intentionally per route
- [ ] Server Actions have `'use server'` directive
- [ ] `revalidatePath()` or `revalidateTag()` called after mutations
- [ ] `params` typed explicitly in page components
- [ ] `type="button"` on non-submit buttons inside Client Component forms
