# Next.js — Data Fetching, Server Actions & Forms

---

## Server Component Data Fetching

```tsx
// app/orders/page.tsx — Server Component (default)
import { Suspense } from 'react';
import { db } from '@/lib/db';
import { OrderList } from '@/features/orders/OrderList';
import { OrderListSkeleton } from '@/features/orders/OrderListSkeleton';

// This runs on the server — direct DB access, no API round-trip
async function OrdersPage() {
  return (
    <main>
      <h1>Orders</h1>
      <Suspense fallback={<OrderListSkeleton />}>
        <OrdersData />
      </Suspense>
    </main>
  );
}

async function OrdersData() {
  const orders = await db.orders.findMany({
    where:   { status: { not: 'DELETED' } },
    orderBy: { createdAt: 'desc' },
    take:    50,
  });
  return <OrderList orders={orders} />;
}

export default OrdersPage;

// Cache control
export const revalidate = 300; // revalidate every 5 minutes (ISR)
// or: export const dynamic = 'force-dynamic'; // always fresh (SSR)
```

---

## Server Actions — Mutations Without API Routes

```typescript
// app/actions/orderActions.ts
'use server';  // ← marks all exports as Server Actions

import { db } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { z } from 'zod';

const createOrderSchema = z.object({
  reference: z.string().min(3),
  amount:    z.coerce.number().positive(),
});

export async function createOrderAction(
  _prevState: ActionState,
  formData: FormData,
): Promise<ActionState> {
  // Always validate on server — never trust form data
  const result = createOrderSchema.safeParse({
    reference: formData.get('reference'),
    amount:    formData.get('amount'),
  });

  if (!result.success) {
    return {
      success: false,
      errors:  result.error.flatten().fieldErrors,
    };
  }

  try {
    await db.orders.create({ data: result.data });
    revalidatePath('/orders');
    return { success: true };
  } catch (e) {
    return { success: false, errors: { _form: ['Failed to create order'] } };
  }
}

export async function deleteOrderAction(id: string): Promise<void> {
  await db.orders.delete({ where: { id } });
  revalidatePath('/orders');
  // redirect inside try block — throws internally (this is expected behaviour)
  redirect('/orders');
}

interface ActionState {
  success: boolean;
  errors?: Record<string, string[]>;
}
```

---

## Client Component Form Using Server Action

```tsx
// features/orders/CreateOrderForm.tsx
'use client';

import { useActionState } from 'react';  // React 19 / Next.js 14+
import { createOrderAction } from '@/app/actions/orderActions';

const initialState = { success: false };

export function CreateOrderForm() {
  const [state, formAction, isPending] = useActionState(
    createOrderAction,
    initialState,
  );

  return (
    <form action={formAction} noValidate>
      {state.errors?._form && (
        <div role="alert" className="form-error">
          {state.errors._form.join(', ')}
        </div>
      )}

      <div>
        <label htmlFor="reference">Order Reference *</label>
        <input
          id="reference"
          name="reference"
          required
          aria-invalid={Boolean(state.errors?.reference)}
          aria-describedby={state.errors?.reference ? 'reference-error' : undefined}
        />
        {state.errors?.reference && (
          <span id="reference-error" role="alert">
            {state.errors.reference.join(', ')}
          </span>
        )}
      </div>

      <button type="submit" disabled={isPending}>
        {isPending ? 'Creating...' : 'Create Order'}
      </button>
    </form>
  );
}
```

---

## Client-Side Fetching — TanStack Query (when SSR not appropriate)

```typescript
// For user-specific data loaded after interaction, use TanStack Query
// in Client Components — same pattern as React CORE.
'use client';
import { useQuery } from '@tanstack/react-query';

export function OrderFilterResults({ filter }: { filter: string }) {
  const { data, isLoading } = useQuery({
    queryKey: ['orders', 'filtered', filter],
    queryFn:  () => fetch(`/api/orders?status=${filter}`).then(r => r.json()),
    enabled:  Boolean(filter),
  });
  // ...
}
```

---

## API Route Handlers

```typescript
// app/api/orders/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  const status = request.nextUrl.searchParams.get('status');

  const orders = await db.orders.findMany({
    where: status ? { status } : undefined,
    orderBy: { createdAt: 'desc' },
  });

  return NextResponse.json(orders);
}

export async function POST(request: NextRequest) {
  const body = await request.json();
  // Always validate — never trust request body
  const order = await db.orders.create({ data: body });
  return NextResponse.json(order, { status: 201 });
}

// app/api/orders/[id]/route.ts
export async function DELETE(
  _request: NextRequest,
  { params }: { params: { id: string } }
) {
  await db.orders.delete({ where: { id: params.id } });
  return new NextResponse(null, { status: 204 });
}
```

---

## Generation Checklist

- [ ] `'use server'` on all Server Action files
- [ ] `'use client'` only where interactivity or browser APIs are needed
- [ ] Server Actions validate input with Zod — never trust `formData` raw
- [ ] `revalidatePath()` or `revalidateTag()` called after every mutation
- [ ] `Suspense` wrapping async Server Components with `fallback` skeleton
- [ ] `loading.tsx` exists alongside every `page.tsx`
- [ ] `error.tsx` exists alongside every `page.tsx`
- [ ] API route handlers validate input before DB operations
- [ ] `useActionState` used for progressive enhancement forms (not `useState` + `fetch`)
- [ ] `revalidate` or `dynamic` export intentionally set on every `page.tsx`
