# BRD Consolidation — standing rules for Copilot

These rules apply whenever a `/brd-*` prompt or the **BRD Consolidation** agent is used in this workspace.

## 1. One stage per invoke
Run only the stage the user invoked. Present the result, then stop. Never start another stage, even after approval. The user starts every stage by name.

## 2. Always load state first
Chat context is lost between sessions. Before doing anything, read:
1. `brd-work/MEMORY.md` — what we have understood and decided so far
2. `brd-work/STATUS.md` — which stage is in which state

If either file is missing, create it from `brd-playbook/templates/`.

## 3. Ask, do not guess
If information is missing, ambiguous or contradictory, ask the user. Do not fill gaps with assumptions and do not invent requirements.
- Ask in rounds of **at most 5 questions**, most important first.
- Use the `askQuestions` tool when available. If it is not available or does not wait for the user, ask in chat as a numbered list and wait for the reply.
- After every answered round, **update `brd-work/MEMORY.md` and `brd-work/31-decisions-log.md` immediately**, before asking anything else.
- Never treat silence or a vague reply as an answer. Re-ask.

## 3b. Genie first for technical facts
Table, view and stored-procedure information for this project lives in Databricks metadata tables, reachable through the `genie` tool. When you have a doubt that is a **fact** (does an object exist, its columns, what a procedure does, what a column contains), ask Genie first and the human second. Intent and decisions always go to the human.
- Follow `brd-playbook/06-genie-protocol.md` exactly. Read `brd-work/genie-config.md` to know where the metadata is.
- Log every Genie question and answer in `brd-work/35-genie-log.md` immediately, as `PENDING-CONFIRM`.
- A Genie finding is evidence, not a decision. Only the human can confirm it. Until then tag it `[GENIE-PROVISIONAL GQ-nnn]`.
- If Genie contradicts a BRD document, raise a gap; never overwrite.
- If the `genie` tool is unavailable, say so and ask the human. Do not invent answers.
- **Every stage ends with a Genie verification pass** (protocol section 2b): for each technical claim the stage produced, record whether Genie ANSWERED it and whether the returned SQL supports the answer (SQL-VERIFIED / SQL-MISMATCH / SQL-NOT-AVAILABLE). Only ANSWERED + SQL-VERIFIED counts as answered; anything else is escalated to the human. Never claim SQL was re-executed (you cannot run SQL yourself).
- Show the Genie verification table in every stage's review message.
- **Read-only, always, including every rerun** (protocol section 0). Ask only questions that read. Never ask Genie to create, change, delete, load, refresh or optimize anything, and never to call or execute a stored procedure; read its stored text only. Before accepting any answer, check that the SQL returned is SELECT/WITH/SHOW/DESCRIBE/EXPLAIN only. If it contains anything else, do not use or repeat it: stop the Genie work, tell the user immediately, and escalate.
- On a rerun, ask the same read-only questions, record an as-of time, and if the answer differs from before, report it and log a new entry instead of replacing the old one.
- No credentials or sensitive row-level data in files.

## 4. Approval is explicit
You may mark a stage `APPROVED` in `STATUS.md` only when the user's latest message contains the word **APPROVED** for that stage. Never mark any stage approved yourself.

## 5. Scope of changes
Write only inside `brd-work/`. Never edit `brd-work/sources/` (the original BRD files). Never run terminal commands. Stages 1–4 never write code, schemas or SQL.

## 6. Provenance
Every statement you record cites its source (`SRC-A`, `SRC-B`, `SRC-C` + section or procedure name) or a decision ID (`DEC-nnn`). If it has neither, it does not go in.

## 7. End of every stage
Finish with the review prompt:

```
STAGE <n> — <name>: ready for your review.
Output: <files>
Summary: <3-5 lines>
Genie verification table (GQ | verified | answered? | SQL verified? | result | your confirmation)
Genie: asked N · answered M (SQL-verified V) · partial P · not answered K · SQL mismatches X · pending your confirmation C
Open items needing you: <count>

Reply: FEEDBACK: <change>  |  APPROVED  |  HALT
To continue after approval, run the next stage's command yourself.
```
