---
name: brd-apply-review
description: Stage 4b - apply my HTML review (Genie confirmations, corrections, section comments) and update the BRD
agent: BRD Consolidation
---
Run **Stage 4b — Apply Review** and nothing else.

Follow the stage instructions in [04b-apply-review.md](../../brd-playbook/04b-apply-review.md) and the rules in [06-genie-protocol.md](../../brd-playbook/06-genie-protocol.md).

First read `brd-work/MEMORY.md` and `brd-work/STATUS.md`. Stage 4 must be PRESENTED. My review is in `brd-work/review-feedback.json`; if it is missing, ask me for my verdicts in chat. Do not mark any Genie finding confirmed without my verdict. When finished, present counts and what changed with the review prompt, then stop.
