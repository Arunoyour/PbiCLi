# BRD Consolidation — setup for VS Code + GitHub Copilot

## 1. Install (2 minutes)
1. Copy these into the root of your workspace, keeping the structure:
   - `.github/` (instructions, agent, prompts)
   - `brd-playbook/`
   - `brd-work/`
2. **Convert your Word BRDs to Markdown** (one time, on your machine), then put the `.md` files in `brd-work/sources/`:
   ```
   pip install "markitdown[docx]"
   markitdown "BRD_Business.docx" > brd-work/sources/SRC-A_business.md
   markitdown "BRD_Summary.docx"  > brd-work/sources/SRC-B_summary.md
   markitdown "BRD_Technical.docx" > brd-work/sources/SRC-C_technical.md
   ```
   Alternative with pandoc: `pandoc "BRD_Technical.docx" -t gfm --wrap=none -o brd-work/sources/SRC-C_technical.md`
   - Keep the original `.docx` files somewhere else (outside `brd-work/sources/`).
   - Open each `.md` and spot-check: tables are intact, stored procedure code is in code blocks, headings look right.
   - Images, diagrams and Word comments or tracked changes do not convert. If they matter (ERDs, flow diagrams, reviewer comments), describe them in a short `SRC-x_extras.md` file, or accept all tracked changes in Word before converting.
3. In VS Code open Copilot Chat. In the agent dropdown you should see **BRD Consolidation**. Typing `/brd` should list the commands.
4. Check the tools: open the agent's tool picker and confirm it has read, search, edit and ask-questions, and **no terminal**.

## 1b. Connect Genie (technical metadata in Databricks)
0. **Make the connection read-only in Databricks first (required).** Create or choose a service principal (or user) with only: `USE CATALOG`, `USE SCHEMA` and `SELECT` on the metadata/data tables the Genie space uses; `CAN RUN` on the Genie space; `CAN USE` on the SQL warehouse. Grant no `MODIFY`, `CREATE`, `ALL PRIVILEGES`, `MANAGE`, or rights to run procedures. Then test it: a write attempt should be refused. Tick the checklist in `brd-work/genie-config.md`. This is the real protection; the agent's own rules are a second layer.
1. Copy `.vscode/mcp.json.example` to `.vscode/mcp.json`; set your workspace host and Genie space ID. VS Code will ask for the token when it starts the server. Use the read-only identity's token from step 0.
2. Make sure the Genie space includes the metadata tables (tables, columns, views, stored procedures, dependencies).
3. Fill in `brd-work/genie-config.md` (table names and what each holds, scope filter, sensitive columns). If you leave gaps, `/brd-ingest` will ask.
4. In Copilot Chat, open the tool picker and confirm the `genie` tools appear for the BRD Consolidation agent. Your organization may need to allow MCP servers.
5. Test with `/brd-status`, then ask the agent: "Ask Genie how many tables are in scope" before running Stage 1.

## 2. Run
| Step | You type | You do next |
|------|----------|-------------|
| 1 | `/brd-ingest` | Review. Answer any questions. Reply `APPROVED` |
| 2 | `/brd-gaps` | Review the gap register. Reply `APPROVED` |
| 3 | `/brd-clarify` | Answer the question rounds. Reply `APPROVED` at the end |
| 4 | `/brd-consolidate` | Open `brd-work/40-consolidated-brd.html` in a browser. Work through the "What we checked with Genie" cards (Agree / Disagree / Correct), click Export review, save as `brd-work/review-feedback.json` |
| 4b | `/brd-apply-review` | Review what changed. Repeat 4b until no Genie finding is pending, then reply `APPROVED` |
| 5 | `/brd-blueprint` | Review the blueprint |

Lost your place? `/brd-status`. New chat? Same: memory lives in `brd-work/MEMORY.md`.

## 3. Things to know
- **The pause is mostly instruction-based.** The agent has no terminal and each command loads only its own stage, but Copilot can still run on if it ignores instructions. If it starts the next stage, say HALT and check that `STATUS.md` was not changed. Only your APPROVED may change a stage to approved.
- **`askQuestions` has had bugs** (for example auto-answering instead of waiting, and not working inside subagents). The rules fall back to plain numbered questions in chat if it does not wait. If it auto-answers, tell the agent to ask in chat instead.
- **Custom agents are `.agent.md` in `.github/agents/`.** The older `.chatmode.md` format is no longer supported by VS Code.
- Tool names can vary by VS Code version. If the picker shows different names, adjust the `tools:` line in the agent file.
- Do not edit `brd-work/sources/`. The agent is told not to, but keep a backup anyway.
