# BRD Consolidation — MEMORY

The agent's running understanding of the project. Read at the start of every stage; updated after every answered round.
Every line cites a source (`SRC-A/B/C` + location) or a decision (`DEC-nnn`).

## Project in one paragraph
(what is being built or replaced, for whom, why)

## Scope
- In:
- Out:

## Agreed terms
| Term | Meaning | Source / decision |
|------|---------|-------------------|

## Business rules (confirmed)
| ID | Rule | Source / decision |
|----|------|-------------------|

## Business rules found only in code (confirmed or not)
| Procedure | Rule | Confirmed? | Decision |
|-----------|------|------------|----------|

## Genie findings
| GQ | Fact | Status (PENDING-CONFIRM / CONFIRMED / CORRECTED / REJECTED) | Affects |
|----|------|------------------------------------------------------------|---------|

## Key decisions so far
| DEC | Decision | Date |
|-----|----------|------|

## People and owners
| Name / role | Knows about | Notes |
|-------------|-------------|-------|

## Still unclear (waiting on human)
-

## Changed understanding
(what we used to think, what changed it)

## Session log
| Date | Stage | What happened |
|------|-------|---------------|
