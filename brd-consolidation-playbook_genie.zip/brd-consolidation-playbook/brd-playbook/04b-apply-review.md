# Stage 4b — Apply Review

**Invoke:** `/brd-apply-review` (after you have reviewed the HTML)
**Input:** `brd-work/review-feedback.json` (exported from the HTML), or your comments in chat
**Output:** updated `35-genie-log.md`, `31-decisions-log.md`, `20-gap-register.md`, `MEMORY.md`, and a new version of `40-consolidated-brd.html`
**Mode:** write docs only. Then STOP.

## Purpose
Take what the reviewers decided in the HTML (which Genie findings they agree with, which they correct or reject, section approvals and comments) and apply it everywhere. This is how Genie findings become confirmed facts and how the BRD is updated.

## Export format the HTML produces
```
{
  "document_version": "v3",
  "reviewer": "name",
  "date": "YYYY-MM-DD",
  "genie": [ { "id": "GQ-001", "verdict": "agree|disagree|correct", "correction": "", "comment": "" } ],
  "sections": [ { "id": "sec-5", "verdict": "approve|reject", "comment": "" } ]
}
```
If the file is missing, ask the human to save the export into `brd-work/review-feedback.json` or to paste their verdicts in chat.

## Steps
1. Read the feedback. List what it contains (counts) and anything you cannot map to an existing id. Ask about unmappable items.
2. **Genie findings**, one by one:
   - `agree` → `CONFIRMED`. Add a `DEC` row (basis: "confirmed GQ-nnn"). Remove the provisional tag wherever it was used. Move related gaps to `RESOLVED`.
   - `correct` → `CORRECTED`. Record the human's correction as the fact. New `DEC` row (basis: "human correction of GQ-nnn"). Update every place that used the original finding.
   - `disagree` → `REJECTED`. The finding is not used. Re-open related gaps and ask the human what is right, in this stage if they are present, otherwise list the questions.
3. **Sections**: record approvals; for rejected sections or comments, make the changes, and ask if anything is unclear.
4. **Propagate**: update the gap register and `MEMORY.md` (confirmed facts section, changed understanding). If a correction affects earlier stages (inventory, gap register), say which and flag them for re-approval in `STATUS.md`.
5. **Rebuild the HTML** as the next version: confirmed items shown as confirmed with reviewer and date, remaining items still provisional, change log updated.
6. Present counts: confirmed / corrected / rejected / still pending; sections approved / rejected; what changed in the BRD. Then the standard review prompt and **stop**.

## Gate for approving Stage 4
Stage 4 can be marked APPROVED only when:
- no Genie entry is `PENDING-CONFIRM` (all are confirmed, corrected, rejected-and-resolved, or escalated-and-answered), and
- the human replies APPROVED.

If the human replies APPROVED while Genie entries are still pending, say so, list them, and do not mark it approved.

## Genie verification pass (mandatory, before presenting)
After applying corrections, re-verify with Genie anything that changed: every CORRECTED fact, and every fact downstream of a REJECTED or CORRECTED finding (per `06-genie-protocol.md` section 2b, with the SQL check). Show the Genie verification table. If a human correction contradicts what Genie shows, keep the human's correction as the decision, record the conflict in the log, and tell the human.

## Do NOT
- Mark any Genie finding confirmed without the human's verdict.
- Silently change a past decision; supersede it with a new DEC row.
- Start the blueprint.
