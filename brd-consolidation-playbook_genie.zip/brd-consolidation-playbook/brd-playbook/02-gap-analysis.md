# Stage 2 — Gap Analysis

**Invoke:** `/brd-gaps` (requires Stage 1 APPROVED)
**Output:** `brd-work/20-gap-register.md`, updated `brd-work/MEMORY.md`
**Mode:** analyse inventory, write docs only. Then STOP.

## Use Genie to verify (follow `06-genie-protocol.md`)
Before logging a gap that is really a fact question, try to settle it with Genie:
- Does the object the document names exist? Do the column names, types and keys match what the document says?
- Does the stored procedure really read/write what the document claims?
- Does the data show the rule is followed (counts of violations, distinct values, null rates)?
Log each query in `35-genie-log.md`. If Genie settles it, record the gap as `RESOLVED-PENDING-CONFIRM` citing the GQ id, not as `RESOLVED`. If Genie contradicts a document, log a `CON` gap. If it cannot answer, log the gap normally.

## Questions belong to Stage 3
In this stage, log gaps; do not interview the human yet. The one exception: if you cannot continue without an answer (for example the inventory contradicts itself so badly that comparison is meaningless), ask one short round and record it in `MEMORY.md`. Everything else becomes a gap, and Stage 3 asks about it.

## Memory
At the end, add to `MEMORY.md`: the headline gap counts, the top HIGH gaps, and the hidden rules found in stored procedures (marked unconfirmed).

## Purpose
Find everything that is missing, conflicting, ambiguous or undocumented across the three files, and register each as a numbered gap. Nothing is merged or resolved here.

## Gap types
| Code | Type | Meaning |
|------|------|---------|
| `CON` | Conflict | Two files state different things about the same item |
| `MIS` | Missing | Present in one file, absent where it should also appear |
| `HID` | Hidden rule | Business rule exists only in stored-procedure code |
| `ORP` | Orphan requirement | Business requirement with no technical implementation |
| `ORT` | Orphan technical | Technical logic with no business requirement behind it |
| `AMB` | Ambiguity | Wording allows more than one reading |
| `TRM` | Term mismatch | Same word, different meaning (or different words, same thing) |
| `ASM` | Unstated assumption | Edge cases, error handling, volumes, ownership, timing not stated |
| `STL` | Stale | Version or date suggests one file is outdated against another |

## Steps
1. **Cross-trace.** For every inventory item, check whether the same item appears in the other files. Record matches, near-matches, and absences.
2. **Compare values.** For every matched item compare: wording, numbers, thresholds, field names, formulas, sequence, ownership.
3. **Procedure coverage.** For each stored procedure, list rules it implements and whether SRC-A/SRC-B mention them (`HID` if not). For each business rule in SRC-A/SRC-B, find the procedure that implements it (`ORP` if none).
4. **Check completeness** per area against this list: error handling, null/duplicate handling, history/audit, security, volumes, scheduling, reconciliation, reporting, rollback/restart, data retention.
5. **Register each gap** using the entry format below. Do not propose a final answer, but you may list the candidate readings.
6. **Rate severity:**
   - `HIGH`: blocks design or changes results/money/compliance
   - `MEDIUM`: affects design choices
   - `LOW`: wording or cosmetic

## Entry format (`20-gap-register.md`)
```
### GAP-001 · CON · HIGH
Topic: <short title>
What each source says:
  - SRC-A <loc>: "<quote or tight paraphrase>"
  - SRC-B <loc>: ...
  - SRC-C <loc>: ...
Why it matters: <one or two lines>
Candidate readings: <A / B / C if applicable>
Status: OPEN
```

## Summary section (top of the file)
Counts by type x severity, the top 10 HIGH gaps, and the areas with most gaps.

## Do NOT
- Pick a winner between conflicting files.
- Invent an answer for a missing item.
- Drop a gap because it seems obvious. Log it as LOW.

## Genie verification pass (mandatory, before presenting)
Per `06-genie-protocol.md` section 2b, verify every technical claim behind a logged gap: both sides of each conflict (what the document says vs what the metadata shows), each hidden-rule claim (the procedure really contains that condition), each orphan claim (the object or procedure really does or does not exist). Show the Genie verification table. A gap that rests on a claim not ANSWERED + SQL-VERIFIED is marked "unverified" in the register.

## Present and stop
Show the summary tables, the top HIGH gaps in full, and the count of total gaps. End with the standard review prompt.

## Human checks
- Are the severities right?
- Any gap that is not really a gap, or a gap that was missed?
- Any gap you already know the answer to (say so now; it speeds Stage 3).
