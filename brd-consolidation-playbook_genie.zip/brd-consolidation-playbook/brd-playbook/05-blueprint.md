# Stage 5 — Technical Blueprint

**Invoke:** `/brd-blueprint` (requires Stage 4 APPROVED)
**Output:** `brd-work/50-technical-blueprint.md`, updated `brd-work/MEMORY.md`
**Mode:** design documents only. No code, no deployments. Ask the human when a technical choice is really a decision. Then STOP.

## Purpose
Produce the technical design that implements the approved consolidated BRD, and nothing else.

## Genie in this stage
You may query Genie (per `06-genie-protocol.md`) to check design assumptions: volumes, key uniqueness, data types, dependency chains, partitioning candidates. Log each in `35-genie-log.md`. Findings that drive a design decision must be shown to the human as `PENDING-CONFIRM` in the blueprint's "Decisions needed" list. Use only `CONFIRMED` or `CORRECTED` metadata from earlier stages; if any earlier finding is still `PENDING-CONFIRM`, stop and say so.

## Genie verification pass (mandatory, before presenting)
Per `06-genie-protocol.md` section 2b, verify the technical assumptions the blueprint rests on: that every object, column, type, key and dependency used in the design exists as stated, and that volume and uniqueness assumptions hold. Show the Genie verification table in the review message.

## Gate check (first action, always)
Confirm in `STATUS.md` that Stage 4 is APPROVED and that the HTML version matches the approved version. If not, stop and say so.

## Opening question
Ask once: target platform (for example Databricks, Fabric, SQL Server, other), existing standards to follow, environments, and any hard constraints. If the human has already stated these, use them.

## Blueprint sections
1. **Traceability header:** the approved HTML version and date this blueprint is based on
2. **Architecture overview:** components, data flow, layers (for example landing, cleansed, curated, serving), with a diagram
3. **Data model:** entities, keys, relationships, history handling
4. **Source-to-target mapping:** every field, transformation, and the rule/requirement it implements
5. **Logic design:** each approved business rule mapped to its implementation approach. For every legacy stored procedure, state: replicated as-is, redesigned, or retired, and why
6. **Processing design:** orchestration, scheduling, dependencies, restart/rerun, error handling, reconciliation
7. **Non-functional design:** performance, volumes, security, audit, retention
8. **Interfaces:** inputs, outputs, formats, contracts
9. **Test approach:** one test idea per business rule, plus reconciliation checks against the legacy results
10. **Risks and open items:** carried over from the HTML, plus any new technical decisions needing approval
11. **Traceability matrix:** requirement ID, design element, test idea

## Rules
- Every design element traces to an approved requirement. Anything without one is flagged as a proposed addition and needs separate human approval.
- If a requirement turns out to be unclear during design, do not guess. Record it as a new gap and stop for the human.
- Technical choices that are really decisions (platform, retention, approach to a legacy procedure) are listed as "Decisions needed" with options and a recommendation.

## Present and stop
Show the section list, the key decisions needed, and the traceability coverage (requirements covered / total). End with the standard review prompt.

## After approval
The blueprint feeds the implementation planning stages of the main playbook. That is a separate invoke.
