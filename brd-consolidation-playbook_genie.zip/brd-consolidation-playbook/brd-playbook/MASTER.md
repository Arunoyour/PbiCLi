# BRD Consolidation Playbook — MASTER

Turns three BRD files of different depth into one human-approved HTML, then into a technical blueprint.
Runs in VS Code with GitHub Copilot as a **conversation**: the agent works one stage at a time, asks you when it needs information, remembers what you tell it, and never advances on its own.

---

## 1. Inputs

| Code | File type | Typical content |
|------|-----------|-----------------|
| `SRC-A` | Business + light technical BRD | Objectives, scope, rules, some technical notes |
| `SRC-B` | Summary BRD | Short version, headline requirements |
| `SRC-C` | Technical BRD | Stored procedures, tables, technical detail |

| `SRC-G` | Databricks metadata via Genie | Tables, views, stored procedures, dependencies and data facts, read through the `genie` tool (not a file) |

The Word documents give intent and business detail; `SRC-G` gives the technical facts as they exist in the database. See `06-genie-protocol.md`.

Put the three files in `brd-work/sources/` as Markdown or other text. Word files must be converted first (see README: `markitdown` or `pandoc`); Copilot cannot read `.docx` directly. Stage 1 checks the conversion for damage (broken tables, lost code formatting, missing figures).

---

## 2. The loop

```
YOU run a /brd-* command
   → AGENT reads MEMORY.md + STATUS.md
   → AGENT works the stage (asks you questions when it needs information)
   → AGENT records your answers in MEMORY.md and the decisions log
   → AGENT presents the result and STOPS
        ├─ FEEDBACK: ...  → agent revises the same stage, presents, stops
        ├─ APPROVED       → agent records it in STATUS.md, stops
        └─ HALT           → agent stops
YOU run the next /brd-* command yourself
```

### Hard rules
1. One stage per command. The agent never starts the next stage.
2. The agent asks instead of guessing. Technical fact questions go to Genie first, intent and decision questions go to you. Questions to you come in rounds of at most 5.
2b. Every stage ends with a **Genie verification pass**: the agent verifies the stage's technical claims with Genie and reports, for each, whether Genie answered and whether the SQL Genie returned supports the answer (SQL-VERIFIED / SQL-MISMATCH / SQL-NOT-AVAILABLE). Only answered + SQL-verified findings count; the rest go to you. Genie answers are evidence, not decisions. You confirm each one (in the HTML), and nothing built on an unconfirmed finding can be approved.
3. Every answer is written to `MEMORY.md` and the decisions log before the next question.
4. Every statement traces to a source (file + section/procedure) or a decision ID.
5. Conflicts are never merged silently; each becomes a gap-register entry.
6. Only a human message containing APPROVED approves a stage.
7. Stages 1-4 write documents only: no code, no schema changes, no terminal.
8. Stage 5 starts only when Stage 4 is APPROVED.
9. **Everything against Databricks is read-only, on every run and rerun.** Enforced by a read-only identity, the agent's question rules, a check that every returned SQL is a plain read, and a tool set with no write path. Stored procedures are read as text and never executed. A non-read SQL stops the Genie work and is reported to you at once. Reruns repeat reads only, record an as-of time, and log any change in answer as a new entry. See `06-genie-protocol.md` section 0.

---

## 3. Stages and commands

| # | Command | Stage file | What happens | Needs approved |
|---|---------|-----------|--------------|----------------|
| 1 | `/brd-ingest` | `01-ingest.md` | Reads the 3 files into one tagged inventory; asks if anything is unreadable or unclear | — |
| 2 | `/brd-gaps` | `02-gap-analysis.md` | Finds conflicts, missing items, rules hidden in stored procedures | 1 |
| 3 | `/brd-clarify` | `03-clarify.md` | **Live Q&A**: asks you in rounds, records answers, updates memory | 2 |
| 4 | `/brd-consolidate` | `04-consolidate.md` | Builds the single readable HTML | 3 |
| 4b | `/brd-apply-review` | `04b-apply-review.md` | Applies your HTML review: Genie confirmations, corrections, section comments; rebuilds the HTML | 4 presented |
| 5 | `/brd-blueprint` | `05-blueprint.md` | Technical blueprint from the approved HTML | 4 (no Genie finding pending) |
| — | `/brd-status` | — | Shows where you are; changes nothing | — |

---

## 4. Folder layout

```
.github/
  copilot-instructions.md        standing rules
  agents/brd-consolidation.agent.md   the agent (read + edit + ask, no terminal)
  prompts/brd-*.prompt.md        the slash commands
brd-playbook/                    these instructions (do not edit during a run)
  MASTER.md, 01..05 stage files, templates/
brd-work/                        everything the agent produces
  sources/                       your 3 BRD files (agent never edits)
  MEMORY.md                      the agent's running understanding
  genie-config.md                where the metadata lives in Databricks (you fill this in)
  35-genie-log.md                every Genie question, answer, SQL and your verdict
  review-feedback.json           exported from the HTML after your review
  STATUS.md                      stage states and approvals
  00-source-register.md  10-inventory.md  20-gap-register.md
  30-questions.md  31-decisions-log.md
  40-consolidated-brd.html  50-technical-blueprint.md
```

---

## 5. Memory

Copilot chat does not keep memory between sessions, so the memory is a file.
`brd-work/MEMORY.md` holds the project summary, agreed terms, confirmed rules, decisions, who knows what, and what is still unclear. Every command reads it first and every answered round updates it. If you open a new chat tomorrow, run `/brd-status` and carry on.

---

## 6. Standard review prompt (end of every stage)

```
STAGE <n> — <name>: ready for your review.
Output: <file(s)>
Summary: <3-5 lines>
Genie verification table: GQ | verified | answered? | SQL verified? | result | your confirmation
Genie: asked N · answered M (SQL-verified V) · partial P · not answered K · SQL mismatches X · pending C
Open items needing you: <count>

Reply: FEEDBACK: <change>  |  APPROVED  |  HALT
To continue after approval, run the next stage's command yourself.
```

---

## 7. Settings (defaults; tell the agent to change any)

| Setting | Default |
|---------|---------|
| Conflict resolution | No file wins automatically; every conflict goes to you |
| Stored procedures | Reverse-engineer business rules from each one, with a checklist |
| Question rounds | Max 5 questions per round |
| HTML review | Readable page; approval by replying APPROVED in chat; optional per-section buttons |
| Blueprint platform | Asked at the start of Stage 5 |
