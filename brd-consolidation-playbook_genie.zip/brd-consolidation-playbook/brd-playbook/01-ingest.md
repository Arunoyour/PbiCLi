# Stage 1 — Ingest

**Invoke:** `/brd-ingest` (BRD files in `brd-work/sources/`)
**Output:** `brd-work/00-source-register.md`, `brd-work/10-inventory.md`, first version of `brd-work/MEMORY.md`
**Mode:** read sources, write docs only. Then STOP.

## Metadata from Genie (SRC-G)
Part of the technical picture (tables, views, stored procedures) is in Databricks metadata tables, not in the Word files. After reading the documents:
1. Read `brd-work/genie-config.md`. If it is empty or incomplete, ask the human for the missing details before querying.
2. Follow `06-genie-protocol.md`. Through Genie, list the in-scope tables, views and stored procedures; for each get columns/types, definitions or procedure text, and dependencies.
3. Add them to the inventory with source `SRC-G` (plus the GQ id). For each stored procedure, extract the business rules it implements, as described below, and mark them `IMPLIED-IN-CODE`.
4. Compare quickly with what the Word documents mention: objects named in the documents but not found in the metadata, and the reverse. Note them (Stage 2 will log them as gaps).
5. Every Genie finding is logged in `35-genie-log.md` as `PENDING-CONFIRM`.

## Conversion check (first thing, because sources were converted from Word)
The BRDs started as Word files and were converted to Markdown. Before extracting, check each file for conversion damage and report it:
- Tables that are broken, merged into plain text, or missing columns
- Stored procedure code that is not in code blocks, or has lost indentation or line breaks
- Places that refer to a figure, diagram, ERD or screenshot that is not in the text ("see Figure 3")
- Text that looks like Word comments or tracked changes (duplicated or struck-through wording)
- Numbering or headings that look scrambled

List each problem with file and location, and ask the human how to handle it (fix the file, describe the missing item, or ignore). Record "figures referenced but not available" as a gap candidate for Stage 2.

## Ask when blocked
If a file is unreadable, a version is unclear, or you cannot tell which file is which, ask the human (one round, max 5 questions) before continuing. Do not guess. Record the answers in `MEMORY.md`.

## Memory
At the end of this stage write the first `MEMORY.md` from `brd-playbook/templates/MEMORY.md`: project summary, scope as stated, terms found, and the list of source files with versions. Cite sources on every line.

## Purpose
Build one structured inventory of everything the three BRDs say, with source tags, so later stages compare facts instead of re-reading documents.

## Steps
1. **Register sources.** For each file record: code (SRC-A/B/C), filename, apparent version/date/author if stated, and its depth level (business / summary / technical). Do not guess missing metadata; write "not stated".
2. **Read each file fully.** Large files: work section by section (SRC-A, SRC-B) or procedure by procedure (SRC-C). Keep a checklist of sections/procedures and tick each when covered.
3. **Extract into the inventory**, one row per item, in these categories:
   - Objectives and scope (in / out)
   - Business requirements
   - Business rules and calculations
   - Data entities, fields, sources, targets
   - Processes and workflows
   - Interfaces and integrations
   - Non-functional requirements (volume, timing, security, audit)
   - Roles, owners, stakeholders
   - Glossary terms and how each file uses them
   - Assumptions, constraints, dependencies
4. **Stored procedures (SRC-C).** For each procedure record: name, purpose as stated, inputs, outputs, tables read/written, and the **business rules it actually implements** (conditions, thresholds, calculations, filters, exclusions, defaults). Mark each rule `IMPLIED-IN-CODE` if no other file states it.
5. **Tag every row** with: ID (`INV-001`...), category, statement (faithful, not paraphrased into new meaning), source code + location, and confidence (`CLEAR` / `AMBIGUOUS`).
6. **Coverage report.** Section/procedure checklist per file with counts: items extracted per file per category.

## Output format (`10-inventory.md`)
```
| ID | Category | Statement | Source | Location | Confidence |
```
Followed by the coverage report and a short "things I could not read or parse" list.

## Do NOT
- Compare or judge between files yet (that is Stage 2).
- Resolve ambiguities. Mark them `AMBIGUOUS` and move on.
- Skip a procedure because it looks minor.

## Genie verification pass (mandatory, before presenting)
Per `06-genie-protocol.md` section 2b, verify the technical claims this stage produced: that each object in the inventory exists with the columns/types recorded, that each stored procedure's text and the tables it reads/writes are as recorded, and that object counts match. Show the Genie verification table (answered? / SQL verified?). Items that are not ANSWERED + SQL-VERIFIED are removed from the inventory's confirmed rows and listed for the human.

## Present and stop
Show: counts per file/category, 5 sample rows including at least one `IMPLIED-IN-CODE`, any unreadable parts, and anything that looked inconsistent (just noted, not analysed). End with the standard review prompt from MASTER.md section 5.

## Human checks
- Is any section or procedure missing from the coverage list?
- Are any statements misread?
- Are the source versions correct?
