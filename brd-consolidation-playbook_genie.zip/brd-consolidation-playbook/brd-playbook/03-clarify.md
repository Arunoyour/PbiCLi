# Stage 3 — Clarify (live conversation)

**Invoke:** `/brd-clarify` (requires Stage 2 APPROVED)
**Output:** `brd-work/30-questions.md`, `brd-work/31-decisions-log.md`, updated `brd-work/MEMORY.md` and `brd-work/20-gap-register.md`
**Mode:** conversation with the human. Write docs only.

## Purpose
Close the gaps by asking the human, in rounds, and recording every answer as it arrives. This is the stage where the human feeds in what the documents do not say. The agent's understanding (`MEMORY.md`) grows with each round.

## Genie first, then the human
Before preparing any round for the human, go through every open gap and split it:
- **Fact question** (object, column, procedure behaviour, data contents) → ask Genie now, per `06-genie-protocol.md`. Log it in `35-genie-log.md`. If answered, mark the gap `RESOLVED-PENDING-CONFIRM`. If not, it joins the human's questions as `ESCALATED`.
- **Intent or decision** → straight to the human.

The human's rounds then contain only intent/decision questions, plus escalated ones, plus a short list of Genie findings to confirm early if they wish (`CONFIRM GQ-001, GQ-004`). Final confirmation happens in the HTML.

## The conversation loop

```
Pick next round (max 5 questions)
   → Ask (askQuestions tool, or numbered list in chat)
   → WAIT for answers
   → Record: decisions log, gap register, MEMORY.md   (before asking anything else)
   → Check: did an answer create new gaps or contradict an earlier decision?
   → More HIGH/MEDIUM gaps open?  yes → next round   |   no → present summary and STOP
```

The human may answer "defer" for any question (with an owner), or say "enough for now". Both end the loop early; open items stay visible.

## Preparing a round
1. Group open gaps by topic, so one answer can close several gaps.
2. Order by severity, then by dependency (answers that unblock other questions go first).
3. Take the top 5 (fewer if they belong together).
4. Write each question so it can be answered without opening the source files:
   - One or two lines of context, with source references
   - The question
   - Options A/B/C built from the candidate readings, plus "Other"
   - The agent's **proposed default** and why, labelled as a proposal
5. Save the round to `brd-work/30-questions.md` (so the questions survive if the session ends).

## Recording answers
For every answered question:
1. Add a row to `brd-work/31-decisions-log.md`:
   `DEC-nnn | gap IDs | decision | decided by | date | basis (answer / accepted default / deferred) | supersedes`
2. Update gap status in `20-gap-register.md`: `RESOLVED` (with DEC id), `DEFERRED` (reason + owner), or `STILL-OPEN`.
3. Update `brd-work/MEMORY.md` (see template): new facts, new terms, new rules, changed understanding.
4. If the answer is unclear, ask a short follow-up. Do not interpret loosely.

## Rules
- Accepting a proposed default counts only if the human says so explicitly. Silence is not acceptance.
- Never edit a past decision silently. A changed decision gets a new DEC row that supersedes the old one.
- Do not ask what the sources already answer.
- Do not bundle unrelated topics into one question.
- Do not start the HTML. That is Stage 4.

## Genie verification pass (mandatory, before presenting)
Per `06-genie-protocol.md` section 2b, verify the facts behind every decision recorded this stage and every gap marked `RESOLVED-PENDING-CONFIRM`: ask Genie whether the data or metadata is consistent with the decision, and check each answer against its SQL. If a human decision conflicts with what Genie shows, do not change the decision; show the conflict to the human and ask. Show the Genie verification table.

## Finishing the stage
Present: how many gaps resolved / deferred / still open, the list of deferred items with owners, anything the answers changed in earlier assumptions, and the current `MEMORY.md` highlights. Then the standard review prompt, and stop.

## Human checks
- Do the recorded decisions say what you meant?
- Are the deferred items and owners right?
- Is anything still unclear that you want to settle before the HTML is built?
