Put your three BRD files here (converted Markdown or text files; Word files must be converted first, see README). The agent reads but never edits this folder.
