Databricks details: workspace, catalogs/schemas in scope, environment. If Genie is available: workspace host, Genie space id, metadata tables (text or JSON). Never put tokens or passwords here.
