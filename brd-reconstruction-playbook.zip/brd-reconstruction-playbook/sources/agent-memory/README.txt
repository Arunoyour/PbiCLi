Memory files from other agents or colleagues. Treated as Inferred until confirmed.
