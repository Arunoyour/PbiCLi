Put the client's BRD template here (Markdown). Phase 8 follows it exactly. If there is none, /brd-setup offers a default.
