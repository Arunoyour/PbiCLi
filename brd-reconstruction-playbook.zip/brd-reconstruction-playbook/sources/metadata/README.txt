Results of tools/metadata-extraction (CSV files) plus metadata-run-notes.md (when, where, by whom, which environment).
