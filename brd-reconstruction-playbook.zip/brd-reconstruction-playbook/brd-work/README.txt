The agent writes everything here (memory, BRD phases, review pages, feedback). Created by /brd-setup.
