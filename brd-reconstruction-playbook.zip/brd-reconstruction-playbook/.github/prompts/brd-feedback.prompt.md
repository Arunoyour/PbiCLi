---
name: brd-feedback
description: Apply my feedback (exported file and/or chat) to the step in progress and redraft it
agent: BRD Reconstruction
---
Apply my feedback to the step that is PRESENTED or REVISING in `brd-work/STATUS.md`, following [review-loop.md](../../playbook/review-loop.md) section 3.

Read the newest matching file in `brd-work/feedback/` (`feedback-<step>-r<N>.json`) and anything I wrote in chat. If more than one step is waiting, ask which. If the file is missing or unreadable, say so and ask me to save it again or paste the feedback.

Update the working files, write the next round's review page with "What changed since round N", then stop. Do not close the step and do not start another.
