---
name: brd-check
description: Independent reviewer check of the memory or the draft BRD (findings only)
agent: BRD Reviewer
---
Run **Independent check** and nothing else.

Follow [RV-check.md](../../playbook/RV-check.md), together with [review-loop.md](../../playbook/review-loop.md) and [labels-and-versions.md](../../playbook/labels-and-versions.md).

First read `brd-work/PROJECT.md`, `brd-work/STATUS.md` and `brd-work/memory/MANIFEST.md` and check the step's gate; if it is not met, tell me what is missing and stop.

Ask me whether to check the memory or the draft BRD if it is not clear. Write findings only; do not edit anything outside `brd-work/reviews/`.

Write the findings page, tell me where it is, and stop.
