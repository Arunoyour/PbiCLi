---
name: brd-p6-clarify
description: Phase 6 - Clarification, in rounds until no questions remain
agent: BRD Reconstruction
---
Run **BRD phase 6, clarification** and nothing else.

Follow [P0-phase-rules.md](../../playbook/P0-phase-rules.md), [P6-clarify.md](../../playbook/P6-clarify.md), together with [review-loop.md](../../playbook/review-loop.md) and [labels-and-versions.md](../../playbook/labels-and-versions.md).

First read `brd-work/PROJECT.md`, `brd-work/STATUS.md` and `brd-work/memory/MANIFEST.md` and check the step's gate; if it is not met, tell me what is missing and stop.

Check the evidence before asking me anything. Record every answer with the confirmer's name and role.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do not start any other step.
