---
name: brd-p5a-technical
description: Phase 5A - Technical analysis
agent: BRD Reconstruction
---
Run **BRD phase 5A, technical analysis** and nothing else.

Follow [P0-phase-rules.md](../../playbook/P0-phase-rules.md), [P5A-technical.md](../../playbook/P5A-technical.md), together with [review-loop.md](../../playbook/review-loop.md) and [labels-and-versions.md](../../playbook/labels-and-versions.md).

First read `brd-work/PROJECT.md`, `brd-work/STATUS.md` and `brd-work/memory/MANIFEST.md` and check the step's gate; if it is not met, tell me what is missing and stop.

Work in batches until every in-scope object is covered.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do not start any other step.
