---
name: brd-p5d-gaps
description: Phase 5D - Gap analysis
agent: BRD Reconstruction
---
Run **BRD phase 5D, gap analysis** and nothing else.

Follow [P0-phase-rules.md](../../playbook/P0-phase-rules.md), [P5D-gaps.md](../../playbook/P5D-gaps.md), together with [review-loop.md](../../playbook/review-loop.md) and [labels-and-versions.md](../../playbook/labels-and-versions.md).

First read `brd-work/PROJECT.md`, `brd-work/STATUS.md` and `brd-work/memory/MANIFEST.md` and check the step's gate; if it is not met, tell me what is missing and stop.


End with the HTML review page and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do not start any other step.
