---
name: brd-p2-scope
description: Phase 2 - Scope and boundaries
agent: BRD Reconstruction
---
Run **BRD phase 2, scope and boundaries** and nothing else.

Follow [P0-phase-rules.md](../../playbook/P0-phase-rules.md), [P2-scope.md](../../playbook/P2-scope.md), together with [review-loop.md](../../playbook/review-loop.md) and [labels-and-versions.md](../../playbook/labels-and-versions.md).

First read `brd-work/PROJECT.md`, `brd-work/STATUS.md` and `brd-work/memory/MANIFEST.md` and check the step's gate; if it is not met, tell me what is missing and stop.

Include the one-line note that future-state material is held in the memory and excluded.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do not start any other step.
