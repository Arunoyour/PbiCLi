---
name: brd-memory-understand
description: M3 - purpose, business terms, relationships, current vs future state
agent: BRD Reconstruction
---
Run **Memory step M3, understand the business** and nothing else.

Follow [M3-understand.md](../../playbook/M3-understand.md), together with [review-loop.md](../../playbook/review-loop.md) and [labels-and-versions.md](../../playbook/labels-and-versions.md).

First read `brd-work/PROJECT.md`, `brd-work/STATUS.md` and `brd-work/memory/MANIFEST.md` and check the step's gate; if it is not met, tell me what is missing and stop.

Ask me for supporting documents where the evidence is thin. If I add files to `sources/inbox/` and say "added", register and use them in this step.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, PROCEED or HALT. Do not start any other step.
