---
name: brd-p8-draft
description: Phase 8 - Draft BRD in the client template, as MD and HTML
agent: BRD Reconstruction
---
Run **BRD phase 8, draft BRD** and nothing else.

Follow [P0-phase-rules.md](../../playbook/P0-phase-rules.md), [P8-draft.md](../../playbook/P8-draft.md), together with [review-loop.md](../../playbook/review-loop.md) and [labels-and-versions.md](../../playbook/labels-and-versions.md).

First read `brd-work/PROJECT.md`, `brd-work/STATUS.md` and `brd-work/memory/MANIFEST.md` and check the step's gate; if it is not met, tell me what is missing and stop.

Write `brd-work/brd/BRD_v<n>.md` and `.html` with identical text, stamped with BRD, memory and playbook versions. Never overwrite an earlier version.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do not start any other step.
