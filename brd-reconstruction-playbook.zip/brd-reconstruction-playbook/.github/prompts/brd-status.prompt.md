---
name: brd-status
description: Where are we - steps, memory version, BRD version, open questions, next command. Changes nothing.
agent: BRD Reconstruction
tools: ['search/codebase', 'search', 'read']
---
Read `brd-work/PROJECT.md`, `brd-work/STATUS.md`, `brd-work/memory/MANIFEST.md` and `brd-work/memory/_progress.md` (if they exist) and tell me briefly:

1. Project, analyst, Genie status, DevOps status
2. Memory: current version, last change, files in `sources/` not yet processed (so a /brd-memory-update is due)
3. The BRD chosen (if any), BRD versions, and the memory version each approved phase was built on; flag phases built on an older memory
4. Every step: state, round, closed by
5. Open counters: questions waiting, conflicting statements, state-unclear items, Genie findings to confirm
6. The next command to run

Change nothing. Run no step. If `brd-work/PROJECT.md` does not exist, say the first command is `/brd-setup`.
