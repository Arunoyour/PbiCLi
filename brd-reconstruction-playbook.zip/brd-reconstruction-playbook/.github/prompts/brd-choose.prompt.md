---
name: brd-choose
description: Choose the BRD for this workspace (agent proposes, or you summarise)
agent: BRD Reconstruction
---
Run **Choose the BRD** and nothing else.

Follow [10-choose-brd.md](../../playbook/10-choose-brd.md), together with [review-loop.md](../../playbook/review-loop.md) and [labels-and-versions.md](../../playbook/labels-and-versions.md).

First read `brd-work/PROJECT.md`, `brd-work/STATUS.md` and `brd-work/memory/MANIFEST.md` and check the step's gate; if it is not met, tell me what is missing and stop.

One BRD per workspace: if one is already chosen, say so and stop.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do not start any other step.
