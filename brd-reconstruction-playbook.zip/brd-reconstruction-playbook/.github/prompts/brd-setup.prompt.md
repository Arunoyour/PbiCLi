---
name: brd-setup
description: Setup - project, analyst, sources check, BRD template, Databricks, Genie, DevOps
agent: BRD Reconstruction
---
Run **Setup** and nothing else.

Follow [00-setup.md](../../playbook/00-setup.md), together with [review-loop.md](../../playbook/review-loop.md) and [labels-and-versions.md](../../playbook/labels-and-versions.md).

First read `brd-work/PROJECT.md`, `brd-work/STATUS.md` and `brd-work/memory/MANIFEST.md` if they exist.

This is a conversation: ask one thing at a time and save each answer to `brd-work/PROJECT.md` before the next. If setup already exists, show it and change only what I ask (for example when DevOps access arrives). **Never ask me to paste a token or password in chat.**

End with the HTML review page and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do not start any other step.
