---
name: brd-memory-update
description: Add new files from the inbox; one update = one sub-version
agent: BRD Reconstruction
---
Run **Memory update** and nothing else.

Follow [MU-memory-update.md](../../playbook/MU-memory-update.md), together with [review-loop.md](../../playbook/review-loop.md) and [labels-and-versions.md](../../playbook/labels-and-versions.md).

First read `brd-work/PROJECT.md`, `brd-work/STATUS.md` and `brd-work/memory/MANIFEST.md` and check the step's gate; if it is not met, tell me what is missing and stop.

Process every file in `sources/` not yet listed in the manifest. All of them together are one sub-version. Do not change any BRD content; only report which phases are affected.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, PROCEED or HALT. Do not start any other step.
