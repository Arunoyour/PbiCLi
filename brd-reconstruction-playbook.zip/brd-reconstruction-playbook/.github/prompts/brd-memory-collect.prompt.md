---
name: brd-memory-collect
description: M1 - register every source file
agent: BRD Reconstruction
---
Run **Memory step M1, collect the evidence** and nothing else.

Follow [M1-collect.md](../../playbook/M1-collect.md), together with [review-loop.md](../../playbook/review-loop.md) and [labels-and-versions.md](../../playbook/labels-and-versions.md).

First read `brd-work/PROJECT.md`, `brd-work/STATUS.md` and `brd-work/memory/MANIFEST.md` and check the step's gate; if it is not met, tell me what is missing and stop.

Register every file in `sources/`. Team BRDs and agent memory files enter as Inferred. If I add files to `sources/inbox/` and say "added", register them in this step.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, PROCEED or HALT. Do not start any other step.
