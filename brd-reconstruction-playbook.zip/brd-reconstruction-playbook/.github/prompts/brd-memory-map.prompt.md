---
name: brd-memory-map
description: M2 - technical map: objects, code, lineage, active or inactive
agent: BRD Reconstruction
---
Run **Memory step M2, map the technology** and nothing else.

Follow [M2-map.md](../../playbook/M2-map.md), together with [review-loop.md](../../playbook/review-loop.md) and [labels-and-versions.md](../../playbook/labels-and-versions.md).

First read `brd-work/PROJECT.md`, `brd-work/STATUS.md` and `brd-work/memory/MANIFEST.md` and check the step's gate; if it is not met, tell me what is missing and stop.

Work in batches with the checklist in `brd-work/memory/_progress.md`; resume from it if it exists. Never skip an object.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, PROCEED or HALT. Do not start any other step.
