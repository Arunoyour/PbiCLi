---
name: brd-memory-review
description: M4 - advisory memory review; closes the first memory as v1.0
agent: BRD Reconstruction
---
Run **Memory step M4, memory review** and nothing else.

Follow [M4-review.md](../../playbook/M4-review.md), together with [review-loop.md](../../playbook/review-loop.md) and [labels-and-versions.md](../../playbook/labels-and-versions.md).

First read `brd-work/PROJECT.md`, `brd-work/STATUS.md` and `brd-work/memory/MANIFEST.md` and check the step's gate; if it is not met, tell me what is missing and stop.

This review is advisory: I give feedback, then PROCEED. On PROCEED, write Memory v1.0 to the manifest.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, PROCEED or HALT. Do not start any other step.
