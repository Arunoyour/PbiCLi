---
name: brd-p5c-devops
description: Phase 5C - Azure DevOps evidence (read-only)
agent: BRD Reconstruction
---
Run **BRD phase 5C, DevOps evidence** and nothing else.

Follow [P0-phase-rules.md](../../playbook/P0-phase-rules.md), [P5C-devops.md](../../playbook/P5C-devops.md), [devops-protocol.md](../../playbook/devops-protocol.md), together with [review-loop.md](../../playbook/review-loop.md) and [labels-and-versions.md](../../playbook/labels-and-versions.md).

First read `brd-work/PROJECT.md`, `brd-work/STATUS.md` and `brd-work/memory/MANIFEST.md` and check the step's gate; if it is not met, tell me what is missing and stop.

If DevOps is not available yet, say so plainly on the page and list what ticket evidence would answer.

End with the HTML review page and the review message, then stop and wait for FEEDBACK, APPROVED or HALT. Do not start any other step.
