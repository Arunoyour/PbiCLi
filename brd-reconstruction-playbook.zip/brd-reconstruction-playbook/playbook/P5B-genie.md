# Phase 5B — Genie evidence collection — `/brd-p5b-genie`

**Follow:** `P0-phase-rules.md` and `genie-protocol.md` · **Closes with:** APPROVED · **Output:** `brd/P5B-genie.md`, `genie-log.md`

## If Genie is not in use
Write a short page: "Genie not in use for this project (<reason from PROJECT.md>). No data evidence was collected in this phase. Facts that would have been checked are listed below for manual checking." List those facts (the most important Inferred and Conflicting technical statements), then close with APPROVED.

## If Genie is in use
1. **Choose what to check:** the facts this BRD relies on that the data can settle: does the data follow each important rule (counts of exceptions), key uniqueness, null rates, value ranges, volumes, how often edge cases occur, whether "inactive" objects really have no recent data.
2. **Ask Genie, read-only**, one fact per question; log each in `genie-log.md` with the SQL; apply the SQL check (read-only, objects, scope, logic, result matches answer, complete; a second differently worded query for important facts).
3. **Label:** answered and SQL-verified → From evidence (Current state); not verified → not used, listed.
4. **Never** ask for row-level personal data; counts and patterns only.

## Review page
Genie verification table (fact, answered?, SQL verified?, result, what it supports or contradicts), findings that change earlier phases (information only), findings to confirm (`### GQ-…`).
