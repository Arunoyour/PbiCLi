# Memory manifest

The single source of truth for the memory version, and the contract with the consolidation agent.
This playbook raises only the **sub** number (and writes v1.0 at the end of M4). A consolidation agent may raise the **master** number (vN.0); this playbook then builds on it.

current_version: v0
master: 0
sub: 0
last_changed:
changed_by:

## History
| Version | Date | Type (build / update / consolidation) | Files | Change log | By |
|---|---|---|---|---|---|

## Processed source files
Files listed here are not processed again by /brd-memory-update.

| File | Evidence id | Registered in version | Notes (supersedes, quality) |
|---|---|---|---|

## Memory files
| File | Holds |
|---|---|
| 00-evidence-register.md | every source, its type, date, state tag, default label |
| 10-catalog/ | one card per table, view, procedure, function, job |
| 20-lineage.md | data flows from source to consumer |
| 30-business-map.md | purposes (PUR) and business terms |
| 40-claims.md | statements from documents, team BRDs, agent memory (CLM) |
| 50-relationships.md | how areas relate; candidate BRD areas |
| 60-future-state.md | future-state items (FS), linked to current processes |
| 70-open-questions.md | open questions |
| 80-summaries.md | summaries: object group, area, whole system |
| changes/ | one change log per version |
