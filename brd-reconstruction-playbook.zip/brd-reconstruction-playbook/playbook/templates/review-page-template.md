---
kind: review
title: <Step in plain words>
subtitle: <One sentence: what this page asks you to check>
project: <Project name>
stage: <Setup | M1 Collect | M2 Map | M3 Understand | M4 Review | Memory update | Choose BRD | Phase 1 - Summary | ...>
brd_name: <once chosen>
round: <N>
memory_version: <vX.Y this step was built on>
memory_notice: <only if MANIFEST shows a newer version, e.g. "Newer memory v1.4 exists (new evidence added)">
status: Waiting for your review
date: <YYYY-MM-DD>
platform: <Databricks | SQL Server | ...>
genie: <In use (read-only) | Not in use (no access details provided)>
devops: <In use (read-only) | Not available yet>
playbook_version: 1.0.0
feedback_file: feedback-<step>-r<N>.json
feedback_folder: brd-work/feedback/
---

<!--
- Plain English. Every statement: label ([[Confirmed]] / [[From evidence]] / [[Inferred]] / [[Conflicting]]),
  state tag where relevant ([[Current state]] / [[Future state]] / [[State unclear]]), and its source (EV id + location).
- Items needing an answer: ### heading starting with an id (Q-, CLM-, PUR-, STU-, FS-, OBJ-, GAP-, GQ-, WI-, ITEM-).
- Blocks: ```figures (Value | label), ```flow (Step | detail), ```layers (Name | note | part, part)
- Callouts: > [!NOTE] > [!DECISION] > [!RISK] > [!PROVISIONAL] > [!CONFIRMED]
- Memory steps: say at the top that the review is advisory (FEEDBACK or PROCEED).
-->

## 1. Summary

```figures
<n> | <what>
<n> | <what>
<n> | <what>
```

<3–5 sentences: what this step did, what it found, what it needs from you.>

## 2. <Step-specific content>

## 3. Needs your answer

### Q-001 <question in one line>
<context with sources> · options · suggested answer and why · [[Inferred]]

## 4. Genie and DevOps

<Genie verification table, or "Genie not in use for this project.">
<DevOps findings, or "DevOps not available yet.">

## 5. What changed since the last round

<Round 1: "First round.">
