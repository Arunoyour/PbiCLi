---
kind: brd
title: <BRD name>
subtitle: Business requirements, current state, reconstructed from existing systems and documents
project: <Project name>
brd_name: <BRD name>
brd_version: v<n>
memory_version: <vX.Y>
memory_notice: <only if a newer memory exists>
status: Draft for review
date: <YYYY-MM-DD>
platform: <platform>
genie: <status>
devops: <status>
playbook_version: 1.0.0
prepared_by: <analyst> with the BRD Reconstruction agent
approved_by: Pending
feedback_file: brd-review-v<n>.json
feedback_folder: brd-work/feedback/
---

<!-- Used only if the client has no template and the user accepted this default at /brd-setup. -->

## 1. Document control
Version table · memory version per phase (P1–P7) · sources (evidence index summary) · approvals

## 2. Executive summary
What the area does, who uses it, key figures, top risks and open questions

## 3. Scope
In scope · out of scope · inputs · outputs · boundaries with other areas · future-state line

## 4. Business process
Process flow · step table with the technology behind each step · variants and exceptions · manual steps

## 5. Business rules and controls
Rules (BR) with labels and sources · calculations · controls

## 6. Data
Entities and keys · data model · lineage · data quality observations

## 7. Technical reference
Objects in scope with activity · procedures and jobs and what they implement

## 8. Assumptions, risks and open questions

## 9. Client validation list
Items confirmed only by the analyst, and important Inferred items, grouped by who should confirm

## 10. Glossary

## Appendix A. Evidence index
## Appendix B. Genie findings (if used)
## Appendix C. DevOps findings (if used)
