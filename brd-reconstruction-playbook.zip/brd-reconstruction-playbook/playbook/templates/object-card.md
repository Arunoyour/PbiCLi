# Object card format (`brd-work/memory/10-catalog/<schema>.md`)

```
### OBJ-0042 · sales.usp_calc_rebate · Stored procedure · Active
Source: EV-001 (Q4 chunks 1-3), EV-003 (Q5 dependencies), EV-006 (Q6 usage)
Reads: sales.invoice, sales.rate_card, ref.calendar
Writes: sales.rebate_calc
Called by: SQL Agent job "Nightly rebate" step 3 (EV-008)
Parameters: @period_end DATE
What it does (From evidence):
  1. Selects invoices with status = 'PAID' for the period
  2. Applies tier thresholds from rate_card (5,000 units → tier 2)
  3. Subtracts credit notes where doc_type = 'CN'
  4. Writes one row per customer per period
Edge handling seen in code: nulls in rate → default 0; no error handling on missing calendar rows
Dynamic SQL / external references: none
Activity: Active — 92 executions since server start 2026-09-30, last 2026-10-17 (EV-006)
Purpose: see PUR-007 (Inferred)
Open questions: Q-012
State: Current state
```

For tables and views: columns (name, type, nullable, key), row count, keys, readers and writers, activity.
For jobs and pipelines: steps in order, what each runs, schedule, dependencies, last run, failures.
