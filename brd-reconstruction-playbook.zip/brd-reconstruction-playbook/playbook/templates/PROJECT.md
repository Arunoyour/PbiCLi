# Project

Written by /brd-setup; updated by later steps. Every command reads this first.

## Project
- Project name:
- Analyst (default confirmer): <name> · role: Analyst
- Playbook version: 1.0.0
- Started:

## Sources
- BRD template: <sources/template/file> | default template accepted by <name> on <date> | missing
- Databricks details: <sources/databricks/file> | missing
- Metadata: <sources/metadata/…> · environment: Production | <other — treated as Inferred for current state> · run date:
- Pipelines: <count> files
- Documents / team BRDs / agent memory files: <counts>

## Genie
- Status: In use (read-only) | Not in use (no access details provided) | Not in use (connection test failed: …)
- Workspace host / space ID (no secrets):
- Connection test: date, question, result, SQL check

## DevOps
- Status: Not available yet | In use (read-only)
- Organisation / project / process template:
- Mapping to this BRD (query / area path / epics / tags / field):
- Filters, comments included, anchor tickets:

## People
| Name | Role | Knows about |
|---|---|---|

## Exclusions and constraints
-

## The BRD (filled by /brd-choose)
- BRD name:
- Scope sketch:
- Touches other areas:
- Chosen on memory version:
- BRD versions: latest | approved

## Notes
-
