# Evidence register (`brd-work/memory/00-evidence-register.md`)

| ID | Path | Type | Covers | Date | Origin | State tag | Default label | Quality notes | Registered in |
|---|---|---|---|---|---|---|---|---|---|
| EV-001 | sources/metadata/sqlserver_Sales_Q4_definitions.csv | Metadata (code) | Procedure and view code, Sales DB | 2026-10-18 | Metadata script run by A. Rao, prod | Current state | From evidence | — | v0 (build) |
| EV-014 | sources/team-brds/rebate-brd-v0.3.md | Team BRD | Rebate calculation | 2025-11-02 | Delivery team | State unclear | Inferred | Refers to "Figure 3", not provided | v0 (build) |

Types: Document · Metadata · Pipeline definition · Team BRD · Agent memory · Image description · Template · Databricks details · DevOps snapshot · Other
State tags: Current state · Future state · State unclear
Default labels: From evidence (documents, metadata, pipelines) · Inferred (team BRDs, agent memory)
