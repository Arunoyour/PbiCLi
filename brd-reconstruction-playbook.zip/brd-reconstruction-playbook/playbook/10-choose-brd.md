# Choose the BRD — `/brd-choose`

**Closes with:** APPROVED · **Needs:** memory v1.0 or later · **Writes:** `PROJECT.md` (BRD name, scope sketch, memory version), `STATUS.md` (phase rows) · **Review page:** `reviews/choose-brd-r<N>.html`

## One BRD per workspace
If a BRD has already been chosen in this workspace, say so and stop. A different BRD needs a new workspace.

## Work
1. Ask: "Do you want me to propose candidate BRDs from the memory, or will you give a short summary of the BRD you want?"
2. **If the agent proposes:** from `50-relationships.md` and `80-summaries.md`, suggest 2–6 candidate BRDs. For each: name, what it would cover (flows, processes, main objects), its boundaries, how it connects to the other candidates, how well the memory covers it (strong / partial / thin), and the main unknowns.
3. **If the user summarises:** take the summary, map it to the memory (which flows, objects, purposes fit), and show what the memory knows and what is missing.
4. Agree on: BRD name, a short scope sketch (final scope is phase 2), and where it touches other areas (stored for later stages).
5. Record the chosen BRD in `PROJECT.md` with the memory version it was chosen on, and create the phase rows in `STATUS.md`.

## Review page
Candidates (or the mapped summary), the recommended choice with reasons, coverage and unknowns, connections to other areas. Then `review-loop.md`. Closes with **APPROVED**.
