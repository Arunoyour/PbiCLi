# Phase 1 — Summary — `/brd-p1-summary`

**Follow:** `P0-phase-rules.md` · **Closes with:** APPROVED · **Output:** `brd/P1-summary.md`

## Purpose
Pull together what the memory knows about this BRD's area and describe it plainly, so everyone agrees what the BRD is about before going deeper.

## Produce
1. **What this area is:** a short narrative of what it does for the business, in plain English.
2. **Who uses it:** users, teams, downstream consumers (with sources).
3. **Main data and flows:** the key entities and the main flows as a ```flow block, with the jobs and procedures behind them.
4. **Key facts:** volumes, frequency, systems involved, as a ```figures block where the memory has numbers.
5. **What the memory knows well and where it is thin:** coverage per part of the area.
6. **Initial questions** about the area's purpose and users (`### Q-…`).

## Review page
The summary, with labels on every statement; coverage; questions.
