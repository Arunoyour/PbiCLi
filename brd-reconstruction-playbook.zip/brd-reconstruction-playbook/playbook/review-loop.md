# Review loop — every step

Every step ends with an HTML review page, feedback from the person, redrafts, and a closing decision typed in chat.

## 1. Closing words

| Word | Allowed at | Meaning |
|---|---|---|
| `FEEDBACK: …` | every step | Change something; the agent redrafts this step as the next round |
| `APPROVED` | setup, choose BRD, phases 1–8 | The step is done; record it and stop |
| `PROCEED` | memory steps M1–M4 and memory updates | Move on **without** formal approval; record "reviewed by <name>, proceeded without approval" |
| `HALT` | every step | Stop now; resume later from the same point |

- Only a chat message from the person closes a step. Clicks in the page ("Agree") are feedback, not approval.
- `APPROVED` typed at a memory step is treated as `PROCEED` (memory is never formally approved). `PROCEED` typed at a BRD phase is refused: say that phase needs APPROVED.
- **Loop exit for BRD phases:** before accepting APPROVED, the agent states either "I have no further questions for this phase" or lists what is still open. If items are open, it asks: "Approve anyway, leaving these open?" and records the answer. They then appear in phase 7.

## 2. Writing the review page

1. Round number: from `STATUS.md` for this step (first run = round 1).
2. Write `brd-work/reviews/<step>-r<N>.md` from `templates/review-page-template.md`. Front matter: `kind: review`, title, subtitle, project, stage, brd_name (once chosen), round, `memory_version` (the version this step was built on), `memory_notice` (only if `MANIFEST.md` now shows a newer version), status, date, platform, genie, devops, `playbook_version: 1.0.0`, `feedback_file: feedback-<step>-r<N>.json`, `feedback_folder: brd-work/feedback/`.
3. Plain English for someone who has not read the sources. Every statement carries its label, its state tag where relevant, and its source.
4. Everything needing an answer is a `###` heading starting with an id (`Q-`, `CLM-`, `PUR-`, `STU-`, `FS-`, `OBJ-`, `GAP-`, `GQ-`, `WI-`, `ITEM-`), so the page gives it an answer box.
5. Copy `playbook/templates/viewer.html` to `brd-work/reviews/<step>-r<N>.html` and replace everything between the marker comments `BLUEPRINT-MARKDOWN-START` and `BLUEPRINT-MARKDOWN-END` with the page Markdown (identical text). Don't change the CSS or JavaScript. Large pages: several edits, each inserted just before the END marker. Never write `</script` inside the Markdown.
6. Never overwrite an earlier round.
7. Update `STATUS.md`: PRESENTED, round, page path, memory version used.
8. Tell the person in chat, then stop:

```
<STEP>: round N ready for your review.
Open: brd-work/reviews/<file>.html
Built on: Memory vX.Y   <+ "Newer memory vX.Z exists" if so>
Summary: <3-5 lines>
Needs you: <n questions, n items to confirm>
Genie: <in use: asked N · SQL-verified V · to confirm C> | not in use
DevOps: <in use> | not available yet

Reply: FEEDBACK: … | <APPROVED or PROCEED> | HALT
(Or answer in the page, click Export review, save the file in brd-work/feedback/, then type FEEDBACK FILE.)
```

## 3. Taking feedback

Sources: the exported file (`brd-work/feedback/feedback-<step>-r<N>.json`, with `sections` and `items`), chat, or both. If they contradict each other, ask which stands.

For each piece of feedback:
1. Apply it to the step's working files.
2. An answer that settles something becomes **Confirmed**: record the person's name and role (`labels-and-versions.md` §2) and date. If the person says the answer came from someone else ("confirmed by J. Smith, Finance SME"), record that person.
3. "Correct it" on an item: record the correction as Confirmed, and update every place that used the old statement.
4. An answer that conflicts with evidence: keep both, label **Conflicting**, and ask once more which is right.
5. Unclear answer: ask a short follow-up.
6. Write the next round with a "What changed since round N" section, and stop.

If the feedback file is missing or unreadable, say so and ask the person to save it again or paste the feedback.

## 4. On APPROVED / PROCEED

- `STATUS.md`: state APPROVED or PROCEEDED, round, name, date, memory version used.
- Latest page: front matter `status:` becomes "Approved by <name> on <date>" or "Reviewed by <name>, proceeded without approval on <date>", and its HTML is rebuilt.
- For BRD phases: copy the final content to `brd-work/brd/P<n>-<name>.md` with front matter `memory_version`, `round`, `approved_by`, `date`.
- Stop. Do not start the next step.

## 5. Re-running a step

- Re-running a step that was already closed creates the next round and needs closing again.
- Later steps that used it are marked `EARLIER-STEP-CHANGED` in `STATUS.md` and get a note on their next page. They are not changed automatically; the person decides what to revisit.

## 6. Resuming in a new chat

Everything lives in files. `/brd-status` reads `STATUS.md`, `MANIFEST.md` and `_progress.md` and shows the next command. Long steps (M2 especially) keep a batch checklist in `brd-work/memory/_progress.md`, so a step can continue where it stopped.
