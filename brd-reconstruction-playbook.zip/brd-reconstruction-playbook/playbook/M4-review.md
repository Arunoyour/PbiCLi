# M4 — Memory review — `/brd-memory-review`

**Closes with:** FEEDBACK or PROCEED (advisory, never formally approved) · **Needs:** M3 proceeded · **Writes:** memory updates from feedback, `MANIFEST.md` → **v1.0**, `memory/changes/v1.0.md` · **Review page:** `reviews/m4-review-r<N>.html`

## Purpose
Give people a chance to see and correct the agent's whole picture of the system before any BRD is built. Nobody may know the full flow, so this is a review, not a sign-off.

## Work
1. Re-read the memory files and check consistency: every purpose cites evidence, every claim has a label, every object has an activity mark, future-state items are separated, open questions are listed.
2. Rank what the agent is **least sure about** (inferred purposes behind important flows, conflicting claims, unclear state, unknown activity of important objects) and put those first.
3. Build the review page.
4. Apply feedback rounds (`review-loop.md`). Corrections from people become Confirmed with name and role.
5. On **PROCEED**: write `MANIFEST.md` `current_version: v1.0`, a History row (type: build), and `memory/changes/v1.0.md` (what the first memory contains, the counts, the files it was built from). Record "reviewed by <name>, proceeded without approval".

## Review page
- "What I think this system does": one-page narrative with the main flows
- Figures: sources, objects (active / inactive / unknown), flows, purposes (confirmed / inferred), claims (supported / conflicting), future-state items, open questions
- **Where I am least sure**: as `### PUR-n`, `### CLM-n`, `### STU-n`, `### OBJ-n` items with answer boxes
- Relationships and candidate BRD areas
- Open questions
- A clear note at the top: "This review is advisory. Reply FEEDBACK to correct, or PROCEED to continue without formal approval."
