# Phase 2 — Scope and boundaries — `/brd-p2-scope`

**Follow:** `P0-phase-rules.md` · **Closes with:** APPROVED · **Output:** `brd/P2-scope.md`

## Purpose
Agree exactly what this BRD covers and where it stops.

## Produce
1. **In scope:** processes, flows, data, reports, the technical objects behind them (by OBJ id).
2. **Out of scope:** what is deliberately excluded and why (including inactive objects, unless the user wants them documented).
3. **Inputs (upstream):** each source system or area: what data, format, frequency, owner. Missing details become questions.
4. **Outputs (downstream):** each consumer: what data, grain, freshness, interface. Missing details become questions.
5. **Boundaries with other areas:** where this BRD touches other areas or BRDs (from `50-relationships.md`), and who owns the shared data.
6. **Future-state line:** exactly one line, for example: "Future-state material relating to this area (N items, FS-002, FS-007 …) is held in the memory and excluded from this BRD." No description of the future state.
7. **Questions** on anything that decides scope (`### Q-…`).

## Review page
In / out lists, inputs and outputs tables, a ```flow or ```layers picture of the boundary, the future-state line, questions.
