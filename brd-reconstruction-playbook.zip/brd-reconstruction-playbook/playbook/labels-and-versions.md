# Labels, tags and versions

## 1. Statement labels (exactly one per statement)

| Label | Use when | Must record |
|---|---|---|
| **Confirmed** | A person confirmed it | who, role, date, where (chat / page round) |
| **From evidence** | Seen directly in a source: a document, code, a pipeline definition, metadata, or a SQL-verified Genie finding | evidence id + location (file, section, line, query) |
| **Inferred** | The agent's reading: for example the likely purpose of a procedure, or a statement from a team BRD or another agent's memory | what it is based on |
| **Conflicting** | Two or more sources disagree | every source and what each says |

Rules:
- Statements from `sources/team-brds/` and `sources/agent-memory/` always enter as **Inferred**, even if they sound certain.
- Code tells *what* the system does (From evidence). *Why* it does it is Inferred until a person confirms it.
- A label only moves up to Confirmed through a person. The agent never promotes its own inference.
- Never present an Inferred statement as fact in prose. Say "appears to", "likely", and show the label.

## 2. Who confirmed

Every Confirmed statement records the confirmer and their role:
`Confirmed by A. Rao (Client Finance SME), 2026-10-20, phase 4 round 2`

Roles: `Analyst`, `Client SME`, `Business owner`, `Technical owner`, `Other (describe)`. The analyst's own name and role come from `PROJECT.md`; if the analyst relays someone else's answer, the agent records that person. Phase 8 lists every item confirmed only by the analyst, and every Inferred item, for client validation.

## 3. State tags

| Tag | Meaning |
|---|---|
| **Current state** | How the system works today |
| **Future state** | What the client plans to build (target designs, roadmaps, "to-be", "will", "phase 2") |
| **State unclear** | The agent cannot tell |

- Metadata, code, pipeline definitions, run history and Genie findings are **Current state** by definition (they describe what is running).
- Documents can be either; tag at document, section or statement level.
- A document that describes something the code does not do is **State unclear** (it may be future state, or out of date). Ask; never decide silently.
- The BRD uses **Current state** only. Future-state items live in `memory/60-future-state.md`, each linked to the current processes or objects it would change.

## 4. Activity of technical objects

Every table, view, procedure and job in the catalog is marked:
- **Active**: evidence of use in the last 90 days (job runs, lineage events, procedure or table usage stats).
- **Inactive**: evidence that it has not run (for example a disabled job with no runs), or a person says so.
- **Unknown**: no usage evidence either way (for example usage stats reset by a restart). Unknown is never treated as inactive.

Production is the reference environment. If metadata comes from another environment, say so on every page that uses it and treat it as Inferred for the current state.

## 5. Memory versions: v<master>.<sub>

- **Master** changes only when a consolidated memory is produced. That is done by a separate consolidation agent, not by this playbook.
- **Sub** changes with every `/brd-memory-update`. All files added in one update count as **one** sub-version.
- The first memory build ends at **v1.0** when M4 is closed with PROCEED.
- Examples: v1.0 → update → v1.1 → update → v1.2 → consolidation (other agent) → v2.0 → update → v2.1.

## 6. The manifest: `brd-work/memory/MANIFEST.md`

The single source of truth for the memory version, and the contract with the consolidation agent. This playbook reads the version from here at the start of every command.

```
# Memory manifest
current_version: v1.2
master: 1
sub: 2
last_changed: 2026-10-20
changed_by: BRD Reconstruction agent | <consolidation agent name>

## History
| Version | Date | Type (build / update / consolidation) | Files | Change log | By |
|---|---|---|---|---|---|

## Processed source files
| File | Evidence id | Registered in version | Notes |
|---|---|---|---|
```

- This playbook only ever raises **sub** (and writes v1.0 at the end of M4).
- When the consolidation agent produces a new master, it writes the new `current_version` (vN.0) and a History row. This playbook accepts that and stamps new work with it. It does not repeat the consolidation.
- Files listed under "Processed source files" are not processed again. That is how the inbox works without being emptied.

## 7. Stamps and notices

- **Every phase output and review page** records the memory version it was built on.
- **The draft BRD** carries: `BRD v<n>`, the memory version, the playbook version, and a table of which memory version each phase was approved on.
- **Memory notice:** whenever `MANIFEST.md` shows a newer version than a page or BRD was built on, show it: "Built on Memory v1.2 · current memory is v1.4 (new evidence added)" or "… v2.0 (memory consolidated)". The agent changes nothing because of it. Revisiting is the user's decision.

## 8. BRD versions

- `BRD_v1` is the first draft produced by phase 8; each further redraft is v2, v3 …
- Earlier versions are never overwritten. `brd/CHANGELOG.md` records each version: date, what changed, why, memory version used.
