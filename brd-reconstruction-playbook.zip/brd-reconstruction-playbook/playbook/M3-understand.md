# M3 — Understand the business — `/brd-memory-understand`

**Closes with:** FEEDBACK or PROCEED · **Needs:** M2 proceeded · **Writes:** `memory/30-business-map.md`, `40-claims.md`, `50-relationships.md`, `60-future-state.md`, `70-open-questions.md`, `80-summaries.md` · **Review page:** `reviews/m3-understand-r<N>.html`

## Purpose
Turn the technical map and the documents into a business understanding, the way a business owner would explain the system: what each flow is for, what the business terms mean, how areas relate, and what is current versus planned.

## Work
1. **Purpose of each flow** (`30-business-map.md`): for each main data flow and important procedure, write *what it does* (From evidence, citing M2) and *why it probably exists* (**Inferred**, with the clues: names, documents, consumers, comments in code). Give each purpose an id `PUR-nnn`.
2. **Business terms** (`30-business-map.md`): glossary of terms found in documents and code, each linked to the tables/columns/procedures that implement it. Note when two sources use a term differently.
3. **Claims** (`40-claims.md`, `templates/claims-register.md`): every important statement from documents, team BRDs and agent memory files, as `CLM-nnn`, each with label, state tag, sources, and whether the code/data agrees (supports / contradicts / not checkable). Team-BRD and agent-memory claims stay **Inferred**; contradicted claims become **Conflicting**.
4. **Current vs future state** (`60-future-state.md`): move future-state material out of the current picture. For each `FS-nnn`: what is planned, source, and which current processes or objects it would change. Anything unclear → `STU-nnn` question.
5. **Relationships** (`50-relationships.md`): how areas of the system relate (shared data, flows between areas, shared keys, ownership), and candidate BRD boundaries with how they would connect. These feed `/brd-choose` and later stages.
6. **Ask for supporting documents** where evidence is thin, specifically ("Do you have anything on the month-end reconciliation flow, for example a runbook or a process chart?"). If the user adds files to `sources/inbox/` and says "added", register them (as in M1) and use them in this step.
7. **Summaries** (`80-summaries.md`), in three levels so later steps stay fast: one paragraph per object group, one page per area, one page for the whole system.
8. Open questions to `70-open-questions.md`.

## Review page
- The system in one page (from the summaries), with a ```layers or ```flow picture
- Purposes per flow, each with its label, the least certain as `### PUR-n …`
- Conflicting claims as `### CLM-n …`
- Current vs future: counts, and unclear items as `### STU-n …`
- Relationships and candidate BRD areas
- Requests for supporting documents
- Open questions
Then `review-loop.md`. Closes with **PROCEED**.
