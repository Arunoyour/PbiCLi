# Phase 8 — Draft BRD — `/brd-p8-draft`

**Follow:** `P0-phase-rules.md` · **Closes with:** APPROVED · **Output:** `brd/BRD_v<n>.md`, `brd/BRD_v<n>.html`, `brd/CHANGELOG.md`

## Purpose
Write the BRD in the client's template from the approved phases.

## Template
- Use the template in `sources/template/` exactly: its section order, headings and any required fields. Map the phase content into it.
- If the template has sections the phases do not cover, fill them from the memory where possible, labelled; otherwise mark them "To be completed" and ask.
- If the user accepted the default at setup, use `templates/default-brd-template.md`.

## Content rules
- Build only from approved phase outputs (P1–P7) and the latest answers in P6. **No new facts.**
- **Current state only.** The scope section carries the future-state line from phase 2.
- Every statement keeps its label and source; Confirmed items show who confirmed them. Use pills in the HTML: `[[Confirmed]]`, `[[From evidence]]`, `[[Inferred]]`, `[[Conflicting]]`.
- Include, where the template allows (otherwise as appendices): assumptions, risks and open questions (P7), the client validation list, and an evidence index (EV ids used).

## Versions and stamps
- First draft is `BRD_v1`; each redraft after feedback is the next version. Never overwrite.
- Front matter and cover show: `brd_version`, `memory_version` (current), `playbook_version: 1.0.0`, and a table **"Memory version per phase"** (P1 … P7 with the version each was approved on).
- If any phase was approved on an older memory version than the current one, show the memory notice on the cover. Do not change content because of it.
- `brd/CHANGELOG.md`: one row per version (date, what changed, why, memory version, round).

## Build
1. Write `BRD_v<n>.md`.
2. Copy `templates/viewer.html` to `BRD_v<n>.html` and put the identical Markdown between the marker comments, with front matter `kind: brd`.
3. The BRD HTML is the review page for this phase. Feedback creates the next version.

## Before presenting
Optionally run `/brd-check` (independent reviewer) and include its findings. Self-check: every template section present or marked; every BR and process step from P3/P4 present; no future-state description; labels on every statement; stamps correct.
