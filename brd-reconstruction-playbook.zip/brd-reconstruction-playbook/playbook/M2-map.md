# M2 — Map the technology — `/brd-memory-map`

**Closes with:** FEEDBACK or PROCEED · **Needs:** M1 proceeded · **Writes:** `memory/10-catalog/`, `memory/20-lineage.md`, `memory/_progress.md`, `genie-log.md` (if used) · **Review page:** `reviews/m2-map-r<N>.html`

## Purpose
A complete, sourced map of the technical estate: every table, view, procedure, function and job, what each reads, writes and does, how data flows, and what is actually running. Everything here is **From evidence** and **Current state** unless stated otherwise.

## Inputs, in this order
1. `sources/metadata/` results (from `tools/metadata-extraction/`): objects, columns, keys, code, dependencies, usage, jobs, runs, lineage.
2. `sources/pipelines/`: pipeline JSON (Databricks jobs, ADF pipelines): activities, sources, sinks, parameters, schedules, dependencies.
3. Genie (if in use), read-only, to fill gaps (`genie-protocol.md`).
4. Technical sections of documents (as supporting evidence only).

## Work, in batches
Work schema by schema (or pipeline by pipeline); keep a checklist in `_progress.md` and tick each batch. Never skip an object because it looks minor.

1. **Object cards** (`templates/object-card.md`), one per object, grouped in `10-catalog/<schema>.md` files:
   - name, type, columns and keys (tables/views)
   - for procedures, views, functions: what it reads, what it writes, parameters, and the **logic in plain English** (conditions, thresholds, filters, calculations, defaults, error handling). Rebuild code from the numbered chunks in the Q4 export (`chunk_no`), restoring ` \n ` as line breaks.
   - dynamic SQL, cross-database or linked-server references (upstream/downstream hints)
   - **activity**: Active / Inactive / Unknown, with the evidence (`labels-and-versions.md` §4)
   - source of every fact: evidence id + location
2. **Jobs and pipelines**: steps in order, schedule, what each step runs, dependencies between jobs, last run and failure counts.
3. **Lineage** (`20-lineage.md`): source → pipeline/job → procedure → table → view → consumer, as tables and as ```flow blocks for the main chains. Mark each link with its evidence (dependency list, code reading, lineage table, pipeline JSON). Mark links inferred from naming only as Inferred.
4. **Gaps in the technical picture**: objects referenced but not found, encrypted procedures (no code), metadata from a non-production environment, stats that reset. Record as open questions in `70-open-questions.md`.
5. **Genie (if in use)**: confirm existence, columns, row counts, key uniqueness where the metadata is missing or doubtful; SQL check on every finding.

## Review page
- Figures: objects by type; active / inactive / unknown; procedures with code read n of N; pipelines mapped
- Main data flows (```flow blocks) and a lineage table
- Jobs and their order
- The least certain parts of the map, as `### OBJ-n …` or `### ITEM-n …`
- Gaps and open questions
- Genie verification table, or "not in use"
- Batch checklist status (all batches done?)
Then `review-loop.md`. Closes with **PROCEED**.
