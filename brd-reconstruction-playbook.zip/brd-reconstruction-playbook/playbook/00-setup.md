# Setup — `/brd-setup`

**Closes with:** APPROVED · **Writes:** `brd-work/PROJECT.md`, `STATUS.md`, `memory/MANIFEST.md` (empty, v0), `.vscode/mcp.json` if Genie / DevOps are used · **Review page:** `reviews/setup-r<N>.html`

A conversation, one question at a time. Save each answer to `PROJECT.md` before the next. Use the ask-questions tool if it waits for the user; otherwise ask in chat. If `PROJECT.md` already exists (setup re-run, for example when DevOps access arrives), show the current values and change only what the user asks.

## Step 1 — Project and analyst
- Project name (for example "Rebate settlement BRD").
- The analyst's name and role (stored as the default confirmer, see `labels-and-versions.md` §2).
- Create `brd-work/` folders from `MASTER.md` §4; copy `templates/PROJECT.md`, `templates/STATUS.md`, `templates/MANIFEST.md`.

## Step 2 — Check the sources folder
List what is in each `sources/` subfolder (file names and counts). Then check:

| Check | If missing |
|---|---|
| `sources/template/` holds the client's BRD template | Ask for it. If none exists, offer `playbook/templates/default-brd-template.md` and record the user's choice |
| `sources/databricks/` holds Databricks details (workspace, catalogs/schemas in scope, environment) | Ask for them, in a text or JSON file there |
| `sources/metadata/` holds the metadata extraction results (CSV) and run notes | Point to `tools/metadata-extraction/README.md`; the user can add them later through the inbox |
| Environment of the metadata | Ask; production is the reference. If not production, record it |
| Anything not in Markdown / CSV / JSON | List it and ask the user to provide a Markdown version |

Do not read the content in depth yet (that is M1). Report what is there and what is missing.

## Step 3 — Genie
Ask: "Is Databricks Genie available for this work?" If the access details are in `sources/databricks/`, read the **non-secret** parts (workspace host, Genie space ID, metadata tables).

**If yes:**
1. Fill `brd-work/genie-config.md` from `templates/genie-config.md`.
2. Write `.vscode/mcp.json` from `.vscode/mcp.genie.example.json` with host and space ID. The token stays `${input:dbx_token}`.
3. Tell the user: **never paste the token in chat**. Start the server (Command Palette → "MCP: List Servers" → `genie` → Start); VS Code asks for the token in its own password box. The token must belong to a read-only identity (checklist in `genie-config.md`).
4. Test with one harmless read-only question; apply the SQL check (`genie-protocol.md`).
5. Record `Genie: In use (read-only)` with test date and result.

**If no, or the test fails:** record `Genie: Not in use (no access details provided)` or `Not in use (connection test failed: <reason>)`. Every page shows this.

## Step 4 — Azure DevOps
Ask: "Is Azure DevOps access available yet?" If not, record `DevOps: Not available yet`. If yes, follow `devops-protocol.md` §2–3 (PAT, read-only, mapping details), merge the `ado` server into `.vscode/mcp.json` from `.vscode/mcp.ado.example.json`, test, and record `DevOps: In use (read-only)` with the mapping.

## Step 5 — Anything else to know
Ask once: known business owners or subject experts, known areas to exclude, deadlines. Record answers.

## Review page
Project, analyst, sources inventory (table per subfolder), BRD template status, Databricks details, metadata environment, Genie status with test result, DevOps status, missing items as `### ITEM-n …`. Then `review-loop.md`. Closes with **APPROVED**.
