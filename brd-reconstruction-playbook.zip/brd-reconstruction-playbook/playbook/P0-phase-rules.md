# Rules for every BRD phase (1–8)

1. **Gate.** The BRD has been chosen (`PROJECT.md`) and the previous phase is APPROVED in `STATUS.md`. Otherwise say what is missing and stop.
2. **Inputs.** The memory at its **current version** (read `MANIFEST.md`), the approved outputs of earlier phases (`brd-work/brd/P*.md`), and the evidence they cite. Use the summaries first and open detailed memory files only where needed.
3. **Current state only.** Use only Current state statements. Future-state material is never described in the BRD (phase 2 adds one line noting it exists). State unclear items that matter for this phase become questions.
4. **Labels everywhere.** Every statement shows its label (Confirmed / From evidence / Inferred / Conflicting) and source. Never write an Inferred statement as fact.
5. **Ask, don't guess.** Questions in rounds of at most 8, each with context, options and a suggested answer. Record each answer as Confirmed with name, role and date (`labels-and-versions.md` §2).
6. **Memory version.** Stamp the page and the phase output with the memory version used. If an earlier phase was approved on an older memory version, show that on the page ("Phase 2 was approved on Memory v1.1; this phase uses v1.3"). Change nothing because of it.
7. **Memory feedback.** If a person corrects something that is also in the memory (a purpose, a rule, a relationship), record it in the BRD phase as Confirmed, and list it on the page under "Corrections the memory should receive". The memory itself is changed only by `/brd-memory-update` or by the consolidation agent.
8. **Batches.** Long lists (rules, steps, objects) are written in batches until complete. Never cut a list short to save space.
9. **Exit.** Before accepting APPROVED, state "I have no further questions for this phase" or list what is still open (`review-loop.md` §1).
10. **Output.** On APPROVED, save the phase content to `brd-work/brd/P<n>-<name>.md` with front matter: memory_version, round, approved_by, date.
11. **Genie / DevOps.** If in use, they may be consulted in any phase for a specific doubt (read-only, logged). Phases 5B and 5C are the systematic passes.
