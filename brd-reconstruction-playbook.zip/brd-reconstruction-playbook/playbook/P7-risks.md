# Phase 7 — Assumptions, risks and open questions — `/brd-p7-risks`

**Follow:** `P0-phase-rules.md` · **Closes with:** APPROVED · **Output:** `brd/P7-risks.md`

## Purpose
List, from the business owner's point of view, everything the BRD rests on that is not confirmed, and what could go wrong because of it.

## Produce
1. **Assumptions (`ASM-nn`):** every Inferred statement the BRD still relies on, written as an assumption: what we assume, why we believe it (evidence), what happens if it is wrong, who can confirm.
2. **Risks (`R-nn`):** business, data and process risks visible in the evidence (for example a rule with no control, an inactive object that may still be needed, a manual step, a single point of knowledge), with impact, likelihood, owner and suggested mitigation.
3. **Open questions:** everything left open in phase 6, with owner and needed-by date.
4. **Client validation list:** every statement confirmed only by the analyst, and every important Inferred statement, grouped by who on the client side should confirm it.
5. **Memory notes:** "Corrections the memory should receive" collected from all phases, so the analyst can feed them back through `/brd-memory-update`.

## Review page
Assumptions, risks, open questions, client validation list, memory notes; items as `### ASM-…`, `### R-…`, `### Q-…`.
