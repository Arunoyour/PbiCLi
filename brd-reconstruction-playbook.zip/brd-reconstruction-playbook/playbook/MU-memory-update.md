# Memory update — `/brd-memory-update`

**Closes with:** FEEDBACK or PROCEED · **Needs:** memory v1.0 or later · **Writes:** memory files, `MANIFEST.md` → next **sub-version**, `memory/changes/v<x.y>.md` · **Review page:** `reviews/memory-update-v<x.y>-r<N>.html`

## Purpose
Add new evidence at any time without rebuilding the memory. One update = **one sub-version**, however many files it adds.

## Work
1. **Find new files**: every file anywhere in `sources/` (normally `sources/inbox/`) that is not in `MANIFEST.md` → "Processed source files". If there are none, say so and stop.
2. If a new file says it replaces an older one (or looks like a newer version of one), note it and ask if unsure. The older file stays registered; its statements are marked superseded where the new file changes them.
3. **Register** each new file in the evidence register (as in M1: type, date, state tag, default label, quality notes).
4. **Extract and compare** with the memory, sorting every finding into:
   - **New:** something the memory did not have
   - **Changes:** updates an existing statement (old and new shown)
   - **Contradicts:** disagrees with an existing statement → Conflicting, with a question
   - **Confirms:** supports an existing statement (add the source; an Inferred statement stays Inferred unless a person confirms)
   New metadata or pipeline files go through the M2 method for the affected objects; future-state material goes to `60-future-state.md`.
5. **Impact on the BRD**: list which BRD phases (if any have been approved) used the changed or contradicted statements. **Do not change any BRD content.** The pages will show the memory notice; the user decides.
6. **Version**: new sub-version (e.g. v1.2 → v1.3). Write `memory/changes/v1.3.md` (files, new / changed / contradicted / confirmed, BRD phases affected), a History row in `MANIFEST.md`, and add the files to "Processed source files".
7. If `MANIFEST.md` already shows a newer master written by the consolidation agent (e.g. v2.0), build on that: the next update becomes v2.1.

## Review page
- Version change (from → to) and the files in this update
- New / changes / contradicts / confirms, as tables; contradictions as `### CLM-n …` questions
- BRD phases affected (information only)
- Future-state items added
Then `review-loop.md`. Closes with **PROCEED**. The version number is written when the step closes.
