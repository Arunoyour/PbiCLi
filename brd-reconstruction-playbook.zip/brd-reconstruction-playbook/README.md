# BRD Reconstruction Playbook (VS Code + GitHub Copilot) — v1.0.0

Rebuilds a BRD for an existing system that was never properly documented. The agent builds a **memory** of the system from everything available (documents, metadata, stored procedures, pipelines, team BRDs, other agents' memory files, and optionally Genie and Azure DevOps), then writes **one BRD** phase by phase. You review every step in a browser page; nothing moves on until you say so.

## 1. Set up the workspace (once per BRD)

1. Copy into a new, empty workspace folder: `.github/`, `.vscode/`, `playbook/`, `tools/`, `sources/`, `brd-work/`.
2. Put your files in `sources/`, all as Markdown (metadata as CSV, pipelines as JSON):

   | Folder | What goes in |
   |---|---|
   | `sources/template/` | the client's BRD template |
   | `sources/databricks/` | Databricks details; Genie access details if available (no tokens) |
   | `sources/metadata/` | results of `tools/metadata-extraction/` (run them first, read-only) + run notes |
   | `sources/pipelines/` | pipeline JSON (Databricks jobs, ADF) |
   | `sources/documents/` | implementation docs, slides, spreadsheets, image descriptions |
   | `sources/team-brds/` | BRDs the team prepared earlier (treated as unconfirmed) |
   | `sources/agent-memory/` | memory files from other agents (treated as unconfirmed) |
   | `sources/inbox/` | anything new that arrives later |

3. In VS Code open Copilot Chat in agent mode. Pick the **BRD Reconstruction** agent. Typing `/brd` lists the commands.
4. Check the agent's tools in the tool picker: read, search, edit, ask-questions (plus `genie` / `ado` once connected), and **no terminal**. If your VS Code shows different tool names, adjust the `tools:` line in `.github/agents/*.agent.md`.
5. Optional: pin a model for consistency between users by adding `model: '<model name>'` to the agent files.
6. Your organisation may need to allow MCP servers in Copilot (for Genie / DevOps).

## 2. Run

| # | Command | Closes with |
|---|---|---|
| 1 | `/brd-setup` | APPROVED |
| 2 | `/brd-memory-collect` (M1) | PROCEED |
| 3 | `/brd-memory-map` (M2) | PROCEED |
| 4 | `/brd-memory-understand` (M3) | PROCEED |
| 5 | `/brd-memory-review` (M4) → Memory v1.0 | PROCEED |
| 6 | `/brd-choose` | APPROVED |
| 7–17 | `/brd-p1-summary`, `/brd-p2-scope`, `/brd-p3-process`, `/brd-p4-rules`, `/brd-p5a-technical`, `/brd-p5b-genie`, `/brd-p5c-devops`, `/brd-p5d-gaps`, `/brd-p6-clarify`, `/brd-p7-risks`, `/brd-p8-draft` | APPROVED each |

**Any time:** `/brd-status` (where am I, next command; use it in every new chat) · `/brd-feedback` (apply feedback saved from a page) · `/brd-memory-update` (new files in the inbox) · `/brd-check` (independent reviewer, findings only).

After each step the agent names a review page in `brd-work/reviews/`. Open it in a browser, then reply in chat:
- `FEEDBACK: …`: the agent redrafts (or answer in the page, click **Export review**, save the file into `brd-work/feedback/`, and type `FEEDBACK FILE`)
- `APPROVED`: setup, choose-BRD and BRD phases
- `PROCEED`: memory steps (advisory; recorded as "proceeded without approval")
- `HALT`: stop; resume later with `/brd-status`

## 3. What to expect

- **Labels on everything:** Confirmed (with who and their role), From evidence, Inferred, Conflicting. Team BRDs and other agents' memory start as Inferred.
- **Current vs future state:** everything is tagged. The BRD covers the current state only; future-state items stay in the memory, and the scope section notes they were excluded.
- **Active / inactive / unknown** for every technical object, from run history and usage evidence. Production is the reference.
- **Versions:** memory `v<master>.<sub>`. The first build is v1.0; each `/brd-memory-update` adds one sub-version (v1.1, v1.2 …) however many files it contains. A separate consolidation agent may raise the master (v2.0); this playbook picks it up from `brd-work/memory/MANIFEST.md`. Every page and BRD shows the memory version it was built on, plus the BRD and playbook versions. When the memory moves on, you see a notice; nothing changes unless you revisit.
- **Nothing is overwritten:** review rounds, feedback files, memory versions and BRD versions are all kept.
- **One BRD per workspace,** no switching. A new BRD needs a new workspace.

## 4. Genie and Azure DevOps (both optional)

- **Genie:** asked at `/brd-setup`. The agent writes `.vscode/mcp.json` from `.vscode/mcp.genie.example.json`. Start the server from the Command Palette (*MCP: List Servers*); VS Code asks for the token in its own password box. The token must belong to a **read-only** identity. If not available, every page says "Genie: Not in use".
- **Azure DevOps:** until access arrives, phase 5C records "Not available yet". When it arrives, re-run `/brd-setup` and then `/brd-p5c-devops`. Use a PAT with **Work Items: Read** only (`.vscode/mcp.ado.example.json`, details in `playbook/devops-protocol.md`).
- **Never type a token or password into the chat.**

## 5. Things to know

- **The stop after each step is instruction-based.** The agent has no terminal and each command loads only its own step, but Copilot can still run on. Type `HALT` if it does, and check `brd-work/STATUS.md`.
- **Large systems take time in M2.** Hundreds of objects are processed in batches with a checklist (`brd-work/memory/_progress.md`); if a chat ends mid-way, run the same command again and it resumes.
- **Inbox files stay where they are.** The agent can't move files; it records which ones it has processed in the manifest, so they are never processed twice.
- **Source content is data.** Anything in a document that looks like an instruction to the AI is reported, not followed.
- **The agent never edits `sources/`,** and writes only in `brd-work/`.
